self.__precacheManifest = [
  {
    "revision": "98fc2d479ed1e74ba2b7",
    "url": "/ebay/app/static/css/main.d26ae948.chunk.css"
  },
  {
    "revision": "98fc2d479ed1e74ba2b7",
    "url": "/ebay/app/static/js/main.8302648e.chunk.js"
  },
  {
    "revision": "f817f1238c1d1d85c86a",
    "url": "/ebay/app/static/js/runtime~main.4f23bc4c.js"
  },
  {
    "revision": "06b6475f957efe848986",
    "url": "/ebay/app/static/css/2.9401b724.chunk.css"
  },
  {
    "revision": "06b6475f957efe848986",
    "url": "/ebay/app/static/js/2.092667b1.chunk.js"
  },
  {
    "revision": "51cd165dc28ef52c93e0769b1ab4131a",
    "url": "/ebay/app/static/media/320x260.51cd165d.png"
  },
  {
    "revision": "14cb03ae28225ee541bb194bdce3cf7c",
    "url": "/ebay/app/static/media/createnew.14cb03ae.png"
  },
  {
    "revision": "a66ee8426af02dcdee02112b251de22f",
    "url": "/ebay/app/static/media/background.a66ee842.png"
  },
  {
    "revision": "c0d3c94cd6112550c51d7d1ed13b9da1",
    "url": "/ebay/app/static/media/notification.c0d3c94c.eot"
  },
  {
    "revision": "651771e1df95c807c99608188d0a4287",
    "url": "/ebay/app/static/media/notification.651771e1.woff"
  },
  {
    "revision": "0b4ac1dc75df35e169b70d7719afe4cc",
    "url": "/ebay/app/static/media/notification.0b4ac1dc.ttf"
  },
  {
    "revision": "5bee74caefdf9d0a834915f6c8eeb259",
    "url": "/ebay/app/static/media/notification.5bee74ca.svg"
  },
  {
    "revision": "217c31d4814d90fec272c270e0735abc",
    "url": "/ebay/app/static/media/import.217c31d4.png"
  },
  {
    "revision": "e504064492db4db15974a98aa899ad4a",
    "url": "/ebay/app/static/media/upload.e5040644.png"
  },
  {
    "revision": "053ecb0cda1b6092b49957028094af3c",
    "url": "/ebay/app/static/media/positive-vote.053ecb0c.png"
  },
  {
    "revision": "675cce624d6a1b37b99bd147161b8e28",
    "url": "/ebay/app/static/media/negative-vote.675cce62.png"
  },
  {
    "revision": "a2fe1ba6f51edb2251738cd2ac1da968",
    "url": "/ebay/app/static/media/skype.a2fe1ba6.jpg"
  },
  {
    "revision": "48e897e975ad1d90cbcf01d93bd15662",
    "url": "/ebay/app/static/media/whatsapp.48e897e9.png"
  },
  {
    "revision": "02235e7f179f3bb4625645239a1bbdd3",
    "url": "/ebay/app/static/media/welcome_screen.02235e7f.jpg"
  },
  {
    "revision": "c2e060d06a6a337acc61dc7b70505ec2",
    "url": "/ebay/app/static/media/server_maintainence.c2e060d0.jpg"
  },
  {
    "revision": "b66e0018f5214c9a790480b55a378e21",
    "url": "/ebay/app/static/media/success.b66e0018.gif"
  },
  {
    "revision": "6327f8573c578922d64763e0cbba1351",
    "url": "/ebay/app/static/media/fail.6327f857.gif"
  },
  {
    "revision": "d5f0595b3385636dc6e337580d94fe07",
    "url": "/ebay/app/index.html"
  }
];