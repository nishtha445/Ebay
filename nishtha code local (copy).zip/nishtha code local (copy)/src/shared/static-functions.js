import React from "react";

export function capitalizeWord(string) {
    string = string.toLowerCase();
    return string.charAt(0).toUpperCase() + string.slice(1);
}

export function modifyOptionsData(data) {
    let options = [];
    for (let i = 0; i < Object.keys(data).length; i++) {
        let key = Object.keys(data)[i];
        options.push({
            label: data[key],
            value: key
        });
    }
    return options;
}

export function paginationShow(activePage, count, totalData, success) {
    // console.log('object',activePage * count)
    if ( !isNaN(totalData) && totalData !== 0  && success) {
        // return <span>Showing {(activePage - 1 )* count} to {activePage * count} of <b>{totalData}</b></span>
        return <span>Showing {((activePage - 1 )* count)+1} to {activePage * count > totalData ? totalData : activePage * count} of <b>{totalData}</b></span>
    } else {
        return <span>{totalData}</span>;
    }
}

export function modifyAttributes(str) {
    const strArray = str.split('_');
    let finalText = strArray[0];
    for (let i = 1; i < strArray.length; i++) {
        finalText += strArray[i].charAt(0).toUpperCase() + strArray[i].slice(1);
    }
    return finalText;
}

export function getSiteIDfromAbbr(str) {
    switch (str) {
        case 'US':
            return '0';
        case 'ENCA':
            return '2';
        case 'GB':
            return '3';
        case 'AU':
            return '15';
        case 'AT':
            return '16';
        case 'BEFR':
            return '23';
        case 'FR':
            return '71';
        case 'DE':
            return '77';
        case 'MOTORS':
            return '100';
        case 'IT':
            return '101';
        case 'BENL':
            return '123';
        case 'NL':
            return '146';
        case 'ES':
            return '186';
        case 'CH':
            return '193';
        case 'HK':
            return '201';
        case 'IN':
            return '203';
        case 'IE':
            return '205';
        case 'MY':
            return '207';
        case 'CAFR':
            return '210';
        case 'PH':
            return '211';
        case 'PL':
            return '212';
        case 'SG':
            return '216';
        default:
            return '0';
    }
}
