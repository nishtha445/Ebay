// import createHashHistory from 'history/createBrowserHistory';
import { createBrowserHistory } from 'history'
export default createBrowserHistory();
// export default createHashHistory();
