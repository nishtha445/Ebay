import React, {Component} from 'react';

import {
    Page,
    Card,
    Select,
    Label,
    Button,
    TextField,
    Icon,
    Layout, Banner,FormLayout,Stack,Heading,DisplayText
} from '@shopify/polaris';

import {notify} from '../../services/notify';
import {requests} from '../../services/request';



import {isUndefined} from 'util';
import {modifyAttributes} from "../static-functions";

export class CustomItemId extends Component {

    separatorOptions = [
        {
            label: 'Underscore (_)',
            value: '_'
        },
        {
            label: 'Hyphen (-)',
            value: '-'
        }
    ];
    attributeOptions = [];

    constructor(props) {
        super(props);
        this.state = {
            default_item_id: {
                separator: '_',
                attributes: [
                    {
                        attribute: '',
                        parent_attribute: '',
                        static_text: 'shopify'
                    },
                    {
                        attribute: 'targetCountry',
                        parent_attribute: 'marketplace_attribute',
                        static_text: ''
                    },
                    {
                        attribute: 'source_product_id',
                        parent_attribute: 'details',
                        static_text: ''
                    },
                    {
                        attribute: 'source_variant_id',
                        parent_attribute: 'variants',
                        static_text: ''
                    }
                ]
            },
            item_id_example: 'shopify_US_9330430195923_12800472882413',
            custom_item_id: {
                separator: '_',
                attributes: []
            },
            attributes: [],
            current_item_id: {
                separator: '_',
                attributes: []
            }
        };
        this.getAttributesForId();
        this.getCurrentlyUsedFormat();
    }

    getAttributesForId() {
        requests.getRequest('frontend/app/getAttributesForItemId').then(data => {
            if (data.success) {
                this.state.attributes = data.data;
                this.prepareAttributeOptions();
                this.updateState();
            } else {
                notify.error(data.message);
            }
        });
    }  //done copy1

    getCurrentlyUsedFormat() {
        this.state.custom_item_id = {
            separator: '_',
            attributes: [
                {
                    attribute: '',
                    parent_attribute: '',
                    static_text: ''
                }
            ]
        };
        requests.getRequest('frontend/app/getCurrentItemIdFormat').then(data => {
            if (data.success) {
                this.state.current_item_id = data.data;
                this.updateState();
            } else {
                // notify.error(data.message);
            }
        });
    }

    prepareAttributeOptions() {
        this.attributeOptions = [];
        for (let i = 0; i < this.state.attributes.length; i++) {
            this.attributeOptions.push({
                label: modifyAttributes(this.state.attributes[i].attribute),
                value: this.state.attributes[i].attribute
            });
        }
        this.updateState();
    }
    defaultItemId() {
        let attribute = this.state.custom_item_id.attributes[0]['attribute'];
        if (attribute !== "" && attribute !== undefined && attribute !== null) {
            return (<Banner status="info">
                <Stack spacing={"none"}>
                    {
                        this.state.custom_item_id.attributes.length > 0 &&


                        this.state.custom_item_id.attributes.map((attribute) => {
                            if (attribute.static_text !== '') {
                                return (
                                    <Stack.Item
                                        key={this.state.custom_item_id.attributes.indexOf(attribute)}>
                                        {attribute.static_text}
                                        {
                                            this.state.custom_item_id.attributes.indexOf(attribute) < (this.state.custom_item_id.attributes.length - 1) &&
                                            <React.Fragment>{this.state.custom_item_id.separator}</React.Fragment>
                                        }
                                    </Stack.Item>
                                );
                            } else if (attribute.attribute !== '') {
                                return (
                                    <Stack.Item
                                        key={this.state.custom_item_id.attributes.indexOf(attribute)}>
                                        {'{{ ' + modifyAttributes(attribute.attribute) + ' }}'}
                                        {
                                            this.state.custom_item_id.attributes.indexOf(attribute) < (this.state.custom_item_id.attributes.length - 1) &&
                                            <React.Fragment>{this.state.custom_item_id.separator}</React.Fragment>
                                        }
                                    </Stack.Item>
                                );
                            }
                        })


                    }
                    {
                        this.state.custom_item_id.attributes.length === 0 &&
                        <Stack.Item>
                            No Format Defined Yet
                        </Stack.Item>
                    }
                </Stack>
            </Banner>)
        }
    }
    renderDefaultIdFormat() {
        return (
            <Banner status="info" title="Format">
                <Stack spacing={"none"}>
                    {
                        this.state.default_item_id.attributes.map((attribute) => {
                            if (attribute.static_text !== '') {
                                return (
                                    <Stack.Item
                                        key={this.state.default_item_id.attributes.indexOf(attribute)}>
                                        {attribute.static_text}
                                        {
                                            this.state.default_item_id.attributes.indexOf(attribute) < (this.state.default_item_id.attributes.length - 1) &&
                                            <React.Fragment>{this.state.default_item_id.separator}</React.Fragment>
                                        }
                                    </Stack.Item>
                                );
                            } else if (attribute.attribute !== '') {
                                return (
                                    <Stack.Item
                                        key={this.state.default_item_id.attributes.indexOf(attribute)}>
                                        {'{{ ' + modifyAttributes(attribute.attribute) + ' }}'}
                                        {
                                            this.state.default_item_id.attributes.indexOf(attribute) < (this.state.default_item_id.attributes.length - 1) &&
                                            <React.Fragment>{this.state.default_item_id.separator}</React.Fragment>
                                        }
                                    </Stack.Item>
                                );
                            }
                        })
                    }
                </Stack>
                <br/>
                <Heading element={"h6"}>For Example:</Heading>
                <p style={{marginTop:'1rem'}}>
                    {this.state.item_id_example}
                </p>
            </Banner>
        );
    }

    renderCustomIdFormat() {

        return (
            <FormLayout>

                <React.Fragment>
                    <Banner status="info">
                        <Label><b>Currently used format</b></Label>
                        {
                            this.state.current_item_id.attributes.length > 0 &&
                            <Label>
                                {
                                    this.state.current_item_id.attributes.map((attribute) => {
                                        if (attribute.static_text !== '') {
                                            return (
                                                <div className="d-inline-block"
                                                     key={this.state.current_item_id.attributes.indexOf(attribute)}>
                                                    {attribute.static_text}
                                                    {
                                                        this.state.current_item_id.attributes.indexOf(attribute) < (this.state.current_item_id.attributes.length - 1) &&
                                                        <React.Fragment>{this.state.current_item_id.separator}</React.Fragment>
                                                    }
                                                </div>
                                            );
                                        } else if (attribute.attribute !== '') {
                                            return (
                                                <div className="d-inline-block"
                                                     key={this.state.current_item_id.attributes.indexOf(attribute)}>
                                                    {'{{ ' + modifyAttributes(attribute.attribute) + ' }}'}
                                                    {
                                                        this.state.current_item_id.attributes.indexOf(attribute) < (this.state.current_item_id.attributes.length - 1) &&
                                                        <React.Fragment>{this.state.current_item_id.separator}</React.Fragment>
                                                    }
                                                </div>
                                            );
                                        }
                                    })
                                }
                            </Label>
                        }
                        {
                            this.state.current_item_id.attributes.length === 0 &&
                            <Label>
                                Currently using default format
                            </Label>
                        }
                    </Banner>
                </React.Fragment>


                <React.Fragment>
                    {this.defaultItemId()}
                </React.Fragment>


                <React.Fragment>
                    <Select
                        helpText="The separator that you want to use (_,-)"
                        label="Separator"
                        options={this.separatorOptions}
                        onChange={this.handleSeparatorChange.bind(this)}
                        value={this.state.custom_item_id.separator}
                    />
                </React.Fragment>

                <Heading>
                    Prepare Custom ID
                </Heading>
                {
                    this.state.custom_item_id.attributes.map((attribute) => {
                        return (
                            <React.Fragment key={attribute.attribute}>
                                <Stack distribution={"fillEvenly"} spacing={"loose"}>
                                    <Stack.Item>
                                        <Select
                                            helpText="Choose Attribute"
                                            placeholder="Choose Attribute"
                                            disabled={attribute.static_text !== ''}
                                            options={this.attributeOptions}
                                            onChange={this.handleAttributeChange.bind(this, this.state.custom_item_id.attributes.indexOf(attribute), 'attribute')}
                                            value={attribute.attribute}
                                        />
                                    </Stack.Item>
                                    <Stack.Item alignment={"center"}>
                                        <div style={{textAlign:'center'}}>Or</div>
                                    </Stack.Item>
                                    <Stack.Item >
                                        <TextField
                                            helpText="Static Text"
                                            placeholder="Static Text"
                                            value={attribute.static_text}
                                            onChange={this.handleAttributeChange.bind(this, this.state.custom_item_id.attributes.indexOf(attribute), 'static_text')}
                                        />
                                    </Stack.Item>
                                    <Stack.Item >
                                        {
                                            this.state.custom_item_id.attributes.indexOf(attribute) === (this.state.custom_item_id.attributes.length - 1) &&
                                            <Button
                                                disabled={this.state.custom_item_id.attributes.length > 10}
                                                onClick={() => {
                                                    this.addAttributeField();
                                                }}
                                                primary><Icon source="add" color="white"/></Button>
                                        }
                                    </Stack.Item>
                                </Stack>
                            </React.Fragment>
                        );
                    })
                }
                <React.Fragment>
                    <Button

                        onClick={() => {
                            this.resetCustomItemId();
                        }}>Reset ID</Button>
                </React.Fragment>
            </FormLayout>
        );
    }



    resetCustomItemId() {
        this.state.custom_item_id.attributes = [
            {
                attribute: '',
                parent_attribute: '',
                static_text: ''
            }
        ];
        this.state.custom_item_id.separator = '_';
        this.updateState();
    }

    //done copy4


    saveCustomItemId() {
        let customItemId = this.validateItemId();
        if (customItemId.attributes.length > 0) {
            requests.postRequest('frontend/app/setCurrentItemIdFormat', {item_id_format: customItemId})
                .then(data => {
                    if (data.success) {
                        notify.success(data.message);
                        this.props.checkCustomId();
                    } else {
                        notify.error(data.message);
                        this.props.buttonLoadertoggle();
                    }
                });
        } else {
            notify.error('Kindly add atleast one attribute');
            this.props.buttonLoadertoggle();
        }

    }

    skipCustomItemId() {
        this.props.checkCustomId();
    }

    validateItemId() {
        let customCreatedAttribute = {
            separator: this.state.custom_item_id.separator,
            attributes: this.state.custom_item_id.attributes.slice(0)
        };
        for (let i = 0; i < customCreatedAttribute.attributes.length; i++) {
            if (customCreatedAttribute.attributes[i].attribute === '' &&
                customCreatedAttribute.attributes[i].static_text === '') {
                customCreatedAttribute.attributes.splice(i, 1);
            }
        }
        return customCreatedAttribute;
    }

    handleSeparatorChange(separator) {
        this.state.custom_item_id.separator = separator;
        this.updateState();
    }

    handleAttributeChange(index, key, value) {
        this.state.custom_item_id.attributes[index][key] = value;
        if (key === 'static_text' &&
            value !== '') {
            this.state.custom_item_id.attributes[index]['attribute'] = '';
            this.state.custom_item_id.attributes[index]['parent_attribute'] = '';
        } else if (key === 'attribute') {
            this.state.custom_item_id.attributes[index]['parent_attribute'] = this.getParentAttribute(value);
            this.state.custom_item_id.attributes[index]['static_text'] = '';
        }
        this.updateState();
    }

    addAttributeField() {
        this.state.custom_item_id.attributes.push({
            attribute: '',
            parent_attribute: '',
            static_text: ''
        });
        this.updateState();
    }

    getParentAttribute(attribute) {
        for (let i = 0; i < this.state.attributes.length; i++) {
            if (this.state.attributes[i].attribute === attribute) {
                return this.state.attributes[i].parent_attribute;
            }
        }
    }

    render() {
        return (
            <Stack vertical={true}>
                <Stack.Item>
                    <Card title="Default Item ID">
                        <Card.Section>
                            {
                                this.renderDefaultIdFormat()
                            }
                        </Card.Section>
                    </Card>
                </Stack.Item >
                <Stack.Item>

                    <Card title="Create Custom Item ID">
                        <Card.Section>
                            {
                                this.renderCustomIdFormat()
                            }
                        </Card.Section>
                    </Card>
                </Stack.Item>
            </Stack>

        );
    }

    updateState() {
        const state = this.state;
        this.setState(state);
    }

    redirect(url) {
        this.props.history.push(url);
    }
}
export default CustomItemId
