import React, {Component} from 'react';
import { Toolbar, Data, Filters } from "react-data-grid-addons";
import { Thumbnail ,Icon,Badge,SkeletonBodyText,SkeletonThumbnail,EmptyState,Checkbox} from '@shopify/polaris';
import Filter from "./filter";
import NumericFilter from "./filters/numericFilter";
import {isUndefined} from "util";
import {ImageMajorMonotone,DeleteMajorMonotone} from '@shopify/polaris-icons';
import CheckboxEditor2 from "./checkbox/CheckboxEditor";
var imageExists = require('image-exists');
var src = <Icon source={ImageMajorMonotone} /> ;
const {SingleSelectFilter} = Filters;


export function createDemoRows(data,loading="false",whichOne) {
    if(loading === true) {
        var n = 10
        var data = new Array();
        for (var i = 0; i < n; i++)
          data.push(new Object());

        return data.map(row => {
            let data = {};
            data['main_image'] = <SkeletonThumbnail size="medium"/>;
            data['id'] = <SkeletonBodyText lines={2}/>;
            data['fulfillment'] = <SkeletonBodyText lines={2}/>
            data['customer_name'] = <SkeletonBodyText lines={2}/>
            data['category'] = <SkeletonBodyText lines={2}/>
            data['source_marketplace'] = <SkeletonBodyText lines={2}/>
            data['quantity'] = <SkeletonBodyText lines={2}/>
            data['product_type'] = <SkeletonBodyText lines={2}/>
            data['price'] = <SkeletonBodyText lines={2}/>
            data['source_variant_id'] = <SkeletonBodyText lines={2}/>
            data['parent_id'] = <SkeletonBodyText lines={2}/>
            data['title'] = <SkeletonBodyText lines={2}/>
            data['ebay_item_id'] = <SkeletonBodyText lines={2}/>
            data['ebay_profile'] = <SkeletonBodyText lines={2}/>
            data['source_order_id'] =<SkeletonBodyText lines={2}/>
            data['shopify_order_name']=<SkeletonBodyText lines={2}/>
            data['importedAt']=<SkeletonBodyText lines={2}/>
            data['ebay_status']=<SkeletonBodyText lines={2}/>
            data['name'] =<SkeletonBodyText lines={2}/>
            data['inventory']=<SkeletonBodyText lines={2}/>
            data['query']=<SkeletonBodyText lines={2}/>
            data['productCount']=<SkeletonBodyText lines={2}/>
            data['action']=<SkeletonThumbnail size="small"/>
            data['check']=<SkeletonThumbnail size="small"/>

            return data;
        });
    }
    else {
       /* if (whichOne == "Products_grid") {
            let source_product_id = [];
            return data.map(row => {
                let data = {};
                if (row["product_data"]['details']['additional_images'] && row["product_data"]['variants']['additional_images'][0] !== '') {
                    data['image'] =imageExists(row["product_data"]['variants']['additional_images'][0], function(exists) {
                        if (exists) {
                            data['image'] =<Thumbnail size="large" alt="image"
                                              source={row["product_data"]['variants']['additional_images'][0]}/>;
                        }
                        else {
                            data['image'] =src
                        }
                    });
                } else {
                    imageExists(row["product_data"]['details']['image_main'], function(exists) {
                        if (exists) {
                            data['image'] = data['image'] = <Thumbnail size="extralarge" alt="Image"
                                              source={row["product_data"]['details']['image_main']}/>;
                        } else {
                            return data['image']=src
                        }
                    });
                }
               // data["check"]=<Checkbox checked={(Object.keys(checkbox).indexOf(row["product_data"]['variants']['source_variant_id']) > -1)?true:false}
                data["check"]=<Checkbox checked={(checkbox.hasOwnProperty(row["product_data"]['variants']['source_variant_id']))?true:false}
                                        label={row["product_data"]['variants']['source_variant_id']}
                                        id={row["product_data"]['variants']['source_variant_id']}
                                        onChange={handleChangeCheck}/>;
                data['id'] = row["product_data"]['_id'];
                data['vendor'] = row["product_data"]['details']['tags'];
                data['type'] = row["product_data"]['details']['type'];
                data['category'] = row["product_data"]['details']['primary_category_id'];
                data['source_marketplace'] = row["product_data"]['source_marketplace'];
                data['quantity'] = row["product_data"]["variants"]['quantity'];
                data['sku'] = row["product_data"]['variants']['sku'];
                data['price'] = row["product_data"]['variants']['price'];
                data['source_variant_id'] = row["product_data"]['variants']['source_variant_id'];
                data['parent_id'] = row["product_data"]['details']['source_product_id'];
               // data['variants'] = row["product_data"]['details']['source_product_id'];

                if (source_product_id.indexOf(row["product_data"]['details']['source_product_id']) === -1) {
                    data['title'] = row["product_data"]['details']['title'];
                    source_product_id.push(row["product_data"]['details']['source_product_id']);
                } else {
                    data['title'] = <Icon source="horizontalDots"/>
                }
                data['google_status'] = conditioncheck(row);

                return data;
            });
        }*/
        if(whichOne=="Profile_grid"){
            let source_product_id = [];
            return data.map(row => {
                let data = {};
                data['name'] =row["name"];
                data['targetCategory']=(row["targetCategory"] !== ""?row["targetCategory"]:<div title={" "}><img title={""} src={require("../../assets/img/dots.png")}/></div>)
                data['query']=row["query"];
                data['productCount']=row["product_count"]+" products in profile ";
                data['action']=<div title={"Delete"}><Icon source={DeleteMajorMonotone} /> </div>

                return data;
            })
        }
        else if(whichOne=="Profile_ProductGrid"){
            let source_product_id = [];
            return data.map(row => {
                let data = {};
                if (row['details']['additional_images'] && row['variants']['additional_images'][0] !== '') {
                    data['image'] =imageExists(row['variants']['additional_images'][0], function(exists) {
                        if (exists) {
                            data['image'] =<Thumbnail size="large" alt="image"
                                                      source={row['variants']['additional_images'][0]}/>;
                        }
                        else {
                            data['image'] =src
                        }
                    });
                } else {
                    imageExists(row['details']['image_main'], function(exists) {
                        if (exists) {
                            data['image'] = data['image'] =<Thumbnail size="extralarge" alt="Image"
                                                                      source={row['details']['image_main']}/>;
                        } else {
                            return data['image']=src
                        }
                    });
                }
                if (source_product_id.indexOf(row['details']['source_product_id']) === -1) {
                    data['title'] = row['details']['title'];
                    source_product_id.push(row['details']['source_product_id']);
                } else {
                    data['title'] = <div title={row['details']['title']}><img title={row['details']['title']} src={require("../../assets/img/dots.png")}/></div>
                }
                data['quantity'] = row["variants"]['quantity'];
                data['sku'] = row['variants']['sku'];
                data['price'] = row['variants']['price'];

                return data;
            })
        }
    }

}

let handleChangeCheck = (value,e) => {
    console.log("value",value);
    console.log("e",e);

};

export function getStatus(status){
    switch (status) {
        case 'pendingShipment': return <Badge status={"info"} progress="partiallyComplete">Pending</Badge>;break;
        case 'canceled': return <Badge status={"warning"} progress="complete">Canceled</Badge>;break;
        case 'fulfilled': return <Badge status={"success"} progress="complete">Fulfilled</Badge>;break;
        case 'inProgress': return <Badge status={"attention"} progress="incomplete">Progress</Badge>;break;
        default: return <Badge status={"attention"} progress="partiallyComplete">{status}</Badge>
    }
};
export function conditioncheck(data)
    {

    let temparr=[];
    let final_arr=[];
    let upload=0;
    let google_status=0;
    // if( data[i]['product_data']['output']!= [] && !isUndefined(data[i]['product_data']['output'][0]['variants']) && data[i]['product_data']['output'][0]['variants']['v']['marketplace_status']!= null )
    if(!isUndefined(data['status']) &&!isUndefined(data['status'][0]) && data['status'][0]!= null  && data['status'][0].length!= 0)
    {
        upload=1;

    }
    // if(data[i]['product_data']['fromItems'].length>0 &&
    //     (data[i]['product_data']['variants']['source_variant_id'] in data[i]['product_data']['fromItems'][0]['variants']) &&
    //     ('marketplace_status' in data[i]['product_data']['fromItems'][0]['variants'][data[i]['product_data']['variants']['source_variant_id']] ) &&
    //     !isUndefined(data[i]['product_data']['fromItems'][0]['variants'][data[i]['product_data']['variants']['source_variant_id']]['marketplace_status']) &&
    //     data[i]['product_data']['fromItems'][0]['variants'][data[i]['product_data']['variants']['source_variant_id']]['marketplace_status'].length > 0 )
    // {
    //     google_status=1;
    // }
    if( !isUndefined(data['status']) &&
        !isUndefined(data['status'][0]) &&
        data['status'][0]!= null && data['status'][0]!= ["nada"] &&
        data['status'][0].length!= 0
    )
    {

        google_status=1;
    }
    temparr.push(

            <div style={{ marginTop:"5px"}}>
                { google_status ?<Badge status="success">Product Uploaded</Badge>:
                    <img title={"No Status"} src={require("../../assets/img/dots.png")}/>
                }
            </div>
    );
    if(upload && google_status){
        temparr.push(
            getGoogleStatus( data['status'][0])
        );
    }
    // else {
    //     temparr.push(
    //         <div className="row">
    //             <div className="col-12 col-md-12">
    //             <Badge status="attention">Status Unavailable</Badge>
    //             </div>
    //         </div>
    //     );
    // }
    final_arr.push(
        <React.Fragment key={'Status'+data["product_data"]['_id']}>
            {temparr}
        </React.Fragment>
    );

    return temparr;

}
export function getGoogleStatus(marketplacestatus){

    let temparr=[];
    let status={Shopping:{message:'',type:'attention'},ExpressOnline:{message:'',type:'attention'}};
    temparr.push()
    for(let i=0;i<marketplacestatus.length;i++) {
        switch (marketplacestatus[i]['label']) {
            case 'Shopping':
                status.Shopping.message=marketplacestatus[i]['message'];
                if(marketplacestatus[i]['message'] == 'approved'){
                    status.Shopping.type='success';
                }

                break;
            case 'ExpressOnline':
                status.ExpressOnline.message=marketplacestatus[i]['message'];
                if(marketplacestatus[i]['message'] == 'approved'){
                    status.ExpressOnline.type='success';
                }
                break;
        }
    }
    if(status.Shopping.message!=='' || status.ExpressOnline.message!=='') {
        temparr.push(
            <div>
                {status.Shopping.message !== '' ?
                    <div >
                        <Badge status= {status.Shopping.type}>{`Shopping ${status.Shopping.message}`}</Badge> </div>: ''}
                <br/>
                {status.ExpressOnline.message !== '' ?
                    <div>
                        <Badge status={status.ExpressOnline.type}>{`Express ${status.ExpressOnline.message}`}</Badge> </div>: ''}
            </div>
        );
    }
    else{
        temparr.push(
            <div className="row" style={{whiteSpace:'nowrap'}}>
                <div className="col-12 col-md-12">
                    <Badge status="attention">Status Unavailable</Badge>
                </div>
            </div>
        );
    }
    return temparr;

}

export const product_column = [
    {
        key: "check",
        name: <Checkbox label={"check"}/>,
        frozen: true,
        editable: false,
        width: 50,
        sortable: false,
        draggable: false,
        filterable: false,
    },
    // {
    //     key: "main_image",
    //     name: "Image",
    //     frozen: true,
    //     editable: false,
    //     width: 80,
    //     sortable: false,
    //     draggable: false,
    //     filterable: false,
    // },
    // {
    //     key: "title",
    //     frozen: false,
    //     width: 250,
    //     filterRenderer: Filter,
    //     name: "Title",
    // },
    // {
    //     key: "ebay_item_id",
    //     sortable: true,
    //     name: "eBay Item ID",
    //     width: 150,
    //     filterRenderer: NumericFilter
    // },
    // {
    //     key: "ebay_profile",
    //     width: 200,
    //     filterRenderer: Filter,
    //     name: "Profile",
    // },
    // {
    //     key: "product_type",
    //     sortable: true,
    //     name: "Product type",
    //     width: 200,
    //     filterRenderer: Filter,
    // },
    // {
    //     key: "inventory",
    //     sortable: true,
    //     name: "Inventory",
    //     width: 150,
    //     filterable: false,
    //
    // },
    // {
    //     key: "ebay_status",
    //     sortable: true,
    //     name: "eBay Status",
    //     width: 150,
    //     filterable: false,
    //
    // },
  {
    key: "main_image",
    name: "Image",
    frozen: true,
    editable: false,
    width: 80,
    sortable: false,
    draggable: false,
    filterable: false,
  },
  {
    key: "title",
    frozen: false,
    width: 100,
    filterRenderer: Filter,
    name: "Title",
  },
  {
    frozen: false,
    key: "quantity",
    sortable: false,
    name: "Inventory",
    width: 100,
    filterRenderer: NumericFilter,

  },
  {
    key: "ebay_status",
    sortable: false,
    name: "eBay Status",
    width: 100,
    filterable: false,

  },
  {
    key: "sku",
    sortable: false,
    name: "SKU",
    width: 100,
    filterRenderer: Filter,
  },
  {
    key: "ebay_item_id",
    sortable: false,
    name: "eBay Item ID",
    width: 100,
    filterRenderer: NumericFilter
  },
  {
    key: "tags",
    sortable: false,
    name: "Tags",
    width: 100,
    filterRenderer: Filter,
  },
  {
    key: "ebay_profile",
    width: 100,
    filterRenderer: Filter,
    name: "Profile",
  },
  {
    key: "product_type",
    sortable: true,
    name: "Product type",
    width: 100,
    filterRenderer: Filter,
  },
  {
    key: "vendor",
    sortable: true,
    name: "Vendor",
    width: 100,
    filterRenderer: Filter,
  },

]
export const column = [
    {
        key: "check",
        name: <Checkbox label={"chcek"}/>,
        frozen: true,
        editable: false,
        width :150,
        sortable: false,
        draggable: false,
        filterable: false,
    },
    {
        key: "image",
        name: "Image",
        frozen: true,
        editable: false,
        width :80,
        sortable: false,
        draggable: false,
        filterable: false,
    },
    {
        key: "title",
        frozen: false,
        width:250,
        filterRenderer: Filter,
        name: "Title",
    },
    {
        key: "sku",
        width:200,
        filterRenderer: Filter,
        name: "SKU",
    },
    {
        key: "price",
        sortable: true,
        name: "Price",
        width:200,
        filterRenderer: NumericFilter
    },
    {
        key:"source_variant_id",
        sortable: true,
        name: "Variant ID",
        width:150,
        filterable: false,
        filterRenderer:Filter,
    },
    {
        key:"parent_id",
        sortable: true,
        name: "Parent ID",
        width:150,
        filterable: false,
        filterRenderer:Filter,
    },
    {
        key:"google_status",
        sortable: true,
        name: "Google Status",
        width:150,
        filterable: false,
        filterRenderer:Filter,
    },
    {
        key:'type',
        name:'Type',
        editable: false,
        width:100,
        filterable: false,
        filterRenderer: SingleSelectFilter
    },
    {
        key: "quantity",
        sortable: true,
        name: "Quantity",
        width:100,
        filterable: false,
        filterRenderer: NumericFilter
    },
    {
        key:'vendor',
        name:'Vendor/Brand',
        filterable: false,
        filterRenderer: Filter,
    },
    {
        key:'category',
        name:'Category',
        filterable: false,
        filterRenderer: Filter,
    },
    {
        key:'source_marketplace',
        name:'Marketplace',
        editable: false,
        filterable: false,
        filterRenderer: SingleSelectFilter
    },
    {
        key: "id",
        name: "ID",
        frozen: false,
        editable: false,
        width :60,
        filterable: false,
        sortable: false

    },
    {
        key: "source_order_id",
        name: "Google Order ID",
        frozen: false,
        editable: false,
        width :250,
        filterable: true,
        filterRenderer: Filter,
        sortable: false,

    },
    {
        key: "shopify_order_name",
        name: "Order Name",
        frozen: false,
        editable: false,
        width :250,
        filterRenderer: NumericFilter,
        filterable: true,
        sortable: false,
        attachment:true

    },
    {
        key: "importedAt",
        name: "Imported At",
        frozen: false,
        editable: false,
        width :250,
        filterable: false,
        sortable: false

    },
    {
        key: "status",
        name: "Status",
        frozen: false,
        editable: false,
        width :250,
        filterable: false,
        sortable: false

    },
    {
        key: "action",
        name: "Action",
        frozen: true,
        editable: false,
        width :80,
        filterable: false,
        draggable: false,
        sortable: false,
        events: {
            onClick: function(ev,args) {

            }
        }
    },
    {
        key: "name",
        name: "Name",
        frozen: false,
        editable: false,
        width :250,
        filterable: true,
        filterRenderer: Filter,
        sortable: false

    },
    {
        key: "targetCategory",
        name: "Category",
        frozen: false,
        editable: false,
        width :200,
        filterable: true,
        filterRenderer: Filter,
        sortable: false

    },
    {
        key: "query",
        name: "Query",
        frozen: false,
        editable: false,
        width :200,
        filterable: false,
        sortable: false

    },
    {
        key: "productCount",
        name: "Count",
        frozen: false,
        editable: false,
        width :200,
        filterable: false,
        sortable: false

    },




];

export const column2 = [

    {
        key: "image",
        name: "Image",
        frozen: true,
        editable: false,
        width :80,
        sortable: false,
        draggable: false,
        filterable: false,
    },
    {
        key: "title",
        frozen: false,
        width:250,
        filterRenderer: Filter,
        name: "Title",
    },
    {
        key: "sku",
        width:200,
        filterRenderer: Filter,
        name: "SKU",
    },
    {
        key: "price",
        sortable: true,
        name: "Price",
        width:200,
        filterRenderer: NumericFilter
    },
    {
        key: "quantity",
        sortable: true,
        name: "Quantity",
        width:100,
        filterable: false,
        filterRenderer: NumericFilter
    },
    {
        key:'category',
        name:'Category',
        filterable: false,
        filterRenderer: Filter,
    },

];
