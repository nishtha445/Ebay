import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Checkbox } from '@shopify/polaris';

class SelectAllExtend extends Component {
    constructor(props) {
        super(props);

        this.state = {
            value: false,
        };
        setInterval(() => {
            if ( window.checkboxStatus ) {
                this.setState({value:false});
                this.props.onChange(false);
                window.checkboxStatus = false;
            }
        },1000)
        console.log(props.pageChanged);
    }

    componentWillReceiveProps(nextProps, nextContext) {
        console.log(nextProps.pageChanged);
        if ( nextProps.pageChanged ) {
            this.setState({value:false});
            this.props.onChange(false);
        }
    }

    componentWillUpdate(nextProps, nextState, nextContext) {
        console.log("will Uploaded");
    }

    callBack = (e) => {
        this.setState({value:e});
        this.props.onChange(e);
    };

    render() {
        return (
            <div className="react-grid-checkbox-container checkbox-align">
                <Checkbox
                    label={"tt"}
                    labelHidden
                    checked={this.state.value}
                    onChange={this.callBack}
                />
            </div>
        );
    }
}

SelectAllExtend.propTypes = {
  onChange: PropTypes.func,
  inputRef: PropTypes.func
};

export default SelectAllExtend;
