import React from 'react';
import ReactDataGrid from 'react-data-grid';
import CheckboxEditor2  from './checkbox/CheckboxEditor';
import SelectAllExtend from './formatters/SelectAllExtend';
import RowUtils from './formatters/RowUtils';


class ExtendReactGrid extends ReactDataGrid {

    constructor(props) {
        super(props);
        //console.log("Extend gris",props);
    }

    componentDidMount() {
        // Override canFilter which open Filter by Default
       const columnMetrics = this.createColumnMetricsExtend();
       this.setState({columnMetrics:columnMetrics,canFilter:true});
       if ( this.props.paginationProps !== undefined && this.props.paginationProps.page !== undefined ) {
           this.setState({paginationProps:this.props.paginationProps});
       }
    }

    componentDidUpdate() {
        if ( this.props.paginationProps && this.props.paginationProps.page && this.state.paginationProps && this.props.paginationProps.page != this.state.paginationProps.page ) {
            this.setState({paginationProps:this.props.paginationProps}, () => {
                // window.checkboxStatus = true;
                const columnMetrics = this.createColumnMetricsExtend(this.props, true);
                this.setState({columnMetrics:columnMetrics});
            });

        } else {
            const columnMetrics = this.createColumnMetricsExtend(this.props);
        }
    }

        onCellClick = (rowIndex) => {
        if ( this.props.getCellClick !== undefined ) {
            this.props.getCellClick(rowIndex);
        }
    };

    createColumnMetricsExtend = (props = this.props, pageChanged = false) => {

        const gridColumns = this.setupGridColumnsExtend(props, pageChanged);
        //console.log(gridColumns);
        return this.getColumnMetricsType({
            columns: gridColumns,
            minColumnWidth: this.props.minColumnWidth,
            totalWidth: props.minWidth
        });
    };

    setupGridColumnsExtend = (props = this.props, pageChanged = false) => {
        const { columns } = props;
        // removed
        // if (this._cachedColumns === columns) {
        //     return this._cachedComputedColumns;
        // }

        // this._cachedColumns = columns;

        let cols = columns.slice(0);
        let unshiftedCols = {};
        if (this.props.rowActionsCell
            || (props.enableRowSelect && !this.props.rowSelection)
            || (props.rowSelection && props.rowSelection.showCheckbox !== false)) {
            const SelectAllComponent = this.props.selectAllRenderer || SelectAllExtend;
            const SelectAllRenderer = <SelectAllExtend onChange={this.handleCheckboxChangeExtent} grid={this.selectAllCheckbox} inputRef={grid => this.selectAllCheckbox = grid} pageChanged={pageChanged} />;
            const headerRenderer = props.enableRowSelect === 'single' ? null : SelectAllRenderer;
            const Formatter = CheckboxEditor2;
            const selectColumn = {
                key: 'select-row',
                name: '',
                formatter: <Formatter rowSelection={this.props.rowSelection} />,
                onCellChange: this.handleRowSelectExtended,
                filterable: false,
                headerRenderer: headerRenderer,
                width: 60,
                frozen: true,
                getRowMetaData: (rowData) => rowData,
                cellClass: this.props.rowActionsCell ? 'rdg-row-actions-cell' : ''
            };
            //console.log(selectColumn);
            unshiftedCols = cols.unshift(selectColumn);
            cols = unshiftedCols > 0 ? cols : unshiftedCols;
        }
        this._cachedComputedColumns = cols;
        return this._cachedComputedColumns;
    };

    handleCheckboxChangeExtent = (e) => {
        let allRowsSelected = e;
        //console.log(e);
        // removed
        // if (e.currentTarget instanceof HTMLInputElement && e === true) {
        //     allRowsSelected = true;
        //  } else {
        //      allRowsSelected = false;
        // }
        if (this.useNewRowSelection()) {
            const { keys, indexes, isSelectedKey } = this.props.rowSelection.selectBy;

            if (allRowsSelected && typeof this.props.rowSelection.onRowsSelected === 'function') {
                const selectedRows = [];
                for (let i = 0; i < this.props.rowsCount; i++) {
                    const rowData = this.props.rowGetter(i);
                    if (!RowUtils.isRowSelected(keys, indexes, isSelectedKey, rowData, i)) {
                        selectedRows.push({ rowIdx: i, row: rowData });
                    }
                }

                if (selectedRows.length > 0) {
                    this.props.rowSelection.onRowsSelected(selectedRows);
                }
            } else if (!allRowsSelected && typeof this.props.rowSelection.onRowsDeselected === 'function') {
                const deselectedRows = [];
                for (let i = 0; i < this.props.rowsCount; i++) {
                    const rowData = this.props.rowGetter(i);
                    if (RowUtils.isRowSelected(keys, indexes, isSelectedKey, rowData, i)) {
                        deselectedRows.push({ rowIdx: i, row: rowData });
                    }
                }

                if (deselectedRows.length > 0) {
                    this.props.rowSelection.onRowsDeselected(deselectedRows);
                }
            }
        } else {
            const selectedRows = [];
            for (let i = 0; i < this.props.rowsCount; i++) {
                const row = Object.assign({}, this.props.rowGetter(i), { isSelected: allRowsSelected });
                selectedRows.push(row);
            }
            this.setState({ selectedRows: selectedRows });
            if (typeof this.props.onRowSelect === 'function') {
                this.props.onRowSelect(selectedRows.filter(r => r.isSelected === true));
            }
        }
    };

    handleRowSelectExtended = (rowIdx, columnKey, rowData, e) => {
        // remove
        // e.stopPropagation();
        if (this.useNewRowSelection()) {
            if (this.props.rowSelection.enableShiftSelect === true) {
                if (!this.handleShiftSelect(rowIdx)) {
                    this.handleNewRowSelect(rowIdx, rowData);
                }
            } else {
                this.handleNewRowSelect(rowIdx, rowData);
            }
        } else { // Fallback to old onRowSelect handler
            const selectedRows = this.props.enableRowSelect === 'single' ? [] : this.state.selectedRows.slice(0);
            const selectedRow = this.getSelectedRow(selectedRows, rowData[this.props.rowKey]);
            if (selectedRow) {
                selectedRow.isSelected = !selectedRow.isSelected;
            } else {
                rowData.isSelected = true;
                selectedRows.push(rowData);
            }
            //console.log({ selectedRows: selectedRows, selected: { rowIdx: rowIdx, idx: 0 } });
            this.setState({ selectedRows: selectedRows, selected: { rowIdx: rowIdx, idx: 0 } });
            if (this.props.onRowSelect) {
                this.props.onRowSelect(selectedRows.filter(r => r.isSelected === true));
            }
        }
    };

    onGridRowsUpdated = (fieldName, fromRow, toRow, value, operation) => {
        this.props.onGridRowsUpdated(fieldName, fromRow, toRow, value, operation);
    };
    // use this function to Toogle the custom Filter
}

export default ExtendReactGrid;
