import React, {Component} from 'react';
import './css/head.css';
import ExtendReactGrid from "./extendDataGrid";
import Toolbar from "./Toolbar";
import Skeleton from "../../shared/skeleton";
import {Stack} from "@shopify/polaris";





class Grid extends Component {

    constructor(props) {
        super(props);
        this.state = {
            defaultParams :this.props.filtercolumnSize,
            Defaultprops:this.props,
            updatedSize:this.props.columns,
            newColoums: [],
            massActions:[],
            suffix:this.props.suffix,

        };
        this.hitToggleFilter = React.createRef();
        this.handleResize();
    }

    defaultParams = {
        rowHeight:40,
        minHeight:window.innerHeight,
        headerRowHeight:50,
        headerFiltersHeight:50,
        enableCellSelect:true,
    };

    handleResize = (forceUpdate = false) => {
      if (window.innerHeight > 400) {
                let {defaultParams} = this.state;
                defaultParams['minHeight'] = window.innerHeight - 170;
                this.setState({defaultParams: defaultParams});
            }
            // console.clear();
            let count = 0;
            let widthCount = 0;
            this.props.columns.forEach(e => {
                if (!e.frozen && this.props.visibleColumns[e.key] == 1) {
                    count += parseInt(e.width);
                    widthCount += 1;
                }
            });
            let newColoums = [];
            if (((window.innerWidth - count) > 0 || forceUpdate)) {
                let widthSize = (window.innerWidth - count) / (widthCount);
                this.props.columns.forEach(e => {
                    let newE = Object.assign({}, e);
                    if (!e.frozen) {
                        newE.width = newE.width + (widthSize);
                    }
                    // for diffrentiating the new object from Old
                    if (forceUpdate) {
                        newE.width = newE.width + 10;
                    }
                    if (this.props.visibleColumns[newE.key] == 1) {
                        newColoums.push(newE);
                    }
                });
                // //console.log(newColoums.length);
                if (newColoums.length > 0) {
                    this.setState({newColoums: newColoums, widthSize: widthSize});
                }
            }

    };

    componentDidMount() {
        // //console.log(this.state.updatedSize)
            for(let i=0;i<this.state.updatedSize.length;i++){
                /*if(thisthis.state.updatedSize[i].)*/
            }
        // this.setState({Defaultprops:Defaultprops})
        // this.handleResize(false);
        window.addEventListener('resize', this.handleResize);
    }

    componentWillUnmount() {
        window.removeEventListener('resize', this.handleResize);
    }

    onToggleFilter = () => {
        this.hitToggleFilter.current.onToggleFilter();
        setTimeout(() => {this.hitToggleFilter.current.onToggleFilter();})
    };

    // handlePagination = (pageProps) => {
    //     this.props.handlePagination(pageProps);
    // };

    componentWillReceiveProps(nextProps, nextContext) {
        this.setState({updatedSize:nextProps.columns ,massAction:nextProps.massAction},()=>{this.handleResize()});
        this.handleResize(true);
    }

    render() {
        let arr=[];
        if ( this.state.newColoums.length > 0 ) {
            arr.push(
                <Stack vertical={true}>
                    <Toolbar {...this.props}  selected_count={this.props.selected_count} toolbar_suffix={this.state.suffix} massAction={this.state.massAction} onToggleFilter={this.onToggleFilter} visibleColumns={this.props.visibleColumns}  />
                    <ExtendReactGrid
                        ref={this.hitToggleFilter}
                        {...this.state.defaultParams}
                        {...this.props}
                        columns={this.state.newColoums}
                    />
                </Stack>
            )
        } else {
            arr.push(
                <Stack vertical={true}>

                    <Toolbar {...this.props} selected_count={this.props.selected_count} toolbar_suffix={this.state.suffix}  massAction={this.state.massAction} onToggleFilter={this.onToggleFilter} visibleColumns={this.props.visibleColumns}  />

                    <ExtendReactGrid
                        ref={this.hitToggleFilter}
                        {...this.state.defaultParams}
                        {...this.props}

                    />
                </Stack>
            )
        }
        return arr;
    }
}

export default Grid;
