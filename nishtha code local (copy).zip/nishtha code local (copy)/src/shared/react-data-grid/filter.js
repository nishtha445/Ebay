import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { shapes } from 'react-data-grid';
import { Select, TextField, Icon, Button, Modal, Card, Checkbox, RadioButton, Stack } from "@shopify/polaris";
import { FilterMajorMonotone } from '@shopify/polaris-icons';
import { column } from "./createDemoRows";
const { Column } = shapes;

class Filter extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            filterValue: '',
            selected: 0,
            filterModal: false,
            value: 3,
            placeholder: "Search",
            filterConditions: [
                { label: 'equals', value: "1" },
                { label: 'not equals', value: "2" },
                { label: 'contains', value: "3" },
                { label: 'does not contain', value: "4" },
                { label: 'starts with', value: "5" },
                { label: 'ends with', value: "6" }
            ],
        };
        this.handleChange = this.handleChange.bind(this);
    }

    filterValues(row, columnFilter, columnKey) {

        // Filter logic goes here

        return true;
    }

    handleChange(e) {
        this.setState({ filterValue: e });
        // this.setState({ filterValue: e.replace('*', '').replace('-', '').replace('+', '').replace('/', '').replace('*', '').replace(/[^\w\s]/gi, "") });
        // console.log(typeof e)
        // if (e.match(/[\*~!@#$%^&*:;,<>?()\'\"_+-.\/ \[\] \{\}]/g)) {
        //     return
        // }
        // else {
            setTimeout(() => {
                this.props.onChange({
                    key: this.props.column["key"],
                    column: this.props.column,
                    rawValue: e,
                    filterValues: this.filterValues,
                    operator: this.state.value
                });
            }, 2000);
        // }


    }
    handleChangefilter = (checked, newValue) => {
        //console.log(checked, newValue);
        let { filterConditions } = this.state;
        let temp;
        let j = parseInt(newValue) + 1;
        for (let i in filterConditions) {
            if (filterConditions[i]["value"] == j) {
                temp = filterConditions[i]["label"]
            }
        }
        this.setState({
            value: j,
            filterModal: false,
            placeholder: temp
        }, () => {
            this.handleChange(this.state.filterValue)
        });
    };
    renderCheckbox() {
        //console.log(this.state.value);
        let final = [];
        let { filterConditions } = this.state;
        for (let i = 0; i < filterConditions.length; i++) {
            final.push(<RadioButton
                label={filterConditions[i]["label"]}
                id={i}
                checked={this.state.value == filterConditions[i]["value"]}
                onChange={this.handleChangefilter
                }
            />);
        }
        return final;
    }

    FilterModal() {
        return (
            <Modal
                title={"Filter to be applied"}
                open={this.state.filterModal}
                onClose={() => {
                    this.closeModal();
                }}
            >
                <Modal.Section>
                    <Stack>
                        {this.renderCheckbox()}
                    </Stack>
                </Modal.Section>
            </Modal>
        );
    }

    closeModal() {
        this.setState({ filterModal: false })
    }

    render() {
        let inputKey = 'header-filter-' + this.props.column.key;
        let columnStyle = {
            float: 'left',
            marginRight: 0,
            minWidth: '100%',
            height: "100%",
        };

        return (
            <div style={columnStyle}>
                {this.state.filterModal && this.FilterModal()}
                <TextField
                    label=""
                    placeholder={this.state.placeholder}
                    labelHidden
                    connectedRight={<Button icon={<Icon
                        source={FilterMajorMonotone} />}
                        onClick={() => {
                            this.setState({ filterModal: true }, () => {

                            })
                        }}>
                    </Button>}
                    value={this.state.filterValue}
                    onChange={this.handleChange}
                    readOnly={false} />
            </div>
        );
    }
    handleChangeSelect = (newValue) => {
        this.setState({ selected: newValue });
    };
}

Filter.propTypes = {
    onChange: PropTypes.func.isRequired,
    column: PropTypes.shape(Column)
};
export default Filter;
