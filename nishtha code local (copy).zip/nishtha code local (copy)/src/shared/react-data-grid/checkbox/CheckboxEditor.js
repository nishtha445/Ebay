
import PropTypes from 'prop-types';

import React, {Component} from 'react';
import { Checkbox } from "@shopify/polaris";

class CheckboxEditor2 extends Component {
    static propTypes = {
        value: PropTypes.bool,
        rowIdx: PropTypes.number,
        column: PropTypes.shape({
            key: PropTypes.string,
            onCellChange: PropTypes.func
        }),
        dependentValues: PropTypes.object
    };

    handleChange = (e) => {
        this.props.column.onCellChange(this.props.rowIdx, this.props.column.key, this.props.dependentValues, e);
    };

    render() {
        const checked = this.props.value != null ? this.props.value : false;
        const checkboxName = 'checkbox' + this.props.rowIdx;
        return (<React.Fragment>
            <div className="react-grid-checkbox-container checkbox-align">
                <Checkbox
                    checked={checked}
                    label={checkboxName}
                    labelHidden
                    onChange={this.handleChange}
                />
            </div>
        </React.Fragment>);
    }
}

export default CheckboxEditor2;