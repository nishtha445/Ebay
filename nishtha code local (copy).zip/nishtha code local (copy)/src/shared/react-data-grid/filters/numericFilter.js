import React, {Component} from 'react';
import PropTypes from 'prop-types';
import { shapes } from 'react-data-grid';
import {Button, Modal, RadioButton, Stack, TextField,Icon, Checkbox} from '@shopify/polaris';
import {FilterMajorMonotone,HashtagMajorMonotone} from '@shopify/polaris-icons';
const { Column } = shapes;

class NumericFilter extends React.Component {
    constructor(props) {
        super(props);
        //console.log("numeric filter-->",props);
        this.state = {
            numericValue: '',
            filterModal:false,
            filterConditions :[
                {label: 'equals', value: "1"},
                {label: 'not equals', value: "2"},
            ],
            value:1,
            // hashAttach:(props.column.attachment !== undefined)?props.column.attachment:false
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
        this.getRules = this.getRules.bind(this);
    }

    filterValues(row, columnFilter, columnKey) {
        if (columnFilter.filterTerm == null) {
            return true;
        }
        let result = false;
        // implement default filter logic
        const value = parseInt(row[columnKey], 10);
        for (const ruleKey in columnFilter.filterTerm) {
            if (!columnFilter.filterTerm.hasOwnProperty(ruleKey)) {
                continue;
            }

            const rule = columnFilter.filterTerm[ruleKey];

            switch (rule.type) {
                case "Number":
                    if (rule.value === value) {
                        result = true;
                    }
                    break;
                case "GreaterThen":
                    if (rule.value <= value) {
                        result = true;
                    }
                    break;
                case "LessThen":
                    if (rule.value >= value) {
                        result = true;
                    }
                    break;
                case "Range":
                    if (rule.begin <= value && rule.end >= value ) {
                        result = true;
                    }
                    break;
                default:
                    // do nothing
                    break;
            }
        }
        return result;
    }

    getRules(value) {
        return true;
        // const rules = [];
        // if (value === '') {
        //     return rules;
        // }
        // // check comma
        // const list = value.split(',');
        // if (list.length > 0) {
        //     // handle each value with comma
        //     for (const key in list) {
        //         if (!list.hasOwnProperty(key)) {
        //             continue;
        //         }
        //
        //         const obj = list[key];
        //         if (obj.indexOf('-') > 0) { // handle dash
        //             const begin = parseInt(obj.split('-')[0], 10);
        //             const end = parseInt(obj.split('-')[1], 10);
        //             rules.push({ type: "Range", begin: begin, end: end });
        //         } else if (obj.indexOf('>') > -1) { // handle greater then
        //             const begin = parseInt(obj.split('>')[1], 10);
        //             rules.push({ type: "GreaterThen", value: begin });
        //         } else if (obj.indexOf('<') > -1) { // handle less then
        //             const end = parseInt(obj.split('<')[1], 10);
        //             rules.push({ type: "LessThen", value: end });
        //         } else { // handle normal values
        //             const numericValue = parseInt(obj, 10);
        //             rules.push({ type: "Number", value: numericValue });
        //         }
        //     }
        // }
        // return rules;
    }

    handleKeyPress(e) { // Validate the input
        if ( e === '' ) return true;
        const regex = '>|<|-|,|([0-9])';
        return RegExp(regex).test(e);
        // return result;
        // if (result === false) {
        //     e.preventDefault();
        // }
    }
    handleChangefilter = (checked, newValue) => {
        //console.log(checked, newValue);
        let  {filterConditions} = this.state;
        let temp;
        let j = parseInt(newValue)+1;
        for(let i in filterConditions ) {
            if (filterConditions[i]["value"] == j) {
                temp = filterConditions[i]["label"]
            }
        }
        this.setState({
            value: j,
            filterModal:false,
            placeholder:temp
        },()=>{
            this.handleChange(this.state.numericValue)
        });
    };
    prepareFilterObject(coloumn,filterVal,rawValue) {
        this.state.appliedFilters = {};
        let filterObtained='';

        if (coloumn !== '') {
            switch (coloumn) {
                case 'type':
                case 'title':
                case 'long_description':
                case 'source_product_id':
                    filterObtained='filter[details.' + coloumn + '][' + filterVal + ']';
                    break;
                case 'sku':
                case 'price':
                case 'weight':
                case 'weight_unit':
                case 'main_image':
                case 'quantity':
                    filterObtained='filter[variants.' + coloumn + '][' + filterVal + ']';
                    break;
            }
        }
        return filterObtained;
    }
    handleChange(e) {
        let value = '';
            value=this.prepareFilterObject(this.props.column["key"],this.state.value,e);
        this.setState({numericValue:e});
        // const filters = this.getRules(value);
        this.props.onChange({
                    key:this.props.column["key"],
                    column: this.props.column,
                    rawValue: e,
                    operator:this.state.value,
                    filterValues: this.filterValues
              });
    }
    closeModal(){
        this.setState({filterModal:false})
    }

    renderCheckbox(){
        //console.log(this.state.value);
        let final=[];
        let  {filterConditions} = this.state;
        for(let i=0;i<filterConditions.length;i++ ){
            final.push(<RadioButton
                label={filterConditions[i]["label"]}
                id={i}
                checked={this.state.value == filterConditions[i]["value"] }
                onChange={this.handleChangefilter
                }
            />);
        }
        return final;
    }
    FilterModal() {
        return (
            <Modal
                title={"Filter to be applied"}
                open={this.state.filterModal}
                onClose={() => {
                    this.closeModal();
                }}
            >
                <Modal.Section>
                    <Stack>
                        {this.renderCheckbox()}
                    </Stack>
                </Modal.Section>
            </Modal>
        );
    }
    render() {
        // const tooltipText = 'Input Methods: Range (x-y), Greater Then (>x), Less Then (<y)';
        const tooltipText = '';

        return (
            <>
                {this.state.filterModal && this.FilterModal()}
                <TextField
                    label=""
                    value={this.state.numericValue}
                    onChange={(e) => {
                        this.handleChange(e);
                    }}
                    connectedLeft={this.state.hashAttach && <Button icon={<Icon
                        source={HashtagMajorMonotone} />}  />}
                    connectedRight={ <Button icon={<Icon
                        source={FilterMajorMonotone} />}
                                             onClick={() => {
                                                 this.setState({filterModal:true})
                                             }}>
                    </Button>}
                    type="number"
                    placeholder="numeric"
                    labelHidden
                    readOnly={false}/>
            </>
                );
    }
}

NumericFilter.propTypes = {
    onChange: PropTypes.func.isRequired,
    column: PropTypes.shape(Column)
};
export default NumericFilter;