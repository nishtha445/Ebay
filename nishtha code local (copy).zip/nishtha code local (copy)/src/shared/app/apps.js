import React, { Component } from 'react';
import { Stack, Card, Layout, Select, Thumbnail, Banner ,Button} from "@shopify/polaris";
import { requests } from "../../services/request";
import { notify } from "../../services/notify";
import { json } from "../../environments/static-json";
import { isUndefined } from "util";
import { getSiteIDfromAbbr } from "../static-functions";
import 'react-modal-video/scss/modal-video.scss';
import ModalVideo from 'react-modal-video'

const publicIp = require('public-ip');


class AppsShared extends Component {

    error = {
        acc_type: false,
    };

    constructor(props) {
        super(props);
        this.state = {
            flagselected: false,
            vedioModal: false,
            apps: [],
            ebay_country_code: '',
            mode: 'production',
            ebay_code: '',
            ip: ''
        }
        this.getConnectors();
        this.getSideID();
    }

    getSideID() {
        requests.getRequest('ebayV1/get/siteId').then(data => {
            if (data.success) {
                this.state.ebay_country_code = !isUndefined(data.data.site_id) ? getSiteIDfromAbbr(data.data.site_id) : '';
                this.state.mode = !isUndefined(data.data.mode) ? data.data.mode : '';
                /*this.state.ebay_code=getSiteIDfromAbbr(data.data);*/
                this.state.flagselected = this.getFlagurl(getSiteIDfromAbbr(data.data.site_id));
                // siteID ='MOTORS';
            }
            this.setState(this.state);
            // console.log(data)
        });

    }

    async getUserIP() {

        this.state.ip = await publicIp.v4();
        this.setState(this.state,()=>{

            // console.log(this.state);
        });

    }

    componentDidMount() {
        this.getUserIP()
    }

    getConnectors() {
        //this.state = {
         //   apps: []
       // };
        requests.getRequest('connector/get/all')
            .then(data => {
                // console.log(data)
                if (data.success) {
                    let installedApps = [];
                    for (let i = 0; i < Object.keys(data.data).length; i++) {
                        installedApps.push(data.data[Object.keys(data.data)[i]]);
                    }
                    this.setState({
                        apps: installedApps
                    });
                } else {
                    notify.error(data.message);
                }
            });

    }

    openVedioModal() {
        this.state.vedioModal = true;
        this.setState(this.state);
    }

    closeVedioModal() {
        this.state.vedioModal = false;
        this.setState(this.state);
    }

    render() {
        return (
            <div>
                {
                    this.state.apps.map(app => {
                        if (app.code === 'ebay') {
                            return (
                                <Card title='' key={app.title} actions={
                                    this.props.fromRegistration && [
                                        { content: 'Help video?', onAction: this.openVedioModal.bind(this) }
                                    ]
                                } 
                                // primaryFooterAction={{
                                //     content: app['installed'] !== 0 ? 'ReConnect' : 'Connect', onAction: this.installApp.bind(this, app.code)
                                // }}
                                >
                                    {isUndefined(this.props.noReconnect) ?
                                        <Card.Section subdued>
                                            <Banner status={"info"} >
                                                <p >Kindly select below the <span className="font-weight-bold">country in which you are selling</span></p>
                                                <p style={{ fontSize: '1.2rem' }}>For eg. If you sell in <span className="font-weight-bold">MOTORS</span> then select <span className="font-weight-bold">eBay Motors from the options.</span></p>
                                            </Banner>
                                        </Card.Section> : true}
                                    <Card.Section>
                                        <Layout>
                                            <Layout.Section>
                                                <Stack distribution={"center"}>
                                                    <img src={app.image} alt={app.title} />
                                                </Stack>
                                            </Layout.Section>
                                        </Layout>
                                    </Card.Section>
                                    <Card.Section>
                                        <Stack vertical={false} distribution={"center"}>
                                            {isUndefined(this.props.noReconnect) &&
                                                <Select
                                                    options={[{
                                                        label: 'Live account',
                                                        value: 'production'
                                                    }, { label: 'Sandbox account', value: 'sandbox' }]}
                                                    value={this.state.mode}
                                                    onChange={this.handleModeChange.bind(this, 'mode')}
                                                    disabled={this.state.ip !== '103.97.184.106'}
                                                    error={this.error.acc_type ? '*required field' : ''}
                                                    placeholder={'Choose account type..'}
                                                    label={''} />
                                            }
                                            {this.state.flagselected &&
                                                <Thumbnail
                                                    size={"small"}
                                                    source={this.state.flagselected}
                                                />
                                            }
                                            <Select
                                                options={json.flag_country}
                                                value={this.state.ebay_country_code}
                                                onChange={this.handleDropDownChange.bind(this, 'ebay_country_code')}
                                                disabled={!isUndefined(this.props.noReconnect)}
                                                placeholder={'Choose Country'}
                                                label={''} />

                                            {/*<Button*/}
                                            {/*onClick={() => {*/}
                                            {/*this.installApp(app.code);*/}
                                            {/*}} primary >*/}
                                            {/*{app['installed']!==0?'ReConnect':'Connect'}*/}
                                            {/*</Button>*/}
                                            <Button onClick={this.installApp.bind(this, app.code)} primary  >{app['installed']!==0?'ReConnect':'Connect'}</Button>
                                        </Stack>
                                    </Card.Section>
                                </Card>
                            );
                            // return (
                            //         <AccountConnection
                            //             key={app.code}
                            //             accountName={app.code}
                            //             connected={false}
                            //             title={app.title}
                            //             action={{
                            //                 content:app['installed']==0?'Connect':'ReConnect',
                            //                 onClick: this.installApp.bind(this,app.code)
                            //             }}
                            //             details={app['installed']==0?'Connect Now':'Already Connected'}
                            //             termsOfService={<img className='img-fluid text-center' src={app.image} alt={app.title}/>}
                            //         />
                            // )
                            ;

                        }
                        else {
                            return null;
                        }
                    })
                }

                <ModalVideo channel='youtube' isOpen={this.state.vedioModal} videoId='g6afmrLeVzo' onClose={this.closeVedioModal.bind(this)} />
                {/*<Modal*/}
                {/*    open={this.state.vedioModal}*/}
                {/*    onClose={this.closeVedioModal.bind(this)}*/}
                {/*    title="Help"*/}
                {/*    size={"Large"}*/}
                {/*    src="https://www.youtube.com/embed/c-oKvQU2MIE"*/}
                {/*>*/}
                {/*    <Modal.Section>*/}
                {/*        <div className="p-5">*/}
                {/*        </div>*/}
                {/*    </Modal.Section>*/}
                {/*</Modal>*/}

            </div>
        );
    }

    getFlagurl(val) {
        console.log('val', val)
        let tempFLag = '';
        json.flag_country.forEach((value, index) => {
            console.log(value, '-------', index)
            if (val === value.value) {
                if (val == 207)
                    tempFLag = 'https://cdn11.bigcommerce.com/s-ey7tq/images/stencil/1280x1280/products/3404/18798/malaysia-flag__65890.1575392639.jpg?c=2'
                else
                    tempFLag = value.flag;
            }
        });
        return tempFLag;
    }

    handleDropDownChange(key, val) {
        let flagUrl = this.getFlagurl(val);
        let tempOBJ = Object.assign({}, this.state);
        tempOBJ[key] = val;
        /* tempOBJ.ebay_code=val;*/
        tempOBJ.flagselected = flagUrl;
        this.setState(tempOBJ);

    }

    handleModeChange(key, val) {
        let tempOBJ = Object.assign({}, this.state);
        tempOBJ[key] = val;
        this.setState(tempOBJ);
    }

    handleChange = (obj, val) => {
        this.setState({ [obj]: val });

    };
    installApp(code) {
        console.log("code")
        if (this.state.ebay_country_code !== '' && !this.error.acc_type) {
            this.props.redirectResult(code, this.state.ebay_country_code, this.state.mode);
        } else {
            notify.info('Kindly select a country');
        }
    }
}

export default AppsShared;