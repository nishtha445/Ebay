import React, {Component} from 'react';
import {Banner, Button, Checkbox, Heading, Label, Modal, Select, TextField,DisplayText,Stack} from "@shopify/polaris";

import {isUndefined} from "util";
import * as queryString from "query-string";
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import {capitalizeWord, modifyOptionsData} from "../static-functions";

class InstallAppsShared extends Component {
    queryParams;
    constructor(props) {
        super(props);
       
        this.queryParams = {
            code : props.code,
            site_id : props.site_id,
            mode:props.mode
        };
        this.getInstallationForm();
        this.redirect = this.redirect.bind(this);
        this.getAppInstallationForm = this.getAppInstallationForm.bind(this);
    }
    handleClick(){
        this.state.confirmOpen.open=false
        this.setState(this.state)
        this.props.handleLoader(true)
    }
    getInstallationForm() {
        if (!isUndefined(this.queryParams.code)) {
            this.state = {
                code: this.queryParams.code,
                site_id:this.queryParams.site_id,
                mode:this.queryParams.mode,
                confirmOpen: {
                    open: false,
                    url:''
                }
            };
            this.getAppInstallationForm();
        } else {
            this.props.redirect(false);
        }
    }
    render() {
        return (
            <div className="row">
                <div className="col-12 mt-4 mb-4">
                    {!isUndefined(this.state.schema) && <Banner status="info">
                        <Heading>{'Connect ' + capitalizeWord(this.state.code)}</Heading>
                    </Banner> }
                </div>
                <div className="col-12 mt-1">
                    <div className="row">
                        {   !isUndefined(this.state.schema) &&
                        this.state.schema.map((field) => {
                            switch(field.type) {
                                case 'select':
                                    return (
                                        <div className="col-12 pt-2 pb-2" key={this.state.schema.indexOf(field)}>
                                            <Select
                                                options={field.options}
                                                label={field.title}
                                                placeholder={field.title}
                                                value={field.value}
                                                onChange={this.handleChange.bind(this, field.key)}>
                                            </Select>
                                        </div>
                                    );
                                    break;
                                case 'checkbox':
                                    return (
                                        <div className="col-12 pt-2 pb-2" key={this.state.schema.indexOf(field)}>
                                            <Label>{field.title}</Label>
                                            <div className="row">
                                                {
                                                    field.options.map(option => {
                                                        return (
                                                            <div className="col-md-6 col-sm-6 col-12 p-1" key={field.options.indexOf(option)}>
                                                                <Checkbox
                                                                    checked={field.value.indexOf(option.value) !== -1}
                                                                    label={option.value}
                                                                    onChange={this.handleMultiselectChange.bind(this, this.state.schema.indexOf(field), field.options.indexOf(option))}
                                                                />
                                                            </div>
                                                        );
                                                    })
                                                }
                                            </div>
                                        </div>
                                    );
                                    break;
                                default:
                                    return (
                                        <div className="col-12 pt-2 pb-2" key={this.state.schema.indexOf(field)}>
                                            <TextField
                                                label={field.title}
                                                placeholder={field.title}
                                                value={field.value}
                                                onChange={this.handleChange.bind(this, field.key)}>
                                            </TextField>
                                        </div>
                                    );
                                    break;
                            }
                        })
                        }
                        <div className="col-12 text-center mt-3">
                            { !isUndefined(this.state.schema) && <Button onClick={() => {
                                this.onSubmit();
                            }}>Submit</Button> }
                        </div>
                    </div>
                </div>
                <Modal open={this.state.confirmOpen.open} onClose={() => {
                    let temp = {
                        open: false,
                        url: '',
                    };
                    this.redirect();
                    this.setState({confirmOpen: temp});
                    if(this.state.confirmOpen.open===true)
                    {
                        this.setState({loading:true})
                    }
                    
                }}>
                    <Modal.Section>
                        <div style={{textAlign:'center',padding:'4rem'}}>
                            <Stack vertical={true} spacing={"extraLoose"}>
                                <Stack.Item>
                                    <DisplayText size={"medium"} element={"h3"}><p>Redirect to eBay?</p></DisplayText>
                                </Stack.Item>
                                <Stack.Item>
                                    {/*<div className="col-6 text-right pt-5">*/}
                                    {/*<Button onClick={() => {*/}
                                    {/*let temp = {*/}
                                    {/*open: false,*/}
                                    {/*url: '',*/}
                                    {/*};*/}
                                    {/*this.setState({confirmOpen: temp});*/}
                                    {/*}}>*/}
                                    {/*Cancel*/}
                                    {/*</Button>*/}
                                    {/*</div>*/}

                                    <a style={{color:'#fff'}} href={this.state.confirmOpen.url} target="_parent"> 
                                        <Button primary onClick={this.handleClick.bind(this)}>
                                            Redirect
                                        </Button>
                                    </a>
                                </Stack.Item>
                            </Stack>

                        </div>
                    </Modal.Section>
                </Modal>
            </div>
        );
    }
    handleChange(key, event) {
        for (let i = 0; i < this.state.schema.length; i++) {
            if (this.state.schema[i].key === key) {
                const state = this.state;
                state.schema[i].value = event;
                this.setState(state);
                break;
            }
        }
    }

    handleMultiselectChange(index, optionIndex, event) {
        const checkboxValue = this.state.schema[index].options[optionIndex].value;
        const optIndex = this.state.schema[index].value.indexOf(checkboxValue);
        if (event) {
            if (optIndex === -1) {
                this.state.schema[index].value.push(checkboxValue);
            }
        } else {
            if (optIndex !== -1) {
                this.state.schema[index].value.splice(optIndex, 1);
            }
        }
        this.updateState();
    }

    onSubmit() {
        if (this.state.postType === 'external') {
            let url = this.state.action;
            let end = url.indexOf('?') === -1 ? '?' : '&';
            for (let i = 0; i < this.state.schema.length; i++) {
                url += end + this.state.schema[i].key + '=' + this.state.schema[i].value;
                end = '&';
            }
            window.open(url, '_blank', 'location=yes,height=600,width=550,scrollbars=yes,status=yes');
        } else {
            let url = this.state.action;
            let data = {};
            let flag = true;
            for (let i = 0; i < this.state.schema.length; i++) {
                if (this.state.schema[i].value !== '' && this.state.schema[i].type !== 'checkbox') {
                    data[this.state.schema[i].key] = this.state.schema[i].value;
                } else if (this.state.schema[i].type === 'checkbox' && this.state.schema[i].value.length > 0) {
                    data[this.state.schema[i].key] = this.state.schema[i].value;
                } else if (this.state.schema[i].required !== 0) {
                    flag = false;
                }
            }
            if ( flag ) {
                requests.postRequest(url, data, true)
                    .then(data => {
                        if (data.success) {
                            notify.success(data.message);
                        } else {
                            notify.error(data.message);
                        }
                        this.redirect();
                    });
            } else {
                notify.info('Please Fill Up All Required Field');
            }
        }
    }

    getAppInstallationForm = () => {
        // let win = window.open('', '_blank', 'location=yes,height=600,width=550,scrollbars=yes,status=yes');
        requests.getRequest('connector/get/installationForm', {code: this.state.code,site_id:this.state.site_id,mode:this.state.mode })
            .then(data => {
                if (data.success === true) {
                    if (data.data.post_type === 'redirect') {
                        // win.location = data.data.action;
                        let tempURL = {
                            open: true,
                            url: data.data.action,
                        };
                        this.setState({confirmOpen: tempURL})
                        // this.redirect();
                    } else {
                        // if (win !== null) {
                        //     win.close();
                        // }
                        const state = this.state;
                        this.state['schema'] = this.modifySchemaData(data.data.schema);
                        this.state['action'] = data.data.action;
                        this.state['postType'] = data.data.post_type;
                        this.updateState();
                    }
                } else {
                    notify.error(data.message);
                    this.redirect();
                }
            });
    }

    modifySchemaData(data) {
        for (let i = 0; i < data.length; i++) {
            if (!isUndefined(data[i].options)) {
                data[i].options = modifyOptionsData(data[i].options);
            }
        }
        return data;
    }

    updateState() {
        const state = this.state;
        this.setState(state);
    }

    redirect() {
        this.props.redirect(false);
    }
}

export default InstallAppsShared;
