// Main imports
import SmartDataTable from './SmartDataTable'

// Main exports
export default SmartDataTable
