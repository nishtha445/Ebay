import React, { Component } from 'react';
import {
  Card,
  Select,
  FormLayout,
  Layout,
  DisplayText,
  Heading,
  Stack,
  Banner,
  Checkbox,
  ChoiceList, Button, Modal
} from "@shopify/polaris";
import { requests } from "../../services/request";
import { notify } from "../../services/notify";
import { isUndefined } from "util";

const optionSellOnEbay = [
  { label: 'Yes', value: 'yes' },
  { label: 'No', value: 'no' },
];
const Account_type = [
  { label: 'Personal', value: 'personal' },
  { label: 'Business', value: 'business' },
];
const mappingoptions = [
  { label: 'Title', value: 'details.title' },
  { label: 'SKU', value: 'variants.sku' },
  /*{label:'Barcode',value:'variants.barcode'}*/
];
class MappingProducts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      product_sync: 'yes',
      selling_on_ebay: 'no',
      account_type: 'business',
      product_status: ['published'],
      optional_filter: false,
      use_product_type_filter: false,
      use_vendor_filter: false,
      vendor: '',
      product_type: '',
      vendor_options: false,
      product_type_options: false,
      matching_identifier: {
        Title: 'details.title',
        SKU: 'variants.sku',
        // eBay_Item_ID:''
        /*   Barcode:'variants.barcode'*/
      }
    };
  }


  handleSelectChange(key, value) {
    let tempObj = Object.assign({}, this.state);
    tempObj[key] = value;
    this.state = tempObj;
    this.setState(this.state);
  }

  handleMappingSelectChange(key, value) {
    let tempObj = Object.assign({}, this.state);
    tempObj['matching_identifier'][key] = value;
    this.state = tempObj;
    this.setState(this.state);
  }

  saveMatchingId() {
    this.props.saveMapping(this.state);
  }

  renderMappingProducts() {
    let temparr = [];

    temparr.push(
      <Stack vertical={false} distribution={"fillEvenly"} key={'Lheading'}>
        <Stack.Item>
          <Heading element={"h6"}>
            eBay Attributes
          </Heading>
        </Stack.Item>
        <Stack.Item fill>
          <Heading element={"h6"}>
            Shopify Attributes
          </Heading>
        </Stack.Item>
      </Stack>
    )

    Object.keys(this.state.matching_identifier).map(key => {
      temparr.push(
        <Stack vertical={false} distribution={"fillEvenly"} key={'L' + key}>
          <Stack.Item>
            <Heading element={"h6"}>
              {key.replace(/_/g, " ")}
            </Heading>
          </Stack.Item>
          <Stack.Item fill>
            <Select
              key={'select' + key}
              options={mappingoptions}
              placeholder={'Please select...'}
              helpText={key === 'eBay_Item_ID' ? <p style={{ wordBreak: 'all' }}>*Select only If you have eBay item id on your Shopify store</p> : ''}
              value={this.state.matching_identifier[key]}
              onChange={this.handleMappingSelectChange.bind(this, key)}>
            </Select>
          </Stack.Item>
        </Stack>
      )
    });
    return temparr;
  }

  componentDidMount() {
    this.getVendorProducttype();
  }

  initiatefetchVendorProductType() {
    requests.getRequest('shopify/product/initiateVendorProductTypeFetch').then(data => {
      if (data.success) {
        notify.success('Vendor and product type fetch has been initiated');
        notify.info('Please wait for 5 minutes for options to prepare');
      } else {
        notify.error(data.message);
      }
    })
  }



  getImportSettings() {
    return (
      <Stack vertical={true} distribution={"fill"}>
        <Banner status={"info"} title=" We are about to import products from Shopify" action={{
          content: 'Refetch filter', onAction: this.getVendorProducttype.bind(this, 'clicked')
        }} />
        <Card actions={((isUndefined(this.state.vendor_options) || this.state.vendor_options.length === 0) ||
          (isUndefined(this.state.product_type_options) || this.state.product_type_options.length === 0)) && {
          content: 'Refetch vendor and product type',
          onAction: this.initiatefetchVendorProductType.bind(this)
        }}>
          {
            ((!isUndefined(this.state.vendor_options) && this.state.vendor_options.length > 0) ||
              (!isUndefined(this.state.product_type_options) && this.state.product_type_options.length > 0)) &&
            <Card.Section title={'filters'}>
              <Stack vertical={true}>
                <Stack.Item>
                  <Checkbox label={'Optional filter'} checked={this.state.optional_filter} onChange={(e) => {
                    this.setState({ optional_filter: e });
                  }} />
                </Stack.Item>
                {this.state.optional_filter &&
                  <Stack.Item>
                    <Stack vertical={false} spacing={"loose"}>
                      <Checkbox label={'Vendor'} checked={this.state.use_vendor_filter} onChange={(e) => {
                        this.setState({ use_vendor_filter: e })
                      }} />
                      <Checkbox label={'Product type'} checked={this.state.use_product_type_filter} onChange={(e) => {
                        this.setState({ use_product_type_filter: e })
                      }} />
                    </Stack>
                  </Stack.Item>
                }
              </Stack>
            </Card.Section>
          }
          {this.state.optional_filter &&
            <Card.Section title={'Optional filters'}>
              {((!isUndefined(this.state.vendor_options) && this.state.vendor_options.length > 0) ||
                (!isUndefined(this.state.product_type_options) && this.state.product_type_options.length > 0)) &&
                <FormLayout>
                  <FormLayout.Group condensed={true}>
                    {this.state.product_type_options && this.state.use_product_type_filter &&
                      <Select label={'Product type'}
                        options={this.state.product_type_options}
                        value={this.state.product_type}
                        placeholder={'Select....'}
                        onChange={(e) => {
                          this.setState({ product_type: e });
                        }} />
                    }
                    {this.state.vendor_options && this.state.use_vendor_filter &&
                      <Select label={'Vendors'}
                        options={this.state.vendor_options}
                        value={this.state.vendor}
                        placeholder={'Select....'}
                        onChange={(e) => {
                          this.setState({ vendor: e });
                        }} />
                    }
                  </FormLayout.Group>
                </FormLayout>
              }

            </Card.Section>
          }
          <Card.Section title={'Necessary filter'}>
            <ChoiceList
              title={'Kindly select the status of product you want to import'}
              choices={[
                { label: 'Published', value: 'published' },
                { label: 'Unpublished', value: 'unpublished' },
                { label: 'All', value: 'any' },
              ]}
              allowMultiple={false}
              selected={this.state.product_status}
              onChange={(e) => {
                this.setState({ product_status: e });
              }}
            />
          </Card.Section>
        </Card>
      </Stack>
    )
  }

  prepareOptions(data) {
    let tempOptions = [];
    data.forEach((value, index) => {
      tempOptions.push(
        { label: value, value: value }
      )
    });
    return tempOptions;
  }

  getVendorProducttype(ifClicked) {
    if (ifClicked == 'clicked') {
      requests.getRequest('shopify/product/getVendorProductTypeProducts').then(data => {
        console.log(data)
        if (data.success) {
          console.log('Inside')
          this.setState({ product_type_options: this.prepareOptions(data.data.product_type), vendor_options: this.prepareOptions(data.data.vendor) });
          notify.success('Initiated')
        }
      })
    }
    else if (ifClicked == undefined) {
      requests.getRequest('shopify/product/getVendorProductTypeProducts').then(data => {
        console.log('2', data)
        if (data.success) {
          console.log('2', 'Inside')
          this.setState({ product_type_options: this.prepareOptions(data.data.product_type), vendor_options: this.prepareOptions(data.data.vendor) });
        }
      })
    }
  }

  render() {
    return (
      <Card>
        <Card.Section>
          <FormLayout>
            <Stack vertical={false} distribution={"fillEvenly"}>
              {/*<Select*/}
              {/*key={'select'+'account-type'}*/}
              {/*options={Account_type}*/}
              {/*label={'Select the type of account you have on eBay?'}*/}
              {/*value={this.state.account_type}*/}
              {/*onChange={this.handleSelectChange.bind(this,'account_type')}>*/}
              {/*</Select>*/}
              <Select
                key={'select' + 'SellOnebay'}
                options={optionSellOnEbay}
                label={'Are you already selling on eBay?'}
                value={this.state.selling_on_ebay}
                onChange={this.handleSelectChange.bind(this, 'selling_on_ebay')}>
              </Select>
            </Stack>
            {
              this.getImportSettings()
            }
            {this.state.selling_on_ebay === 'yes' &&
              <Card title={'Mapping options'} >
                {this.state.selling_on_ebay === 'yes' && this.state.product_sync === 'yes' &&
                  <Card.Header>
                    <Banner status={"warning"}>
                      <b>Please note</b> if you select <b>product sync option below as "Yes"</b> then all the <b>products
                  from Shopify that are already present on eBay</b> will be treated as <b>uploaded
                  products</b> and <b>product credits will be reduced accordingly</b>.
                </Banner>
                  </Card.Header>
                }
                <Card.Section>
                  <Select
                    key={'approve_product_sync'}
                    options={[{ label: 'Yes', value: 'yes' }, { label: 'No', value: 'no' }]}
                    label={'Do you want to sync your product from eBay to store?'}
                    value={this.state.product_sync}
                    onChange={this.handleSelectChange.bind(this, 'product_sync')}>
                  </Select>
                </Card.Section>
                <Card.Section>
                  <FormLayout>

                    {
                      this.renderMappingProducts()
                    }
                  </FormLayout>
                </Card.Section>
              </Card>
            }
          </FormLayout>
        </Card.Section>

      </Card>
    );
  }
}

export default MappingProducts;
