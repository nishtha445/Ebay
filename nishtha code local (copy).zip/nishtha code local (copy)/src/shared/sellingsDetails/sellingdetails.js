import React, { Component } from "react";
import {
  Card,
  Checkbox,
  ChoiceList,
  FormLayout,
  Select,
  Stack,
  Banner,
  Tooltip,
  TextField,
  Button,
  DatePicker,
  Heading,
  Modal,
  TextContainer,
  Icon,
} from "@shopify/polaris";
import { RefreshMinor } from "@shopify/polaris-icons";
import { requests } from "../../services/request";
import { isUndefined } from "util";
import { notify } from "../../services/notify";

const reason_end_listing = [
  { label: "Incorrect", value: "Incorrect" },
  { label: "Lost or broken", value: "LostOrBroken" },
  { label: "Not available", value: "NotAvailable" },
  { label: "Other listing error", value: "OtherListingError" },
  { label: "Sell to high bidder", value: "SellToHighBidder" },
  { label: "Sold", value: "Sold" },
];

class SellingDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      site_id: "",
      firstHalf: [],
      secondHalf: [],

      selling_details: {
        use_ebay_tax_rate_table: "no",
        business_seller: "",
        restricted_to_business: "",
        vat_percentage: "",
        dimension: {
          length: "",
          width: "",
          height: "",
          unit: "",
        },
        reason_end_listing: "Incorrect",
        vrm: "",
        vin: "",
        /* format:'fixed_price',*/
        country: "",
        state: "",
        /* listing_duration:'GTC',*/
        use_seller_profile: false,
        tax_percentage: "",
        shipping_include: false,
        variation_image_setting: [],
        item_location: {
          country: "",
          zipcode: "",
          city_state: "",
          currency: "",
        },
        synced_by: false,
        order_import_setting: {
          order_create: {
            month: new Date().getMonth(),
            year: new Date().getFullYear(),
            selected: {
              start: new Date(),
              end: new Date(),
            },
          },
          modify_order: {
            month: new Date().getMonth(),
            year: new Date().getFullYear(),
            selected: {
              start: new Date(),
              end: new Date(),
            },
          },
          number_of_days: 7,
        },
        exclude_locations: false,
        excluded_shipping_location: [],
        webhook_setting: "no",
      },
      errors: {
        config_data: {
          item_location: {
            country: false,
            zipcode: false,
            city_state: false,
          },
          order_import_setting: {
            number_of_days: false,
          },
          exclude_locations: false,
          vrm: false,
          vin: false,
        },
      },
      options_recieved: {
        country: [],
        states: [],
        currency: [],
        excluded_shipping_locations: [],
        shopifyattrib: [],
        shopifyattribMain: [],
      },

      dateConfig: {
        order_create: {
          todayDate: new Date(),
          rangeBack: new Date(new Date().setDate(new Date().getDate() - 90)),
        },
        modify_order: {
          todayDate: new Date(),
          rangeBack: new Date(new Date().setDate(new Date().getDate() - 90)),
        },
      },
    };
  }

  callBasicFunctions() {
    this.getShopifyConfigurableAttributes();
    this.getShopdetails();
    this.getShopifyAttributesMain();
    this.getSideID();
  }

  importeBaydetails() {
    requests.getRequest("ebayV1/import/updateEbayDetails").then((data) => {
      if (data.success) {
        notify.success(data.message);
      } else {
        notify.error(data.message);
      }
    });
  }

  getSideID() {
    requests.getRequest("ebayV1/get/siteId").then((data) => {
      if (data.success) {
        this.state.site_id = data.data.site_id;
      }
    });
    this.setState(this.state);
  }

  getShopifyAttributesMain() {
    requests
      .getRequest("connector/product/getAttributesByProductQuery", {
        marketplace: "shopify",
        query: "(price>-1)",
      })
      .then((data) => {
        if (data.success) {
          this.setShopifyAttributeMain(data.data);
        }
      });
  }

  componentDidMount() {
    this.getFormDetails();
    this.callBasicFunctions();
  }

  getFormDetails() {
    if (!isUndefined(this.props.data) && this.props.data !== null) {
      let tempObj = Object.assign({}, this.state.selling_details);
      let tempObjrecieved = Object.assign({}, this.props.data);
      Object.keys(tempObjrecieved).map((key) => {
        switch (key) {
          case "order_import_setting":
            Object.keys(tempObjrecieved[key]).map((subkeys) => {
              switch (subkeys) {
                case "number_of_days":
                  break;
                default:
                  tempObjrecieved[key][subkeys].selected.start = new Date(
                    tempObjrecieved[key][subkeys].selected.start
                  );
                  tempObjrecieved[key][subkeys].selected.end = new Date(
                    tempObjrecieved[key][subkeys].selected.end
                  );
                  break;
              }
            });
            break;
        }
      });
      Object.keys(this.props.data).map((key) => {
        tempObj[key] = this.props.data[key];
      });
      this.state.selling_details = Object.assign({}, tempObj);
      this.state.selling_details.exclude_locations = false;
    }

    this.setState(this.state);
  }

  getDate(startdate, key) {
    let thisrange = JSON.parse(startdate);
    let getEndDate = new Date(thisrange.end);
    this.state.dateConfig[key].rangeBack = new Date(
      getEndDate.setDate(getEndDate.getDate() - 90)
    );
    this.setState(this.state);
  }

  getShopifyConfigurableAttributes() {
    requests.getRequest("connector/get/configurableAttributes").then((data) => {
      if (data.success) {
        this.setShopifyAttribute(data.data);
      }
    });
  }
  setShopifyAttribute(data) {
    let temparr = [];
    data.forEach((value, index) => {
      temparr.push({ label: value, value: value });
    });
    this.state.options_recieved.shopifyattrib = temparr;
    this.setState(this.state);
  }

  setShopifyAttributeMain(data) {
    let temparr = [];
    data.forEach((value, index) => {
      temparr.push({ label: value.title, value: value.code });
    });
    this.state.options_recieved.shopifyattribMain = temparr;
    this.setState(this.state);
  }

  extractCountryDetails(data) {
    let temparr = [];
    Object.keys(data).map((key) => {
      temparr.push({
        label: data[key]["Description"],
        value: data[key]["Country"],
      });
    });
    this.state.options_recieved.country = temparr;
    this.setState(this.state);
  }
  extractCurrencyDetails(data) {
    let temparr = [];
    Object.keys(data).map((key) => {
      temparr.push({
        label: data[key]["Description"],
        value: data[key]["Currency"],
      });
    });
    this.state.options_recieved.currency = temparr;
    this.setState(this.state);
  }

  extractExcludedLocations(data) {
    let temparr = [];
    Object.keys(data).map((key) => {
      temparr.push({
        label: data[key]["Description"],
        value: data[key]["Location"],
      });
    });
    this.state.options_recieved.excluded_shipping_locations = temparr;
    this.setState(this.state);
  }
  getShopdetails() {
    requests
      .getRequest("ebayV1/get/details", { site_id: "US" })
      .then((data) => {
        if (data.success) {
          this.extractCountryDetails(data.data[0]["CountryDetails"]);
          this.extractCurrencyDetails(data.data[0]["CurrencyDetails"]);
          this.extractExcludedLocations(
            data.data[0]["ExcludeShippingLocationDetails"]
          );
          if (
            !isUndefined(data.data[0]["TaxJurisdiction"]) &&
            data.data[0]["TaxJurisdiction"] !== null
          ) {
            this.extractStatefromsiteId(data.data[0]["TaxJurisdiction"]);
          }
        }
      });
  }

  extractStatefromsiteId(data) {
    let temparr = [];
    data.forEach((tax_detail, index) => {
      temparr.push({
        label: tax_detail["JurisdictionName"],
        value: tax_detail["JurisdictionID"],
      });
    });
    this.state.options_recieved.states = temparr;
    this.setState(this.state);
  }

  handleChangeDateChange(key, range) {
    let tempObj = Object.assign({}, range);
    let dateRange = JSON.stringify(tempObj);
    switch (key) {
      case "order_create":
        this.state.selling_details.order_import_setting.order_create.selected =
          tempObj;
        // this.getDate(dateRange,key);
        break;
      case "modify_order":
        this.state.selling_details.order_import_setting.modify_order.selected =
          tempObj;
        // this.getDate(dateRange,key);
        break;
    }
    this.setState(this.state);
  }
  handleMonthChange(key, month, year) {
    switch (key) {
      case "order_create":
        {
          this.state.selling_details.order_import_setting.order_create.month =
            month;
          this.state.selling_details.order_import_setting.order_create.year =
            year;
        }
        break;
      case "modify_order":
        {
          this.state.selling_details.order_import_setting.modify_order.month =
            month;
          this.state.selling_details.order_import_setting.modify_order.year =
            year;
        }
        break;
    }
    this.setState(this.state);
  }

  feildsChangeLevelTwo(key, subkey, value) {
    let tempObj = Object.assign({}, this.state);
    tempObj.selling_details[key][subkey] = value;
    this.setState(tempObj);
  }

  renderSellingdetails() {
    let temparr = [];
    temparr.push(
      <React.Fragment key={"selllingdetails"}>
        {!isUndefined(this.state.options_recieved.states) &&
          this.state.options_recieved.states.length > 0 && (
            <Card.Section title={"Sales Tax details"}>
              <FormLayout>
                <Stack
                  key={"usesalestaxDetails"}
                  distribution={"fillEvenly"}
                  vertical={false}
                >
                  <Select
                    key={"UseTaxRateTable"}
                    options={[
                      { label: "Yes", value: "yes" },
                      { label: "No", value: "no" },
                    ]}
                    label={"Use eBay tax rate table"}
                    placeholder={"Please select"}
                    value={this.state.selling_details.use_ebay_tax_rate_table}
                    onChange={this.feildsChange.bind(
                      this,
                      "selling_details",
                      "use_ebay_tax_rate_table"
                    )}
                  />
                  {this.state.selling_details.use_ebay_tax_rate_table ===
                    "no" && (
                    <Stack
                      key={"salestaxDetails"}
                      distribution={"fillEvenly"}
                      vertical={false}
                    >
                      <Select
                        key={"CountrySalestax"}
                        options={this.state.options_recieved.states}
                        label={"State"}
                        placeholder={"Please select"}
                        value={this.state.selling_details.state}
                        onChange={this.feildsChange.bind(
                          this,
                          "selling_details",
                          "state"
                        )}
                      />
                      <TextField
                        label="Tax Percentage"
                        key={"Tax Percentage"}
                        type={"number"}
                        value={this.state.selling_details.tax_percentage}
                        suffix="%"
                        onChange={this.feildsChange.bind(
                          this,
                          "selling_details",
                          "tax_percentage"
                        )}
                      />
                      <div style={{ marginTop: "3rem" }}>
                        <Checkbox
                          key={"salestaxDetails"}
                          checked={this.state.selling_details.shipping_include}
                          label="Also apply to shipping and handling costs"
                          onChange={this.feildsChangeCheckBox.bind(
                            this,
                            "selling_details",
                            "shipping_include"
                          )}
                        />
                      </div>
                    </Stack>
                  )}
                </Stack>
              </FormLayout>
            </Card.Section>
          )}
        {this.state.site_id === "MOTORS" && (
          <Card.Section title={"Vehicle details"}>
            <Stack
              key={"AdditionalVINVRM"}
              distribution={"fillEvenly"}
              vertical={false}
            >
              <TextField
                key={"VehicleIdentificationNumber"}
                /* options={this.state.options_recieved.shopifyattribMain}*/
                placeholder={"..."}
                label={"Vehicle identification number"}
                error={
                  this.state.errors.config_data.vin ? "*required field" : ""
                }
                value={this.state.selling_details.vin}
                onChange={this.feildsChange.bind(
                  this,
                  "selling_details",
                  "vin"
                )}
              />
              <TextField
                key={"VehicleRegistrationMark"}
                /*options={this.state.options_recieved.shopifyattribMain}*/
                placeholder={"..."}
                error={
                  this.state.errors.config_data.vrm ? "*required field" : ""
                }
                label={"Vehicle registration mark"}
                value={this.state.selling_details.vrm}
                onChange={this.feildsChange.bind(
                  this,
                  "selling_details",
                  "vrm"
                )}
              />
            </Stack>
          </Card.Section>
        )}
        <Card.Section title={"VAT details"}>
          <FormLayout>
            <FormLayout.Group condensed>
              <Select
                key={"BusinessSeller"}
                options={[
                  { label: "Yes", value: "true" },
                  { label: "No", value: "false" },
                ]}
                placeholder={"Please select..."}
                label={"Business seller"}
                value={this.state.selling_details.business_seller}
                onChange={this.feildsChange.bind(
                  this,
                  "selling_details",
                  "business_seller"
                )}
              />
              <Select
                key={"RestrictedToBusiness"}
                placeholder={"Please select..."}
                options={[
                  { label: "Yes", value: "yes" },
                  { label: "No", value: "no" },
                ]}
                label={"Restricted to business"}
                value={this.state.selling_details.restricted_to_business}
                onChange={this.feildsChange.bind(
                  this,
                  "selling_details",
                  "restricted_to_business"
                )}
              />
              <TextField
                label="VAT Percentage"
                key={"VAT Percentage"}
                type={"number"}
                value={this.state.selling_details.vat_percentage}
                suffix="%"
                onChange={this.feildsChange.bind(
                  this,
                  "selling_details",
                  "vat_percentage"
                )}
              />
            </FormLayout.Group>
          </FormLayout>
        </Card.Section>
        {/*<Card.Section title={'Product dimensions'}>*/}
        {/*<FormLayout>*/}
        {/*<Banner status={"info"}>Choose only if you have selected <b>Calculated Shipping</b></Banner>*/}
        {/*<FormLayout.Group condensed>*/}
        {/*<Select*/}
        {/*key={'LengthProduct'}*/}
        {/*options={this.state.options_recieved.shopifyattribMain}*/}
        {/*placeholder={'Please select...'}*/}
        {/*label={'Length'}*/}
        {/*value={this.state.selling_details.dimension.length}*/}
        {/*onChange={this.feildsChangeLevelTwo.bind(this,'dimension','length')}/>*/}
        {/*<Select*/}
        {/*key={'BreadthProduct'}*/}
        {/*placeholder={'Please select...'}*/}
        {/*options={this.state.options_recieved.shopifyattribMain}*/}
        {/*label={'Width'}*/}
        {/*value={this.state.selling_details.dimension.width}*/}
        {/*onChange={this.feildsChangeLevelTwo.bind(this,'dimension','width')}/>*/}
        {/*<Select*/}
        {/*key={'HeightProduct'}*/}
        {/*placeholder={'Please select...'}*/}
        {/*options={this.state.options_recieved.shopifyattribMain}*/}
        {/*label={'Height'}*/}
        {/*value={this.state.selling_details.dimension.height}*/}
        {/*onChange={this.feildsChangeLevelTwo.bind(this,'dimension','height')}/>*/}
        {/*</FormLayout.Group>*/}
        {/*<Select*/}
        {/*key={'UnitMeasurement'}*/}
        {/*placeholder={'Please select...'}*/}
        {/*options={[{label:'Inch',value:'in'},{label:'Centimeters',value:'cm'},{label:'Meters',value:'m'},{label:'Foot',value:'ft'}]}*/}
        {/*label={'Select unit for above dimensions'}*/}
        {/*value={this.state.selling_details.dimension.unit}*/}
        {/*onChange={this.feildsChangeLevelTwo.bind(this,'dimension','unit')}/>*/}
        {/*</FormLayout>*/}
        {/*</Card.Section>*/}
        <Card.Section title={"General settings"}>
          <FormLayout>
            <FormLayout.Group condensed>
              {/*<div style={{marginTop:"3rem"}}>*/}
              {/*<Checkbox*/}
              {/*key={'useSellerProfile'}*/}
              {/*checked={this.state.selling_details.use_seller_profile}*/}
              {/*label="Use seller profile"*/}
              {/*onChange={this.feildsChange.bind(this,'selling_details','use_seller_profile')}*/}
              {/*/>*/}
              {/*</div>*/}
              <div style={{ maxHeight: 100, overflowY: "scroll" }}>
                <ChoiceList
                  key={"VariationImageSetting"}
                  title={"Variation image setting"}
                  allowMultiple
                  choices={this.state.options_recieved.shopifyattrib}
                  selected={this.state.selling_details.variation_image_setting}
                  onChange={this.feildsChangeChoiceList.bind(
                    this,
                    "selling_details",
                    "variation_image_setting"
                  )}
                />
              </div>
            </FormLayout.Group>
            {/*<Stack key={'Endreasonlisting'} distribution={"fillEvenly"} vertical={false}>*/}
            {/*<Select*/}
            {/*key={'SelectWebhookSetting'}*/}
            {/*options={[{label:'Yes',value:'yes'},{label:'No',value:'no'}]}*/}
            {/*label={'Enable Webhook setting'}*/}
            {/*value={this.state.selling_details.webhook_setting}*/}
            {/*onChange={this.feildsChange.bind(this,'selling_details','webhook_setting')}/>*/}
            {/*<Select*/}
            {/*key={'Endreasonlisting-select'}*/}
            {/*options={reason_end_listing}*/}
            {/*label={'End reason listing'}*/}
            {/*value={this.state.selling_details.reason_end_listing}*/}
            {/*onChange={this.feildsChange.bind(this,'selling_details','reason_end_listing')}/>*/}
            {/*</Stack>*/}
          </FormLayout>
        </Card.Section>

        {/*<Card.Section title={'Order import settings'}>*/}
        {/*<Stack vertical={false} distribution={"fillEvenly"}>*/}
        {/*{this.state.selling_details.synced_by &&*/}
        {/*<Card>*/}
        {/*<Card.Section title={'Order create'}>*/}
        {/*<DatePicker*/}
        {/*month={this.state.selling_details.order_import_setting.order_create.month}*/}
        {/*allowRange={true}*/}
        {/*onMonthChange={this.handleMonthChange.bind(this, 'order_create')}*/}
        {/*disableDatesAfter={this.state.dateConfig.order_create.todayDate}*/}
        {/*disableDatesBefore={this.state.dateConfig.order_create.rangeBack}*/}
        {/*year={this.state.selling_details.order_import_setting.order_create.year}*/}
        {/*onChange={this.handleChangeDateChange.bind(this, 'order_create')}*/}
        {/*selected={this.state.selling_details.order_import_setting.order_create.selected}*/}
        {/*/>*/}
        {/*</Card.Section>*/}
        {/*<Card.Section title={'Range'}>*/}
        {/*<Heading>{this.state.selling_details.order_import_setting.order_create.selected.start.toLocaleDateString()} -- {this.state.selling_details.order_import_setting.order_create.selected.end.toLocaleDateString()} </Heading>*/}
        {/*</Card.Section>*/}
        {/*</Card>*/}
        {/*}*/}
        {/*{this.state.selling_details.synced_by &&*/}
        {/*<Card>*/}
        {/*<Card.Section title={'Modify order'}>*/}
        {/*<DatePicker*/}
        {/*month={this.state.selling_details.order_import_setting.modify_order.month}*/}
        {/*allowRange={true}*/}
        {/*onMonthChange={this.handleMonthChange.bind(this, 'modify_order')}*/}
        {/*disableDatesAfter={this.state.dateConfig.modify_order.todayDate}*/}
        {/*disableDatesBefore={this.state.dateConfig.modify_order.rangeBack}*/}
        {/*year={this.state.selling_details.order_import_setting.modify_order.year}*/}
        {/*onChange={this.handleChangeDateChange.bind(this, 'modify_order')}*/}
        {/*selected={this.state.selling_details.order_import_setting.modify_order.selected}*/}
        {/*/>*/}
        {/*</Card.Section>*/}
        {/*<Card.Section title={'Range'}>*/}
        {/*<Heading>{this.state.selling_details.order_import_setting.modify_order.selected.start.toLocaleDateString()} -- {this.state.selling_details.order_import_setting.modify_order.selected.end.toLocaleDateString()} </Heading>*/}
        {/*</Card.Section>*/}
        {/*</Card>*/}
        {/*}*/}
        {/*<TextField*/}
        {/*label="Number of days"*/}
        {/*key={'NumberofDays'}*/}
        {/*type={"number"}*/}
        {/*error={this.state.errors.config_data.order_import_setting.number_of_days ? '*max value accepted is 90' : ''}*/}
        {/*value={this.state.selling_details.order_import_setting.number_of_days}*/}
        {/*onChange={this.handlesellingDetailsLevelTwo.bind(this, 'order_import_setting', 'number_of_days')}*/}
        {/*/>*/}
        {/*</Stack>*/}
        {/*</Card.Section>*/}
        <Card.Section title={"Item Location"}>
          <Stack key={"Item Location"} vertical={true}>
            <Banner status={"info"}>
              <p>
                <b>Zip code</b> is the postal code of the place where the item
                is located. This value is used for proximity searches
              </p>
            </Banner>
            {/*{this.state.site_id ==='MOTORS' &&*/}
            <Stack distribution={"fillEvenly"} vertical={false}>
              {/*<Select*/}
              {/*key={'Currencylocation'}*/}
              {/*options={this.state.options_recieved.currency}*/}
              {/*label={'Currency'}*/}
              {/*placeholder={'Select...'}*/}
              {/*value={this.state.selling_details.item_location.currency}*/}
              {/*onChange={this.handlesellingDetailsLevelTwo.bind(this,'item_location','currency')}/>*/}
              <Select
                key={"Countrylocation"}
                options={this.state.options_recieved.country}
                label={"Country"}
                placeholder={"Select..."}
                value={this.state.selling_details.item_location.country}
                error={
                  this.state.errors.config_data.item_location.country
                    ? "*required field"
                    : ""
                }
                onChange={this.handlesellingDetailsLevelTwo.bind(
                  this,
                  "item_location",
                  "country"
                )}
              />
              {/*}*/}
              <TextField
                label="Zip Code"
                key={"Zip Code"}
                error={
                  this.state.errors.config_data.item_location.zipcode
                    ? "*required field"
                    : ""
                }
                value={this.state.selling_details.item_location.zipcode}
                onChange={this.handlesellingDetailsLevelTwo.bind(
                  this,
                  "item_location",
                  "zipcode"
                )}
              />
              {/*<TextField*/}
              {/*label="City,State"*/}
              {/*key={'City,State'}*/}
              {/*error={this.state.errors.config_data.item_location.city_state?'*required field':''}*/}
              {/*value={this.state.selling_details.item_location.city_state}*/}
              {/*onChange={this.handlesellingDetailsLevelTwo.bind(this,'item_location','city_state')}*/}
              {/*/>*/}
            </Stack>
          </Stack>
        </Card.Section>
        <Card.Section title={"Excluded Shipping Location"}>
          <Stack
            key={"Excluded Shipping Location"}
            distribution={"fillEvenly"}
            vertical={true}
          >
            <Button
              primary
              onClick={() => {
                this.state.selling_details.exclude_locations = true;
                this.setState(this.state);
              }}
            >
              Create Exclusion List
            </Button>
            <Modal
              key={"chooseExcluded Shipping Location"}
              open={this.state.selling_details.exclude_locations}
              onClose={() => {
                this.state.selling_details.exclude_locations = false;
                this.setState(this.state);
              }}
              title="Create Exclusion List"
             
            >
              <Modal.Section>
                <TextContainer>
                  <p>
                    {this.state.selling_details.exclude_locations && (
                      <div className="row">
                        <div className="col-md-6">
                          <ChoiceList
                            key={"Exclusion Location"}
                            allowMultiple
                            choices={this.state.options_recieved.excluded_shipping_locations.slice(
                              0,
                              this.state.options_recieved
                                .excluded_shipping_locations.length / 2
                            )}
                            selected={
                              this.state.selling_details
                                .excluded_shipping_location
                            }
                            onChange={this.feildsChangeChoiceList.bind(
                              this,
                              "selling_details",
                              "excluded_shipping_location"
                            )}
                          />
                        </div>
                        <div className="col-md-6">
                          <ChoiceList
                            key={"Exclusion Location"}
                            allowMultiple
                            choices={this.state.options_recieved.excluded_shipping_locations.slice(
                              this.state.options_recieved
                                .excluded_shipping_locations.length / 2,
                              this.state.options_recieved
                                .excluded_shipping_locations.length
                            )}
                            selected={
                              this.state.selling_details
                                .excluded_shipping_location
                            }
                            onChange={this.feildsChangeChoiceList.bind(
                              this,
                              "selling_details",
                              "excluded_shipping_location"
                            )}
                          />
                        </div>
                      </div>
                    )}
                  </p>
                </TextContainer>
              </Modal.Section>
            </Modal>
            {/* <Checkbox
              key={'chooseExcluded Shipping Location'}
              checked={this.state.selling_details.exclude_locations}
              label="Create Exclusion List"
              onChange={this.feildsChangeCheckBox.bind(this, 'selling_details', 'exclude_locations')}
           />*/}
          </Stack>
        </Card.Section>
      </React.Fragment>
    );
    return temparr;
  }

  ExcludedShippingModal() {
    return (
      <Modal
        open={this.state.selling_details.exclude_locations}
        onClose={() => {
          this.state.selling_details.exclude_locations = false;
          this.setState(this.state);
        }}
        title="Excluded Shipping Location"
      >
        <Modal.Section></Modal.Section>
      </Modal>
    );
  }

  render() {
    return (
      <Card title={"Selling details"} /*actions={[{content:<React.Fragment><Tooltip content={'Re-import eBay details'} /><Icon source={RefreshMinor}/></React.Fragment>,onAction:this.importeBaydetails.bind(this)}]}*/  /*actions={[{content:'Save',onAction:this.saveAllprofiles.bind(this)}]}*/
        primaryFooterAction={{ content: 'Save', onAction: this.saveAllprofiles.bind(this), loading: this.props.loaders }}
      
      >
        {this.renderSellingdetails()}
      </Card>
    );
  }

  saveAllprofiles() {
    let tempObjTemp = {
      config_data: {},
    };

    tempObjTemp.config_data = this.state.selling_details;

    let selling_details_validated = this.sellingDetailsValidator(
      tempObjTemp.config_data
    );
    if (selling_details_validated === 1) {
      this.props.recieveFormData(tempObjTemp);
    } else {
      this.props.recieveFormData({ errors: true });
    }
  }

  sellingDetailsValidator(data) {
    let errors = 0;
    // if(data.item_location.city_state==='')
    // {
    //     this.state.errors.config_data.item_location.city_state=true;
    //     errors+=1;
    // }
    // else{
    //     this.state.errors.config_data.item_location.city_state=false;
    // }
    if (data.item_location.zipcode === "") {
      this.state.errors.config_data.item_location.zipcode = true;
      errors += 1;
    } else {
      this.state.errors.config_data.item_location.zipcode = false;
    }
    // if(this.state.site_id ==='MOTORS') {
    // if (data.item_location.country === '') {
    //     this.state.errors.config_data.item_location.country = true;
    //     errors += 1;
    // }
    // else {
    //     this.state.errors.config_data.item_location.country = false;
    // }
    // }
    if (data.order_import_setting.number_of_days > 30) {
      this.state.errors.config_data.order_import_setting.number_of_days = true;
      errors += 1;
    } else {
      this.state.errors.config_data.order_import_setting.number_of_days = false;
    }
    if (this.state.site_id === "MOTORS") {
      // if (data.vin === '') {
      //     this.state.errors.config_data.vin = true;
      //     errors += 1;
      // }
      // else {
      //     this.state.errors.config_data.vin = false;
      // }
      // if (data.vrm === '') {
      //     this.state.errors.config_data.vrm = true;
      //     errors += 1;
      // }
      // else {
      //     this.state.errors.config_data.vrm = false;
      // }
    }
    this.setState(this.state);
    if (errors > 0) {
      return 0;
    } else {
      return 1;
    }
  }

  handlesellingDetailsLevelTwo(key, tag, value) {
    let tempObj = Object.assign({}, this.state);
    // tempObj['selling_details'][key][tag] = value.replace(/[^\w\s]/gi, ""). replace(/[a-zA-Z]/gi, '');
    tempObj["selling_details"][key][tag] = value;
    this.setState(tempObj);
  }

  feildsChange(key, tag, value) {
    let tempObj = Object.assign({}, this.state);
    tempObj[key][tag] = value.replace("-", "");
    this.setState(tempObj);
  }
  feildsChangeChoiceList(key, tag, value) {
    let tempObj = Object.assign({}, this.state);
    tempObj[key][tag] = value;
    this.setState(tempObj);
  }
  feildsChangeCheckBox(key, tag, value) {
    let tempObj = Object.assign({}, this.state);
    tempObj[key][tag] = value;
    this.setState(tempObj);
  }
}

export default SellingDetails;
