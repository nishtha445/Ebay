import React, {Component} from 'react';
import {requests} from "../../services/request";
import {isUndefined} from "util";
import {notify} from "../../services/notify";
import {Banner, Button, Card, Checkbox, Label, Select, TextField,Stack,Heading,FormLayout,ChoiceList} from "@shopify/polaris";
import {modifyOptionsData} from "../static-functions";


class ConfigShared extends Component {
    googleConfigurationData = [];
    shopifyConfigurationData = [];

    constructor(props) {
        super(props);
        this.state = {
            config_management:[
                ['targetCountry','contentLanguage','currency'],
                ['included_destination'],
                ['repricerFlow','repricerType','repricerPercentage'],
                ['fixed_inventory','threshold_inventory']
            ],
            config_postion:{
            },
            account_information: {
                username: '',
                email: ''
            },
            google_configuration: {},
            shopify_configuration: {},
            google_configuration_updated: false,
            shopify_configuration_updated: false,
            account_information_updated: false
        };
        this.getGoogleConfigurations();
    }

    getGoogleConfigurations() {
        requests.getRequest('connector/get/config', { marketplace: 'google' })
            .then(data => {
                if (data.success) {
                    this.googleConfigurationData = this.modifyGoogleConfigData(data.data);
                    this.updateState();

                } else {
                    notify.error(data.message);
                }
            });
    }

    modifyGoogleConfigData(data) {
        let store_config_position={};
        for (let i = 0; i < data.length; i++) {
            this.state.google_configuration[data[i].code] = data[i].value;
            if (!isUndefined(data[i].options)) {
                data[i].options = modifyOptionsData(data[i].options);
            }
            store_config_position[data[i].code]=i;
        }
        this.state.config_postion=Object.assign({},store_config_position);
        return data;
    }

    renderGoogleConfigurationSection() {
        return (

            <Card title="Google Configuration">
                <Card.Section>

                    <Stack distribution={"fill"}>
                        <Stack.Item fill>
                            <Banner status="info" >
                                <div style={{fontSize:'1.2rem'}}>
                                <Heading >Included Destination</Heading>
                                <ul style={{margin:0}}>
                                    <li>To Enable Google Express - Select "Shopping Action"</li>
                                    <li>To Enable Google Shopping - Select "Shopping"</li>
                                    <li>To Enable Ads - Select "Display Ads"</li>
                                </ul>
                                <h6>*You can select all three of them as well</h6>
                                </div>
                            </Banner>
                        </Stack.Item>
                        <Stack.Item fill>
                            <Banner status="info">
                                <div style={{fontSize:'1.2rem'}}>
                                    <Heading>Repricer Feature</Heading>
                                <ul style={{margin:0}}>
                                    <li>If you want to upload different price on Google,</li>
                                    <li>Select flow of Repricer (Increase or Decrease price). Then enter the percentage by which you want to differ the price.</li>
                                    <li>If you do not want to change the price then make no changes in Repricer Percentage</li>
                                </ul>
                                </div>
                            </Banner>
                        </Stack.Item>
                    </Stack>
                    <br/>
                    <FormLayout>
                    {
                        Object.keys(this.googleConfigurationData).length>0 &&

                        this.render_form_body()
                    }
                    </FormLayout>
                </Card.Section>
            </Card>

        )
    }

    render_form_body(){
        let temparr=[];
        for(let i=0;i<this.state.config_management.length;i++){
            let internal_components=[];
            for(let j=0;j<this.state.config_management[i].length;j++) {
                let position_config = this.state.config_postion[this.state.config_management[i][j]];
                internal_components.push(
                    this.get_form_components(this.googleConfigurationData[position_config])
                )
            }
            if(this.state.config_management[i].length===1){
                temparr.push(<React.Fragment
                    key={"config_management_" + i}>{internal_components}</React.Fragment>)
            }
            else {
                temparr.push(<FormLayout.Group condensed
                                               key={"config_management_" + i}>{internal_components}</FormLayout.Group>)
            }
        }
        return temparr
    }

    get_form_components(config){
        switch(config.type) {
            case 'select':
                return (
                        <Select
                            key={'select'+config.title}
                            options={config.options}
                            label={config.title}
                            helpText={config.description+"*"}
                            placeholder={config.title}
                            value={this.state.google_configuration[config.code]}
                            onChange={this.googleConfigurationChange.bind(this, this.googleConfigurationData.indexOf(config))}>
                        </Select>
                );
            case 'checkbox':
                return (
                        <ChoiceList
                            key={'checkbox'+config.title}
                            allowMultiple
                            title={config.title}
                            helpText={config.description+"*"}
                            choices={config.options}
                            selected={this.state.google_configuration[config.code]}
                            onChange={this.googleConfigurationCheckboxChange.bind(this,config.code)}
                        />
                );
            default:
                return (

                    <TextField
                        key={"default"+this.googleConfigurationData.indexOf(config)}
                        helpText={config.description+"*"}
                        label={config.title}
                        placeholder={config.title}
                        value={this.state.google_configuration[config.code]}
                        onChange={this.googleConfigurationChange.bind(this, this.googleConfigurationData.indexOf(config))}>
                    </TextField>
                );
        }
    }

    render() {
        return (

            this.renderGoogleConfigurationSection()

        );
    }

    googleConfigurationChange(index, value) {
        this.state.google_configuration_updated = true;
        this.state.google_configuration[this.googleConfigurationData[index].code] = value;
        this.updateState();
    }
    googleConfigurationCheckboxChange(code ,event) {
        this.state.google_configuration[code]=event;
        this.updateState();
    }

    saveGoogleConfigData() {
        let error_log = '';
        Object.keys(this.state.google_configuration).forEach(e => {
            if ( this.state.google_configuration[e] === '') {
                this.googleConfigurationData.forEach(data => {
                    if ( data.code === e && data.required ) {
                        error_log += data.title + ', ';
                    }
                });
            } else if (typeof this.state.google_configuration[e] === 'object' && this.state.google_configuration[e].length <= 0) {
                this.googleConfigurationData.forEach(data => {
                    if ( data.code === e && data.required ) {
                        error_log += data.title + ', ';
                    }
                });
            }
        });
        if ( error_log !== '' ) {
            notify.info(error_log + ' are Required');
        } else {
            requests.postRequest('connector/get/saveConfig', { marketplace: 'google', data: this.state.google_configuration })
                .then(data => {
                    if (data.success) {
                        notify.success(data.message);
                        this.props.checkConfig();
                    } else {
                        notify.error(data.message);
                    }
                    this.getGoogleConfigurations();
                });
        }
    }

    ContinueGoogleConfigData()
    {
        this.props.checkConfig();
    }

    updateState() {
        const state = this.state;
        this.setState(state);
    }
}

export default ConfigShared;
