import { Banner, Button, Select, TextField } from "@shopify/polaris";
import { MarketingMajorMonotone } from "@shopify/polaris-icons";
import React from "react";

export function button(label, onClick, submit = false, loading = false, primary = true, size = 'medium', disabled = false, destructive = false, icon = false, plain = false, outline = false, removeUnderline = false) {
    return <Button children={label} onClick={onClick} submit={submit} primary={primary} size={size} loading={loading} disabled={disabled} destructive={destructive} icon={icon} plain={plain} outline={outline} removeUnderline={removeUnderline} />
}

export function bannerPolaris(title = "", message = "", status = "warning", icon = MarketingMajorMonotone, action = false, onDismiss) {
    return (<Banner title={title} status={status} icon={icon} action={action} onDismiss={onDismiss}>
        {message}
    </Banner>)
}

export function textField(label, value, onChange, placeholder = '', helptext = '', error = false, type = 'text', prefix = '', suffix = '', maxLength = false, disabled = false, showCharacterCount = false, min = '', readOnly = false, requiredIndicator = false) {
    return <TextField
        label={label}
        value={value ? value.toString() : ''}
        onChange={onChange}
        type={type}
        helpText={helptext}
        error={error}
        placeholder={placeholder}
        prefix={prefix}
        maxLength={maxLength ? maxLength : undefined}
        disabled={disabled}
        suffix={suffix}
        showCharacterCount={showCharacterCount}
        min={min}
        readOnly={readOnly}
        requiredIndicator={requiredIndicator}
    />;
}

export function select(label = '', options = [], onChange, value, placeholder = 'Please Select', error = false, labelInline = false, disabled = false, helpText = false, requiredIndicator = false) {
    return <Select
        label={label}
        options={[{ label: 'Please Select', value: '' }, ...options]} // 
        onChange={onChange}
        labelInline={labelInline}
        helpText={helpText}
        value={value}
        error={error}
        disabled={disabled}
        // placeholder={placeholder}
        requiredIndicator={requiredIndicator}
    />
}