import React, { Component } from 'react';
import './App.css';
import Panel from "./Components/Panel/panel";
import {Redirect, Route, Switch, withRouter} from "react-router-dom";

import Auth from "./Components/Auth/auth";

import OthersRoutes from "./Components/Others/routes";
import {environment} from "./environments/environment";

class App extends Component {

    constructor(props)
    {
        super(props);

    }
    componentDidMount(){
        if(environment.isLive) {
            console.log = console.info = console.warn = console.error = () => {
            };
        }
    }
    render() {
        return (
            <React.Fragment>
            <Switch>
                <Route exact path="/" render={() => (
                    <Redirect to="/auth/"/>
                )}/>
                <Route  path='/auth/' component={Auth}/>
                <Route  path='/panel' component={Panel}/>
                <Route  path='/show' component={OthersRoutes}/>
                <Route path="**" render={() => (
                    <Redirect to="/auth"/>
                )}/>
            </Switch>
            </React.Fragment>
        );
    }
}

export default App;
