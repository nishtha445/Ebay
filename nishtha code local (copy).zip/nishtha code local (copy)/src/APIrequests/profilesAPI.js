import { requests } from "../services/request";

export async function getprofiles(filters = {}){
    return await requests.getRequest('connector/profile/getAllProfiles', filters);
}