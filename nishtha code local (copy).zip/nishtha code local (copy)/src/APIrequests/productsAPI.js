import { requests } from "../services/request";

export async function getproducts(filters = {}){
    return await requests.getRequest('ebayV1/get/products', filters);
}

export async function fetchProductById(data){
    return await requests.getRequest('ebayV1/get/productById', { ...data })
}

export async function getVendorProductTypeProducts() {
    return await requests.getRequest('shopify/product/getVendorProductTypeProducts')
}