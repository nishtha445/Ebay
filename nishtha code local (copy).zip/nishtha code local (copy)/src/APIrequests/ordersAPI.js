import { requests } from "../services/request";

export async function getorders(filters = {}){
    return await requests.getRequest('connector/order/getOrders', filters);
}