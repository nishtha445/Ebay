import React, { Component } from 'react';
import { Card, Collapsible, Icon, SkeletonBodyText, SkeletonDisplayText, Stack, Tag, TextContainer, TextStyle, Tooltip } from "@shopify/polaris";
import _ from "lodash";
import { getFilterSentence, prepareChoiceoption } from "./gridHelper";
import { select, textField, bannerPolaris, button } from "../../PolarisComponents/Common";
import { PlusMinor, QuestionMarkMajorMonotone } from "@shopify/polaris-icons";
import { filterOptions } from '../../Components/Products/producthelper';
import { getprofiles } from '../../APIrequests/profilesAPI';

class FilterComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            filters: [],
            attributeSelected: '',
            conditionSelected: '',
            valueApplied: '',
            errors: {
                attributeSelected: false,
                conditionSelected: false,
                valueApplied: false,
                similiarFilter: false
            },
            filterHasError: false,
            // utkarsh
            applyFilterClicked: false,
            profilesRequestSuccess: false,
            filtersProps: this.props.filtersProps,
        }
    }

    getDataFromProfiles = async () => {
        let profilesRequest = await getprofiles({ count: 25, activePage: 1, getAllProfiles: true,getAllProfilesFromProductGridFilter: true });
        let { success: profilesRequestSuccess, data: profilesRequestData } = profilesRequest;
        // let attributeOptions = [...prepareChoiceoption(filterOptions, 'headerName', "field")];
        let templateArray = [{ 'label': 'Default Profile', 'value': 'Default Profile' }];
        this.setState({profilesRequestSuccess}, () => {
            // console.log('1')
            if (profilesRequestSuccess) {
                let { rows } = profilesRequestData;
                Object.entries(rows).map(([key, value]) => {
                    let { name, profile_id } = value;
                    templateArray.push({ 'label': name, 'value': name });
                });
                // console.log('templateArray', templateArray)
                // attributeOptions.forEach((attrib, index) => {
                //     if (attrib.value === 'profile_name') {
                //         attributeOptions[index]['choices'] = [...templateArray];
                //     }
                // })
                let { filtersProps } = this.state;
                let { attributeoptions } = filtersProps;
                console.log('attributeoptions', attributeoptions)
                attributeoptions = [...attributeoptions, attributeoptions.map(option => {
                    if(option.value === 'profile_name') {
                        option.choices = [...templateArray]
                    }
                })]
                this.setState({filtersProps})
            }
    
        })
    }

    handleFilterChanges(field, value) {
        // console.log('filed', field, 'value', value)
        let obj = {};
        let { errors } = this.state;
        if (field === 'attributeSelected' && value === 'profile_name') {
            this.getDataFromProfiles()
        }
        if (field === 'attributeSelected') {
            switch (value) {
                case 'variants.quantity':
                case 'variants.price':
                    obj = {
                        conditionSelected: '1',
                        valueApplied: '',
                    }
                    break;
                case 'listing_id':
                    obj = {
                        conditionSelected: '1',
                        valueApplied: '',
                    }
                    break;
                default:
                    obj = {
                        conditionSelected: '3',
                        valueApplied: '',
                    }
                    break;
            }
        }
        this.setState({ [field]: value, ...obj }, () => {
            // console.log('state', this.state)
            let { attributeSelected, conditionSelected, valueApplied } = this.state;
            // if (!(Object.values({ attributeSelected, conditionSelected, valueApplied }).indexOf("") > -1)) this.addMoreFilters();
            if (Object.values(errors).indexOf(true) > -1) this.filterHasError();
            this.setDefaultCondition();
        });
    }

    setDefaultCondition() {
        let { attributeSelected } = this.state;
        let { filtersProps } = this.props;
        let { attributeoptions, filterCondition } = filtersProps;
        // console.log('filtersProps', filtersProps);
        let getAttribute = attributeoptions.filter(attrib => attrib.value === attributeSelected);
        let extractConditionValue = '';
        if (getAttribute.length) {
            let getDefaultCondition = getAttribute[0]['default_condition'];
            if (getDefaultCondition !== '') {
                let getConditionValue = filterCondition.filter(filter => filter.label === getDefaultCondition);
                if (getConditionValue.length) {
                    extractConditionValue = getConditionValue[0]['value'];
                    this.setState({ conditionSelected: extractConditionValue });
                }
            }
        }
    }

    filterHasError() {
        let { attributeSelected, conditionSelected, valueApplied, filters: existingFilters } = this.state;
        let appliedFilter = { attribute: attributeSelected, condition: conditionSelected, value: valueApplied };
        let { errors } = this.state;
        Object.keys(this.state).map(key => {
            if (key in errors) errors[key] = this.state[key] === '';
            return true;
        });
        let similiarFilterExists = existingFilters.filter(filterObj => _.isEqual(filterObj, appliedFilter));
        errors = { ...errors, similiarFilter: similiarFilterExists.length > 0 };
        this.setState({ errors, filterHasError: Object.values(errors).indexOf(true) > -1 });
        return Object.values(errors).indexOf(true) > -1;
    }

    removeTags(index) {
        let { filters: componentFilters } = this.state;
        componentFilters = componentFilters.filter((filterExisting, pos) => pos !== index);
        this.setState({ filters: componentFilters }, () => {
            this.applyFilterFunc();
            if (componentFilters.length === 0) {
                this.resetAll();
            }
        });
    }

    renderTags(filters, attributeoptions, filterCondition, onRemoveShow = true) {
        // console.log(filters, attributeoptions, filterCondition, onRemoveShow)
        let Tags = [];
        // console.log('filters', filters)
        filters.forEach((filter, index) => {
            if (onRemoveShow) {
                Tags.push(<Tag key={`Tag-${index}`}
                    onRemove={() => {
                        this.removeTags(index)
                    }}>{getFilterSentence(filter, attributeoptions, filterCondition)}</Tag>);
            } else {
                Tags.push(<Tag key={`Tag-${index}`}>{getFilterSentence(filter, attributeoptions, filterCondition)}</Tag>);
            }
        });
        // console.log('Tags', Tags)
        return Tags;
        // return <Stack>
        //     {Tags}
        //     <Tooltip active content="Please note these added filters need to be applied for filtering results. For doing so kindly use Apply filters action">
        //         <TextStyle variation="strong">Filter Details</TextStyle>
        //     </Tooltip>
        // </Stack>;
    }

    mergepreExistingfilters(componentFilter, appliedFilters) {
        // console.log('componentFilter', componentFilter, 'appliedFilters', appliedFilters)
        let { filtersProps } = this.props;
        let { attributeoptions, filters, filterCondition } = filtersProps;
        let createUniqueFilters = [];
        let filterExistsFromRedux = filters.filter(Obj => Obj.attribute === appliedFilters.attribute);
        let filterExists = componentFilter.filter(Obj => Obj.attribute === appliedFilters.attribute);
        if(filterExistsFromRedux.length) {
            filters.forEach(Obj => {
                if (Obj.attribute === appliedFilters.attribute) {
                    createUniqueFilters.push(appliedFilters);
                } else {
                    createUniqueFilters.push(Obj)
                }
            })
        }
        else 
        if (filterExists.length) {
            componentFilter.forEach(Obj => {
                if (Obj.attribute === appliedFilters.attribute) {
                    createUniqueFilters.push(appliedFilters);
                } else {
                    createUniqueFilters.push(Obj)
                }
            })
        } else if(componentFilter.length > 0) {
            createUniqueFilters = [...componentFilter];
            createUniqueFilters.push(appliedFilters);
        } else {

            createUniqueFilters = [...componentFilter, ...filters];
            createUniqueFilters.push(appliedFilters);
        }
        return [...createUniqueFilters];
    }

    valueFilter(attributeSelected, attributeoptions, valueApplied, valueError, conditionSelected) {
        // console.log('attributeSelected', attributeSelected, 'attributeoptions', attributeoptions, 'valueApplied', valueApplied, 'valueError', valueError, 'conditionSelected', conditionSelected )
        let disabled = false;
        let choicesExists = attributeoptions.filter(attribute => attribute.value === attributeSelected);
        if (conditionSelected === '') {
            disabled = true;
        }
        if (choicesExists.length && choicesExists[0]['choices'].length) {
            return select('Value', choicesExists[0]['choices'], this.handleFilterChanges.bind(this, 'valueApplied'), valueApplied, "Choose...",
                // valueError,
                false, false, disabled
            )
        } else {
            if(attributeSelected === 'price') {
            // if(['variants.quantity', 'price'].filter(attributes => attributeSelected === attributes)) {
                valueApplied = valueApplied.replace(/[a-zA-Z-!$%^&*()@_+|~=`\\#{}\[\]:";'<>?,\/]/gi, '')
                // if(valueApplied.split('.')) {
                //     console.log('object')
                // }
                console.log(valueApplied.split('.').length)
                // if(valueApplied.split('.').length>2) {
                //     valueApplied = valueApplied.replace(/\.+$/,"");
                // }
            }else if(attributeSelected === 'variants.quantity') {
                // if(['variants.quantity', 'price'].filter(attributes => attributeSelected === attributes)) {
                valueApplied = valueApplied.replace(/[a-zA-Z-!$%^&*()@_+|~=`\\#{}\[\]:";'<>?,.\/]/gi, '')
            }
            // return <input type='text' onChange={()=>this.handleFilterChanges.bind(this, 'valueApplied')}  />
            return textField('Value', valueApplied, this.handleFilterChanges.bind(this, 'valueApplied'), "Choose...", "", false
                // valueError, 
                , "text", '', '', false, disabled)
        }
    }



    conditionFilter(attributeSelected, attributeoptions, filterCondition, conditionSelected = 'contains', conditionError) {
        let disabled = false;
        let getAttribute = attributeoptions.filter(attrib => attrib.value === attributeSelected);
        if (getAttribute.length) {
            let getDefaultCondition = getAttribute[0]['default_condition'];
            if (getDefaultCondition !== '') {
                let getConditionValue = filterCondition.filter(filter => filter.label === getDefaultCondition);
                if (getConditionValue.length) disabled = true;
            }
        }
        let filterConditionTemp = filterCondition.map(data => {
            let { disable_for } = data;
            if (disable_for && Array.isArray(disable_for) && disable_for.length) {
                return { ...data, disabled: disable_for.indexOf(attributeSelected) > -1 };
            }
            return { ...data, disabled: false }
        })
        if (attributeSelected === '') {
            disabled = true;
        }
        return select('Condition', [...filterConditionTemp], this.handleFilterChanges.bind(this, 'conditionSelected'), conditionSelected, "Choose...", false
            // conditionError,
            , false, disabled)
    }

    addMoreFilters() {
        let { attributeSelected, conditionSelected, valueApplied, filters: componentFilters } = this.state;
        let { filterData } = this.props;
        // filterData(this, componentFilters);
        let appliedFilter = { attribute: attributeSelected, condition: conditionSelected, value: valueApplied };
        if (!this.filterHasError()) {
            let filtersMerged = this.mergepreExistingfilters(componentFilters, appliedFilter);
            this.setState({
                filters: [...filtersMerged],
                // attributeSelected: '',
                // conditionSelected: '',
                // valueApplied: ''
            }, () => {
            });
        }
    }

    resetAll() {
        this.setState({
            attributeSelected: '',
            conditionSelected: '',
            valueApplied: '', filters: []
        });
    }
    applyFilterFunc = () => {
        let { filterData } = this.props;
        this.props.filterCollapsibleFunc()
        let { filters: componentFilters, attributeSelected, conditionSelected, valueApplied } = this.state;
        if (!(Object.values({ attributeSelected, conditionSelected, valueApplied }).indexOf("") > -1)) this.addMoreFilters();
        // filterData(componentFilters);
        this.setState({
            attributeSelected: '',
            conditionSelected: '',
            valueApplied: '',
            applyFilterClicked: true,
        }, () => {
            filterData(this.state.filters);
        });
    }
    render() {
        let { attributeSelected, conditionSelected, valueApplied, errors, filterHasError, filters: componentFilters, filtersProps } = this.state;
        let { 
            // filtersProps, 
            filterData, filterCollapsible
         } = this.props;
        let { attributeoptions, filters, filterCondition } = filtersProps;
        // console.log('attributeoptions', attributeoptions)
        let { attributeSelected: attributeError, conditionSelected: conditionError, valueApplied: valueError, similiarFilter } = errors;
        return (
            <React.Fragment>
                <Stack vertical={true} spacing={"loose"}>
                    <Collapsible
                        open={filterCollapsible}
                        id="filter-collapsible"
                        transition={{ duration: '150ms', timingFunction: 'ease' }}
                    >
                        <Card
                            // title={"Filters"} actions={[
                            //     {
                            //         content: 'Reset all', onAction: () => {
                            //             this.resetAll();
                            //             filterData([]);
                            //         }
                            //     }
                            // ]}

                            // attributeSelected: '',
                            // conditionSelected: '',
                            // valueApplied: ''
                            // secondaryFooterActions={[{ content: 'Apply filters', onAction: filterData.bind(this, componentFilters), 
                            // disabled: componentFilters.length === 0, 
                            // primary: true }]}
                            // primaryFooterAction={{ content: 'Apply filters', onAction: filterData.bind(this, componentFilters) }}

                            // utkarsh
                            primaryFooterAction={{
                                content: 'Apply filters', onAction: this.applyFilterFunc, disabled:
                                    // componentFilters.length === 0
                                    this.state.attributeSelected === '' || this.state.conditionSelected === '' || this.state.valueApplied === ''
                                ,
                            }}
                            secondaryFooterActions={[{
                                content: 'Reset all', onAction: () => {
                                    this.resetAll();
                                    filterData([]);
                                }, 
                                disabled: filters.length === 0
                                // disabled: componentFilters.length === 0
                            }]}

                        // end

                        // primaryFooterAction={{
                        //     content: 'Apply filters', onAction: filterData.bind(this, componentFilters),
                        //     disabled: componentFilters.length === 0,
                        //     primary: true
                        // }}
                        // secondaryFooterActions={[{ content: 'Add filters', onAction: this.addMoreFilters.bind(this) }]}
                        >
                            {/* {filterHasError && similiarFilter &&
                                <Card.Section>
                                    {similiarFilter &&
                                        bannerPolaris('Please note', 'The filter you are trying to add is already applied', 'attention')
                                    }
                                </Card.Section>
                            } */}
                            {
                                // componentFilters.length > 0 &&
                                filters.length > 0 &&
                                // this.state.applyFilterClicked &&
                                <Card.Section>
                                    <Stack vertical={false} spacing={"loose"} distribution="equalSpacing">
                                        {/* <TextContainer>
                                            <b>Please note these added filters need to be applied for filtering results. For doing so kindly use Apply filters action</b>
                                        </TextContainer> */}
                                        <Stack vertical={false} spacing={"loose"}>
                                            {
                                                // this.renderTags(componentFilters, attributeoptions, filterCondition)
                                            }
                                            {
                                                this.renderTags(filters, attributeoptions, filterCondition)
                                                // this.renderTags(componentFilters, attributeoptions, filterCondition)

                                            }
                                        </Stack>
                                        <Tooltip content="You can apply multiple fields at time to filter the products.Use Apply Filter button to get the desired result based on applied filters.">
                                            {/* <TextStyle variation="strong">Read More?</TextStyle> */}
                                            <Icon
                                            source={QuestionMarkMajorMonotone}
                                            color="base" />
                                        </Tooltip>
                                    </Stack>
                                </Card.Section>
                            }
                            {
                                attributeoptions.length > 0 ? 
                            <Card.Section>
                                <Stack vertical={false}>
                                    <Stack.Item fill={true}>
                                        <Stack vertical={false} distribution={"fill"}>
                                            {
                                                select('Field', attributeoptions, this.handleFilterChanges.bind(this, 'attributeSelected'), attributeSelected, "Choose...",
                                                    // attributeError
                                                )
                                            }
                                            {
                                                this.conditionFilter(attributeSelected, attributeoptions, filterCondition, conditionSelected, conditionError)
                                            }
                                            {/*{*/}
                                            {/*    select('Condition', filterCondition, this.handleFilterChanges.bind(this,'conditionSelected'),conditionSelected, "Choose...",conditionError)*/}
                                            {/*}*/}
                                            {
                                                this.state.attributeSelected === "profile_name" ? (
                                                    // attributeoptions[7]['choices'].length > 0
                                                    this.state.profilesRequestSuccess 
                                                    ? this.valueFilter(attributeSelected, attributeoptions, valueApplied, valueError, conditionSelected) : 
                                                    <div style={{marginTop: '35px'}}><SkeletonBodyText lines={2} /></div>) :
                                                this.valueFilter(attributeSelected, attributeoptions, valueApplied, valueError, conditionSelected)
                                            }
                                        </Stack>
                                    </Stack.Item>
                                    {/* { componentFilters.length &&
                                    <div style={{marginTop: 23}}>
                                       {
                                           button('Add filters', () => {
                                               this.addMoreFilters();
                                           }, false, false, true, 'medium')
                                       }
                                    </div>
                                    } */}
                                </Stack>
                            </Card.Section> :
                            <Card.Section>
                                <SkeletonBodyText />
                            </Card.Section>
                            }
                        </Card>
                        <br />
                    </Collapsible>
                    {/* {filters.length > 0 &&
                        <Card>
                            <Card.Section title={"Applied Filters"} actions={[{ content: 'Reset applied filters', onAction: filterData.bind(this, []) }]}>
                                {
                                    this.renderTags(filters, attributeoptions, filterCondition, false)
                                    // this.renderTags(componentFilters, attributeoptions, filterCondition)
                                }
                            </Card.Section>
                        </Card>
                    } */}
                </Stack>

            </React.Fragment>
        );
    }
}

export default FilterComponent;