import React, { Component } from 'react';

export default class CustomNoRowsOverlay extends Component {
    render() {
        return this.props.noRowsMessageFunc()
    }
}