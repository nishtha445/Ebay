import React, { Component } from 'react';
import { Select, Pagination, FormLayout, TextField, Card, Stack, Button, ButtonGroup, Modal, Checkbox, Icon } from '@shopify/polaris';
import { product_column, createDemoRows } from "../../shared/react-data-grid/createDemoRows";
import { ViewMajorMonotone, RefreshMajorMonotone, CategoriesMajorMonotone } from '@shopify/polaris-icons';

const defaultpagination = {
    page: 1,
    totalNumberOfPages: 1,
    totalNumberOfProducts: 0,
    totalNumberOfItems: 0,
    pageSize: "25",
};

class NewToolbar extends Component {
    constructor(props) {
        super(props);

        this.state = {
            massAction: props.massAction ? props.massAction : [],
            showcolumns_modal: false,
            checkbox_render: [],
            checkbox_status: [],
            visible_columns: {},
            hideColumnToggleButton: props.hideColumnToggleButton ? props.hideColumnToggleButton : false,
            toolbar_suffix: props.toolbar_suffix,
            selected_count: props.selected_count,

        }
    }
    paginationSideCount = "Loading...";

    componentWillMount() {
        // this.checkboxMapping();
    }


    checkboxMapping(data) {
        let { checkbox_render } = this.state;

        let temp = [];
        let obj = {};
        let arr = {};
        let arr2 = [];
        if (data != undefined) {
            arr2 = data;
        }
        else {
            for (let i in product_column) {
                if (product_column[i]["key"] in this.props["visibleColumns"]) {
                    arr2.push(obj[product_column[i]["key"]] = [product_column[i]["key"], true, product_column[i]["name"]])
                } else {
                    arr2.push(obj[product_column[i]["key"]] = [product_column[i]["key"], false, product_column[i]["name"]])
                }
            }
        }
        for (let i = 0; i < arr2.length; i++) {
            if (arr2[i][0] == "check") {
                temp.push(<Checkbox
                    id={arr2[i][0]}
                    checked={true}
                    label={"MultiSelect"}
                    disabled={true}
                />
                )
            } else if (arr2[i][0] == "image") {
                temp.push(<Checkbox
                    id={arr2[i][0]}
                    checked={true}
                    label={arr2[i][2]}
                    disabled={true}
                />
                )
            }
            else if (arr2[i][0] == "title") {
                temp.push(<Checkbox
                    id={arr2[i][0]}
                    checked={true}
                    label={arr2[i][2]}
                    disabled={true}
                />
                )
            }
            else {
                temp.push(<Checkbox
                    id={arr2[i][0]}
                    checked={arr2[i][1]}
                    label={arr2[i][2]}
                    onChange={this.handleChangeCheck}
                />
                )
            }
            if (arr2[i][1]) {
                arr[arr2[i][0]] = arr2[i][1];
            }
        }
        this.setState({ checkbox_render: temp, checkbox_status: arr2, visible_columns: arr });
    }

    handleChangeCheck = (value, e) => {

        let { checkbox_status } = this.state;
        for (let i = 0; i < this.state.checkbox_status.length; i++) {
            if (this.state.checkbox_status[i][0] == e) {
                checkbox_status[i][1] = value
            }
            this.setState(this.state, () => {
                this.checkboxMapping(this.state.checkbox_status);
                this.columnModal();
            });
        }
        this.props.handleColumn(this.state.visible_columns);

    };

    columnModal() {
        return (
            <Modal
                title={"Columns"}
                open={this.state.showcolumns_modal}
                onClose={() => {
                    this.closecolumnModal();
                }}
            >
                <Modal.Section>
                    <Stack>
                        {this.state.checkbox_render}
                    </Stack>
                </Modal.Section>
            </Modal>
        );
    }

    closecolumnModal() {
        this.setState({ showcolumns_modal: false })
        this.props.handleColumn(this.state.visible_columns);
    }

    componentWillReceiveProps(nextProps, nextContext) {

        if (nextProps['massAction'] != undefined && nextProps['massAction'] !== []) {
            this.setState({ massAction: nextProps['massAction'] });
        }
    }

    handleChange = (key, value) => {
        // //console.log(key,value)
        let { pagination } = this.state;

        let paginate_string = " ";
        pagination = JSON.parse(JSON.stringify(pagination))
        pagination[key] = value;
        if (this.props.handlePagination !== undefined) {
            this.props.handlePagination(pagination);
        } else {
            // this.setState({pagination:pagination});
        }
        paginate_string = "Showing " + pagination.page - 1 * pagination.pageSize +
            " to " + pagination.page * pagination.pageSize +
            " of " + pagination.totalNumberOfItems;

        this.paginationSideCount = paginate_string;
    };

    performMassAction = (action) => {
        if (this.props.performMassAction !== undefined) {
            this.props.performMassAction(action);
        }
    };

    render() {
        let { massAction, pagination } = this.state;
        return (
            <div 
            // style={{ margin: '0px 20px 5px 5px' }}
            style={{ margin: '0px 20px 5px 0px' }}
            >
                <FormLayout>
                    <FormLayout.Group>
                        {this.state.showcolumns_modal && this.columnModal()}
                        <Stack >
                            <Stack.Item fill>
                                <Stack>
                                    {massAction.length ?
                                        this.props.selected_count > 0 ? <div style={{border: '2px solid #5E6CC5', borderRadius: '5px'}}>
                                        <Select
                                            label={"Mass Actions - " + this.props.selected_count}
                                            placeholder={'selected'}
                                            options={this.state.massAction}
                                            onChange={(e) => { this.performMassAction(e) }}
                                            labelInline />
                                        </div> : <Select
                                            label={"Mass Actions - " + this.props.selected_count}
                                            placeholder={'selected'}
                                            options={this.state.massAction}
                                            onChange={(e) => { this.performMassAction(e) }}
                                            labelInline />
                                        : null}
                                </Stack>
                            </Stack.Item>
                        </Stack>


                    </FormLayout.Group>
                </FormLayout>
            </div>
        );
    }
}

export default NewToolbar;
