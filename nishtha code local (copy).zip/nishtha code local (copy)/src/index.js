import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import '@shopify/polaris/dist/styles.css';
import {AppProvider,Page} from "@shopify/polaris";
import {BrowserRouter} from "react-router-dom";
import {NotificationContainer} from "react-notifications";
import { Provider } from 'react-redux';
import configureStore from "./store/configureStore";
import translations from "@shopify/polaris/locales/en.json";
//import history from './shared/history';

// function redirect(url){
//     console.log(history)
//     history.push(url)
//     //console.log("check",history.push(url));
// }
const theme = {
  
    colors: {
        // topBar: {
        //     backgroundColor: 'red',
        // },
        // topBar: {
        //     background: "red",
        //     primary: "red",
        // }
        // surface: 'green',
        // onSurface: 'blue'
      primary: '#084e8a',

    },
    // colorScheme: "dark",
    logo: {
        width: 219,
        topBarSource: require('./ced-ebay-logo.png'),
        //url: redirect('/panel/dashboard'),
        accessibilityLabel: 'CedCommerce',
    },
    
    
};

const store = configureStore();

ReactDOM.render(
  <BrowserRouter basename="/ebay/dev/app/">
        <AppProvider 
        theme={theme} 

//   theme={{
//     colors: {
//       surface: '#111213',
//       onSurface: '#111213',
//       interactive: '#2e72d2',
//       secondary: '#111213',
//       primary: '#3b5998',
//       critical: '#d82c0d',
//       warning: '#ffc453',
//       highlight: '#5bcdda',
//       success: '#008060',
//       decorative: '#ffc96b',
//     },
//   }}
        i18n={translations}>
            <Provider store={store}>
            <App />
            </Provider>
        </AppProvider>
        <NotificationContainer/>
    </BrowserRouter>, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
