import { combineReducers } from "redux";
import ebayReducer from './reducers/ebay/reducers';
export default combineReducers({
    ebay : ebayReducer
})