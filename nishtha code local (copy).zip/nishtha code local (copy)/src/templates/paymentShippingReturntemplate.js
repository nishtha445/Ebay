import React, { Component } from "react";
import {
  Badge,
  Banner,
  Button,
  Modal,
  TextContainer,
  Card,
  Checkbox,
  ChoiceList,
  FormLayout,
  Icon,
  Select,
  Stack,
  TextField,
} from "@shopify/polaris";
import { isUndefined } from "util";
import { notify } from "../services/notify";
import { requests } from "../services/request";

const ShippingPolicyServicetype = [
  { label: "Flat", value: "Flat" },
  { label: "Calculated", value: "Calculated" },
  {
    label: "Calculated Domestic Flat International",
    value: "CalculatedDomesticFlatInternational",
  },
  {
    label: "Flat Domestic Calculated International",
    value: "FlatDomesticCalculatedInternational",
  },
  // {label:'Freight',value:'FreightFlat'},
];

const countriestoInclude = [
  { value: "Worldwide", label: "Worldwide" },
  { value: "CA", label: "Canada" },
  { value: "Americas", label: "Americas" },
  { value: "Europe", label: "Europe" },
  { value: "Asia", label: "Asia" },
  { value: "AU", label: "Australia" },
  { value: "UK", label: "United Kingdom" },
  { value: "MX", label: "Mexico" },
  { value: "DE", label: "Germany" },
  { value: "JP", label: "Japan" },
  { value: "BR", label: "Brazil" },
  { value: "FR", label: "France" },
  { value: "CN", label: "China" },
  { value: "RU", label: "Russian Federation" },
  { value: "Africa", label: "Africa" },
  { value: "Caribbean", label: "Caribbean" },
  { value: "EuropeanUnion", label: " European Union" },
  { value: "CustomCode", label: "Reserved for internal or future use" },
  { value: "LatinAmerica", label: " Latin America" },
  { value: "MiddleEast", label: "Middle East" },
  { value: "None", label: "(description not yet available)" },
  { value: "NorthAmerica", label: " North America" },
  { value: "Oceania", label: " Oceania (Pacific region other than Asia)" },
  { value: "SouthAmerica", label: "South America" },
  // {value : 'WillNotShip ', label :' Seller will not ship the item.'},
];

let tempObjShippingserviceDomestic = {
  service: "",
  charges: "",
  codfee: "",
  free_shipping: false,
  additional_charges: "",
};
let tempObjShippingserviceInternational = {
  service: "",
  charges: "",
  additional_charges: "",
  codfee: "",
  ship_to: [],
};

class PaymentShippingReturn extends Component {
  constructor(props) {
    super(props);
    this.state = {
      site_id: "",
      isDestinationModalActive: false,
      isGlobalShippingModalActive: false,
      id: "",
      display: {
        payment_policy: false,
        return_policy: false,
        shipping_policy: false,
      },

      errors: {
        business_policies: {
          payment_policy: {
            existing_id: false,
            name: false,
            selected: false,
            paypal_email: false,
            motors: {
              paypal: false,
              deposit_details: {
                days_to_full_payment: false,
                deposit_amount: false,
                hours_to_deposit: false,
              },
            },
          },
          shipping_policy: {
            existing_id: false,
            name: false,
            domestic: {
              service_not_selected: false,
              null_services: [],
              handling_time: false,
              buyer_responsible_for_pickup: false,
              shipping_surcharge: false,
            },
            international: {
              service_not_selected: false,
              null_services: [],
              buyer_responsible_for_pickup: false,
              shipping_surcharge: false,
            },
            exclude_locations: false,
          },
          return_policy: {
            existing_id: false,
            name: false,
            domestic: {
              return_within: false,
              return_paid_by: false,
            },
          },
        },
      },

      dropdown: {
        shipping_policy: {
          selected_id: "",
          show_dropdown: false,
          options: [],
        },

        payment_policy: {
          selected_id: "",
          show_dropdown: false,
          options: [],
        },
        return_policy: {
          selected_id: "",
          show_dropdown: false,
          options: [],
        },
      },

      create_new_profile: {
        shipping_policy: false,
        payment_policy: false,
        return_policy: false,
      },

      product_details: {
        template_name: "",
      },
      selling_details: {
        /* format:'fixed_price',*/
        country: "US",
        /* listing_duration:'GTC',*/
        tax_percentage: "",
        shipping_include: false,
        item_location: {
          country: "",
          zipcode: "",
          city_state: "",
        },
      },
      shipping_policy: {
        name: "",
        service_type: "Flat",
        /*free_shipping:true,*/
        global_shipping: false,
        shipping_package_type: "",
        domestic: {
          /*additional_charges:0,*/
          buyer_responsible_for_shipping: false,
          buyer_responsible_for_pickup: "",
          shipping_surcharge: 0,
          handling_time: "1",
          handling_cost: 0,
          PromotionalShippingDiscount: "",
        },
        international: {
          /* additional_charges:0,*/
          buyer_responsible_for_shipping: false,
          buyer_responsible_for_pickup: "",
          shipping_surcharge: 0,
          handling_cost: 0,
          global_ship_to: [],
          InternationalPromotionalShippingDiscount: "",
        },
        shipping_service_domestic: [
          {
            service: "",
            charges: "",
            codfee: "",
            free_shipping: true,
            additional_charges: "",
          },
        ],
        shipping_service_international: [
          {
            service: "",
            charges: "",
            additional_charges: "",
            codfee: "",
            ship_to: [],
          },
        ],
        exclude_locations: false,
        excluded_shipping_location: [],
      },
      payment_policy: {
        immediate_pay: false,
        name: "",
        payment_methods: [],
        checkout_instruction: "",
        paypal_email: "",
        deposit_details: {
          days_to_full_payment: "",
          deposit_amount: "",
          hours_to_deposit: "",
        },
      },
      return_policy: {
        name: "",
        returns_accepted_option: true,
        return_accepted: ["domestic"],
        return_accepted_options: [
          { label: "Domestic returns accepted", value: "domestic" },
          /*  {label:'International returns accepted',value:'international'},*/
        ],
        return_option: "",
        domestic: {
          return_paid_by: "",
          return_within: "",
          replacement_exchange_available: false,
        },
        international: {
          return_paid_by: "",
          return_within: "",
          replacement_exchange_available: false,
        },
        return_description: "",
      },

      options_recieved: {
        shipping_service_options: {
          domestic: [],
          international: [],
        },
        return_policy: [],
        country: [],
        excluded_shipping_locations: [],
        payment_methods: [],
        shipping_service: {
          domestic: {
            Flat: [],
            Calculated: [],
            FreightFlat: [],
          },
          international: {
            Flat: [],
            Calculated: [],
            FreightFlat: [],
          },
        },
        handling_time: [],
        selected_domestic_service: "0",
      },
    };
    this.getShopdetails();
    this.showPolicy();
    this.assignData();
    // this.getSideID();
  }

  //-----------------------------------Extract Data From API Start------------------------------------//

  extractDispatchTimeMaxDetails(data) {
    let temparr = [];
    Object.keys(data).map((key) => {
      temparr.push({
        label: data[key]["Description"],
        value: data[key]["DispatchTimeMax"].toString(),
      });
    });
    this.state.options_recieved.handling_time = temparr;
    this.setState(this.state);
  }

  extractPaymentMethods(data) {
    let temparr = [];
    Object.keys(data).map((key) => {
      temparr.push({ label: data[key], value: data[key] });
    });
    this.state.options_recieved.payment_methods = temparr;
    this.setState(this.state);
  }
  setDestinationModalActive() {
    console.log("this", this);
    this.setState({
      isDestinationModalActive: !this.state.isDestinationModalActive,
    });
    //this.state.isModalActive=!(this.state.isModalActive)
  }
  setGlobalShippingModalActive() {
    this.setState({
      isGlobalShippingModalActive: !this.state.isGlobalShippingModalActive,
    });
  }
  extractExcludedLocations(data) {
    let temparr = [];
    Object.keys(data).map((key) => {
      temparr.push({
        label: data[key]["Description"],
        value: data[key]["Location"],
      });
    });
    this.state.options_recieved.excluded_shipping_locations = temparr;
    this.setState(this.state);
  }

  extractReturnPolicyServices(data) {
    let preparedObj = {};
    let tempObj = Object.assign({}, data);
    Object.keys(tempObj).map((key) => {
      if (typeof tempObj[key] === "object") {
        let temparr = [];
        Object.keys(tempObj[key]).map((Obj) => {
          temparr.push({
            label: tempObj[key][Obj]["Description"],
            value: tempObj[key][Obj][key + "Option"],
          });
        });
        preparedObj[key] = temparr;
      }
    });
    this.state.options_recieved["return_policy"] = preparedObj;
    this.setState(this.state);
  }

  extractCountryDetails(data) {
    let temparr = [];
    Object.keys(data).map((key) => {
      temparr.push({
        label: data[key]["Description"],
        value: data[key]["Country"],
      });
    });
    this.state.options_recieved.country = temparr;
    this.setState(this.state);
  }

  extractShippingDetails(data) {
    // console.log(data);

    let shipping_service = {
      domestic: {
        Flat: [],
        Calculated: [],
        FreightFlat: [],
      },
      international: {
        Flat: [],
        Calculated: [],
        FreightFlat: [],
      },
    };

    let analysis_arr = [];

    let levelTwoObject_categorywise = {
      domestic: {
        Flat: {},
        Calculated: {},
      },
      international: {
        Flat: {},
        Calculated: {},
      },
    };
    Object.keys(data).map((key) => {
      let options_analysis = {};
      options_analysis["category"] = data[key]["ShippingCategory"];
      options_analysis["label"] = data[key]["Description"];
      options_analysis["value"] = data[key]["ShippingService"];
      options_analysis["area"] = data[key]["InternationalService"]
        ? "international"
        : "domestic";
      let serviceTypePresent = [];
      if (!isUndefined(data[key]["ServiceType"])) {
        if (Array.isArray(data[key]["ServiceType"])) {
          serviceTypePresent = data[key]["ServiceType"].slice(0);
        } else {
          serviceTypePresent = Object.values(data[key]["ServiceType"]);
        }
      } else {
        serviceTypePresent = ["Flat", "Calculated"];
      }
      if (
        serviceTypePresent.indexOf("Flat") > -1 &&
        serviceTypePresent.indexOf("Calculated") > -1
      ) {
        options_analysis["service_type"] = "both";
      } else if (serviceTypePresent.indexOf("Flat") > -1) {
        options_analysis["service_type"] = "Flat";
      } else if (serviceTypePresent.indexOf("Calculated") > -1) {
        options_analysis["service_type"] = "Calculated";
      } else if (serviceTypePresent.indexOf("Freight") > -1) {
        options_analysis["service_type"] = "FreightFlat";
      }
      analysis_arr.push(options_analysis);
    });
    analysis_arr.forEach((value, index) => {
      if (value.service_type === "both") {
        levelTwoObject_categorywise[value.area].Flat[value.category] = [];
        levelTwoObject_categorywise[value.area].Calculated[value.category] = [];
      } else {
        if (
          isUndefined(
            levelTwoObject_categorywise[value.area][value.service_type]
          )
        ) {
          levelTwoObject_categorywise[value.area][value.service_type] = {};
          levelTwoObject_categorywise[value.area][value.service_type][
            value.category
          ] = [];
        } else {
          levelTwoObject_categorywise[value.area][value.service_type][
            value.category
          ] = [];
        }
      }
    });

    analysis_arr.forEach((value, index) => {
      if (value.service_type === "both") {
        levelTwoObject_categorywise[value.area].Flat[value.category].push({
          label: value.label,
          value: value.value,
        });
        levelTwoObject_categorywise[value.area].Calculated[value.category].push(
          { label: value.label, value: value.value }
        );
      } else {
        levelTwoObject_categorywise[value.area][value.service_type][
          value.category
        ].push({ label: value.label, value: value.value });
      }
    });

    Object.keys(levelTwoObject_categorywise).map((region) => {
      Object.keys(levelTwoObject_categorywise[region]).map((servicetype) => {
        Object.keys(levelTwoObject_categorywise[region][servicetype]).map(
          (heading) => {
            shipping_service[region][servicetype].push({
              title: heading,
              options:
                levelTwoObject_categorywise[region][servicetype][heading],
            });
          }
        );
      });
    });
    this.state.options_recieved.shipping_service = shipping_service;
    this.state.options_recieved.shipping_service_options.domestic =
      shipping_service.domestic.Flat;
    this.state.options_recieved.shipping_service_options.international =
      shipping_service.international.Flat;
    this.setState(this.state);
  }
  //-----------------------------------Extract Data From API End------------------------------------//

  // -----------------------------------Handle Error Functions Start------------------------------------//
  policyValidator(data) {
    let errors = 0;
    Object.keys(data).map((key) => {
      switch (key) {
        case "payment_policy":
          if (!isUndefined(data[key]["existing_id"])) {
            if (data[key]["existing_id"] === "") {
              this.state.errors.business_policies.payment_policy.existing_id = true;
              errors += 1;
            } else {
              this.state.errors.business_policies.payment_policy.existing_id = false;
            }
          } else {
            if (!isUndefined(data[key]["profile_data"])) {
              if (data[key]["profile_data"].name === "") {
                this.state.errors.business_policies.payment_policy.name = true;
                errors += 1;
              } else {
                this.state.errors.business_policies.payment_policy.name = false;
              }

              if (this.state.site_id === "MOTORS") {
                if (
                  data[key]["profile_data"].payment_methods.indexOf(
                    "PayPal"
                  ) === -1
                ) {
                  this.state.errors.business_policies.payment_policy.motors.paypal = true;
                  errors += 1;
                } else {
                  this.state.errors.business_policies.payment_policy.motors.paypal = false;
                }
                if (
                  data[key]["profile_data"].deposit_details.hours_to_deposit ===
                  ""
                ) {
                  this.state.errors.business_policies.payment_policy.motors.deposit_details.hours_to_deposit = true;
                  errors += 1;
                } else {
                  this.state.errors.business_policies.payment_policy.motors.deposit_details.hours_to_deposit = false;
                }
                if (
                  data[key]["profile_data"].deposit_details.deposit_amount ===
                  ""
                ) {
                  errors += 1;
                  this.state.errors.business_policies.payment_policy.motors.deposit_details.deposit_amount = true;
                } else {
                  this.state.errors.business_policies.payment_policy.motors.deposit_details.deposit_amount = false;
                }
                if (
                  data[key]["profile_data"].deposit_details
                    .days_to_full_payment === ""
                ) {
                  errors += 1;
                  this.state.errors.business_policies.payment_policy.motors.deposit_details.days_to_full_payment = true;
                } else {
                  this.state.errors.business_policies.payment_policy.motors.deposit_details.days_to_full_payment = false;
                }
              }

              if (
                false &&
                data[key]["profile_data"].payment_methods.length === 0
              ) {
                this.state.errors.business_policies.payment_policy.selected = true;
                errors += 1;
              } else {
                this.state.errors.business_policies.payment_policy.selected = false;
                if (
                  false &&
                  data[key]["profile_data"].payment_methods.indexOf("PayPal") >
                    -1
                ) {
                  if (
                    data[key]["profile_data"].paypal_email === "" &&
                    !RegExp(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/).test(
                      data[key]["profile_data"].paypal_email
                    )
                  ) {
                    this.state.errors.business_policies.payment_policy.paypal_email = true;
                    errors += 1;
                  } else {
                    this.state.errors.business_policies.payment_policy.paypal_email = false;
                  }
                }
              }
            }
          }
          break;
        case "shipping_policy":
          if (!isUndefined(data[key]["existing_id"])) {
            if (data[key]["existing_id"] === "") {
              this.state.errors.business_policies.shipping_policy.existing_id = true;
              errors += 1;
            } else {
              this.state.errors.business_policies.shipping_policy.existing_id = false;
            }
          } else {
            if (!isUndefined(data[key]["profile_data"])) {
              if (data[key]["profile_data"].name === "") {
                this.state.errors.business_policies.shipping_policy.name = true;
                errors += 1;
              } else {
                this.state.errors.business_policies.shipping_policy.name = false;
              }

              if (data[key]["profile_data"].domestic.handling_time === "") {
                this.state.errors.business_policies.shipping_policy.domestic.handling_time = true;
                errors += 1;
              } else {
                this.state.errors.business_policies.shipping_policy.domestic.handling_time = false;
              }
              if (this.state.site_id === "MOTORS") {
                if (
                  data[key]["profile_data"].domestic
                    .buyer_responsible_for_pickup === ""
                ) {
                  this.state.errors.business_policies.shipping_policy.domestic.buyer_responsible_for_pickup = true;
                  errors += 1;
                } else {
                  this.state.errors.business_policies.shipping_policy.domestic.buyer_responsible_for_pickup = false;
                }
                if (
                  data[key]["profile_data"].domestic.shipping_surcharge === ""
                ) {
                  this.state.errors.business_policies.shipping_policy.domestic.shipping_surcharge = true;
                  errors += 1;
                } else {
                  this.state.errors.business_policies.shipping_policy.domestic.shipping_surcharge = false;
                }
              }
              this.state.errors.business_policies.shipping_policy.domestic.null_services =
                [];
              data[key]["profile_data"].shipping_service_domestic.forEach(
                (value, index) => {
                  if (value.service === "") {
                    this.state.errors.business_policies.shipping_policy.domestic.null_services.push(
                      index + 1
                    );
                  }
                }
              );
              if (
                this.state.errors.business_policies.shipping_policy.domestic
                  .null_services.length !== 0
              ) {
                this.state.errors.business_policies.shipping_policy.domestic.service_not_selected = true;
                errors += 1;
              } else {
                this.state.errors.business_policies.shipping_policy.domestic.service_not_selected = false;
              }

              // if(data[key]['profile_data'].global_shipping){
              //
              if (this.state.site_id === "MOTORS") {
                if (
                  data[key]["profile_data"].international
                    .buyer_responsible_for_pickup === ""
                ) {
                  this.state.errors.business_policies.shipping_policy.international.buyer_responsible_for_pickup = true;
                  errors += 1;
                } else {
                  this.state.errors.business_policies.shipping_policy.international.buyer_responsible_for_pickup = false;
                }
                if (
                  data[key]["profile_data"].international.shipping_surcharge ===
                  ""
                ) {
                  this.state.errors.business_policies.shipping_policy.international.shipping_surcharge = true;
                  errors += 1;
                } else {
                  this.state.errors.business_policies.shipping_policy.international.shipping_surcharge = false;
                }
              }
              //
              //     this.state.errors.business_policies.shipping_policy.international.null_services=[];
              //     data[key]['profile_data'].shipping_service_international.forEach((value,index)=>{
              //         if(value.service==='')
              //         {
              //             this.state.errors.business_policies.shipping_policy.international.null_services.push(index+1);
              //         }
              //     });
              //     if(this.state.errors.business_policies.shipping_policy.international.null_services.length !==0)
              //     {
              //         this.state.errors.business_policies.shipping_policy.international.service_not_selected=true;
              //         errors+=1;
              //     }
              //     else{
              //         this.state.errors.business_policies.shipping_policy.international.service_not_selected=false;
              //     }
              // }
              // else{
              //     this.state.errors.business_policies.shipping_policy.international.service_not_selected=false;
              // }
            }
          }
          break;

        case "return_policy":
          if (!isUndefined(data[key]["existing_id"])) {
            if (data[key]["existing_id"] === "") {
              this.state.errors.business_policies.return_policy.existing_id = true;
              errors += 1;
            } else {
              this.state.errors.business_policies.return_policy.existing_id = false;
            }
          } else {
            if (!isUndefined(data[key]["profile_data"])) {
              if (data[key]["profile_data"].name === "") {
                this.state.errors.business_policies.return_policy.name = true;
                errors += 1;
              } else {
                this.state.errors.business_policies.return_policy.name = false;
              }
              if (data[key]["profile_data"].returns_accepted_option) {
                if (data[key]["profile_data"].domestic.return_paid_by === "") {
                  this.state.errors.business_policies.return_policy.domestic.return_paid_by = true;
                  errors += 1;
                } else {
                  this.state.errors.business_policies.return_policy.domestic.return_paid_by = false;
                }
                if (data[key]["profile_data"].domestic.return_within === "") {
                  this.state.errors.business_policies.return_policy.domestic.return_within = true;
                  errors += 1;
                } else {
                  this.state.errors.business_policies.return_policy.domestic.return_within = false;
                }
              }
            }
          }
          break;
      }
    });
    this.setState(this.state);
    if (errors > 0) {
      return false;
    } else {
      return true;
    }
  }

  //-----------------------------------Handle Error Functions End------------------------------------//

  //-----------------------------------Render Functions------------------------------------//
  render() {
    return (
      //<Card  actions={!isUndefined(this.props.showSave) && this.props.showSave?[{content:'Save',onAction:this.saveAllprofiles.bind(this)}]:[]}>*/}
      //<Card.Section>
      <FormLayout>
        {this.state.display.payment_policy && (
          <Banner status={"info"}>
            <b>Payment policy</b> helps you to assign multiple payment options
            also you can provide checkout instructions.
          </Banner>
        )}
        {this.state.display.payment_policy && (
          <Card
            title={"Payment policy"}
            actions={[
              {
                content: (
                  <Badge status={"info"}>
                    <b>Need help?</b>
                  </Badge>
                ),
                onAction: () => {
                  window.open(
                    "https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=pym-poli",
                    "_blank"
                  );
                },
              },
            ]}
          >
            <Card.Section>{this.renderPaymentOption()}</Card.Section>
            {this.state.site_id === "MOTORS" && (
              <Card.Section title={"Deposit details"}>
                <FormLayout>
                  <FormLayout.Group>
                    <TextField
                      label="Days to full payment"
                      key={"Days to full payment"}
                      type={"number"}
                      error={
                        this.state.errors.business_policies.payment_policy
                          .motors.deposit_details.days_to_full_payment
                          ? " "
                          : ""
                      }
                      helpText={"*required"}
                      value={
                        this.state.payment_policy.deposit_details
                          .days_to_full_payment
                      }
                      onChange={this.feildsChangePaymentLevelTwo.bind(
                        this,
                        "deposit_details",
                        "days_to_full_payment"
                      )}
                    />
                    <TextField
                      label="Deposit Amount"
                      key={"depositAmount"}
                      type={"number"}
                      error={
                        this.state.errors.business_policies.payment_policy
                          .motors.deposit_details.deposit_amount
                          ? " "
                          : ""
                      }
                      helpText={"*required"}
                      value={
                        this.state.payment_policy.deposit_details.deposit_amount
                      }
                      onChange={this.feildsChangePaymentLevelTwo.bind(
                        this,
                        "deposit_details",
                        "deposit_amount"
                      )}
                    />
                    <TextField
                      label="Hour's to deposit"
                      key={"HourTodeposit"}
                      type={"number"}
                      error={
                        this.state.errors.business_policies.payment_policy
                          .motors.deposit_details.hours_to_deposit
                          ? " "
                          : ""
                      }
                      helpText={"*required"}
                      value={
                        this.state.payment_policy.deposit_details
                          .hours_to_deposit
                      }
                      onChange={this.feildsChangePaymentLevelTwo.bind(
                        this,
                        "deposit_details",
                        "hours_to_deposit"
                      )}
                    />
                  </FormLayout.Group>
                </FormLayout>
              </Card.Section>
            )}
          </Card>
        )}
        {this.state.display.shipping_policy && (
          <Banner status={"info"}>
            <b>Shipping policy</b> helps you to assign shipping services,
            handling time, charges and much more both for global and domestic
            shipping.
          </Banner>
        )}
        {this.state.display.shipping_policy && (
          <Card
            title={"Shipping policy"}
            actions={[
              {
                content: (
                  <Badge status={"info"}>
                    <b>Need help?</b>
                  </Badge>
                ),
                onAction: () => {
                  window.open(
                    "https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=shp-poli",
                    "_blank"
                  );
                },
              },
            ]}
          >
            <Card.Section>
              <TextField
                label="Shipping Profile Name"
                key={"Shipping Profile Name"}
                type="text"
                error={
                  this.state.errors.business_policies.shipping_policy.name
                    ? " "
                    : ""
                }
                helpText={"*required"}
                value={this.state.shipping_policy.name}
                onChange={this.nameFeildChange.bind(
                  this,
                  "shipping_policy",
                  "name"
                )}
              />
              <br />
              {this.renderShippingPolicy()}
            </Card.Section>
          </Card>
        )}
        {this.state.display.return_policy && (
          <Banner status={"info"}>
            <b>Return policy</b> helps you to assign features like whether you
            accept returns or not and if yes then you can provide refund options
            ,contact duration and who will pay for return shipping.
          </Banner>
        )}
        {this.state.display.return_policy && (
          <Card
            title={"Return Policy"}
            actions={[
              {
                content: (
                  <Badge status={"info"}>
                    <b>Need help?</b>
                  </Badge>
                ),
                onAction: () => {
                  window.open(
                    "https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=ret_policy",
                    "_blank"
                  );
                },
              },
            ]}
          >
            <Card.Section>
              <Stack spacing={"loose"} vertical={true}>
                <TextField
                  label="Return Profile Name"
                  key={"Return Profile Name"}
                  type="text"
                  error={
                    this.state.errors.business_policies.return_policy.name
                      ? " "
                      : ""
                  }
                  helpText={"*required"}
                  value={this.state.return_policy.name}
                  onChange={this.nameFeildChange.bind(
                    this,
                    "return_policy",
                    "name"
                  )}
                />
                <Checkbox
                  key={"reTurnAccepted"}
                  checked={this.state.return_policy.returns_accepted_option}
                  label="Returns accepted"
                  onChange={this.feildsChange.bind(
                    this,
                    "return_policy",
                    "returns_accepted_option"
                  )}
                />
                {this.state.return_policy.returns_accepted_option &&
                  !isUndefined(
                    this.state.options_recieved.return_policy.Refund
                  ) &&
                  this.state.options_recieved.return_policy.Refund.length >
                    0 && (
                    <Select
                      key={"selectReturnoption"}
                      options={
                        !isUndefined(
                          this.state.options_recieved.return_policy
                        ) &&
                        !isUndefined(
                          this.state.options_recieved.return_policy.Refund
                        )
                          ? this.state.options_recieved.return_policy.Refund
                          : []
                      }
                      label={"Refund Option"}
                      value={this.state.return_policy.return_option}
                      onChange={this.feildsChange.bind(
                        this,
                        "return_policy",
                        "return_option"
                      )}
                    />
                  )}
                {this.state.return_policy.returns_accepted_option &&
                  this.renderReturnPolicy()}
                {this.returnDescriptionReturn()}
              </Stack>
            </Card.Section>
          </Card>
        )}
      </FormLayout>
      // </Card.Section>
      // </Card>
    );
  }

  renderShippingPolicy() {
    let temparr = [];
console.log("state",this.state)
    temparr.push(
      <Stack vertical={true} key={"Shipping PolicyCard"}>
        <Stack vertical={false}>
          <Stack.Item fill>
            <Select
              key={"selectShippingpolicytype"}
              options={ShippingPolicyServicetype}
              label={"Service Type"}
              value={this.state.shipping_policy.service_type}
              onChange={this.feildsChange.bind(
                this,
                "shipping_policy",
                "service_type"
              )}
            />
          </Stack.Item>
          {/*<div style={{marginTop:"3rem"}}>*/}
          {/*<Checkbox*/}
          {/*checked={this.state.shipping_policy.free_shipping}*/}
          {/*label="Free Shipping"*/}
          {/*onChange={this.feildsChange.bind(this,'shipping_policy','free_shipping')}/>*/}
          {/*</div>*/}
          {this.state.shipping_policy.service_type !== "FreightFlat" && (
            <div style={{ marginTop: "3rem" }}>
              <Checkbox
                checked={this.state.shipping_policy.global_shipping}
                label="Global Shipping"
                onChange={this.feildsChange.bind(
                  this,
                  "shipping_policy",
                  "global_shipping"
                )}
                helpText={
                  <Badge status={"attention"}>
                    <p
                      onClick={(e) => {
                        window.open(
                          "https://www.ebay.com/help/global-shipping-program/default/global-shipping-program?id=4646",
                          "_blank"
                        );
                        e.preventDefault();
                      }}
                    >
                      Learn more
                    </p>
                  </Badge>
                }
              />
            </div>
          )}
        </Stack>

        {this.state.shipping_policy.service_type !== "FreightFlat" && (
          <Card
            title={"Domestic Shipping Services"}
            actions={[
              {
                content: "Add services",
                onAction: this.Addserives.bind(this, "domestic"),
                disabled:
                  this.state.shipping_policy.shipping_service_domestic.length >
                  3,
              },
            ]}
          >
            {this.state.errors.business_policies.shipping_policy.domestic
              .service_not_selected && (
              <Card.Section>
                <Banner status={"critical"}>
                  <p>
                    <b>Shipping services</b> is a required field,Kindly select a
                    value for{" "}
                    {this.state.errors.business_policies.shipping_policy.domestic.null_services.join(
                      ","
                    )}{" "}
                    services below
                  </p>
                </Banner>
              </Card.Section>
            )}
            <Card.Section>{this.getShippingPolicydomestic()}</Card.Section>
            <Card.Section>
              <FormLayout>
                <FormLayout.Group condensed>
                  {/*<TextField*/}
                  {/*label="Additional Charges"*/}
                  {/*key={'DomesticAdditionalCharges'}*/}
                  {/*prefix={"$"}*/}
                  {/*value={this.state.shipping_policy.domestic.additional_charges}*/}
                  {/*onChange={this.handleshippingPOlicyLevelTwo.bind(this,'domestic','additional_charges')}*/}
                  {/*/>*/}
                  <Select
                    key={"selectdomesticHandlingTime"}
                    options={this.state.options_recieved.handling_time}
                    label={"Handling Time"}
                    value={this.state.shipping_policy.domestic.handling_time}
                    error={
                      this.state.errors.business_policies.shipping_policy
                        .domestic.handling_time
                        ? "*required field"
                        : ""
                    }
                    onChange={this.handleshippingPOlicyLevelTwo.bind(
                      this,
                      "domestic",
                      "handling_time"
                    )}
                  />
                  {this.state.shipping_policy.service_type !== "Flat" &&
                    this.state.shipping_policy.service_type !==
                      "FlatDomesticCalculatedInternational" && (
                      <TextField
                        label="Handling Cost"
                        key={"DomesticHandCharges"}
                        prefix={"$"}
                        value={
                          this.state.shipping_policy.domestic.handling_cost
                        }
                        onChange={this.handleshippingPOlicyLevelTwo.bind(
                          this,
                          "domestic",
                          "handling_cost"
                        )}
                      />
                    )}
                  <div style={{ marginTop: "3rem" }}>
                    <Checkbox
                      checked={
                        this.state.shipping_policy.domestic
                          .PromotionalShippingDiscount
                      }
                      label="Promotional shipping discount"
                      onChange={this.handleshippingPOlicyLevelTwo.bind(
                        this,
                        "domestic",
                        "PromotionalShippingDiscount"
                      )}
                    />
                  </div>
                </FormLayout.Group>
              </FormLayout>
            </Card.Section>
            {this.state.site_id === "MOTORS" && (
              <Card.Section>
                <FormLayout>
                  <FormLayout.Group condensed>
                    <Select
                      key={"BuyerResponsibleForpickup"}
                      options={[
                        { label: "Yes", value: "yes" },
                        { label: "No", value: "no" },
                      ]}
                      label={"Buyer responsible for pickup"}
                      placeholder={"Please select ..."}
                      value={
                        this.state.shipping_policy.domestic
                          .buyer_responsible_for_pickup
                      }
                      error={
                        this.state.errors.business_policies.shipping_policy
                          .domestic.buyer_responsible_for_pickup
                          ? "*required field"
                          : ""
                      }
                      onChange={this.handleshippingPOlicyLevelTwo.bind(
                        this,
                        "domestic",
                        "buyer_responsible_for_pickup"
                      )}
                    />
                    <TextField
                      label="Shipping surcharge"
                      key={"ShippingSurcharge"}
                      type={"number"}
                      value={
                        this.state.shipping_policy.domestic.shipping_surcharge
                      }
                      onChange={this.handleshippingPOlicyLevelTwo.bind(
                        this,
                        "domestic",
                        "shipping_surcharge"
                      )}
                    />
                    <div style={{ marginTop: "3rem" }}>
                      <Checkbox
                        checked={
                          this.state.shipping_policy.domestic
                            .buyer_responsible_for_shipping
                        }
                        label="Buyer responsible for shipping"
                        onChange={this.handleshippingPOlicyLevelTwo.bind(
                          this,
                          "domestic",
                          "buyer_responsible_for_shipping"
                        )}
                      />
                    </div>
                  </FormLayout.Group>
                </FormLayout>
              </Card.Section>
            )}
          </Card>
        )}
        {this.state.shipping_policy.service_type !== "FreightFlat" && (
          <Card
            title={"International Shipping Services"}
            actions={[
              {
                content: "Add services",
                onAction: this.Addserives.bind(this, "international"),
                disabled:
                  this.state.shipping_policy.shipping_service_international
                    .length > 4,
              },
            ]}
          >
            {this.state.errors.business_policies.shipping_policy.international
              .service_not_selected && (
              <Card.Section>
                <Banner status={"critical"}>
                  <p>
                    <b>Shipping Services</b> is a required field,Kindly select a
                    value for{" "}
                    {this.state.errors.business_policies.shipping_policy.international.null_services.join(
                      ","
                    )}{" "}
                    services below
                  </p>
                </Banner>
              </Card.Section>
            )}
            <Card.Section>{this.getShippingPolicyInternational()}</Card.Section>
            <Card.Section>
              <FormLayout>
                <FormLayout.Group condensed>
                  {this.state.shipping_policy.service_type !== "Flat" &&
                    this.state.shipping_policy.service_type !==
                      "CalculatedDomesticFlatInternational" && (
                      <TextField
                        label="Handling Cost"
                        key={"DomesticHandCharges"}
                        prefix={"$"}
                        value={
                          this.state.shipping_policy.international.handling_cost
                        }
                        onChange={this.handleshippingPOlicyLevelTwo.bind(
                          this,
                          "international",
                          "handling_cost"
                        )}
                      />
                    )}
                  <div style={{ marginTop: "3rem" }}>
                    <Checkbox
                      checked={
                        this.state.shipping_policy.international
                          .InternationalPromotionalShippingDiscount
                      }
                      label="Promotional shipping discount"
                      onChange={this.handleshippingPOlicyLevelTwo.bind(
                        this,
                        "international",
                        "InternationalPromotionalShippingDiscount"
                      )}
                    />
                  </div>
                  <div
                    style={{
                      marginTop: "25px",
                      position: "relative",
                      left: "190px",
                    }}
                  >
                    <Button
                      primary
                      
                      onClick={this.setGlobalShippingModalActive.bind(this)}
                    >
                      Choose global shipping destinations
                    </Button>
                    <Modal
                      key={"ShiptoDestinationalAreasInternational"}
                      open={this.state.isGlobalShippingModalActive}
                      onClose={this.setGlobalShippingModalActive.bind(this)}
                      title="Choose global shipping destinations"
                      primaryAction={{
                        content: "Save",
                        onAction: this.setGlobalShippingModalActive.bind(this),
                      }}
                    >
                      <Modal.Section>
                        <TextContainer>
                          <p>
                          <div className="row">
                        <div className="col-md-6">
                            <ChoiceList
                              key={"ShiptoDestinationalAreasInternational"}
                             
                              allowMultiple
                              choices={countriestoInclude.slice(0,countriestoInclude.length/2)}
                              selected={
                                this.state.shipping_policy.international
                                  .global_ship_to
                              }
                              onChange={this.handleshippingPOlicyLevelTwo.bind(
                                this,
                                "international",
                                "global_ship_to"
                              )}
                            />
                            </div>
                            <div className="col-md-6">
                            <ChoiceList
                              key={"ShiptoDestinationalAreasInternational"}
                           
                              allowMultiple
                              choices={countriestoInclude.slice(countriestoInclude.length/2,countriestoInclude.length)}
                              selected={
                                this.state.shipping_policy.international
                                  .global_ship_to
                              }
                              onChange={this.handleshippingPOlicyLevelTwo.bind(
                                this,
                                "international",
                                "global_ship_to"
                              )}
                            />
                            </div>
                           
                            </div>
                          </p>
                        </TextContainer>
                      </Modal.Section>
                    </Modal>
                  </div>
                </FormLayout.Group>
              </FormLayout>
            </Card.Section>
            {this.state.site_id === "MOTORS" && (
              <Card.Section>
                <FormLayout>
                  <FormLayout.Group condensed>
                    <Select
                      key={"BuyerResponsibleForpickup"}
                      options={[
                        { label: "Yes", value: "yes" },
                        { label: "No", value: "no" },
                      ]}
                      label={"Buyer responsible for pickup"}
                      placeholder={"Please select ..."}
                      value={
                        this.state.shipping_policy.international
                          .buyer_responsible_for_pickup
                      }
                      error={
                        this.state.errors.business_policies.shipping_policy
                          .international.buyer_responsible_for_pickup
                          ? "*required field"
                          : ""
                      }
                      onChange={this.handleshippingPOlicyLevelTwo.bind(
                        this,
                        "international",
                        "buyer_responsible_for_pickup"
                      )}
                    />
                    <div style={{ marginTop: "3rem" }}>
                      <Checkbox
                        checked={
                          this.state.shipping_policy.international
                            .buyer_responsible_for_shipping
                        }
                        label="Buyer responsible for shipping"
                        onChange={this.handleshippingPOlicyLevelTwo.bind(
                          this,
                          "international",
                          "buyer_responsible_for_shipping"
                        )}
                      />
                    </div>
                    <TextField
                      label="Shipping surcharge"
                      key={"ShippingSurcharge"}
                      type={"number"}
                      value={
                        this.state.shipping_policy.international
                          .shipping_surcharge
                      }
                      onChange={this.handleshippingPOlicyLevelTwo.bind(
                        this,
                        "international",
                        "shipping_surcharge"
                      )}
                    />
                  </FormLayout.Group>
                </FormLayout>
              </Card.Section>
            )}
          </Card>
        )}
      </Stack>
    );

    return temparr;
  }

  getShippingPolicydomestic() {
    //console.log("Choose Destination",this.state.shipping_policy.shipping_service_international)
    //console.log("Choose global shipping destinations",this.state.shipping_policy.international.global_ship_to)
    let temparr = [];
    this.state.shipping_policy.shipping_service_domestic.forEach(
      (service, index) => {
        temparr.push(
          <Card
            title={"#" + (index + 1)}
            key={"ShippingDomesticCard" + index}
            actions={[
              {
                content: "Delete service",
                onAction: this.deleteService.bind(this, "domestic", index),
                disabled:
                  this.state.shipping_policy.shipping_service_domestic
                    .length === 1,
              },
            ]}
          >
            <Card.Section>
              <FormLayout>
                <FormLayout.Group condensed>
                  <Select
                    key={"ServiceTypeShipping" + index}
                    options={
                      this.state.options_recieved.shipping_service_options
                        .domestic
                    }
                    label={"Shipping Services"}
                    placeholder={"Select..."}
                    value={
                      this.state.shipping_policy.shipping_service_domestic[
                        index
                      ].service
                    }
                    onChange={this.handleShippingPolicyService.bind(
                      this,
                      "shipping_service_domestic",
                      index,
                      "service"
                    )}
                  />
                  {this.state.shipping_policy.service_type !== "Calculated" &&
                    this.state.shipping_policy.service_type !==
                      "CalculatedDomesticFlatInternational" && (
                      <TextField
                        label="Charges"
                        key={"DomesticCharges" + index}
                        type={"number"}
                        value={
                          this.state.shipping_policy.shipping_service_domestic[
                            index
                          ].charges
                        }
                        disabled={
                          this.state.shipping_policy.shipping_service_domestic[
                            index
                          ].free_shipping
                        }
                        onChange={this.handleShippingPolicyService.bind(
                          this,
                          "shipping_service_domestic",
                          index,
                          "charges"
                        )}
                      />
                    )}
                  {this.state.shipping_policy.service_type !== "Calculated" &&
                    this.state.shipping_policy.service_type !==
                      "CalculatedDomesticFlatInternational" && (
                      <TextField
                        label="Additional charges"
                        key={"Additionalcharges" + index}
                        type={"number"}
                        value={
                          this.state.shipping_policy.shipping_service_domestic[
                            index
                          ].additional_charges
                        }
                        disabled={
                          this.state.shipping_policy.shipping_service_domestic[
                            index
                          ].free_shipping
                        }
                        onChange={this.handleShippingPolicyService.bind(
                          this,
                          "shipping_service_domestic",
                          index,
                          "additional_charges"
                        )}
                      />
                    )}
                  <TextField
                    label="COD fee"
                    key={"Codfee" + index}
                    type={"number"}
                    value={
                      this.state.shipping_policy.shipping_service_domestic[
                        index
                      ].codfee
                    }
                    onChange={this.handleShippingPolicyService.bind(
                      this,
                      "shipping_service_domestic",
                      index,
                      "codfee"
                    )}
                  />
                  <div style={{ marginTop: "3rem" }}>
                    <Checkbox
                      key={"Free shipping" + index}
                      checked={
                        this.state.shipping_policy.shipping_service_domestic[
                          index
                        ].free_shipping
                      }
                      label={"Free shipping"}
                      disabled={
                        this.state.options_recieved
                          .selected_domestic_service !== "null" &&
                        index.toString() !==
                          this.state.options_recieved.selected_domestic_service
                      }
                      onChange={this.handleShippingPolicyService.bind(
                        this,
                        "shipping_service_domestic",
                        index,
                        "free_shipping"
                      )}
                    />
                  </div>
                </FormLayout.Group>
              </FormLayout>
            </Card.Section>
          </Card>
        );
      }
    );
    return temparr;
  }

  getShippingPolicyInternational() {
    let temparr = [];
    this.state.shipping_policy.shipping_service_international.forEach(
      (service, index) => {
        temparr.push(
          <Card
            title={"#" + (index + 1)}
            key={"ShippingPolicyinternationalCard" + index}
            actions={[
              {
                content: "Delete service",
                onAction: this.deleteService.bind(this, "international", index),
                disabled:
                  this.state.shipping_policy.shipping_service_international
                    .length === 1,
              },
            ]}
          >
            <Card.Section>
              <FormLayout>
                <FormLayout.Group condensed>
                  <div style={{ maxWidth: "26rem" }}>
                    <Select
                      key={"ServiceTypeShipping" + index}
                      options={
                        this.state.options_recieved.shipping_service_options
                          .international
                      }
                      label={"Shipping Services"}
                      placeholder={"Select..."}
                      value={
                        this.state.shipping_policy
                          .shipping_service_international[index].service
                      }
                      onChange={this.handleShippingPolicyService.bind(
                        this,
                        "shipping_service_international",
                        index,
                        "service"
                      )}
                    />
                  </div>
                  {this.state.shipping_policy.service_type !== "Calculated" &&
                    this.state.shipping_policy.service_type !==
                      "FlatDomesticCalculatedInternational" && (
                      <TextField
                        label="Charges"
                        key={"InternationalCharges" + index}
                        type={"number"}
                        value={
                          this.state.shipping_policy
                            .shipping_service_international[index].charges
                        }
                        onChange={this.handleShippingPolicyService.bind(
                          this,
                          "shipping_service_international",
                          index,
                          "charges"
                        )}
                      />
                    )}
                  {this.state.shipping_policy.service_type !== "Calculated" &&
                    this.state.shipping_policy.service_type !==
                      "FlatDomesticCalculatedInternational" && (
                      <TextField
                        label="Additional charges"
                        key={"Additionalcharges" + index}
                        type={"number"}
                        value={
                          this.state.shipping_policy
                            .shipping_service_international[index]
                            .additional_charges
                        }
                        onChange={this.handleShippingPolicyService.bind(
                          this,
                          "shipping_service_international",
                          index,
                          "additional_charges"
                        )}
                      />
                    )}
                  <TextField
                    label="COD fee"
                    key={"codfeeInternational" + index}
                    type={"number"}
                    value={
                      this.state.shipping_policy.shipping_service_international[
                        index
                      ].codfee
                    }
                    onChange={this.handleShippingPolicyService.bind(
                      this,
                      "shipping_service_international",
                      index,
                      "codfee"
                    )}
                  />
                  {/*<div style={{marginTop:'3rem'}}>*/}
                  {/*<Checkbox*/}
                  {/*key={"Free shipping"+index}*/}
                  {/*checked={this.state.shipping_policy.shipping_service_international[index].free_shipping}*/}
                  {/*label={"Free shipping"}*/}
                  {/*onChange={this.handleShippingPolicyService.bind(this, 'shipping_service_international', index, 'free_shipping')}*/}
                  {/*/>*/}
                  {/*</div>*/}
                  {/*{this.state.shipping_policy.service_type !== 'Calculated' && this.state.shipping_policy.service_type !== 'FlatDomesticCalculatedInternational' &&*/}

                  {/*<Select*/}
                  {/*key={'Ship to'}*/}
                  {/*options={InternationalShippingtoChoice}*/}
                  {/*label={'Ship to'}*/}
                  {/*value={this.state.shipping_policy.shipping_service_international[index].ship_to}*/}
                  {/*onChange={this.handleShippingPolicyService.bind(this, 'shipping_service_international', index, 'ship_to')}/>*/}
                  {/*}*/}

                  {/*{*/}
                  {/*this.state.shipping_policy.shipping_service_international[index].ship_to === 'custom' &&*/}
                  <div style={{ marginTop: "28px" }}>
                    <Button
                      primary
                      onClick={this.setDestinationModalActive.bind(this)}
                    >
                      Choose Destination
                    </Button>
                    <Modal
                      key={"DestinationalAreasInternational" + index}
                      open={this.state.isDestinationModalActive}
                      onClose={this.setDestinationModalActive.bind(this)}
                      title="Choose Destination"
                      primaryAction={{
                        content: "Save",
                        onAction: this.setDestinationModalActive.bind(this),
                      }}
                    >
                      <Modal.Section>
                        <TextContainer>
                          <p>
                            <div className="row">
                              <div className="col-md-6">
                                <ChoiceList
                                  key={
                                    "DestinationalAreasInternational" + index
                                  }
                                  allowMultiple
                                  choices={countriestoInclude.slice(0,countriestoInclude.length/2)}
                                  selected={
                                    this.state.shipping_policy
                                      .shipping_service_international[index]
                                      .ship_to
                                  }
                                  onChange={this.handleShippingPolicyService.bind(
                                    this,
                                    "shipping_service_international",
                                    index,
                                    "ship_to"
                                  )}
                                ></ChoiceList>
                              </div>
                              <div className="col-md-6">
                                <ChoiceList
                                  key={
                                    "DestinationalAreasInternational" + index
                                  }
                                  allowMultiple
                                  choices={countriestoInclude.slice(countriestoInclude.length/2,countriestoInclude.length)}
                                  selected={
                                    this.state.shipping_policy
                                      .shipping_service_international[index]
                                      .ship_to
                                  }
                                  onChange={this.handleShippingPolicyService.bind(
                                    this,
                                    "shipping_service_international",
                                    index,
                                    "ship_to"
                                  )}
                                ></ChoiceList>
                              </div>
                            </div>
                          </p>
                        </TextContainer>
                      </Modal.Section>
                    </Modal>
                    {/*<ChoiceList
                                        key={'DestinationalAreasInternational' + index}
                                        title={'Choose Destination'}
                                        allowMultiple
                                        choices={countriestoInclude}
                                        selected={this.state.shipping_policy.shipping_service_international[index].ship_to}
                                        onChange={this.handleShippingPolicyService.bind(this, 'shipping_service_international', index, 'ship_to')}
                                    />*/}
                  </div>
                  {/*}*/}
                </FormLayout.Group>
              </FormLayout>
            </Card.Section>
          </Card>
        );
      }
     
    );
    console.log("states",temparr)
    return temparr;
  }

  renderPaymentOption() {
    let temparr = [];
    temparr.push(
      <Stack vertical={true} distribution={"fillEvenly"} key={"paymentLayout"}>
        <TextField
          label="Payment Profile Name"
          key={"Payment Profile Name"}
          type="text"
          error={
            this.state.errors.business_policies.payment_policy.name ? " " : ""
          }
          helpText={"*required"}
          value={this.state.payment_policy.name}
          onChange={this.nameFeildChange.bind(this, "payment_policy", "name")}
        />
        <Checkbox
          key={"chooseImmediatePay"}
          checked={this.state.payment_policy.immediate_pay}
          label="Immediate Pay"
          onChange={this.feildsChange.bind(
            this,
            "payment_policy",
            "immediate_pay"
          )}
        />
        {this.state.site_id === "MOTORS" &&
          this.state.errors.business_policies.payment_policy.motors.paypal && (
            <Banner status={"critical"}>
              <p>Paypal is a required payment method for your site</p>
            </Banner>
          )}
        <ChoiceList
          key={"paymentOption"}
          title={"Payment Options"}
          allowMultiple
          error={
            this.state.errors.business_policies.payment_policy.selected
              ? "*atleast one payment method is required"
              : ""
          }
          choices={
            this.state.payment_policy.immediate_pay
              ? [{ label: "PayPal", value: "PayPal", disabled: true }]
              : this.state.options_recieved.payment_methods
          }
          selected={this.state.payment_policy.payment_methods}
          onChange={this.feildsChange.bind(
            this,
            "payment_policy",
            "payment_methods"
          )}
        />
        {this.state.payment_policy.payment_methods.indexOf("PayPal") > -1 && (
          <TextField
            label="Paypal email"
            key={"Paypal Email"}
            type="email"
            error={
              this.state.errors.business_policies.payment_policy.paypal_email
                ? " "
                : ""
            }
            helpText={"*required"}
            value={this.state.payment_policy.paypal_email}
            onChange={this.feildsChange.bind(
              this,
              "payment_policy",
              "paypal_email"
            )}
          />
        )}
        <TextField
          label="Additional checkout instruction"
          key={"Additional checkout instruction"}
          value={this.state.payment_policy.checkout_instruction}
          onChange={this.feildsChange.bind(
            this,
            "payment_policy",
            "checkout_instruction"
          )}
          helpText={
            "This free-form string field allows the seller to give payment instructions to the buyer. These instructions will appear on eBay's view item and checkout pages."
          }
          multiline={3}
        />
      </Stack>
    );
    return temparr;
  }

  renderReturnPolicy() {
    let temparr = [];
    temparr.push(
      <FormLayout key={"returnPolicy"}>
        {/*<ChoiceList*/}
        {/*key={'returnPolicytypes'}*/}
        {/*title={'Return types'}*/}
        {/*allowMultiple*/}
        {/*choices={this.state.return_policy.return_accepted_options}*/}
        {/*selected={this.state.return_policy.return_accepted}*/}
        {/*onChange={this.feildsChange.bind(this,'return_policy','return_accepted')}*/}
        {/*/>*/}
        {/*<FormLayout.Group condensed>*/}
        {/*{this.state.return_policy.return_accepted.indexOf('domestic') > -1 &&*/}
        {/*<Card title={'Domestic returns settings'}>*/}
        {/*<Card.Section>*/}
        {/*<Stack vertical={true}>*/}
        <Select
          key={"DomesticcontactWithin"}
          options={
            !isUndefined(
              this.state.options_recieved.return_policy.ReturnsWithin
            )
              ? this.state.options_recieved.return_policy.ReturnsWithin
              : []
          }
          label={
            "After receiving the item, your buyer should contact you within:"
          }
          value={this.state.return_policy.domestic.return_within}
          placeholder={"Select..."}
          error={
            this.state.errors.business_policies.return_policy.domestic
              .return_within
              ? "*required field"
              : ""
          }
          onChange={this.handleReturnPOlicyLevelTwo.bind(
            this,
            "domestic",
            "return_within"
          )}
        />
        <Select
          key={"Returnpaidby"}
          options={
            !isUndefined(
              this.state.options_recieved.return_policy.ShippingCostPaidBy
            )
              ? this.state.options_recieved.return_policy.ShippingCostPaidBy
              : []
          }
          label={"Return shipping will be paid by:"}
          value={this.state.return_policy.domestic.return_paid_by}
          placeholder={"Select..."}
          error={
            this.state.errors.business_policies.return_policy.domestic
              .return_paid_by
              ? "*required field"
              : ""
          }
          onChange={this.handleReturnPOlicyLevelTwo.bind(
            this,
            "domestic",
            "return_paid_by"
          )}
        />
        {/*<Checkbox*/}
        {/*checked={this.state.return_policy.domestic.replacement_exchange_available}*/}
        {/*label="Replacement or exchange available"*/}
        {/*onChange={this.handleReturnPOlicyLevelTwo.bind(this,'domestic','replacement_exchange_available')}/>*/}
        {/*</Stack>*/}
        {/*</Card.Section>*/}
        {/*</Card>*/}
        {/*{this.state.return_policy.return_accepted.indexOf('international') > -1 &&*/}
        {/*<Card title={'International returns settings'}>*/}
        {/*<Card.Section>*/}
        {/*<Stack vertical={true}>*/}
        {/*<Select*/}
        {/*key={'InternationalcontactWithin'}*/}
        {/*options={!isUndefined(this.state.options_recieved.return_policy.ReturnsWithin)?this.state.options_recieved.return_policy.ReturnsWithin:[]}*/}
        {/*label={'After receiving the item, your buyer should contact you within:'}*/}
        {/*value={this.state.return_policy.international.return_within}*/}
        {/*onChange={this.handleReturnPOlicyLevelTwo.bind(this,'international','return_within')}/>*/}
        {/*<Select*/}
        {/*key={'Returnpaidby'}*/}
        {/*options={!isUndefined(this.state.options_recieved.return_policy.ShippingCostPaidBy)?this.state.options_recieved.return_policy.ShippingCostPaidBy:[]}*/}
        {/*label={'Return shipping will be paid by:'}*/}
        {/*value={this.state.return_policy.international.return_paid_by}*/}
        {/*onChange={this.handleReturnPOlicyLevelTwo.bind(this,'international','return_paid_by')}/>*/}
        {/*<Checkbox*/}
        {/*checked={this.state.return_policy.international.replacement_exchange_available}*/}
        {/*label="Replacement or exchange available"*/}
        {/*onChange={this.handleReturnPOlicyLevelTwo.bind(this,'international','replacement_exchange_available')}*/}
        {/*/>*/}
        {/*</Stack>*/}
        {/*</Card.Section>*/}
        {/*</Card>*/}
        {/*}*/}
        {/*</FormLayout.Group>*/}
      </FormLayout>
    );

    return temparr;
  }

  returnDescriptionReturn() {
    let temparr = [];
    let site_id = this.state.site_id;
    let countries = ["DE", "AT", "FR", "IT", "ES"];
    if (countries.indexOf(site_id) > -1) {
      temparr.push(
        <TextField
          label="Return description"
          key={"ReturnDescription"}
          type="text"
          multiline={5}
          value={this.state.return_policy.return_description}
          onChange={this.feildsChange.bind(
            this,
            "return_policy",
            "return_description"
          )}
        />
      );
    }
    return temparr;
  }

  //-----------------------------------Render Functions End------------------------------------//

  //-----------------------------------Input Change Functions Change Start------------------------------------//

  dropdownChange(key, tag, value) {
    let tempObj = Object.assign({}, this.state);
    tempObj.dropdown[key][tag] = value;
    this.setState(tempObj);
  }

  handleShippingPolicyService(key, index, tag, value) {
    
    let tempObj = Object.assign({}, this.state);
    tempObj["shipping_policy"][key][index][tag] = value;
    if (
      key === "shipping_service_domestic" &&
      tag === "free_shipping" &&
      value
    ) {
      tempObj.options_recieved.selected_domestic_service = index.toString();
    } else {
      tempObj.options_recieved.selected_domestic_service = "null";
    }
    this.setState(tempObj);
  }

  handleReturnPOlicyLevelTwo(key, tag, value) {
    let tempObj = Object.assign({}, this.state);
    tempObj["return_policy"][key][tag] = value;
    this.setState(tempObj);
  }

  handleshippingPOlicyLevelTwo(key, tag, value) {
  
    let tempObj = Object.assign({}, this.state);
    tempObj["shipping_policy"][key][tag] = value;
    this.setState(tempObj);
  }

  handlesellingDetailsLevelTwo(key, tag, value) {
    let tempObj = Object.assign({}, this.state);
    tempObj["selling_details"][key][tag] = value;
    this.setState(tempObj);
  }

  Addserives(type) {
    switch (type) {
      case "domestic":
        let insertService = Object.assign({}, tempObjShippingserviceDomestic);
        let currentServicedomestic =
          this.state.shipping_policy.shipping_service_domestic.slice(0);
        currentServicedomestic.push(insertService);
        this.state.shipping_policy.shipping_service_domestic =
          currentServicedomestic;
        this.setState(this.state);
        break;
      case "international":
        let insertServiceinternational = Object.assign(
          {},
          tempObjShippingserviceInternational
        );
        let currentServiceinternational =
          this.state.shipping_policy.shipping_service_international.slice(0);
        currentServiceinternational.push(insertServiceinternational);
        this.state.shipping_policy.shipping_service_international =
          currentServiceinternational;
        this.setState(this.state);
        break;
      default:
        console.log(type);
    }
  }
  deleteService(type, index) {
    switch (type) {
      case "domestic":
        let currentServicedomestic =
          this.state.shipping_policy.shipping_service_domestic.slice(0);
        currentServicedomestic.splice(index, 1);
        this.state.shipping_policy.shipping_service_domestic =
          currentServicedomestic;
        this.setState(this.state);
        break;
      case "international":
        let currentServiceinternational =
          this.state.shipping_policy.shipping_service_international.slice(0);
        currentServiceinternational.splice(index, 1);
        this.state.shipping_policy.shipping_service_international =
          currentServiceinternational;
        this.setState(this.state);
        break;
    }
  }

  nameFeildChange(key, tag, value) {
    let tempObj = Object.assign({}, this.state);
    tempObj[key][tag] = value
      .replace(/[^\w\s]/gi, "")
      .replace(/[0-9]/gi, "")
      .replace("_", "");
    this.setState(tempObj);
  }

  feildsChangePaymentLevelTwo(key, tag, value) {
    let tempObj = Object.assign({}, this.state);
    tempObj.payment_policy[key][tag] = value;
    this.setState(tempObj);
  }

  feildsChange(key, tag, value) {
    let tempObj = Object.assign({}, this.state);
    tempObj[key][tag] = value;
    this.setState(tempObj);
    if (key === "payment_policy" && tag === "immediate_pay") {
      this.state.payment_policy.payment_methods = [];
      this.state.payment_policy.payment_methods.push("PayPal");
      this.setState(this.state);
    }
    // if(key==='selling_details' && tag==='format' && value==='fixed_price'){
    //     this.state.selling_details.listing_duration='GTC';
    //     this.setState(this.state);
    // }
    // else if(key==='selling_details' && tag==='format' && value!=='fixed_price'){
    //     this.state.selling_details.listing_duration=3;
    //     this.setState(this.state);
    // }

    if (key === "shipping_policy" && tag === "service_type") {
      switch (value) {
        case "Flat":
          this.state.options_recieved.shipping_service_options.domestic =
            this.state.options_recieved.shipping_service.domestic.Flat;
          this.state.options_recieved.shipping_service_options.international =
            this.state.options_recieved.shipping_service.international.Flat;
          break;
        case "Calculated":
          this.state.options_recieved.shipping_service_options.domestic =
            this.state.options_recieved.shipping_service.domestic.Calculated;
          this.state.options_recieved.shipping_service_options.international =
            this.state.options_recieved.shipping_service.international.Calculated;
          break;
        case "FreightFlat":
          this.state.options_recieved.shipping_service_options.domestic =
            this.state.options_recieved.shipping_service.domestic.FreightFlat;
          this.state.options_recieved.shipping_service_options.international =
            this.state.options_recieved.shipping_service.international.FreightFlat;
          break;
        case "CalculatedDomesticFlatInternational":
          this.state.options_recieved.shipping_service_options.domestic =
            this.state.options_recieved.shipping_service.domestic.Calculated;
          this.state.options_recieved.shipping_service_options.international =
            this.state.options_recieved.shipping_service.international.Flat;
          break;
        case "FlatDomesticCalculatedInternational":
          this.state.options_recieved.shipping_service_options.domestic =
            this.state.options_recieved.shipping_service.domestic.Flat;
          this.state.options_recieved.shipping_service_options.international =
            this.state.options_recieved.shipping_service.international.Calculated;
          break;
      }
      this.setState(this.state);
    }
  }

  //-----------------------------------Input Change Functions Change End------------------------------------//
  //-----------------------------------Save Function Start ------------------------------------//

  saveAllprofiles() {
    let tempObj = {
      shipping_policy: {},
      return_policy: {},
      payment_policy: {},
    };

    let tempObjTemp = {
      business_policies: {},
    };

    let current_type = "";
    Object.keys(this.state.display).map((key) => {
      if (this.state.display[key]) {
        current_type = key;
        tempObj[key]["profile_data"] = this.state[key];
      } else {
        delete tempObj[key];
      }
    });
    if (this.state.id !== "") {
      tempObj[current_type]["profile_data"]["profileId"] = this.state.id;
    }
    tempObjTemp.business_policies = Object.assign({}, tempObj);

    if (this.policyValidator(tempObjTemp.business_policies)) {
      let tempObjFinal = {};
      tempObjFinal[current_type] = Object.assign(
        {},
        tempObjTemp.business_policies[current_type]["profile_data"]
      );
      this.props.recieveFormData(tempObjFinal);
    } else {
      notify.error("Kindly fill all the required fields");
    }
  }

  //-----------------------------------Save Function End ------------------------------------//

  //-----------------------------------Essential Function Start ------------------------------------//
  redirect(url) {
    this.props.history.push(url);
  }

  assignData() {
    if (!isUndefined(this.props.data)) {
      Object.keys(this.props.data).map((key) => {
        this.state[key] = this.props.data[key];
      });
      this.setState(this.state);
    }
  }
  componentDidMount() {
    if (
      !isUndefined(this.props.data) &&
      !isUndefined(this.props.data.id) &&
      this.props.data.id !== ""
    ) {
      this.state.id = this.props.data.id;
      this.setState(this.state);
      this.getData();
    }
    this.getSideID();
  }

  getData() {
    requests
      .getRequest("ebayV1/get/businessPolicy", {
        profile_id: this.props.data.id,
      })
      .then((data) => {
        if (data.success) {
          this.ModifyData(data);

          // if(!isUndefined(data.data.data)) {
          //     this.state.form_data = data.data.data;
          // }
        }
        this.setState(this.state);
      });
  }

  getServiceType(Service) {
    let service_type = "";
    let flat = 0;
    let calculated = 0;

    Object.keys(Service).map((key) => {
      switch (Service[key]) {
        case "Calculated":
          calculated++;
          break;
        case "Flat":
          flat++;
          break;
      }
    });
    if ((calculated === 2 && flat === 0) || (calculated === 1 && flat === 0)) {
      service_type = "Calculated";
    } else if (
      (calculated === 0 && flat === 2) ||
      (calculated === 0 && flat === 1)
    ) {
      service_type = "Flat";
    } else if (calculated === 1 && flat === 1) {
      if (
        Service.international === "Calculated" &&
        Service.domestic === "Flat"
      ) {
        service_type = "FlatDomesticCalculatedInternational";
      } else if (
        Service.domestic === "Calculated" &&
        Service.international === "Flat"
      ) {
        service_type = "CalculatedDomesticFlatInternational";
      }
    } else if (calculated === 0 && flat === 0) {
      service_type = "FreightFlat";
    }
    return service_type;
  }

  ModifyData(data) {
    switch (data.data.type) {
      case "payment":
        let tempObjpayment = {
          name: !isUndefined(data.data.data["profileName"])
            ? data.data.data["profileName"]
            : "",
          immediate_pay: !isUndefined(
            data.data.data.paymentInfo["immediatePay"]
          )
            ? data.data.data.paymentInfo["immediatePay"]
            : false,
          payment_methods: !isUndefined(
            data.data.data.paymentInfo["acceptedPaymentMethod"]
          )
            ? data.data.data.paymentInfo["acceptedPaymentMethod"]
            : [],
          checkout_instruction: !isUndefined(
            data.data.data.paymentInfo["paymentInstructions"]
          )
            ? data.data.data.paymentInfo["paymentInstructions"]
            : "",
          paypal_email: !isUndefined(
            data.data.data.paymentInfo["paypalEmailAddress"]
          )
            ? data.data.data.paymentInfo["paypalEmailAddress"]
            : "",
          deposit_details: {
            days_to_full_payment:
              !isUndefined(data.data.data.paymentInfo["depositDetails"]) &&
              !isUndefined(
                data.data.data.paymentInfo["depositDetails"][
                  "daysToFullPayment"
                ]
              )
                ? data.data.data.paymentInfo["depositDetails"][
                    "daysToFullPayment"
                  ]
                : "",
            deposit_amount:
              !isUndefined(data.data.data.paymentInfo["depositDetails"]) &&
              !isUndefined(
                data.data.data.paymentInfo["depositDetails"]["depositAmount"]
              )
                ? data.data.data.paymentInfo["depositDetails"]["depositAmount"]
                : "",
            hours_to_deposit:
              !isUndefined(data.data.data.paymentInfo["depositDetails"]) &&
              !isUndefined(
                data.data.data.paymentInfo["depositDetails"]["hoursToDeposit"]
              )
                ? data.data.data.paymentInfo["depositDetails"]["hoursToDeposit"]
                : "",
          },
        };
        this.state.payment_policy = Object.assign({}, tempObjpayment);
        this.setState(this.state);
        break;
      case "shipping":
        let tempObjshipping = Object.assign({}, this.state.shipping_policy);
        tempObjshipping.name = !isUndefined(data.data.data["profileName"])
          ? data.data.data["profileName"]
          : "";
        tempObjshipping.global_shipping = !isUndefined(
          data.data.data.shippingPolicyInfo["GlobalShipping"]
        )
          ? data.data.data.shippingPolicyInfo["GlobalShipping"]
          : false;
        tempObjshipping.exclude_locations =
          !isUndefined(
            data.data.data.shippingPolicyInfo["excludeShipToLocation"]
          ) && data.data.data.shippingPolicyInfo["excludeShipToLocation"]
            ? true
            : false;
        tempObjshipping.excluded_shipping_location = !isUndefined(
          data.data.data.shippingPolicyInfo["excludeShipToLocation"]
        )
          ? data.data.data.shippingPolicyInfo["excludeShipToLocation"]
          : [];
        tempObjshipping.international.handling_cost = !isUndefined(
          data.data.data.shippingPolicyInfo[
            "internationalPackagingHandlingCosts"
          ]
        )
          ? data.data.data.shippingPolicyInfo[
              "internationalPackagingHandlingCosts"
            ].value
          : 0;
        tempObjshipping.international.global_ship_to = !isUndefined(
          data.data.data.shippingPolicyInfo["shipToLocations"]
        )
          ? data.data.data.shippingPolicyInfo["shipToLocations"]
          : [];
        tempObjshipping.domestic.handling_time = !isUndefined(
          data.data.data.shippingPolicyInfo["dispatchTimeMax"]
        )
          ? String(data.data.data.shippingPolicyInfo["dispatchTimeMax"])
          : "1";
        tempObjshipping.domestic.handling_cost = !isUndefined(
          data.data.data.shippingPolicyInfo["packagingHandlingCosts"]
        )
          ? data.data.data.shippingPolicyInfo["packagingHandlingCosts"].value
          : 0;
        tempObjshipping.domestic.PromotionalShippingDiscount =
          !isUndefined(
            data.data.data.shippingPolicyInfo["shippingProfileDiscountInfo"]
          ) &&
          !isUndefined(
            data.data.data.shippingPolicyInfo["shippingProfileDiscountInfo"][
              "applyDomesticPromoShippingProfile"
            ]
          )
            ? data.data.data.shippingPolicyInfo["shippingProfileDiscountInfo"][
                "applyDomesticPromoShippingProfile"
              ]
            : false;
        tempObjshipping.international.InternationalPromotionalShippingDiscount =
          !isUndefined(
            data.data.data.shippingPolicyInfo["shippingProfileDiscountInfo"]
          ) &&
          !isUndefined(
            data.data.data.shippingPolicyInfo["shippingProfileDiscountInfo"][
              "applyIntlPromoShippingProfile"
            ]
          )
            ? data.data.data.shippingPolicyInfo["shippingProfileDiscountInfo"][
                "applyIntlPromoShippingProfile"
              ]
            : false;

        let serVicetype = {
          international: !isUndefined(
            data.data.data.shippingPolicyInfo["intlShippingType"]
          )
            ? data.data.data.shippingPolicyInfo["intlShippingType"]
            : false,
          domestic: !isUndefined(
            data.data.data.shippingPolicyInfo["domesticShippingType"]
          )
            ? data.data.data.shippingPolicyInfo["domesticShippingType"]
            : false,
        };
        tempObjshipping.service_type = this.getServiceType(serVicetype);

        let domesticServices = [];
        let internationalServices = [];
        if (
          !isUndefined(
            data.data.data.shippingPolicyInfo[
              "domesticShippingPolicyInfoService"
            ]
          )
        ) {
          data.data.data.shippingPolicyInfo[
            "domesticShippingPolicyInfoService"
          ].forEach((value, index) => {
            let tempdomesticObj = Object.assign(
              {},
              tempObjShippingserviceDomestic
            );
            tempObjshipping.domestic.buyer_responsible_for_pickup =
              !isUndefined(value["buyerResponsibleForPickup"])
                ? value["buyerResponsibleForPickup"]
                : "";
            tempObjshipping.domestic.buyer_responsible_for_shipping =
              !isUndefined(value["buyerResponsibleForShipping"])
                ? value["buyerResponsibleForShipping"]
                : false;
            tempObjshipping.domestic.shipping_surcharge = !isUndefined(
              value["shippingSurcharge"]
            )
              ? value["shippingSurcharge"]
              : 0;
            tempdomesticObj.service = !isUndefined(value["shippingService"])
              ? value["shippingService"]
              : "";
            tempdomesticObj.free_shipping = !isUndefined(value["freeShipping"])
              ? value["freeShipping"]
              : false;
            tempdomesticObj.codfee = !isUndefined(value["codFee"])
              ? value["codFee"]
              : "";
            tempdomesticObj.additional_charges = !isUndefined(
              value["shippingServiceAdditionalCost"]
            )
              ? value["shippingServiceAdditionalCost"].value
              : "";
            tempdomesticObj.charges = !isUndefined(value["shippingServiceCost"])
              ? value["shippingServiceCost"].value
              : "";
            domesticServices.push(tempdomesticObj);
            // {service:'',charges:'',codfee:'',free_shipping:false,additional_charges:0};
          });
          if (domesticServices.length > 0) {
            tempObjshipping.shipping_service_domestic = domesticServices;
          }
        }

        if (
          !isUndefined(
            data.data.data.shippingPolicyInfo["intlShippingPolicyInfoService"]
          )
        ) {
          data.data.data.shippingPolicyInfo[
            "intlShippingPolicyInfoService"
          ].forEach((value, index) => {
            let tempinternationalObj = Object.assign(
              {},
              tempObjShippingserviceInternational
            );
            tempObjshipping.international.shipping_surcharge = !isUndefined(
              value["shippingSurcharge"]
            )
              ? value["shippingSurcharge"]
              : 0;
            tempObjshipping.international.buyer_responsible_for_shipping =
              !isUndefined(value["buyerResponsibleForShipping"])
                ? value["buyerResponsibleForShipping"]
                : false;
            tempObjshipping.international.buyer_responsible_for_pickup =
              !isUndefined(value["buyerResponsibleForPickup"])
                ? value["buyerResponsibleForPickup"]
                : "";
            tempinternationalObj.service = !isUndefined(
              value["shippingService"]
            )
              ? value["shippingService"]
              : "";
            tempinternationalObj.free_shipping = !isUndefined(
              value["freeShipping"]
            )
              ? value["freeShipping"]
              : false;
            tempinternationalObj.codfee = !isUndefined(value["codFee"])
              ? value["codFee"]
              : "";
            tempinternationalObj.additional_charges = !isUndefined(
              value["shippingServiceAdditionalCost"]
            )
              ? value["shippingServiceAdditionalCost"].value
              : "";
            tempinternationalObj.ship_to = !isUndefined(value["shipToLocation"])
              ? value["shipToLocation"]
              : "";
            tempinternationalObj.charges = !isUndefined(
              value["shippingServiceCost"]
            )
              ? value["shippingServiceCost"].value
              : "";
            internationalServices.push(tempinternationalObj);
          });
          if (internationalServices.length > 0) {
            tempObjshipping.shipping_service_international =
              internationalServices;
          }
        }
        this.state.shipping_policy = Object.assign({}, tempObjshipping);
        this.setState(this.state);
        break;
      case "return":
        let tempObjreturn = Object.assign({}, this.state.return_policy);

        tempObjreturn.name = !isUndefined(data.data.data["profileName"])
          ? data.data.data["profileName"]
          : "";
        tempObjreturn.returns_accepted_option =
          !isUndefined(
            data.data.data.returnPolicyInfo["returnsAcceptedOption"]
          ) &&
          data.data.data.returnPolicyInfo["returnsAcceptedOption"] ===
            "ReturnsAccepted"
            ? true
            : false;
        tempObjreturn.return_option =
          data.data.data.returnPolicyInfo["refundOption"];
        tempObjreturn.domestic.return_within =
          data.data.data.returnPolicyInfo["returnsWithinOption"];
        tempObjreturn.domestic.return_paid_by =
          data.data.data.returnPolicyInfo["shippingCostPaidByOption"];
        tempObjreturn.return_description =
          data.data.data.returnPolicyInfo["description"];
        this.state.return_policy = tempObjreturn;
        this.setState(this.state);
        break;
    }
  }

  getSideID() {
    requests.getRequest("ebayV1/get/siteId").then((data) => {
      if (data.success) {
        this.state.site_id = !isUndefined(data.data.site_id)
          ? data.data.site_id
          : "";
        // this.state.site_id ='MOTORS';
      }
      this.setState(this.state);
    });
  }

  getShopdetails() {
    requests
      .getRequest("ebayV1/get/details", { site_id: "US" })
      .then((data) => {
        if (data.success) {
          this.extractReturnPolicyServices(data.data[0]["ReturnPolicyDetails"]);
          this.extractCountryDetails(data.data[0]["CountryDetails"]);
          this.extractExcludedLocations(
            data.data[0]["ExcludeShippingLocationDetails"]
          );
          this.extractPaymentMethods(data.data[0]["PaymentMethods"]);
          this.extractShippingDetails(data.data[0]["ShippingServiceDetails"]);
          this.extractDispatchTimeMaxDetails(
            data.data[0]["DispatchTimeMaxDetails"]
          );
        }
      });
  }

  showPolicy() {
    this.state.display.shipping_policy = !isUndefined(
      this.props.display.shipping_policy
    )
      ? this.props.display.shipping_policy
      : false;
    this.state.display.payment_policy = !isUndefined(
      this.props.display.payment_policy
    )
      ? this.props.display.payment_policy
      : false;
    this.state.display.return_policy = !isUndefined(
      this.props.display.return_policy
    )
      ? this.props.display.return_policy
      : false;
    this.setState(this.state);
  }

  //-----------------------------------Essential Function End ------------------------------------//
}

export default PaymentShippingReturn;
