import React, {Component} from 'react';
import {Card, Checkbox, FormLayout, Select, Stack, TextField, DisplayText, Banner, Page, Badge} from "@shopify/polaris";
import {requests} from "../services/request";
import {isUndefined} from "util";
import {notify} from "../services/notify";
import ModalVideo from "react-modal-video";

const merge  = require('deepmerge');

let AttributeMapoptions=[
  {label:'Title',value:'title'},
  {label:'Vendor',value:'vendor'},
  {label:'Description',value:'description'},
  {label:'Price',value:'price'},
  {label:'Product Type',value:'product_type'},
  {label:'Tags',value:'tags'},
  {label:'Set custom value',value:'default'},

];
let defaultAttributeoptions=[
  {label:'Title',value:'title'},
  {label:'Vendor',value:'vendor'},
  {label:'SKU',value:'sku'},
  {label:'Description',value:'description'},
  {label:'Price',value:'price'},
  {label:'Main image',value:'image_main'},
  {label:'Tags',value:'tags'},
  {label:'Product Type',value:'product_type'},

];


class Titletemplate extends Component {

  video={Modal:false,id:''};
  constructor(props){
    super(props);
    this.state={
      _id:'',
      form_data: {
        name: '',
        dimensions : {
          length : "",
          width : "",
          height : "",
          unit:'in'
        },
        set_subtitle:false,
        motors:{
          selected:'title',
          default_setting:{
            value:'{{title}}',
          }
        },
        title:{
          selected:'title',
          default_setting:{
            value:'{{title}}',
          },
          trim_title : false
        },
        subtitle:{
          selected:'title',
          default_setting:{
            value:'{{title}}',
          }
        },
        description:{
          selected:'description',
          default_setting:{
            value:'{{description}}',
          }
        }
      },
      default_settings:{
        title:'title',
        subtitle:'title',
        description:'description',
        motors:'title'
      },
      cardHeading:{
        title:'Title',
        subtitle:'Subtitle',
        description:'Description',
        motors:'Seller provided title'
      },

      errors:{
        name:false
      },
      site_id:'',
    }

  }

  getSideID(){
    requests.getRequest('ebayV1/get/siteId').then(data=>{
      if(data.success){
        this.state.site_id=data.data.site_id;
      }
      this.setState(this.state);
    });

  }

  getMetaFields(){
    return requests.getRequest('shopify/product/getMetafieldsOptions').then(data =>{
      return data.success? data.data:[];
    });
  }

  formValidator(){
    let errors=0;
    Object.keys(this.state.form_data).map(key=>{
      switch(key){
        case 'name':
          if(this.state.form_data[key]===''){
            this.state.errors.name=true;
            errors+=1;
          }
          else{
            this.state.errors.name=false;
          }
          break;
      }
    });

    this.setState(this.state);
    if(errors===0){
      return true;
    }
    else
    {
      return false;
    }
  }

  feildsChange(key,tag,value){
    let tempObj = Object.assign({}, this.state);
    tempObj.form_data[key][tag]= value;
    this.setState(tempObj);
  }

  feildsChangeName(key,value){
    let tempObj = Object.assign({}, this.state);
    tempObj.form_data[key]= value;
    this.setState(tempObj);
  }

  handleDefaultChangeValue(key,value)
  {
    let tempObj = Object.assign({}, this.state);
    tempObj.form_data[key].default_setting.value = value;
    this.setState(tempObj);
  }
  handleDefaultChangeSelect(key,value)
  {
    let tempObj = Object.assign({}, this.state);
    tempObj.default_settings[key] = value;
    tempObj.form_data[key].default_setting.value+="{{"+this.state.default_settings[key]+"}}";
    this.setState(tempObj);
  }

  saveConfigTitle(){
    if(this.formValidator()) {
      let tempObj={
        title:this.state.form_data.name,
        type:'title',
        data:this.state.form_data
      };
      if(this.state._id!=='') {
        tempObj['_id'] = this.state._id;
      }
      this.props.recieveFormdata(tempObj);
    }else{
      notify.error('Kindly fill all the required fields');
    }
  }

  saveConfigData(){
    this.saveConfigTitle();
  }


  componentDidMount(){
    if(!isUndefined(this.props.data) && !isUndefined(this.props.data.id) && this.props.data.id!=='') {
      this.state._id=this.props.data.id;
      this.setState(this.state);
      this.getData();
    }
    this.getSideID();
    this.prepareMetaOptions();
  }

  async prepareMetaOptions(){
    let metaOptionsPrepared = [];
    let metaOptions = await this.getMetaFields();
    if(metaOptions.length) {
      metaOptions.forEach(meta => {
        metaOptionsPrepared = [...metaOptionsPrepared, {label: meta, value: meta}];
      });
      defaultAttributeoptions = [...defaultAttributeoptions, ...metaOptionsPrepared];
      AttributeMapoptions = [...AttributeMapoptions, ...metaOptionsPrepared];
      this.setState({});
    }
  }

  getData(){
    requests.getRequest('ebayV1/get/template',{template_id:this.props.data.id}).then(data=>{
      if(data.success){
        if(!isUndefined(data.data.data)) {
          this.state.form_data = merge(this.state.form_data,data.data.data);
        }
      }
      this.setState(this.state);
    });
  }

  openvideoModal(id) {
    this.video.Modal = true;
    this.video.id = id;
    this.setState(this.state);
  }

  closevideoModal() {
    this.video.Modal = false;
    this.video.id = '';
    this.setState(this.state);
  }


  render() {
    let { form_data } = this.state;
    let { dimensions } = form_data;

    return (
      <Card title={"Title template"} key={'titleTemplate'}
            actions={[{content:<Badge status={"info"}><b>Need help?</b></Badge>,onAction:()=>{
                window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=title-templates','_blank')
              }},
              {content:<Badge status={"info"}><b>Help video</b></Badge>,onAction:()=>{
                  this.openvideoModal('WeuuIT-vlC0')
                }},
              ]}
      >
        <Card.Section>
          <Banner title={''} status={"info"}>
            <p><b>Title template </b>helps you map desired Shopify attributes to Title, sub title & description attribute of eBay. You can even pass combination of Shopify attributes and custom values to the aforementioned eBay attributes.</p>
          </Banner>
        </Card.Section>
        <Card.Section key={"Title Template name"}>
          <TextField
            label="Template name"
            key={'templateNameMain'}
            type="text"
            value={this.state.form_data.name}
            error={this.state.errors.name?"*required field":''}
            onChange={this.feildsChangeName.bind(this,'name')}/>
        </Card.Section>
        <Card.Section title={'Settings'}  key={"Title Template settings"}>
          <FormLayout>
            {
              this.renderTemplateBody('title')
            }
            <Checkbox
              key={'Subtitlesettings'}
              checked={this.state.form_data.set_subtitle}
              label="Set subtitle"
              helpText={'*Fees may apply as subtitles appear in eBay search results in list view, and can increase buyer\'s interest by providing more descriptive info'}
              onChange={this.feildsChangeName.bind(this,'set_subtitle')}
            />
            {this.state.form_data.set_subtitle &&
            this.renderTemplateBody('subtitle')
            }
            {
              this.renderTemplateBody('description')
            }

            {this.state.site_id === 'MOTORS' &&
            this.renderTemplateBody('motors')
            }
          </FormLayout>
        </Card.Section>
        <Card.Section title={"Product dimensions"}>
          <Stack vertical={false} distribution={"fillEvenly"}>
            <TextField
            label={"Length"}
            type={"number"}
            value={dimensions.length}
            suffix={"in"}
            onChange={this.feildsChange.bind(this, "dimensions","length")}
            />
            <TextField
                label={"Width"}
                type={"number"}
                value={dimensions.width}
                suffix={"in"}
                onChange={this.feildsChange.bind(this, "dimensions","width")}
            />
            <TextField
                label={"Height"}
                type={"number"}
                value={dimensions.height}
                suffix={"in"}
                onChange={this.feildsChange.bind(this, "dimensions","height")}
            />
          </Stack>
        </Card.Section>
        <ModalVideo channel='youtube' isOpen={this.video.Modal} videoId={this.video.id}  onClose={this.closevideoModal.bind(this)} />

      </Card>
    );
  }


  renderTemplateBody(key){
    let temparr=[];

    temparr.push(
      <Card title={this.state.cardHeading[key]}  key={"feildsettings"+[key]}>
        <Card.Section>
          <FormLayout>
            <Select
              key={'attributeMap'+[key]}
              options={AttributeMapoptions}
              label={'Mapping options for '+key+' field'}
              value={this.state.form_data[key].selected}
              onChange={this.feildsChange.bind(this,key,'selected')}/>
            {key === 'title' &&
            <Stack vertical={false}>
              <Stack.Item fill key={'component' + key}>
                <Checkbox
                  label={'Trim Title'}
                  checked={this.state.form_data[key].trim_title}
                  helpText={'*select this option only if you want to trim the title from starting till 80 characters, Please see this might make your title absurd so make sure accordingly.'}
                  onChange={(e)=>{
                    this.state.form_data[key].trim_title = e;
                    this.setState(this.state);
                  }}/>
              </Stack.Item>
            </Stack>
            }
            {this.state.form_data[key].selected === 'default' &&

            <Stack vertical={false}>
              <Stack.Item key={'mapto'+key}>
                <Select
                  key={'attributeMapdefault'+key}
                  placeholder={"Please select.."}
                  options={defaultAttributeoptions}
                  label={'Choose to add attribute'}
                  value={this.state.default_settings[key]}
                  onChange={this.handleDefaultChangeSelect.bind(this,key)}/>
              </Stack.Item>
              <Stack.Item fill key={'component'+key}>
                {key === 'description' ?
                  <TextField
                    label="Value"
                    key={'value' + key}
                    type="text"
                    value={this.state.form_data[key].default_setting.value}
                    multiline={10}
                    onChange={this.handleDefaultChangeValue.bind(this, key)}/>:
                  <TextField
                    label="Value"
                    key={'value' + key}
                    type="text"
                    value={this.state.form_data[key].default_setting.value}
                    maxLength={80}
                    onChange={this.handleDefaultChangeValue.bind(this, key)}/>
                }
              </Stack.Item>
            </Stack>
            }
          </FormLayout>
        </Card.Section>
      </Card>
    );


    return temparr;
  }
}

export default Titletemplate;
