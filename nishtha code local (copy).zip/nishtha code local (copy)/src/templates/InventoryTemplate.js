import React, { Component } from 'react';
import { Badge, Banner, Card, Checkbox, FormLayout, Select, TextField, Stack } from "@shopify/polaris";
import { requests } from "../services/request";
import { isUndefined } from "util";
import { notify } from "../services/notify";
import ModalVideo from "react-modal-video";
import _ from 'lodash';

const variateType = [
    { label: 'Increase', value: 'increase' },
    { label: 'Decrease', value: 'decrease' },
];
class InventoryTemplate extends Component {
    video = { Modal: false, id: '' };
    constructor(props) {
        super(props)
        this.state = {
            _id: '',
            form_data: {
                name: '',
                fixed_inventory: '',
                customize_inventory: false,
                custom_inventory: {
                    trend: 'increase',
                    value: ""
                },
                threshold_inventory: '',
                send_lower_inventory: false,
                delete_product_outofStock: false,
                QuantityRestrictPerBuyer: '',
            },
            errors: {
                name: false,
                threshold_inventory: false,
            }
        }
    }

    feildsChange(tag, value) {
        let tempObj = Object.assign({}, this.state);
        if (tag == 'customize_inventory' || tag == 'send_lower_inventory' || tag == 'delete_product_outofStock') {
            tempObj.form_data[tag] = value
        }
        else {
            let tempObj = Object.assign({}, this.state);
            tempObj.form_data[tag] = value;
            // tempObj.form_data[tag] = value.replace(/[^\w\s]/gi, "")
        }
        this.setState(tempObj);
    }

    customInventoryFieldchange(tab, value) {
        let { form_data } = this.state;
        form_data['custom_inventory'][tab] = value.replace(/[^\w\s]/gi, "");
        this.setState({ form_data });
    }
    saveFormdata() {
        if (this.formValidator()) {
            let tempObj = {
                title: this.state.form_data.name,
                type: 'inventory',
                data: this.state.form_data,

            };
            if (this.state._id !== '') {
                tempObj['_id'] = this.state._id;
            }
            this.props.recieveFormdata(tempObj);
        } else {
            notify.error('Kindly fill all the required fields');
        }

    }

    saveConfigData() {
        this.saveFormdata();
    }

    componentDidMount() {
        if (!isUndefined(this.props.data) && !isUndefined(this.props.data.id) && this.props.data.id !== '') {
            this.state._id = this.props.data.id;
            this.setState(this.state);
            this.getData();
        }
    }

    getData() {
        requests.getRequest('ebayV1/get/template', { template_id: this.props.data.id }).then(data => {
            if (data.success) {
                if (!isUndefined(data.data.data)) {
                    this.state.form_data = _.merge(this.state.form_data, data.data.data);
                }
            }
            this.setState(this.state);
        })
    }

    formValidator() {
        let errors = 0;
        Object.keys(this.state.form_data).map(key => {
            switch (key) {
                case 'name':
                    if (this.state.form_data[key] === '') {
                        this.state.errors.name = true;
                        errors += 1;
                    }
                    else {
                        this.state.errors.name = false;
                    }
                    break;
                case 'threshold_inventory':
                    // if((this.state.form_data.fixed_inventory !== '' && this.state.form_data[key]==='' )){
                    //   this.state.errors.threshold_inventory=true;
                    //   errors+=1;
                    // }
                    // else{
                    //   this.state.errors.threshold_inventory=false;
                    // }
                    break;
            }
        });

        this.setState(this.state);
        if (errors === 0) {
            return true;
        }
        else {
            return false;
        }
    }

    openvideoModal(id) {
        this.video.Modal = true;
        this.video.id = id;
        this.setState(this.state);
    }

    closevideoModal() {
        this.video.Modal = false;
        this.video.id = '';
        this.setState(this.state);
    }

    render() {
        return (
            <Card title={'Inventory Template'}
                actions={[{
                    content: <Badge status={"info"}><b>Need help?</b></Badge>, onAction: () => {
                        window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=in-templ', '_blank')
                    }
                },
                {
                    content: <Badge status={"info"}><b>Help video</b></Badge>, onAction: () => {
                        this.openvideoModal('IcBzcUXy1TE')
                    }
                },
                ]}
            >
                <Card.Section>
                    <Banner status={"info"}>
                        With the use of <b>Inventory template </b>you can assign properties like how much should be the inventory, what is its limit (threshold), restriction per buyer and whether to delete products when they are out of stock. So by simply using the template all of these conditions can be applied while listing on eBay.
                    </Banner>
                </Card.Section>
                <Card.Section>
                    <FormLayout>
                        <TextField
                            label="Template name"
                            key={'Inventory name'}
                            type="text"
                            value={this.state.form_data.name}
                            error={this.state.errors.name ? ' ' : ''}
                            helpText={"*required"}
                            onChange={this.feildsChange.bind(this, 'name')} />
                        <TextField
                            label="Fixed inventory"
                            key={'Fixed inventory'}
                            type="number"
                            value={this.state.form_data.fixed_inventory}
                            helpText={'*When quantity is not managed through Shopify'}
                            onChange={this.feildsChange.bind(this, 'fixed_inventory')} />
                        <Checkbox
                            key={'SendLowerInventory'}
                            checked={this.state.form_data.send_lower_inventory}
                            label="Send lower inventory"
                            helpText={"*send the original value of inventory when it is lower than fixed inventory"}
                            onChange={this.feildsChange.bind(this, 'send_lower_inventory')}
                        />
                        <TextField
                            label="Threshold inventory"
                            key={'Threshold inventory'}
                            type="number"
                            error={this.state.errors.threshold_inventory ? 'Threshold inventory is required if you provide Fixed Inventory' : ''}
                            value={this.state.form_data.threshold_inventory}
                            helpText={'*Below this inventory product will become out of stock'}
                            onChange={this.feildsChange.bind(this, 'threshold_inventory')} />
                        <Checkbox
                            checked={this.state.form_data.customize_inventory}
                            label="Customize inventory"
                            onChange={this.feildsChange.bind(this, 'customize_inventory')}
                        />
                        {this.state.form_data.customize_inventory &&
                            <Stack vertical={false} distribution={"fillEvenly"}>
                                <Select
                                    label={'Choose trend'}
                                    options={variateType}
                                    value={this.state.form_data.custom_inventory.trend}
                                    onChange={this.customInventoryFieldchange.bind(this, 'trend')}
                                />
                                <TextField
                                    label="Value"
                                    type="number"
                                    value={this.state.form_data.custom_inventory.value}
                                    onChange={this.customInventoryFieldchange.bind(this, 'value')} />
                            </Stack>
                        }
                        <Checkbox
                            key={'DeleteProducts'}
                            checked={this.state.form_data.delete_product_outofStock}
                            label="Delete out of stock product"
                            helpText={'*It applies only for simple products'}
                            onChange={this.feildsChange.bind(this, 'delete_product_outofStock')}
                        />
                        <TextField
                            label="Quantity restriction per buyer"
                            key={'QuantityRestrictPerBuyer'}
                            type="number"
                            value={this.state.form_data.QuantityRestrictPerBuyer}
                            onChange={this.feildsChange.bind(this, 'QuantityRestrictPerBuyer')} />
                    </FormLayout>
                </Card.Section>
                <ModalVideo channel='youtube' isOpen={this.video.Modal} videoId={this.video.id} onClose={this.closevideoModal.bind(this)} />
            </Card>
        );
    }
}

export default InventoryTemplate;
