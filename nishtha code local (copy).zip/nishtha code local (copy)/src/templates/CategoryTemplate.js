import React, {Component} from 'react';
import LoadingOverlay from 'react-loading-overlay';
import {
  FormLayout,
  Card,
  TextField,
  Stack,
  Select,
  Banner,
  Layout,
  Button,
  Autocomplete,
  Icon,
  ChoiceList, Checkbox, RadioButton, Spinner, Badge
} from "@shopify/polaris";
import jwtDecode from "jwt-decode";
import {requests} from "../services/request";
import {isUndefined} from "util";
import {NavLink} from "react-router-dom";
import Skeleton from "../shared/skeleton";
import {notify} from "../services/notify";
import ModalVideo from "react-modal-video";
import {globalState} from "../services/globalstate";
import {
  SearchMajorMonotone
} from '@shopify/polaris-icons';

const merge  = require('deepmerge');
let attribute={ebayAttrib:'',shopifyAttrib:'',recommendation:'',defaultText:''};
let custom_attribute={customAttrib:'',shopifyAttrib:'',defaultText:''};




class CategoryTemplate extends Component {

  constructor(props) {
    super(props);

    this.state={
      overlayloader:false,
      _id:'',
      form_data: {
        name: '',
        storefront_category:{
          options:[],
          selected:'',
        },
        menachemCategory:{
          selected_id : '',
        },
        storefront_category_exists:false,
        bestofferenabled:false,
        variation_specific:false,
        variation_image_settings:{
          options:[],
          selected:[],
        },
        primaryCategory:{
          category_mapping: {},
          category_mapping_name: {},
          category_mapping_options: {},
          show_Attribute_mapping: false,
          attribute_mapping: {
            ebayAttrib: [],
            shopifyAttrib: [],
            customShopifyAttrib: [],
            used_ebay_attrib:[],
            ebayAttribInfo: {},
            required_map: [],
            optional_map: [],
            custom_map:[],
          },
          attributes_minmax:{},
          required_attribute_count:0,
          optional_attribute_count:0,
          category_feature:'',
          condition_description : ''
        },
        enable_advance_options:false,
        bundle_listing : false,
        secondaryCategory:{
          category_mapping: {},
          category_mapping_name: {},
          category_mapping_options: {},

          show_Attribute_mapping: false,
          attribute_mapping: {
            ebayAttrib: [],
            shopifyAttrib: [],
            used_ebay_attrib:[],
            ebayAttribInfo: {},
            required_map: [],
            optional_map: []
          },
          attributes_minmax:{},
          required_attribute_count:0,
          optional_attribute_count:0,
        },
        settings:[],
        /* category_mapping: {},
         category_mapping_name: {},
         category_mapping_options: {},

         show_Attribute_mapping: false,
         attribute_mapping: {
             ebayAttrib: [],
             shopifyAttrib: [],
             used_ebay_attrib:[],
             ebayAttribInfo: {},
             required_map: [],
             optional_map: [{ebayAttrib: '', shopifyAttrib: '', recommendation: '', defaultText: ''}]
         },

         attributes_minmax:{},
         required_attribute_count:0,
         optional_attribute_count:0,*/
      },
      primaryCategory: {
        category_search: {search: '', selected: []},
      },
      secondaryCategory: {
        category_search: {search: '', selected: []},
      },
      errors:{
        name:false,
        primaryCategory:{
          leafCategoryMissing:false,
          noCategorySelected:false,
          attributes:{
            missingerrors:false
          },
          optional_attributes:{
            missingerrors:false
          },
          category_feature:false
        },
        secondaryCategory:{
          leafCategoryMissing:false,
          noCategorySelected:false,
          attributes:{
            missingerrors:false
          }
        }

      },
      optionsAutocomplete:[],
      primary_category_feature_options:[],
      barcode_options:[],
      site_id:'',
      user_id:'',
      menachem_options :[],
      attributePrimaryspinner:false,
      attributeSecondaryspinner:false
    };
    this.getStorefrontcategory();
    this.getCategory('primaryCategory');
    this.getShopifyAttributes('primaryCategory');
    this.getCategory('secondaryCategory');
    this.getShopifyAttributes('secondaryCategory');
    this.getSideID();
  }
  video={Modal:false,id:''};


  getSideID(){
    requests.getRequest('ebayV1/get/siteId').then(data=>{
      if(data.success){
        this.state.site_id=data.data.site_id;
        if(!isUndefined(data.data.user_id)) {
          this.state.user_id = data.data.user_id;
          if(data.data.user_id == 1213){
            this.getMenchamCategories()
          }
        }
        this.setState(this.state);
      }
    });

  }
  getMenchamCategories(){
    requests.getRequest('ebayV1/get/getmenachemCategories').then(data=>{
      if(data.success){
        this.setState({menachem_options:this.getMOdifiedData(data.data)});
      }
    })
  }

  getFilterModified(data){
    let tempArr = [];
    data.forEach((value,index)=>{
      tempArr.push(
          {label:value.label,value:value.id.toString()}
      )
    })

    return tempArr;
  }

  getMOdifiedData(data){
    let tempObj = [];
    data.forEach((value,index)=>{
      let filters =[];
      if(!isUndefined(value.filters) && value.filters.length>0){
        filters = this.getFilterModified(value.filters)
      }
      tempObj.push(
          {label : value.label,value: value.id.toString(),filters: filters}
      )
    });
    return tempObj;
  }

  getCategory(categoryType){
    this.setState({overlayloader:true});
    if(Object.keys(this.state.form_data[categoryType].category_mapping_options).length===0) {
      requests.postRequest("ebayV1/get/categories", {'level': Object.keys(this.state.form_data[categoryType].category_mapping_options).length + 1}).then(data => {
        if (data.success) {
          this.setCategoryOptions(data.data,categoryType);
        }
        this.setState({overlayloader:false});
      });
    }
    else{
      requests.postRequest("ebayV1/get/categories", {'parent_category_id': this.state.form_data[categoryType].category_mapping[Object.keys(this.state.form_data[categoryType].category_mapping_name).length]}).then(data => {
        if (data.success) {
          if(data.data.length>0) {
            this.setCategoryOptions(data.data,categoryType);
          }
          else if(data.data.length===0){

            this.getAttribute(categoryType);
          }
        }
        this.setState({overlayloader:false});
      });
    }
  }

  setCategoryOptions(data,categoryType){
    let tempObj=Object.assign({},this.state.form_data[categoryType].category_mapping_options);
    let temparr=[];
    data.forEach((value,index)=>{
      temparr.push(
          {label:value.CategoryName,value:value.CategoryID}
      );
    });
    let Currentoptionspresent=Object.keys(this.state.form_data[categoryType].category_mapping_options).length+1;
    tempObj[Currentoptionspresent]=temparr.slice(0);
    this.state.form_data[categoryType].category_mapping_options=tempObj;
    this.setState(this.state);

  }

  renderCategory(categoryType){
    let temparr=[];
    Object.keys(this.state.form_data[categoryType].category_mapping_options).map(key=>{
      temparr.push(
          <Select
              key={'CategoryLevel'+key}
              options={this.state.form_data[categoryType].category_mapping_options[key]}
              label={'Category Level '+(parseInt(key))}
              placeholder={"Please select..."}
              value={this.state.form_data[categoryType].category_mapping[key]}
              onChange={this.CategoryfeildsChange.bind(this,key,categoryType)}/>
      );

    });

    return temparr;
  }

  CategoryfeildsChange(key,categoryType,value){

    let tempObj=Object.assign({},this.state.form_data[categoryType].category_mapping);
    let tempObjCategoryNaming=Object.assign({},this.state.form_data[categoryType].category_mapping_name);
    let categoryOptions=Object.assign({},this.state.form_data[categoryType].category_mapping_options);

    tempObj[key]=value;
    this.state.form_data[categoryType].category_mapping_options[key].forEach((objcategory,index)=>{
      if(objcategory['value']===value){
        tempObjCategoryNaming[key]=objcategory['label'];
      }
    });
    Object.keys(this.state.form_data[categoryType].category_mapping_options).map(level=>{
      if(key<level)
      {
        delete tempObjCategoryNaming[level];
        delete categoryOptions[level];
        delete tempObj[level];
        this.resetAttributeSetting(categoryType);
      }
    });
    this.state.form_data[categoryType].category_mapping_name=tempObjCategoryNaming;
    this.state.form_data[categoryType].category_mapping_options=categoryOptions;
    this.state.form_data[categoryType].category_mapping=tempObj;
    this.setState(this.state);
    this.getCategory(categoryType);
  }

  getShopifyConfigurableAttributes(){
    requests.getRequest('connector/get/configurableAttributes').then(data=>{
      if(data.success){
        this.setVariantAttributes(data.data);
      }
    })
  }
  setVariantAttributes(data){
    let temparr=[];
    data.forEach((value,index)=>{
      temparr.push({label:value,value:value})
    });
    // console.log(temparr);
    this.state.form_data.variation_image_settings.options=temparr.slice(0);
    this.setState(this.state);
  }

  resetAttributeSetting(categoryType){
    let shopifyAttribute=this.state.form_data[categoryType].attribute_mapping.shopifyAttrib.slice(0);
    let customShopifyAttrib=this.state.form_data[categoryType].attribute_mapping.customShopifyAttrib.slice(0);
    let attribute_mapping={
      ebayAttrib: [],
      shopifyAttrib: shopifyAttribute,
      customShopifyAttrib:customShopifyAttrib,
      used_ebay_attrib:[],
      ebayAttribInfo: {},
      required_map: [],
      optional_map: [],
      custom_map:[]
    };
    this.state.form_data[categoryType].attributes_minmax={};
    this.state.form_data[categoryType].required_attribute_count=0;
    this.state.form_data[categoryType].optional_attribute_count=0;
    this.state.form_data[categoryType].show_Attribute_mapping=false;
    this.state.form_data[categoryType].attribute_mapping = attribute_mapping;
    this.setState(this.state);
  }

  formValidator(){
    let errors=0;
    Object.keys(this.state.form_data).map(key=>{
      switch(key){
        case 'name':
          if(this.state.form_data[key]===''){
            this.state.errors.name=true;
            errors+=1;
          }
          else{
            this.state.errors.name=false;
          }
          break;
        case 'primaryCategory':
          if(!isUndefined(this.state.form_data[key].category_mapping) && Object.keys(this.state.form_data[key].category_mapping).length ===0){
            this.state.errors.primaryCategory.noCategorySelected=true;
            errors+=1;
          }
          else{
            this.state.errors.primaryCategory.noCategorySelected=false;
            if(Object.keys(this.state.form_data[key].category_mapping).length<Object.keys(this.state.form_data[key].category_mapping_options).length){
              this.state.errors.primaryCategory.leafCategoryMissing=true;
              errors+=1;
            }
            else{
              this.state.errors.primaryCategory.leafCategoryMissing=false;
              if(this.state.form_data[key].required_attribute_count>0 && this.state.form_data[key].show_Attribute_mapping){
                let tempError=[];
                this.state.form_data[key].attribute_mapping.required_map.forEach((reqattrib,positions)=>{
                  let shopifyAtr=false;
                  let recommen=false;
                  let defauText=false;
                  if(reqattrib.shopifyAttrib===''){
                    shopifyAtr=true;
                  }else{
                    shopifyAtr=false;
                    if(reqattrib.shopifyAttrib==='recommendation'){
                      if(reqattrib.recommendation===''){
                        recommen=true;
                      }else{
                        recommen=false;
                        if(reqattrib.recommendation==='custom'){
                          if(reqattrib.defaultText===''){
                            defauText=true;
                          }else{
                            defauText=false;
                          }
                        }
                      }
                    }
                  }

                  if(shopifyAtr || recommen || defauText){
                    let tempTextShopifyAttr= shopifyAtr?' Shopify attribute':'';
                    let tempTextrecommenAttr= recommen?' eBay recommendation':'';
                    let tempdefaultText= defauText?' Custom field':'';

                    tempError.push(
                        'Missing fields in required attribute #'+(positions+1)+tempTextShopifyAttr+tempTextrecommenAttr+tempdefaultText
                    )
                  }

                });
                if(tempError.length>0){
                  this.state.errors.primaryCategory.attributes.missingerrors=tempError.slice(0);
                  errors+=1;
                }else{
                  this.state.errors.primaryCategory.attributes.missingerrors=false;
                }

              }
              if(this.state.form_data[key].optional_attribute_count>0 && this.state.form_data[key].show_Attribute_mapping){
                let tempError=[];
                this.state.form_data[key].attribute_mapping.optional_map.forEach((optionattrib,positions)=>{
                  let shopifyAtr=false;
                  let recommen=false;
                  let defauText=false;
                  if(optionattrib.ebayAttrib!=='') {
                    if (optionattrib.shopifyAttrib === '') {
                      shopifyAtr = true;
                    } else {
                      shopifyAtr = false;
                      if (optionattrib.shopifyAttrib === 'recommendation') {
                        if (optionattrib.recommendation === '') {
                          recommen = true;
                        } else {
                          recommen = false;
                          if (optionattrib.recommendation === 'custom') {
                            if (optionattrib.defaultText === '') {
                              defauText = true;
                            } else {
                              defauText = false;
                            }
                          }
                        }
                      }
                    }

                    if (shopifyAtr || recommen || defauText) {
                      let tempTextShopifyAttr = shopifyAtr ? ' Shopify attribute' : '';
                      let tempTextrecommenAttr = recommen ? ' eBay recommendation' : '';
                      let tempdefaultText = defauText ? ' Custom field' : '';

                      tempError.push(
                          'Missing fields in optional attribute #' + (positions + 1) + tempTextShopifyAttr + tempTextrecommenAttr + tempdefaultText
                      )
                    }
                  }
                });
                if(tempError.length>0){
                  this.state.errors.primaryCategory.optional_attributes.missingerrors=tempError.slice(0);
                  errors+=1;
                }else{
                  this.state.errors.primaryCategory.optional_attributes.missingerrors=false;
                }

              }
            }
          }
          if(!isUndefined(this.state.primary_category_feature_options) && this.state.primary_category_feature_options.length>0){
            if(this.state.form_data[key].category_feature === ''){
              this.state.errors.primaryCategory.category_feature=true;
              errors+=1;
            }else{
              this.state.errors.primaryCategory.category_feature=false;
            }
          }
          break;
        case 'secondaryCategory':
          if(this.state.form_data.enable_advance_options) {
            if (!isUndefined(this.state.form_data[key].category_mapping) && Object.keys(this.state.form_data[key].category_mapping).length === 0) {
              this.state.errors.secondaryCategory.noCategorySelected = true;
              errors += 1;
            }
            else {
              this.state.errors.secondaryCategory.noCategorySelected = false;
              if (Object.keys(this.state.form_data[key].category_mapping).length < Object.keys(this.state.form_data[key].category_mapping_options).length) {
                this.state.errors.secondaryCategory.leafCategoryMissing = true;
                errors += 1;
              }
              else{
                this.state.errors.secondaryCategory.leafCategoryMissing=false;
                // if(this.state.form_data[key].required_attribute_count>0 && this.state.form_data[key].show_Attribute_mapping){
                //     let tempError=[];
                //     this.state.form_data[key].attribute_mapping.required_map.forEach((reqattrib,positions)=>{
                //         let shopifyAtr=false;
                //         let recommen=false;
                //         let defauText=false;
                //         if(reqattrib.shopifyAttrib===''){
                //             shopifyAtr=true;
                //         }else{
                //             shopifyAtr=false;
                //             if(reqattrib.shopifyAttrib==='recommendation'){
                //                 if(reqattrib.recommendation===''){
                //                     recommen=true;
                //                 }else{
                //                     recommen=false;
                //                     if(reqattrib.recommendation==='custom'){
                //                         if(reqattrib.defaultText===''){
                //                             defauText=true;
                //                         }else{
                //                             defauText=false;
                //                         }
                //                     }
                //                 }
                //             }
                //         }
                //
                //         if(shopifyAtr || recommen || defauText){
                //             let tempTextShopifyAttr= shopifyAtr?' Shopify attribute':'';
                //             let tempTextrecommenAttr= recommen?' eBay recommendation':'';
                //             let tempdefaultText= defauText?' Custom field':'';
                //
                //             tempError.push(
                //                 'Missing fields in required attribute #'+(positions+1)+tempTextShopifyAttr+tempTextrecommenAttr+tempdefaultText
                //             )
                //         }
                //
                //     });
                //     if(tempError.length>0){
                //         this.state.errors.secondaryCategory.attributes.missingerrors=tempError.slice(0);
                //         errors+=1;
                //     }
                //     else{
                //         this.state.errors.secondaryCategory.attributes.missingerrors=false;
                //     }
                //
                //
                // }
              }
            }
          }
          break;
      }
    });

    this.setState(this.state);
    if(errors===0){
      return true;
    }
    else
    {
      return false;
    }

  }

  saveConfigData(){

    if(this.formValidator()){
      let FormDataOBj=Object.assign({},this.state.form_data);
      // FormDataOBj.bestofferenabled=this.state.barcode_options.indexOf('BestOfferEnabled')>-1 && this.state.form_data.bestofferenabled;
      FormDataOBj.variation_specific=this.state.barcode_options.indexOf('VariationsEnabled')>-1;
      let tempObj={
        title:this.state.form_data.name,
        type:'category',
        data:FormDataOBj
      };
      if(this.state._id!=='') {
        tempObj['_id'] = this.state._id;
      }
      this.props.recieveFormdata(tempObj);
    }else{
      notify.error('Kindly fill all the required fields');
    }
  }


  componentDidMount(){
    if(!isUndefined(this.props.data) && !isUndefined(this.props.data.id) && this.props.data.id!=='') {
      this.state._id=this.props.data.id;
      this.state.overlayloader = true;
      this.setState(this.state);
      this.getSideID();
      this.getData();
    }else {
      this.getShopifyConfigurableAttributes();
    }
  }

  getStorefrontcategory(){
    requests.getRequest('ebayV1/get/userDetails').then(data=>{
      if(data.success){
        this.extractStoreFrontcategory(data.data);
      }else{
        this.state.form_data.storefront_category_exists=false;
      }
      this.setState(this.state);
    })
  }

  getChildCategory(data, tempArr = [], parentName = []){
    let {ChildCategory, Name, CategoryID } = data;
    // if(parentName.length === 1){
    // tempArr.push(
    //     {
    //       label:Name,value:CategoryID.toString()
    //     }
    // );
    // }
    parentName.push(Name);
    if(ChildCategory){
      ChildCategory.forEach((childCategory,pos)=>{
        tempArr.push(
            {
              label:`${parentName.join("->")}->${childCategory.Name}`,value:(childCategory.CategoryID).toString()
            }
        );
        if(childCategory.hasOwnProperty("ChildCategory")){
          this.getChildCategory(childCategory, tempArr, parentName);
        }
      });
    }
    parentName.pop();
    return tempArr;
  }

  extractStoreFrontcategory(data){
    let temparr=[];
    if(!isUndefined(data.Store) && !isUndefined(data.Store.CustomCategories) && !isUndefined(data.Store.CustomCategories.CustomCategory)){
      data.Store.CustomCategories.CustomCategory.forEach((category,index)=>{
        let childCategoryList = [];
        if(category.hasOwnProperty('ChildCategory')){

          childCategoryList.push(
              {
                label: category.Name+'(Root)', value: (category.CategoryID).toString(),
              }
          );
          childCategoryList = [...this.getChildCategory(category, childCategoryList, [])];
          // console.log(childOptions);
          // category.ChildCategory.forEach((childCategory,pos)=>{
          //   childCategoryList.push(
          //     {
          //       label:childCategory.Name,value:(childCategory.CategoryID).toString()
          //     }
          //   );
          // })
        }
        if(childCategoryList.length > 0){

          temparr.push(
              {
                title: category.Name, /*value: (category.CategoryID).toString(),*/ options: childCategoryList.slice(0)
              }
          );

        }else {
          temparr.push(
              {
                label: category.Name, value: (category.CategoryID).toString()
              }
          );
        }
      });
      this.state.form_data.storefront_category.options=temparr.slice(0);
      this.state.form_data.storefront_category_exists=true;
      this.setState(this.state);
    }


  }

  getData(){
    requests.getRequest('ebayV1/get/template',{template_id:this.props.data.id}).then(data=>{
      if(data.success){
        if(!isUndefined(data.data.data)) {
          // console.log(this.state.form_data);

          this.state.form_data = merge(this.state.form_data,data.data.data);

          // this.state.form_data = {...this.state.form_data,...data.data.data};
          // console.log(data.data.data);
          // console.log({...this.state.form_data,...data.data.data});
        }
      }
      this.setState(this.state);
      this.getShopifyConfigurableAttributes();
      this.getStorefrontcategory();
      this.getCategoryfeatures();
    })
  }

  CategoryPath(categoryType){
    let tempString=Object.values(this.state.form_data[categoryType].category_mapping_name);
    tempString=tempString.join(' / ');
    if(tempString===''){
      return 'Please select a category'
    }
    return tempString;
  }

  feildsChange(tag,value){
    let tempObj = Object.assign({}, this.state);
    tempObj.form_data[tag]= /*typeof value !== "boolean" ? value.replace(/[^\w\s]/gi, "").replace(/[0-9]/gi, ''):*/ value;
    // tempObj.form_data[tag]= typeof value !== "boolean" ? value.replace(/[^\w\s]/gi, "").replace(/[0-9]/gi, ''): value;
    this.setState(tempObj);
  }

  async refreshVariantImageSettingsAttribute(){
    let token = globalState.getLocalStorage("auth_token");
    if(token !== null ){
      let userData = jwtDecode(globalState.getLocalStorage("auth_token"));
      await requests.getRequest("frontend/test/fetchDetail", {user_id: userData.user_id, refresh_variant_attribute : true});
      notify.success("Attributes are refreshed");
      this.getShopifyConfigurableAttributes();
    }
  }

  handleCategorySearch(categoryType,search){
    this.state[categoryType].category_search.search=search;
    this.setState(this.state);
    if(search.length>3 && search.length!==0) {
      requests.getRequest('ebayV1/get/categoryPredictions', {category_name: search}).then(data => {
        if(data.success){
          this.setAutoCompleteValues(data.data)
        }
      })
    }
  }
  setAutoCompleteValues(options){

    let temparr=[];
    options.forEach((value,index)=>{
      temparr.push({
        label:value.CategoryName,value:value.CategoryID
      })
    });
    this.state.optionsAutocomplete=temparr.slice(0);
    this.setState(this.state);
  }

  resetCategory(categoryType){
    let tempObj=Object.assign({},this.state.form_data[categoryType].category_mapping_options);
    Object.keys(this.state.form_data[categoryType].category_mapping_options).map(key=>{
      if(parseInt(key)>1) {
        delete tempObj[key];
      }
    })
    this.state.form_data[categoryType].category_mapping_options=tempObj;
    this.state.form_data[categoryType].category_mapping_name={};
    this.state.form_data[categoryType].category_mapping={};
    this.state.form_data.primaryCategory.category_feature='';
    this.state.primary_category_feature_options=[];
    this.state.barcode_options=[];
    this.setState(this.state);
    this.resetAttributeSetting(categoryType);
  }

  updateAutoCompleteSelection(categoryType,key){
    this.resetCategory(categoryType);
    let getKey='';
    key.forEach((value,index)=>{
      this.state.optionsAutocomplete.forEach((matchedoption,place)=>{
        if(matchedoption.value.match(value)){
          getKey=value;
          this.state[categoryType].category_search.search=matchedoption.label;
        }
      })
    });
    this.setState(this.state);
    requests.getRequest('ebayV1/get/getParentCategories',{category_id:getKey}).then(data=>{
      if(data.success){

        this.ModifyandSetCategory(data.data,categoryType);
      }
    })
  };
  ModifyandSetCategory(data,categoryType){

    let category_map={};
    let category_map_name={};
    let category_map_list=Object.assign({},this.state.form_data[categoryType].category_mapping_options);
    if(data.length>0){
      data.forEach((CategoryInfo,index)=>{
        category_map[index+1]=CategoryInfo.category.CategoryID;
        category_map_name[index+1]=CategoryInfo.category.CategoryName;
        let temparr=[];
        if(CategoryInfo.same_level_categories.length>0) {
          CategoryInfo.same_level_categories.forEach((value, position) => {
            temparr.push({
              label: value.CategoryName, value: value.CategoryID
            });
          });

          category_map_list[index + 1] = temparr.slice(0);

        }

      });
      this.state.form_data[categoryType].category_mapping=Object.assign({},category_map);
      this.state.form_data[categoryType].category_mapping_name=Object.assign({},category_map_name);
      this.state.form_data[categoryType].category_mapping_options=Object.assign({},category_map_list);
      this.setState(this.state);
      this.getCategory(categoryType);
      // this.getAttribute(categoryType);
    }


  }


  getCategoryfeatures(){
    let category =Object.values(this.state.form_data.primaryCategory.category_mapping);
    let last_category_id=category[category.length -1];
    requests.getRequest('ebayV1/get/categoryFeatures', {category_id: last_category_id}).then(data => {
      if (data.success) {
        if(!isUndefined(data.data)){
          this.extractBarcodeCategoryOptions(data.data)
        }
      }
    })

  }

  renderAutoComplete(categoryType){
    // console.log(categoryType)
    let temparr=[];
    temparr.push(
        <div style={{height: '50px'}} key={'autoComplete-'+categoryType}>
          <Autocomplete
              options={this.state[categoryType].category_search.search.length>3?this.state.optionsAutocomplete:[]}
              selected={this.state[categoryType].category_search.selected}
              onSelect={this.updateAutoCompleteSelection.bind(this,categoryType)}
              textField={<Autocomplete.TextField
                  onChange={this.handleCategorySearch.bind(this,categoryType)}
                  label="Category search"
                  value={this.state[categoryType].category_search.search}
                  prefix={<Icon source={SearchMajorMonotone} color="inkLighter" />}
                  placeholder="Search"
              />}
          />
        </div>
    )
    return temparr;
  }

  renderBarcodeOptions(){
    let  temparr =[];

    temparr.push(
        <React.Fragment>
          <Stack key={'BestOfferEnabled'}>
            {this.state.barcode_options.indexOf('BestOfferEnabled') > -1 &&
            <Banner>This category has <b>Best Offer Enabled</b>, To enable/disable Best Offer on this Category simply uncheck the box shown below</Banner>
            }
          </Stack>
          <Stack vertical={false} key={'Barcode-options'}>
            <Checkbox
                key={'BestOffer'}
                checked={this.state.form_data.bestofferenabled}
                label="Best offer enabled"
                disabled={this.state.barcode_options.indexOf('BestOfferEnabled') == -1}
                onChange={(e)=>{
                  this.state.form_data.bestofferenabled = e;
                  this.setState(this.state);
                }}
            />
            <Checkbox
                key={'Variation-specific'}
                checked={this.state.barcode_options.indexOf('VariationsEnabled')>-1}
                label="Variations enabled"
                disabled={true}
                onChange={()=>{}}
            />
            <Checkbox
                key={'ISBNenabled'}
                checked={this.state.barcode_options.indexOf('ISBNEnabled')>-1}
                label="ISBN enabled"
                disabled={true}
                onChange={()=>{}}
            />
            <Checkbox
                key={'UPCEnabled'}
                checked={this.state.barcode_options.indexOf('UPCEnabled')>-1}
                label="UPC enabled"
                disabled={true}
                onChange={()=>{}}
            />
            <Checkbox
                key={'EANEnabled'}
                checked={this.state.barcode_options.indexOf('EANEnabled')>-1}
                label="EAN enabled"
                disabled={true}
                onChange={()=>{}}
            />
          </Stack>

        </React.Fragment>
    )

    return temparr;
  }
  extractBarcodeCategoryOptions(dataRecieved){
    let barcode_options=[];
    let categoryFeature_options=[];
    let isBestOfferEnabled = false;

    if(!isUndefined(dataRecieved[0]) && dataRecieved.length>0){

      Object.keys(dataRecieved[0]).map(key=>{

        switch(key){
          case 'BestOfferEnabled':
            if(dataRecieved[0][key]) {
              barcode_options.push('BestOfferEnabled');
              isBestOfferEnabled =true;
            }
            break;
          case 'VariationsEnabled':
            if(dataRecieved[0][key]) {
              barcode_options.push('VariationsEnabled');
            }
            break;
          case 'ISBNEnabled':
            barcode_options.push('ISBNEnabled');
            break;
          case 'UPCEnabled':
            barcode_options.push('UPCEnabled');
            break;
          case 'EANEnabled':
            barcode_options.push('EANEnabled');
            break;
          case 'ConditionEnabled':
            if(dataRecieved[0][key]==='Required' || dataRecieved[0][key]==='Enabled'){
              if(!isUndefined(dataRecieved[0]['ConditionValues']) && !isUndefined(dataRecieved[0]['ConditionValues']['Condition']))
                dataRecieved[0]['ConditionValues']['Condition'].forEach((value,index)=>{
                  categoryFeature_options.push({
                    label:value.DisplayName,value:(value.ID).toString()
                  });
                })
            }
            break;
        }
      })
    }
    // if( this.state.form_data.bestofferenabled  || isBestOfferEnabled) {
    //   this.state.form_data.bestofferenabled = isBestOfferEnabled;
    // }

    this.state.barcode_options=barcode_options;
    if(categoryFeature_options.length){
      categoryFeature_options.push({
        label: "Unselect", value: ""
      });
    }
    this.state.primary_category_feature_options=categoryFeature_options;
    this.setState(this.state);
  }
  DropdownCategory(data){
    this.state.form_data.primaryCategory.category_feature=data;
    this.setState(this.state);
  }
  getEbayUser(){
    requests.getRequest('ebayV1/get/userDetails').then(data=>{
      if(data.success){
        this.state.ebay_user_details = Object.assign({},data.data);
      }
      this.setState(this.state);
    })
  }
  importEbayShopdetails(){
    this.setState({refreshEbayUserDetails: true})
    requests.getRequest('ebayV1/import/userDetails').then(data=>{
      if(data.success){
        this.setState({refreshEbayUserDetails: false})
        notify.success(data.message);
        this.getEbayUser();
      }else{
        notify.info(data.message);
      }
    })
  }
  renderReqAttributeErrors(key){
    let temparr=[];
    this.state.errors[key].attributes.missingerrors.forEach((error,index)=>{
      temparr.push(<li className="mb-2">{error}</li>);
    });

    return (<Banner status={"critical"}>
      <ul>
        {temparr}
      </ul>
    </Banner>);
  }
  renderOptionalAttributeErrors(key){
    let temparr=[];
    this.state.errors[key].optional_attributes.missingerrors.forEach((error,index)=>{
      temparr.push(<li className="mb-2">{error}</li>);
    });

    return (<Banner status={"critical"}>
      <ul>
        {temparr}
      </ul>
    </Banner>);
  }

  render() {
    return (
        <LoadingOverlay
            active={this.state.overlayloader || this.state.attributePrimaryspinner || this.state.attributeSecondaryspinner}
            spinner
            text='Loading please wait...'
        >
          <Card title={"Category template"}  actions={[{content:<Badge status={"info"}><b style={{color:'#0000aa', textDecoration:'underline'}}>Need help?</b></Badge>,onAction:()=>{
              window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=category-templates','_blank')
            }},
            !this.props.infoBanner && {content:<Badge status={"info"}><b style={{color:'#0000aa', textDecoration:'underline'}}>Help Video</b></Badge>,onAction:()=>{this.openvideoModal('gVB4UW1R4Gk')}}
          ]}
          >

            <Card.Section>
              <Banner status={"info"}>
                <b>Category template </b>is used for assigning a category to your product along with the <b>required and optional attributes</b> which you commonly use for listing on eBay.
              </Banner>
            </Card.Section>
            {!isUndefined(this.props.infoBanner) && this.props.infoBanner  && <Card.Section>
              <Banner status={"info"}>
                Category template created below will be set as <b>default category template</b> for products but you can change your default settings from <b>Configuration</b> section of the app.
              </Banner>
            </Card.Section>}
            <Card.Section>
              <Stack vertical={true}>
                <TextField
                    label="Template name"
                    key={'Categoryname'}
                    type="text"
                    value={this.state.form_data.name}
                    error={this.state.errors.name?' ':''}
                    helpText={"*required"}
                    onChange={this.feildsChange.bind(this,'name')}/>
              </Stack>
            </Card.Section>
            <Card.Section title={"Primary Category Mapping"}>
              <Stack vertical={true} spacing={"loose"}>
                <Stack.Item>
                  {this.state.errors.primaryCategory.noCategorySelected &&
                  <Banner
                      title="Error"
                      status="critical"
                  >
                    <p>
                      No category is selected, Categories from root till leaf are required
                    </p>
                  </Banner>
                  }
                  {this.state.errors.primaryCategory.leafCategoryMissing &&
                  <Banner
                      title="Error"
                      status="critical"
                  >
                    <p>
                      Leaf categories are missing, Categories from root till leaf are required
                    </p>
                  </Banner>}
                  <Banner
                      title="Category path"
                      status="info"
                  >
                    <p>
                      {
                        this.CategoryPath('primaryCategory')
                      }
                    </p>
                  </Banner>
                </Stack.Item>
                <Stack.Item>
                  {
                    this.renderAutoComplete('primaryCategory')
                  }
                </Stack.Item>
                <Stack.Item>
                  <Stack vertical={false} distribution={"fillEvenly"}>
                    {
                      this.renderCategory('primaryCategory')
                    }
                  </Stack>
                </Stack.Item>
                {this.state.user_id == 1213 &&
                <Stack.Item>
                  <Select label={'Menachem Category'} placeholder={'Select....'} options={this.state.menachem_options} value={this.state.form_data.menachemCategory.selected_id}
                          onChange={(e)=>{
                            this.state.form_data.menachemCategory.selected_id = e;
                            this.setState(this.state,()=>{
                              this.getShopifyAttributes('primaryCategory');
                              this.getShopifyAttributes('secondaryCategory');
                            });
                          }}
                  />
                </Stack.Item>
                }
                {this.state.attributePrimaryspinner &&
                <Stack.Item>
                  <Stack vertical={true} alignment={"center"} distribution={"center"}>
                    <p className="font-weight-bold">Fetching attributes ... <Spinner size="small" color="teal"/></p>
                  </Stack>
                </Stack.Item>
                }
              </Stack>
            </Card.Section>
            {   !this.state.attributePrimaryspinner && this.state.barcode_options.length > 0 &&
            <Card.Section title={'Additional Information'}>
              {
                this.renderBarcodeOptions()
              }

            </Card.Section>
            }
            {this.state.form_data.primaryCategory.show_Attribute_mapping &&
            <Card.Section>
              <Card title={"Attribute Mapping"} actions={[{
                          content: 'Refresh eBay Attributes',
                          onAction: this.refreshEbayAttributes.bind(this),
                        }]}>
              {(this.state.attributePrimaryspinner)?<Skeleton case="component"/>:
                  <FormLayout>
                    {this.state.form_data.primaryCategory.attribute_mapping.required_map.length > 0 &&
                    <Card title={'Required Attribute'}>
                      <Card.Section>
                        {
                          this.state.errors.primaryCategory.attributes.missingerrors && this.renderReqAttributeErrors('primaryCategory')
                        }
                        {
                          this.renderRequired('primaryCategory')
                        }
                      </Card.Section>
                    </Card>
                    }
                    {this.state.form_data.primaryCategory.attribute_mapping.ebayAttrib.length > 0 &&
                    <Card title={'Optional Attribute'}
                          actions={[{
                            content: 'Add attribute',
                            onAction: this.handleAdd.bind(this, 'optional', 'primaryCategory'),
                            disabled: this.state.form_data.primaryCategory.attribute_mapping.used_ebay_attrib.length > 0 && this.state.form_data.primaryCategory.attribute_mapping.used_ebay_attrib.length >= this.state.form_data.primaryCategory.optional_attribute_count
                          }]}>
                      <Card.Section>
                        {
                          this.state.errors.primaryCategory.optional_attributes.missingerrors && this.renderOptionalAttributeErrors('primaryCategory')
                        }
                        {
                          this.renderOptional('primaryCategory')
                        }
                        {this.state.form_data.primaryCategory.attribute_mapping.optional_map.length === 0 &&
                        <Banner status={"info"}>
                          {this.state.form_data.primaryCategory.optional_attribute_count>0?"Optional attributes can be added by clicking Add attribute above":"No optional attributes found"}
                        </Banner>
                        }
                      </Card.Section>
                    </Card>
                    }
                    <Card title={'Custom Attribute'}
                          actions={[{
                            content: 'Add attribute',
                            onAction: this.handleAdd.bind(this, 'custom', 'primaryCategory'),
                          }]}>
                      <Card.Section>
                        {
                          this.rendercustom('primaryCategory')
                        }
                        {this.state.form_data.primaryCategory.attribute_mapping.custom_map.length === 0 &&
                        <Banner status={"info"}>
                          {this.state.form_data.primaryCategory.optional_attribute_count>0?"Custom attributes can be added by clicking Add attribute above":"No optional attributes found"}
                        </Banner>
                        }
                      </Card.Section>
                      {/* <Card.Section>
                        <Checkbox
                            key={'EnableBundleOption'}
                            checked={this.state.form_data.bundle_listing}
                            label="Enable bundle listing"
                            onChange={this.feildsChange.bind(this, 'bundle_listing')}
                        />
                      </Card.Section> */}
                    </Card>
                  </FormLayout>
              }
              </Card>
            </Card.Section>
            }
            {!this.state.attributePrimaryspinner && this.state.primary_category_feature_options.length > 0 &&
            <Card.Section title={'Product condition'}>
              <Select
                  options={this.state.primary_category_feature_options}
                  placeholder={'Select..'}
                  onChange={this.DropdownCategory.bind(this)}
                  error={ this.state.errors.primaryCategory.category_feature?'*required field':''}
                  value={this.state.form_data.primaryCategory.category_feature}
              />
              <TextField
                  label="Additional condition description"
                  key={'Additional condition description'}
                  value={this.state.form_data.primaryCategory.condition_description}
                  onChange={this.handletwoLevelDropdown.bind(this,'primaryCategory','condition_description')}
                  multiline={3}
              />
            </Card.Section>
            }
            {this.state.form_data.storefront_category_exists &&
            <Card.Section title={'eBay store front category'} actions={[{
              content: 'Refresh Details',
              onAction: this.importEbayShopdetails.bind(this),
            }]}>
              <Select
                  options={this.state.form_data.storefront_category.options}
                  placeholder={'Select..'}
                  label={''}
                  onChange={this.handletwoLevelDropdown.bind(this, 'storefront_category', 'selected')}
                  value={this.state.form_data.storefront_category.selected}
              />
            </Card.Section>
            }
          </Card>
          <Card  actions={[{content:"Refresh attributes", onAction:this.refreshVariantImageSettingsAttribute.bind(this)}]}>
            {!isUndefined(this.state.form_data.variation_image_settings.options) && this.state.form_data.variation_image_settings.options.length>0 &&
            <Card.Section title={"Variation Image Settings"}>
              <ChoiceList
                  title=""
                  allowMultiple
                  choices={this.state.form_data.variation_image_settings.options}
                  selected={this.state.form_data.variation_image_settings.selected}
                  onChange={(e) => {
                    this.state.form_data.variation_image_settings.selected = e;
                    this.setState(this.state);
                  }}
              />
            </Card.Section>
            }
            {isUndefined(this.props.showSecondaryCategory) &&
            <Card.Section>
              <Stack vertical={true}>
                <Checkbox
                    key={'EnableadvanceOption'}
                    checked={this.state.form_data.enable_advance_options}
                    label="Enable secondary category"
                    disabled={this.state.site_id === 'MOTORS'}
                    onChange={this.feildsChange.bind(this, 'enable_advance_options')}
                />
              </Stack>
            </Card.Section>
            }
            {this.state.form_data.enable_advance_options &&
            <Card.Section title={"Secondary Category Mapping"}>
              <Stack vertical={true} spacing={"loose"}>
                <Stack.Item>
                  {this.state.errors.secondaryCategory.noCategorySelected &&
                  <Banner
                      title="Error"
                      status="critical"
                  >
                    <p>
                      No category is selected, Categories from root till leaf are required
                    </p>
                  </Banner>
                  }
                  {this.state.errors.secondaryCategory.leafCategoryMissing &&
                  <Banner
                      title="Error"
                      status="critical"
                  >
                    <p>
                      Leaf categories are missing, Categories from root till leaf are required
                    </p>
                  </Banner>}
                  <Banner
                      title="Category path"
                      status="info"
                  >
                    <p>
                      {
                        this.CategoryPath('secondaryCategory')
                      }
                    </p>
                  </Banner>
                </Stack.Item>
                <Stack.Item>
                  {
                    this.renderAutoComplete('secondaryCategory')
                  }
                </Stack.Item>
                <Stack.Item>
                  <Stack vertical={false} distribution={"fillEvenly"}>
                    {
                      this.renderCategory('secondaryCategory')
                    }
                  </Stack>
                </Stack.Item>
                {/*{this.state.attributeSecondaryspinner &&*/}
                {/*<Stack.Item>*/}
                {/*<Stack vertical={true} alignment={"center"} distribution={"center"}>*/}
                {/*<p className="font-weight-bold">Fetching attributes ... <Spinner size="small" color="teal"/></p>*/}
                {/*</Stack>*/}
                {/*</Stack.Item>*/}
                {/*}*/}

              </Stack>
            </Card.Section>
            }
            {/*{this.state.form_data.enable_advance_options && this.state.form_data.secondaryCategory.show_Attribute_mapping &&*/}
            {/*<Card.Section title={"Attribute Mapping"}>*/}
            {/*{*/}
            {/*(this.state.attributeSecondaryspinner)?<Skeleton case="component"/>:<FormLayout>*/}
            {/*{this.state.form_data.secondaryCategory.attribute_mapping.required_map.length > 0 &&*/}
            {/*<Card title={'Required Attribute'}>*/}
            {/*<Card.Section>*/}
            {/*{*/}
            {/*this.state.errors.secondaryCategory.attributes.missingerrors && this.renderReqAttributeErrors('secondaryCategory')*/}
            {/*}*/}
            {/*{*/}
            {/*this.renderRequired('secondaryCategory')*/}
            {/*}*/}
            {/*</Card.Section>*/}
            {/*</Card>*/}
            {/*}*/}
            {/*{this.state.form_data.secondaryCategory.attribute_mapping.ebayAttrib.length > 0 &&*/}
            {/*<Card title={'Optional Attribute'}*/}
            {/*actions={[{*/}
            {/*content: 'Add attribute',*/}
            {/*onAction: this.handleAdd.bind(this, 'optional', 'secondaryCategory'),*/}
            {/*disabled: this.state.form_data.secondaryCategory.attribute_mapping.used_ebay_attrib.length > 0 && this.state.form_data.secondaryCategory.attribute_mapping.used_ebay_attrib.length >= this.state.form_data.secondaryCategory.optional_attribute_count*/}
            {/*}]}>*/}
            {/*<Card.Section>*/}
            {/*{*/}
            {/*this.renderOptional('secondaryCategory')*/}
            {/*}*/}
            {/*{this.state.form_data.secondaryCategory.attribute_mapping.optional_map.length === 0 &&*/}
            {/*<Banner status={"info"}>*/}
            {/*No optional attributes added*/}
            {/*</Banner>*/}
            {/*}*/}
            {/*</Card.Section>*/}
            {/*</Card>*/}
            {/*}*/}
            {/*</FormLayout>*/}
            {/*}*/}
            {/*</Card.Section>*/}
            {/*}*/}
            <ModalVideo channel='youtube' isOpen={this.video.Modal} videoId={this.video.id}  onClose={this.closevideoModal.bind(this)} />

          </Card>
        </LoadingOverlay>
    );
  }

  openvideoModal(id){
    this.video.Modal=true;
    this.video.id=id;
    this.setState(this.state);
  }

  closevideoModal(){
    this.video.Modal=false;
    this.video.id='';
    this.setState(this.state);
  }

  handletwoLevelDropdown(field,subhead,value){
    this.state.form_data[field][subhead]=value;
    this.setState(this.state);
  }

  handleDelete(index,type,categoryType){
    switch(type){
      case 'optional':
        let temparr=this.state.form_data[categoryType].attribute_mapping.optional_map.slice(0);
        temparr.splice(index,1);
        this.state.form_data[categoryType].attribute_mapping.optional_map=temparr;
        break;
      case 'required':
        break;
      case 'custom':
        let custom_temparr=this.state.form_data[categoryType].attribute_mapping.custom_map.slice(0);
        custom_temparr.splice(index,1);
        this.state.form_data[categoryType].attribute_mapping.custom_map=custom_temparr;
        break;
    }
    this.setState(this.state);
    this.toggleOptionEbayAttribute(categoryType);
  }

  handleAdd(type,categoryType){
    switch(type){
      case 'optional':
        let temparr=[];
        let tempObj={};
        temparr=this.state.form_data[categoryType].attribute_mapping.optional_map.slice(0);
        tempObj=Object.assign({},attribute);
        temparr.push(tempObj);
        this.state.form_data[categoryType].attribute_mapping.optional_map=temparr;
        break;
      case 'required':
        break;
      case 'custom':
        let customtemparr=[];
        let custom_tempObj={};
        customtemparr=this.state.form_data[categoryType].attribute_mapping.custom_map.slice(0);
        custom_tempObj=Object.assign({},custom_attribute);
        customtemparr.push(custom_tempObj);
        this.state.form_data[categoryType].attribute_mapping.custom_map=customtemparr;
        break;
    }
    this.setState(this.state);
  }

  // utkarsh
  refreshEbayAttributes() {
    this.setState({overlayloader:true});
    let categoryType = 'primaryCategory';
    console.log('check', this.state.form_data[categoryType].category_mapping[Object.keys(this.state.form_data[categoryType].category_mapping_name).length]);
    requests.postRequest("ebayV1/app/removeCategoryAttributes", {'category_id': this.state.form_data[categoryType].category_mapping[Object.keys(this.state.form_data[categoryType].category_mapping_name).length]}).then(data => {
      console.log('data', data);
      if (data.success) {
        this.getAttribute(categoryType);
      }
      this.setState({overlayloader:false});
    });
  }
  renderRequired(categoryType){
    let temparr=[];
    this.state.form_data[categoryType].attribute_mapping.required_map.forEach((value,index)=>{
      temparr.push(
          <Card key={'required-attribute-'+index} title={"# "+(index+1)}>
            <Card.Section>
              <Stack vertical={false}>
                <Stack.Item fill>
                  <FormLayout>
                    <FormLayout.Group condensed>
                      <Select
                          label="eBay attributes"
                          options={this.state.form_data[categoryType].attribute_mapping.ebayAttrib}
                          placeholder={'Select..'}
                          disabled={true}
                          onChange={this.handleMappingChange.bind(this,'ebayAttrib','required',index,categoryType)}
                          value={this.state.form_data[categoryType].attribute_mapping.required_map[index].ebayAttrib}
                      />
                      <Select
                          label="Shopify attributes*"
                          placeholder={'Select..'}
                          options={this.state.form_data[categoryType].attribute_mapping.shopifyAttrib}
                          onChange={this.handleMappingChange.bind(this,'shopifyAttrib','required',index,categoryType)}
                          value={this.state.form_data[categoryType].attribute_mapping.required_map[index].shopifyAttrib}
                      />
                      {this.state.form_data[categoryType].attribute_mapping.required_map[index].shopifyAttrib==='recommendation' &&
                      <Select
                          label="eBay Recommendations*"
                          placeholder={'Select..'}
                          disabled={this.state.form_data[categoryType].attribute_mapping.required_map[index].shopifyAttrib !== 'recommendation'}
                          options={
                            this.state.form_data[categoryType].attribute_mapping.required_map[index].ebayAttrib !== '' && this.state.form_data[categoryType].attribute_mapping.required_map[index].shopifyAttrib === 'recommendation' ?
                                this.state.form_data[categoryType].attribute_mapping.ebayAttribInfo[this.state.form_data[categoryType].attribute_mapping.required_map[index].ebayAttrib].recommendedoptions : []}
                          onChange={this.handleMappingChange.bind(this, 'recommendation', 'required', index, categoryType)}
                          value={this.state.form_data[categoryType].attribute_mapping.required_map[index].recommendation}
                      />
                      }
                      {this.state.form_data[categoryType].attribute_mapping.required_map[index].ebayAttrib !== '' && this.state.form_data[categoryType].attribute_mapping.required_map[index].shopifyAttrib === 'recommendation' && this.state.form_data[categoryType].attribute_mapping.required_map[index].recommendation ==='custom' &&
                      <TextField
                          label="Custom Value"
                          type="text"
                          disabled={this.state.form_data[categoryType].attribute_mapping.required_map[index].recommendation !== 'custom'}
                          helpText={'*required'}
                          value={this.state.form_data[categoryType].attribute_mapping.required_map[index].defaultText}
                          onChange={this.handleMappingChange.bind(this, 'defaultText', 'required', index,categoryType)}
                      />
                      }
                    </FormLayout.Group>
                  </FormLayout>
                </Stack.Item>
              </Stack>
            </Card.Section>
          </Card>
      );
    })
    return temparr;
  }

  renderOptional(categoryType){
    let temparr=[];
    this.state.form_data[categoryType].attribute_mapping.optional_map.forEach((value,index)=>{
      console.log(this.state.form_data[categoryType].attribute_mapping.optional_map[index].ebayAttrib);
      console.log(this.state.form_data[categoryType].attribute_mapping.ebayAttribInfo[this.state.form_data[categoryType].attribute_mapping.optional_map[index].ebayAttrib]);
      temparr.push(
          <Card key={'optionalcategory'+index} title={"# "+(index+1)} actions={[{content:'Delete',onAction:this.handleDelete.bind(this,index,'optional',categoryType),disabled:this.state.form_data[categoryType].attribute_mapping.optional_map.length===0}]}>
            <Card.Section>
              {this.state.form_data[categoryType].attribute_mapping.optional_map.length>0 &&
              <Stack vertical={false}>
                <Stack.Item fill>
                  <FormLayout>
                    <FormLayout.Group condensed>
                      <Select
                          label="eBay attributes"
                          options={this.state.form_data[categoryType].attribute_mapping.ebayAttrib}
                          placeholder={'Select..'}
                          onChange={this.handleMappingChange.bind(this, 'ebayAttrib', 'optional', index,categoryType)}
                          value={this.state.form_data[categoryType].attribute_mapping.optional_map[index].ebayAttrib}
                      />
                      <Select
                          label="Shopify attributes"
                          placeholder={'Select..'}
                          disabled={this.state.form_data[categoryType].attribute_mapping.optional_map[index].ebayAttrib === ''}
                          options={this.state.form_data[categoryType].attribute_mapping.shopifyAttrib}
                          onChange={this.handleMappingChange.bind(this, 'shopifyAttrib', 'optional', index,categoryType)}
                          value={this.state.form_data[categoryType].attribute_mapping.optional_map[index].shopifyAttrib}
                      />
                      {this.state.form_data[categoryType].attribute_mapping.optional_map[index].shopifyAttrib === 'recommendation' &&
                      <Select
                          label="eBay Recommendations"
                          placeholder={'Select..'}
                          disabled={this.state.form_data[categoryType].attribute_mapping.optional_map[index].shopifyAttrib !== 'recommendation'}
                          options={
                            this.state.form_data[categoryType].attribute_mapping.optional_map[index].ebayAttrib !== '' && this.state.form_data[categoryType].attribute_mapping.optional_map[index].shopifyAttrib === 'recommendation' && !isUndefined(this.state.form_data[categoryType].attribute_mapping.ebayAttribInfo[this.state.form_data[categoryType].attribute_mapping.optional_map[index].ebayAttrib])?
                                this.state.form_data[categoryType].attribute_mapping.ebayAttribInfo[this.state.form_data[categoryType].attribute_mapping.optional_map[index].ebayAttrib].recommendedoptions : []}
                          onChange={this.handleMappingChange.bind(this, 'recommendation', 'optional', index, categoryType)}
                          value={this.state.form_data[categoryType].attribute_mapping.optional_map[index].recommendation}
                      />
                      }
                      {this.state.form_data[categoryType].attribute_mapping.optional_map[index].ebayAttrib !== '' && this.state.form_data[categoryType].attribute_mapping.optional_map[index].shopifyAttrib === 'recommendation' && this.state.form_data[categoryType].attribute_mapping.optional_map[index].recommendation === 'custom' &&
                      <TextField
                          label="Custom Value"
                          type="text"
                          disabled={this.state.form_data[categoryType].attribute_mapping.optional_map[index].recommendation !== 'custom'}
                          helpText={'*required'}
                          value={this.state.form_data[categoryType].attribute_mapping.optional_map[index].defaultText}
                          onChange={this.handleMappingChange.bind(this, 'defaultText', 'optional', index,categoryType)}
                      />
                      }
                    </FormLayout.Group>
                  </FormLayout>
                </Stack.Item>
              </Stack>
              }
            </Card.Section>
          </Card>
      );
    });
    return temparr;
  }

  rendercustom(categoryType){
    let temparr=[];
    if(!isUndefined(this.state.form_data[categoryType].attribute_mapping.custom_map)) {
      this.state.form_data[categoryType].attribute_mapping.custom_map.forEach((value, index) => {
        temparr.push(
            <Card key={'customcategory' + index} title={"# " + (index + 1)} actions={[{
              content: 'Delete',
              onAction: this.handleDelete.bind(this, index, 'custom', categoryType),
              disabled: this.state.form_data[categoryType].attribute_mapping.custom_map.length === 0
            }]}>
              <Card.Section>
                {this.state.form_data[categoryType].attribute_mapping.custom_map.length > 0 &&
                <Stack vertical={false}>
                  <Stack.Item fill>
                    <FormLayout>
                      <FormLayout.Group condensed>
                        <TextField
                            label="Custom attribute"
                            placeholder={'Create..'}
                            onChange={this.handleMappingChange.bind(this, 'customAttrib', 'custom', index, categoryType)}
                            value={this.state.form_data[categoryType].attribute_mapping.custom_map[index].customAttrib}
                        />
                        <Select
                            label="Shopify attributes"
                            placeholder={'Select..'}
                            disabled={this.state.form_data[categoryType].attribute_mapping.custom_map[index].customAttrib === ''}
                            options={this.state.form_data[categoryType].attribute_mapping.customShopifyAttrib}
                            onChange={this.handleMappingChange.bind(this, 'shopifyAttrib', 'custom', index, categoryType)}
                            value={this.state.form_data[categoryType].attribute_mapping.custom_map[index].shopifyAttrib}
                        />
                        {this.state.form_data[categoryType].attribute_mapping.custom_map[index].customAttrib !== '' && this.state.form_data[categoryType].attribute_mapping.custom_map[index].shopifyAttrib === 'custom' &&
                        <TextField
                            label="Custom Value"
                            type="text"
                            disabled={this.state.form_data[categoryType].attribute_mapping.custom_map[index].shopifyAttrib !== 'custom'}
                            helpText={'*required'}
                            value={this.state.form_data[categoryType].attribute_mapping.custom_map[index].defaultText}
                            onChange={this.handleMappingChange.bind(this, 'defaultText', 'custom', index, categoryType)}
                        />
                        }
                      </FormLayout.Group>
                    </FormLayout>
                  </Stack.Item>
                </Stack>
                }
              </Card.Section>
            </Card>
        );
      });
    }
    return temparr;
  }

  toggleOptionEbayAttribute(categoryType){
    let temparr=[];
    this.state.form_data[categoryType].attribute_mapping.optional_map.forEach((attrib,place)=>{
      temparr.push(attrib.ebayAttrib);
    });
    this.state.form_data[categoryType].attribute_mapping.used_ebay_attrib=temparr.slice(0);
    this.state.form_data[categoryType].attribute_mapping.ebayAttrib.forEach((attriboptional,position)=>{
      if(attriboptional.title==='Optional'){
        attriboptional.options.forEach((optionOptional,postionoption)=>{
          let count=0;
          temparr.forEach((keyFound,keyPlace)=>{
            if(keyFound===optionOptional.label){
              count++;
            }
          });

          if(count>=this.state.form_data[categoryType].attributes_minmax[optionOptional.label]) {
            this.state.form_data[categoryType].attribute_mapping.ebayAttrib[position].options[postionoption].disabled = true;
          }
          else{
            this.state.form_data[categoryType].attribute_mapping.ebayAttrib[position].options[postionoption].disabled = false;
          }
        });
      }
    });
    this.setState(this.state);
  }


  handleMappingChange(key,type,index,categoryType,value){
    switch(type){
      case 'optional':
        this.state.form_data[categoryType].attribute_mapping.optional_map[index][key]=value;
        if(key==='ebayAttrib') {
          this.toggleOptionEbayAttribute(categoryType)
        }
        break;
      case 'required':
        this.state.form_data[categoryType].attribute_mapping.required_map[index][key]=value;
        break;
      case 'custom':
        this.state.form_data[categoryType].attribute_mapping.custom_map[index][key]=value;
        break;
    }
    this.setState(this.state);

  }

  getAttribute(categoryType){
    let category =Object.values(this.state.form_data[categoryType].category_mapping);
    let last_category_id=category[category.length -1];
    if(categoryType === 'primaryCategory') {
      this.state.attributePrimaryspinner = true;

    }else{
      this.state.attributeSecondaryspinner=true;
    }
    this.setState(this.state);
    requests.getRequest('ebayV1/get/attributesCategorywise',{category_id:last_category_id}).then(data=>{
      if(data.success){
        if(Array.isArray(data.data)) {
          this.ModifyAttributes(data.data[0].NameRecommendation, categoryType);
        }else{
          this.ModifyAttributes(data.data.NameRecommendation, categoryType);
        }
      }else{
        if(categoryType === 'primaryCategory') {
          this.state.attributePrimaryspinner = false;
        }else{
          this.state.attributeSecondaryspinner=false;
        }
        this.setState(this.state);
      }
    });
    if(categoryType==='primaryCategory') {
      requests.getRequest('ebayV1/get/categoryFeatures', {category_id: last_category_id}).then(data => {
        if (data.success) {
          if(!isUndefined(data.data)){
            this.extractBarcodeCategoryOptions(data.data)
          }
        }
      })
    }

  }


  getShopifyAttributes(categoryType){
    if(this.state.user_id == 1213) {
      this.setState({attributePrimaryspinner: true,attributeSecondaryspinner:true});
    }
    requests.getRequest('connector/product/getAttributesByProductQuery',{marketplace:'shopify',query:'(price>-1)'}).then(data=>{
      if(data.success){
        this.setShopifyAttribute(data.data,categoryType);
      }
    })
  }

  getMetaFields(){
    return requests.getRequest('shopify/product/getMetafieldsOptions').then(data =>{
      return data;
    });
  }

  async setShopifyAttribute(data,categoryType){
    let MetaInfo = await this.getMetaFields();
    let Metarray = [];
    if(MetaInfo.hasOwnProperty('success') && MetaInfo.success){
      (MetaInfo.data).forEach((Meta, pos) => {
        Metarray.push({label:Meta, value: Meta});
      });
    }

    let temparr=[];
    let customShopifyAttrib = [];
    customShopifyAttrib.push({
      label: 'Set a custom', value: 'custom'
    });
    customShopifyAttrib.push({
      label: 'Tags', value: 'tags'
    });
    temparr.push({label:'Select eBay recommendations',value:'recommendation'});
    data.forEach((value,index)=>{
      temparr.push({label:value.title,value:value.code})
      customShopifyAttrib.push({label:value.title,value:value.code})
    });

    if(this.state.user_id == 1213){
      this.state.menachem_options.forEach((value,index)=>{
        if(this.state.form_data.menachemCategory.selected_id == value.value){
          temparr.push(...value.filters);
          customShopifyAttrib.push(...value.filters);
        }
      });
    }

    temparr = [...temparr, ...Metarray];

    customShopifyAttrib = [...customShopifyAttrib, ...Metarray];

    this.state.form_data[categoryType].attribute_mapping.shopifyAttrib=temparr;
    this.state.form_data[categoryType].attribute_mapping.customShopifyAttrib=customShopifyAttrib;
    this.setState(this.state,()=>{
      if(this.state.user_id == 1213) {
        this.setState({attributePrimaryspinner: false,attributeSecondaryspinner:false});
      }
    });
  }


  ModifyAttributes(data,categoryType) {

    let tempObj = Object.assign({}, this.state.form_data[categoryType].attribute_mapping);
    let EbayAttribInfo={};
    let Ebayoptions={required:[],optional:[]} ;
    let requiredMap=[];
    let tempObjMinMaxvalues={};
    if(!isUndefined(data)) {
      data.forEach((value, index) => {
        let required = 0;
        if (!isUndefined(value.ValidationRules)) {
          let min = 0;
          let max = 0;
          if ('MinValues' in value.ValidationRules) {
            min = value.ValidationRules.MinValues;
          }
          if ('MaxValues' in value.ValidationRules) {
            max = value.ValidationRules.MaxValues;
          }
          if (min >= max) {
            tempObjMinMaxvalues[value.Name] = min;

          } else {
            tempObjMinMaxvalues[value.Name] = max;
          }
        }

        if (!isUndefined(value.ValidationRules) && !isUndefined(value.ValidationRules.MinValues) && value.ValidationRules.MinValues === 1) {
          required = 1;
          Ebayoptions.required.push(
              {label: value.Name, value: value.Name, disabled: true}
          );
          let requiredAttrib = Object.assign({}, attribute);
          requiredAttrib.ebayAttrib = value.Name;

          //Set default values
          if(!isUndefined(this.state.form_data[categoryType].attribute_mapping.shopifyAttrib) && this.state.form_data[categoryType].attribute_mapping.shopifyAttrib.length > 0){
            switch(value.Name){
              case 'Brand':
                requiredAttrib.shopifyAttrib = 'vendor';
                break;
              case 'MPN':
                requiredAttrib.shopifyAttrib = 'sku';
                break;
              case 'Size':
                requiredAttrib.shopifyAttrib = 'size';
                break;
              case 'Color':
                requiredAttrib.shopifyAttrib = 'color';
                break;
            }
          }
          requiredMap.push(
              requiredAttrib
          );
        } else {
          Ebayoptions.optional.push(
              {label: value.Name, value: value.Name, disabled: false}
          )
        }
        let recommendedOptions = [];
        recommendedOptions.push({
          label: 'Set a custom', value: 'custom'
        });
        if (!isUndefined(value.ValueRecommendation)) {
          value.ValueRecommendation.forEach((recommendValue, position) => {
            recommendedOptions.push({
              label: recommendValue.Value, value: recommendValue.Value
            });
          });
        }
        EbayAttribInfo[value.Name] = {
          recommendedoptions: recommendedOptions,
          required: required
        }
      });
    }

    this.state.form_data[categoryType].attributes_minmax=Object.assign({},tempObjMinMaxvalues);
    this.state.form_data[categoryType].attribute_mapping.ebayAttribInfo=EbayAttribInfo;
    let count_required=0;
    let count_optional=0;
    Ebayoptions.required.forEach((requiredCount,attribPosition)=>{

      count_required+=tempObjMinMaxvalues[requiredCount['label']];
    });
    Ebayoptions.optional.forEach((optionalCount,attribPosition)=>{

      count_optional+=tempObjMinMaxvalues[optionalCount['label']];
    });
    this.state.form_data[categoryType].required_attribute_count=count_required;
    this.state.form_data[categoryType].optional_attribute_count=count_optional;
    let finaltempoptions=[];
    Object.keys(Ebayoptions).map(key=>{

      if(key==='required' && Ebayoptions[key].length!==0){
        finaltempoptions.push(
            {title:'Required',options:Ebayoptions[key]},
        )
      }
      if(key==='optional' && Ebayoptions[key].length!==0){
        finaltempoptions.push(
            {title:'Optional',options:Ebayoptions[key]},
        )
      }
    });
    this.state.form_data[categoryType].attribute_mapping.required_map=requiredMap;
    this.state.form_data[categoryType].attribute_mapping.ebayAttrib=finaltempoptions;
    this.state.form_data[categoryType].show_Attribute_mapping=true;
    if(categoryType === 'primaryCategory') {
      this.state.attributePrimaryspinner = false;
    }else{
      this.state.attributeSecondaryspinner=false;
    }
    this.setState(this.state);
  }



  //
  // feildsChange(key,tag,value){
  //     let tempObj=Object.assign({},this.state);
  //     tempObj[key][tag]=value;
  //     this.setState(tempObj);
  //     if(key==='selling_details' && tag==='format' && value==='fixed_price'){
  //         this.state.selling_details.listing_duration='GTC';
  //         this.setState(this.state);
  //     }
  //     else if(key==='selling_details' && tag==='format' && value!=='fixed_price'){
  //         this.state.selling_details.listing_duration='3';
  //         this.setState(this.state);
  //     }
  // }
}

export default CategoryTemplate;
