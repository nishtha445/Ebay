import React, {Component} from 'react';
import {
  Page,
  Card,
  FormLayout,
  TextField,
  Checkbox,
  Stack,
  Select,
  Icon,
  Tooltip,
  Banner,
  Badge
} from '@shopify/polaris';
import {notify} from "../services/notify";
import {requests} from "../services/request";
import {isUndefined} from "util";
import ModalVideo from "react-modal-video";
import _ from 'lodash';


const sellingFormatOptions=[
  {label:'Fixed Price',value:'fixed_price'},
  {label:'Auction-style',value:'auction_style'}
];

let sellingListingDurations=[
  {
    label :'Days_1',
    value : 'Days_1',
    disabled:false,
  },
  {
    label : 'Days_3',
    value : 'Days_3',
    disabled:false,
  },
  {
    label : 'Days_5',
    value : 'Days_5',
    disabled:false,
  },
  {
    label : 'Days_7',
    value : 'Days_7',
    disabled:false,
  },
  {
    label : 'Days_10',
    value : 'Days_10',
    disabled:false,
  },
  {
    label : 'Days_21',
    value : 'Days_21',
    disabled:false,
  },
  {
    label : 'Days_30',
    value : 'Days_30',
    disabled:false,
  },
  {
    label : 'Days_60',
    value : 'Days_60',
    disabled:false,
  },
  {
    label : 'Days_90',
    value : 'Days_90',
    disabled:false,
  },
  {
    label : 'Days_120',
    value : 'Days_120',
    disabled:false,
  },
];

// const sellingListingDurations=[
//     {label:'3 Days',value:'3'},
//     {label:'5 Days',value:'5'},
//     {label:'7 Days',value:'7'},
//     {label:'10 Days',value:'10'},
//
// ];
const sellingListingDurationFixed=[
  {label:'GTC',value:'GTC'},
];

const SettingsFixed=[
  {label:'Custom price',value:'customized_price'},
  {label:'Flat price',value:'flat_price'},
  {label:'Default',value:'default'},
];
const SettingsAuction=[
  {label:'Custom price',value:'customized_price'},
  {label:'Flat price',value:'flat_price'},
  {label:'Default',value:'default'},
];

const variateType=[
  {label:'Increase',value:'increase'},
  {label:'Decrease',value:'decrease'},
];
const variateBy=[
  {label:'Percentage',value:'percentage'},
  {label:'Value',value:'value'},
];


class PricingTemplate extends Component {
  video={Modal:false,id:''};
  constructor(props){
    super(props);
    this.state={
      _id:'',
      form_data:{
        selling_details:{
          format:'fixed_price',
          listing_duration:'GTC'
        },
        name:'',
        roundOff:{
          all:false,
        },
        fixed_listing:{
          selected:'default',
          customized_price:{
            variate_type: 'increase',
            variate_by: 'value',
            variate_value: 0,

          },
          flat_price:{
            fixed_value:0
          }
        },
        auctions_listing:{
          start_price:{
            selected:'default',
            customized_price:{
              variate_type: 'increase',
              variate_by: 'value',
              variate_value: 0,
            },
            flat_price:{
              fixed_value:0
            }
          },
          use_buyitnow_price: true,
          buyitnow_price:{
            selected:'customized_price',
            customized_price:{
              variate_type: 'increase',
              variate_by: 'percentage',
              variate_value: 30,
            },
            flat_price:{
              fixed_value:0
            }
          },
          use_reserved_price: true,
          reserved_price:{
            selected:'customized_price',
            customized_price:{
              variate_type: 'increase',
              variate_by: 'value',
              variate_value: 0,
            },
            flat_price:{
              fixed_value:0
            }
          }
        }
      },
      site_id:'',
      errors:{
        name:false,
        auctions_listing:{
          buyitnow_price:{
            customized_price:{
              variate_value:false,
            },
            flat_price:{
              fixed_value:false
            },
            variate_value:false,
          },
          start_price:{
            customized_price:{
              variate_value:false,
            },
            flat_price:{
              fixed_value:false
            },
          },
          reserved_price:{
            customized_price:{
              variate_value:false,
            },
            flat_price:{
              fixed_value:false
            },
          }
        },
        fixed_listing:{
          customized_price:{
            variate_value:false,
          },
          flat_price:{
            fixed_value:false
          },
        }
      }
    };
    // this.getSideID();
  }

  getSideID(){
    requests.getRequest('ebayV1/get/siteId').then(data=>{
      if(data.success){
        this.state.site_id=!isUndefined(data.data.site_id)?data.data.site_id:'';
        this.setState(this.state);
        if(this.state.site_id=== 'MOTORS'){
          this.toggleListingDurations();
        }
      }
    });


  }

  componentDidMount(){
    if(!isUndefined(this.props.data) && !isUndefined(this.props.data.id) && this.props.data.id!=='') {
      this.state._id=this.props.data.id;
      this.setState(this.state);
      this.getData();
      this.getSideID();
    }
  }

  getData(){

    requests.getRequest('ebayV1/get/template',{template_id:this.props.data.id}).then(data=>{
      if(data.success){
        if(!isUndefined(data.data.data)) {
          // console.log(data.data.data);
          // this.state.form_data = {...this.state.form_data,...data.data.data};

          this.state.form_data = _.merge(this.state.form_data, data.data.data);
        }
      }
      this.setState(this.state,()=>{
        console.log(this.state.form_data);
        console.log(this.state);
      });
    })

  }


  formValidator(){
    let errors=0;
    Object.keys(this.state.form_data).map(key=>{
      switch(key){
        case 'name':
          if(this.state.form_data[key]===''){
            this.state.errors.name=true;
            errors+=1;
          }
          else{
            this.state.errors.name=false;
          }
          break;
        case 'selling_details':
          if(this.state.form_data.selling_details.format==='auction_style'){
            if(this.state.form_data.auctions_listing.use_buyitnow_price) {
              if (this.state.form_data.auctions_listing.buyitnow_price.customized_price.variate_by === 'percentage') {
                if (this.state.form_data.auctions_listing.buyitnow_price.customized_price.variate_type === 'increase') {
                  if (this.state.form_data.auctions_listing.buyitnow_price.customized_price.variate_value < 30) {
                    this.state.errors.auctions_listing.buyitnow_price.variate_value = true;
                    errors += 1;
                  } else {
                    this.state.errors.auctions_listing.buyitnow_price.variate_value = false;
                  }
                }
              }
              if (this.state.form_data.auctions_listing.buyitnow_price.selected === 'customized_price') {
                if (this.state.form_data.auctions_listing.buyitnow_price.customized_price.variate_value === '') {
                  this.state.errors.auctions_listing.buyitnow_price.customized_price.variate_value = true;
                  errors += 1;
                } else if (this.state.form_data.auctions_listing.buyitnow_price.customized_price.variate_value < 0) {
                  this.state.errors.auctions_listing.buyitnow_price.customized_price.variate_value = true;
                  errors += 1;
                } else {
                  this.state.errors.auctions_listing.buyitnow_price.customized_price.variate_value = false;
                }
              }
              if (this.state.form_data.auctions_listing.buyitnow_price.selected === 'flat_price') {
                if (this.state.form_data.auctions_listing.buyitnow_price.flat_price.fixed_value === '') {
                  this.state.errors.auctions_listing.buyitnow_price.flat_price.fixed_value = true;
                  errors += 1
                } else if (this.state.form_data.auctions_listing.buyitnow_price.flat_price.fixed_value < 0) {
                  this.state.errors.auctions_listing.buyitnow_price.flat_price.fixed_value = true;
                  errors += 1
                } else {
                  this.state.errors.auctions_listing.buyitnow_price.flat_price.fixed_value = false;
                }
              }
            }
            if(this.state.form_data.auctions_listing.start_price.selected==='customized_price'){
              if(this.state.form_data.auctions_listing.start_price.customized_price.variate_value===''){
                this.state.errors.auctions_listing.start_price.customized_price.variate_value=true;
                errors+=1;
              }else if(this.state.form_data.auctions_listing.start_price.customized_price.variate_value<0){
                this.state.errors.auctions_listing.start_price.customized_price.variate_value=true;
                errors+=1;
              }
              else{
                this.state.errors.auctions_listing.start_price.customized_price.variate_value=false;
              }
            }
            if(this.state.form_data.auctions_listing.start_price.selected==='flat_price'){
              if(this.state.form_data.auctions_listing.start_price.flat_price.fixed_value===''){
                this.state.errors.auctions_listing.start_price.flat_price.fixed_value=true;
                errors+=1;
              }else if(this.state.form_data.auctions_listing.start_price.flat_price.fixed_value<0){
                this.state.errors.auctions_listing.start_price.flat_price.fixed_value=true;
                errors+=1;
              }
              else{
                this.state.errors.auctions_listing.start_price.flat_price.fixed_value=false;
              }
            }
            if(this.state.site_id !== 'MOTORS' && this.state.form_data.auctions_listing.use_reserved_price){
              if(this.state.form_data.auctions_listing.reserved_price.selected==='customized_price'){
                if(this.state.form_data.auctions_listing.reserved_price.customized_price.variate_value===''){
                  this.state.errors.auctions_listing.reserved_price.customized_price.variate_value=true;
                  errors+=1;
                }else if(this.state.form_data.auctions_listing.reserved_price.customized_price.variate_value<0){
                  this.state.errors.auctions_listing.reserved_price.customized_price.variate_value=true;
                  errors+=1;
                }
                else{
                  this.state.errors.auctions_listing.reserved_price.customized_price.variate_value=false;
                }
              }
              if(this.state.form_data.auctions_listing.reserved_price.selected==='flat_price'){
                if(this.state.form_data.auctions_listing.reserved_price.flat_price.fixed_value===''){
                  this.state.errors.auctions_listing.reserved_price.flat_price.fixed_value=true;
                  errors+=1;
                }else if(this.state.form_data.auctions_listing.reserved_price.flat_price.fixed_value<0){
                  this.state.errors.auctions_listing.reserved_price.flat_price.fixed_value=true;
                  errors+=1;
                }
                else{
                  this.state.errors.auctions_listing.reserved_price.flat_price.fixed_value=false;
                }
              }
            }

          }else if(this.state.form_data.selling_details.format==='fixed_price'){
            if(this.state.form_data.fixed_listing.selected==='customized_price'){
              if(this.state.form_data.fixed_listing.customized_price.variate_value===''){
                this.state.errors.fixed_listing.customized_price.variate_value=true;
                errors+=1;
              }else if(this.state.form_data.fixed_listing.customized_price.variate_value<0){
                this.state.errors.fixed_listing.customized_price.variate_value=true;
                errors+=1;
              }
              else{
                this.state.errors.fixed_listing.customized_price.variate_value=false;
              }
            }
            if(this.state.form_data.fixed_listing.selected==='flat_price'){
              if(this.state.form_data.fixed_listing.flat_price.fixed_value===''){
                this.state.errors.fixed_listing.flat_price.fixed_value=true;
                errors+=1;
              }else if(this.state.form_data.fixed_listing.flat_price.fixed_value<0){
                this.state.errors.fixed_listing.flat_price.fixed_value=true;
                errors+=1;
              }
              else{
                this.state.errors.fixed_listing.flat_price.fixed_value=false;
              }
            }
          }
          break;
      }
    });

    this.setState(this.state);
    if(errors===0){
      return true;
    }
    else
    {
      return false;
    }
  }

  feildsChangeSelect(key,tag,value) {
    let tempObj = Object.assign({}, this.state);
    tempObj.form_data[key][tag] = value;
    this.setState(tempObj);
  }
  feildsChangeFixed(key,tag,subtag,value) {
    let tempObj = Object.assign({}, this.state);
    tempObj.form_data[key][tag][subtag] = value;
    this.setState(tempObj);
  }
  feildsChangeAuction(key,tag,subtag,subsubtag,value) {
    let tempObj = Object.assign({}, this.state);
    tempObj.form_data[key][tag][subtag][subsubtag] = value;
    this.setState(tempObj);
  }
  handleNameChange(value){
    this.state.form_data.name=value;
    this.setState(this.state);
  }

  toggleListingDurations(){
    let tempArr=sellingListingDurations.slice(0);

    tempArr.forEach((data,index)=>{

      let dayvalue =parseInt((data.value).substr((data.value).indexOf('_')+1));
      if(dayvalue<30){
        if(this.state.site_id ==='MOTORS'){
          tempArr[index].disabled=false;
        }
        else{
          tempArr[index].disabled=false;
        }
      }

    });
    sellingListingDurations =tempArr.slice(0);

  }

  feildsChange(key,tag,value){
    let tempObj=Object.assign({},this.state);
    tempObj.form_data[key][tag]=value;
    this.setState(tempObj);
    if(key==='selling_details' && tag==='format' && value==='fixed_price'){
      this.state.form_data.selling_details.listing_duration='GTC';
      this.setState(this.state);
    }
    else if(key==='selling_details' && tag==='format' && value!=='fixed_price'){
      this.toggleListingDurations()
      if(this.state.site_id !=='MOTORS') {
        this.state.form_data.selling_details.listing_duration = 'Days_3';
      }
      else{
        this.state.form_data.selling_details.listing_duration = 'Days_30';
      }
      this.setState(this.state);
    }
  }

  renderFixedListingSettingConfig(data){
    let temparr=[];
    switch(data){
      case 'customized_price':
        temparr.push(
          <Card  key={data+'settings'}>
            <Card.Section>
              <FormLayout >
                <FormLayout.Group condensed>
                  <Select
                    key={'Variation type Fixed'}

                    options={variateType}
                    value={this.state.form_data.fixed_listing.customized_price.variate_type}
                    onChange={this.feildsChangeFixed.bind(this,'fixed_listing','customized_price','variate_type')}/>
                  <Select
                    key={'Variation by'}
                    options={variateBy}


                    value={this.state.form_data.fixed_listing.customized_price.variate_by}
                    onChange={this.feildsChangeFixed.bind(this,'fixed_listing','customized_price','variate_by')}/>
                  <TextField
                    key={'Variationvalue'}
                    type="number"
                    error={this.state.errors.fixed_listing.customized_price.variate_value?'*invalid value':''}
                    value={this.state.form_data.fixed_listing.customized_price.variate_value}
                    onChange={this.feildsChangeFixed.bind(this,'fixed_listing','customized_price','variate_value')}/>
                </FormLayout.Group>
              </FormLayout>
            </Card.Section>
          </Card>
        );
        break;
      case 'flat_price':
        temparr.push(
          <Card >
            <Card.Section>
              <FormLayout>
                <TextField
                  placeholder={'Please enter flat price...'}
                  key={'FixedPriceFlat'}
                  type="number"
                  error={this.state.errors.fixed_listing.flat_price.fixed_value?'*invalid value':''}
                  value={this.state.form_data.fixed_listing.flat_price.fixed_value}
                  onChange={this.feildsChangeFixed.bind(this,'fixed_listing','flat_price','fixed_value')}/>
              </FormLayout>
            </Card.Section>
          </Card>
        );
        break;

    }

    return temparr
  }

  renderAuctionSettingBody(tag)
  {
    let temparr=[];
    switch(tag){
      case 'start_price':
        switch(this.state.form_data.auctions_listing.start_price.selected){
          case 'customized_price':
            temparr.push(
              <Card  key={'AuctionCalculatedPrice'}>
                <Card.Section>
                  <FormLayout condensed>
                    <FormLayout.Group>
                      <Select
                        key={'Variation type Fixed'}
                        options={variateType}
                        value={this.state.form_data.auctions_listing.start_price.customized_price.variate_type}
                        onChange={this.feildsChangeAuction.bind(this,'auctions_listing','start_price','customized_price','variate_type')}/>
                      <Select
                        key={'Variation by'}
                        options={variateBy}
                        value={this.state.form_data.auctions_listing.start_price.customized_price.variate_by}
                        onChange={this.feildsChangeAuction.bind(this,'auctions_listing','start_price','customized_price','variate_by')}/>
                      <TextField
                        key={'Variationvalue'}
                        type={'number'}
                        error={this.state.errors.auctions_listing.start_price.customized_price.variate_value?'*invalid value':''}
                        value={this.state.form_data.auctions_listing.start_price.customized_price.variate_value}
                        onChange={this.feildsChangeAuction.bind(this,'auctions_listing','start_price','customized_price','variate_value')}/>
                    </FormLayout.Group>
                  </FormLayout>
                </Card.Section>
              </Card>
            );

            break;
          case 'flat_price':
            temparr.push(
              <Card  key={'AuctionFixedpricing'}>
                <Card.Section>
                  <FormLayout>
                    <TextField
                      key={'FixedPriceFlat'}
                      placeholder={'Please enter flat price...'}
                      type="number"
                      error={this.state.errors.auctions_listing.start_price.flat_price.fixed_value?'*invalid value':''}
                      value={this.state.form_data.auctions_listing.start_price.flat_price.fixed_value}
                      onChange={this.feildsChangeAuction.bind(this,'auctions_listing','start_price','flat_price','fixed_value')}/>
                  </FormLayout>
                </Card.Section>
              </Card>
            )
            break;
        }

        break;
      case 'buyitnow_price':

        switch(this.state.form_data.auctions_listing.buyitnow_price.selected){
          case 'customized_price':
            temparr.push(
              <Card key={'AuctionCalculatedPricebuyitnow_price'} title={"Custom price"}>
                <Card.Section>
                  <FormLayout condensed>
                    <FormLayout.Group>
                      <Select
                        key={'Variation type Fixed'}

                        options={variateType}

                        value={this.state.form_data.auctions_listing.buyitnow_price.customized_price.variate_type}
                        onChange={this.feildsChangeAuction.bind(this,'auctions_listing','buyitnow_price','customized_price','variate_type')}/>
                      <Select
                        key={'Variation by'}
                        options={variateBy}

                        value={this.state.form_data.auctions_listing.buyitnow_price.customized_price.variate_by}
                        onChange={this.feildsChangeAuction.bind(this,'auctions_listing','buyitnow_price','customized_price','variate_by')}/>
                      <TextField

                        key={'Variationvalue'}
                        type="number"
                        error={this.state.errors.auctions_listing.buyitnow_price.customized_price.variate_value?'*invalid value':this.state.errors.auctions_listing.buyitnow_price.variate_value?'*value needs to be atleast 30% higher than start/current price':''}
                        value={this.state.form_data.auctions_listing.buyitnow_price.customized_price.variate_value}
                        onChange={this.feildsChangeAuction.bind(this,'auctions_listing','buyitnow_price','customized_price','variate_value')}/>
                    </FormLayout.Group>
                  </FormLayout>
                </Card.Section>
              </Card>
            );

            break;
          case 'flat_price':
            temparr.push(
              <Card key={'AuctionCalculatedPricefixed_pricing'}>
                <Card.Section>
                  <FormLayout>
                    <TextField
                      placeholder={'Please enter flat price...'}
                      key={'FixedPriceFlat'}
                      type="number"
                     /* error={this.state.form_data.auctions_listing.buyitnow_price.flat_price.fixed_value?'*invalid value':''}*/
                      value={this.state.form_data.auctions_listing.buyitnow_price.flat_price.fixed_value}
                      onChange={this.feildsChangeAuction.bind(this,'auctions_listing','buyitnow_price','flat_price','fixed_value')}/>
                  </FormLayout>
                </Card.Section>
              </Card>
            )
            break;
        }


        break;
      case 'reserved_price':

        switch(this.state.form_data.auctions_listing.reserved_price.selected){
          case 'customized_price':
            temparr.push(
              <Card key={'reservedCalculatedPrice'} title={"Custom price"}>
                <Card.Section>
                  <FormLayout condensed>
                    <FormLayout.Group>
                      <Select
                        key={'Variation type Fixed'}

                        options={variateType}

                        value={this.state.form_data.auctions_listing.reserved_price.customized_price.variate_type}
                        onChange={this.feildsChangeAuction.bind(this,'auctions_listing','reserved_price','customized_price','variate_type')}/>
                      <Select
                        key={'Variation by'}
                        options={variateBy}


                        value={this.state.form_data.auctions_listing.reserved_price.customized_price.variate_by}
                        onChange={this.feildsChangeAuction.bind(this,'auctions_listing','reserved_price','customized_price','variate_by')}/>
                      <TextField

                        key={'Variationvalue'}
                        type="number"
                        error={this.state.errors.auctions_listing.reserved_price.customized_price.variate_value?'*invalid value':''}
                        value={this.state.form_data.auctions_listing.reserved_price.customized_price.variate_value}
                        onChange={this.feildsChangeAuction.bind(this,'auctions_listing','reserved_price','customized_price','variate_value')}/>
                    </FormLayout.Group>
                  </FormLayout>
                </Card.Section>
              </Card>
            );

            break;
          case 'flat_price':
            temparr.push(
              <Card  key={'reservedFixedPrice'}>
                <Card.Section>
                  <FormLayout>
                    <TextField
                      placeholder={'Please enter flat price...'}
                      key={'FixedPriceFlat'}
                      type="number"
                      error={this.state.errors.auctions_listing.reserved_price.flat_price.fixed_value?'*invalid value':''}
                      value={this.state.form_data.auctions_listing.reserved_price.flat_price.fixed_value}
                      onChange={this.feildsChangeAuction.bind(this,'auctions_listing','reserved_price','flat_price','fixed_value')}/>
                  </FormLayout>
                </Card.Section>
              </Card>
            )
            break;
        }

        break;
    }

    return temparr;
  }



  savePricingTemplate(){
    if(this.formValidator()){
      let tempObj={
        title:this.state.form_data.name,
        type:'price',
        data:this.state.form_data
      };
      if(this.state._id!=='') {
        tempObj['_id'] = this.state._id;
      }
      this.props.recieveFormdata(tempObj);
    }else{
      notify.error('Kindly fill all the required fields');
    }
    this.setState(this.state);

  }

  saveConfigData(){
    this.savePricingTemplate();
  }


  openvideoModal(id) {
    this.video.Modal = true;
    this.video.id = id;
    this.setState(this.state);
  }

  closevideoModal() {
    this.video.Modal = false;
    this.video.id = '';
    this.setState(this.state);
  }

  render() {
    return (
      <Card title={"Pricing template"}
            actions={[{content:<Badge status={"info"}><b>Need help?</b></Badge>,onAction:()=>{
                window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=pricing-templates','_blank')
              }},
              {content:<Badge status={"info"}><b>Help video</b></Badge>,onAction:()=>{
                  this.openvideoModal('9aMh0zYClEg')
                }},
              ]}
      >
        <Card.Section>
          <Banner status={"info"}>
            <b>Pricing template </b>helps you to assign custom pricing while creating or updating a listing on eBay.
          </Banner>
          <Banner
            status="info"
          >
            <p>
              <i>To sell an item at a fixed price, your feedback score must be 0 or higher, and the item you're listing must be priced at $0.99 or higher.</i>
            </p>
          </Banner>
        </Card.Section>
        <Card.Section title={"Template name"} key={"Templatename"}>
          <Stack vertical={true} spacing={"loose"}>
          <TextField
            key={'PricingtemplateName'}
            type="text"
            error={this.state.errors.name ? ' ' : ''}
            helpText={'*required'}
            value={this.state.form_data.name}
            onChange={this.handleNameChange.bind(this)}/>
          <Checkbox
            label={'Round off price'}
            checked={this.state.form_data.roundOff.all}
            helpText={'By selecting this option you can round off all the prices to it\'s ceil value. Eg. 4.6 -> 5'}
            onChange={(e)=>{
              this.state.form_data.roundOff.all = e;
              this.setState(this.state);
            }}
          />
          </Stack>
        </Card.Section>
        <Card.Section title={'Configuration'}>
          <Stack key={'salesConfigurations'} distribution={"fillEvenly"} vertical={false}>
            <Banner
              status="info"
            >
              <p>
                <i><b>Fixed price listings</b> are set to <b>Good 'Til Cancelled (GTC)</b> duration by default. This means your item will be listed on eBay until it sells or you end it.</i>
              </p>
            </Banner>
            <Select
              key={'Format (Listing type)'}
              options={sellingFormatOptions}
              label={<React.Fragment><p className='font-weight-bold'>Format (Listing type)
                <Badge status={"attention"}><p className='font-weight-bold' style={{cursor:'pointer'}} onClick={(e)=>{
                  window.open('https://www.ebay.in/pages/help/sell/formats.html','_blank');
                  e.preventDefault();
                }}>Learn more</p></Badge></p></React.Fragment>}
              helpText={"*Select how you want to sell the items you're listing"}
              value={this.state.form_data.selling_details.format}
              onChange={this.feildsChange.bind(this,'selling_details','format')}/>
            <Select
              key={'Listing Duration'}
              helpText={'*Duration for which your listing will run. If your item doesn\'t sell, you can choose to relist it.'}
              options={this.state.form_data.selling_details.format==='fixed_price'?sellingListingDurationFixed:sellingListingDurations}
              label={'Listing Duration'}
              disabled={this.state.form_data.selling_details.format==='fixed_price'}
              value={this.state.form_data.selling_details.listing_duration}
              onChange={this.feildsChange.bind(this,'selling_details','listing_duration')}/>
          </Stack>
        </Card.Section>
        {this.state.form_data.selling_details.format === 'fixed_price' &&
        <Card.Section title={"Fixed price listing format"}>

          <React.Fragment>
            <Banner
              status="info"
            >
              <p>
                <i>A buyer knows the exact price they need to pay for your item, and can complete their purchase immediately. There is <b>no bidding on flat price listings</b>.</i>
              </p>
            </Banner>
          </React.Fragment>

          <Card.Section title={"Final Price"}>
            <FormLayout>
              <Select
                key={'Settings'}
                options={SettingsFixed}
                value={this.state.form_data.fixed_listing.selected}
                onChange={this.feildsChangeSelect.bind(this, 'fixed_listing', 'selected')}/>
              {
                this.renderFixedListingSettingConfig(this.state.form_data.fixed_listing.selected)
              }
            </FormLayout>
          </Card.Section>
        </Card.Section>
        }
        {this.state.form_data.selling_details.format === 'auction_style' &&
        <Card.Section title={"Auction listing format"} key={"Auction"}>
          <Banner
            status="info"
          >
            <p>
              <i><b>Start price</b> must be lower than <b>reserved price</b></i>
            </p>
          </Banner>
          <Card.Section title={"Start price"} key={"AuctionStart"}>
            <FormLayout>
              <Select
                key={'Settings'}
                options={SettingsAuction}

                value={this.state.form_data.auctions_listing.start_price.selected}
                onChange={this.feildsChangeFixed.bind(this, 'auctions_listing', 'start_price', 'selected')}/>
              {
                this.renderAuctionSettingBody('start_price')
              }
            </FormLayout>
          </Card.Section>
          <Card.Section>
          <Checkbox label={"Use buy it now price"} checked={this.state.form_data.auctions_listing.use_buyitnow_price} onChange={this.feildsChangeSelect.bind(this, 'auctions_listing', 'use_buyitnow_price')}/>
          </Card.Section>
          {this.state.form_data.auctions_listing.use_buyitnow_price && <Card.Section title={"Buy it now price"} key={"AuctionBuy"}>
            <FormLayout>
              <React.Fragment>
                <Banner
                  status="info"
                >
                  <p>
                    <i>Buyers can either purchase your item right away at the Buy It Now price, or place a bid. In most categories,<b> The Buy It Now price has to be at least 30% higher than the Start/Current price</b>.</i>
                  </p>
                </Banner>
              </React.Fragment>
              <Select
              key={'Settings'}
              options={SettingsAuction}

              value={this.state.form_data.auctions_listing.buyitnow_price.selected}
              onChange={this.feildsChangeFixed.bind(this, 'auctions_listing', 'buyitnow_price', 'selected')}/>
              {
                this.renderAuctionSettingBody('buyitnow_price')
              }
            </FormLayout>
          </Card.Section>
          }
          <Card.Section>
          <Checkbox label={"Use reserved price"} checked={this.state.form_data.auctions_listing.use_reserved_price} onChange={this.feildsChangeSelect.bind(this, 'auctions_listing', 'use_reserved_price')}/>
          </Card.Section>
          {this.state.form_data.auctions_listing.use_reserved_price &&
          <Card.Section title={"Reserved price"} key={"AuctionReserved"}>
            <FormLayout>

              <Banner
                status="info"
              >
                <p>
                  <i><b>Fee May Apply</b> You can set a hidden minimum selling price for your item
                    - the lowest price you're willing to accept for your item. If the listing
                    ends without any bids that reach this price, you don't have to sell the
                    item.</i>
                </p>
              </Banner>
              <Select
              key={'Settings'}
              options={SettingsAuction}

              value={this.state.form_data.auctions_listing.reserved_price.selected}
              onChange={this.feildsChangeFixed.bind(this, 'auctions_listing', 'reserved_price', 'selected')}/>
              {
                this.renderAuctionSettingBody('reserved_price')
              }
            </FormLayout>
          </Card.Section>
            }
          {/*}*/}
        </Card.Section>
        }
        <ModalVideo channel='youtube' isOpen={this.video.Modal} videoId={this.video.id}  onClose={this.closevideoModal.bind(this)} />
      </Card>
    );
  }
}


export default PricingTemplate;
