import React, { Component } from 'react';

import PaymentShippingReturn from "./paymentShippingReturntemplate";
import CategoryTemplate from "./CategoryTemplate";
import PricingTemplate from "./PricingTemplate";
import Titletemplate from "./Titletemplate";
import InventoryTemplate from "./InventoryTemplate";
import { Page, FormLayout, Modal, Stack, Banner, VisuallyHidden } from "@shopify/polaris";
import * as queryString from "query-string";
import SimpleCrypto from "simple-crypto-js";
import { isUndefined } from "util";
import { requests } from "../services/request";
import { notify } from "../services/notify";
const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');
class TemplateModifier extends Component {

  constructor(props) {
    super(props);
    this.state = {
      buttonLoading: false,
      errorPolicyfound: false,
      profiles: [],
      errors_recieved_policy: [],
      display: {
        return_policy: false,
        payment_policy: false,
        shipping_policy: false,
        title: false,
        pricing: false,
        inventory: false,
        category: false,
      },
      data: {
        id: '',
        type: '',
      }
    };

    this.SaveBusinessPolicy = this.SaveBusinessPolicy.bind(this);
    this.getFormData = this.getFormData.bind(this);
    this.hitInternalSave = this.hitInternalSave.bind(this);
    this.hitInternalSetDefault = this.hitInternalSetDefault.bind(this);
    this.buttonToggler = this.buttonToggler.bind(this);
    this.businessPolicyref = React.createRef();
    this.templateref = React.createRef();
  }

  componentDidMount() {
    this.getQueryPrams();
    this.getAppProfiles();
  }

  getQueryPrams() {
    if (this.props.location.search !== "") {
      const queryParams = queryString.parse(this.props.location.search);
      if (!isUndefined(queryParams['message'])) {
        let data_recieved = JSON.parse(cryptr.decrypt(decodeURI(queryParams['message'])))
        if (!isUndefined(data_recieved['id'])) {
          this.state.data.id = data_recieved['id'];
        }
        if (!isUndefined(data_recieved['display'])) {
          this.state.display[data_recieved['display']] = true;
        }
        if (!isUndefined(data_recieved['type'])) {
          this.state.data.type = data_recieved['type'];
        }
        this.setState(this.state);
      }
    }
    else {
      this.redirect('/panel/template/list');
    }
  }

  redirect(url) {

    this.props.history.push(url);
  }

  getFormData(data) {
    this.buttonToggler();
    requests.postRequest('ebayV1/template/save', data).then(data => {
      if (data.success) {
        notify.success('Template saved successfully');
        this.redirect('/panel/template/list')
      }
      else {
        notify.error(data.message)
      }
      this.buttonToggler();
    })
  }

  SaveBusinessPolicy(data) {
    this.buttonToggler();
    requests.postRequest('ebayV1/upload/saveBusinessPolicy', data).then(data => {
      if (data.success) {
        notify.success('Business policy saved successfully');
        this.redirect('/panel/businesspolicies/list')
      }
      else {

        if (data.code !== 'something_went_wrong') {
          this.policyModaldata(data.data);
        } else {
          notify.error(data.message);
        }

      }
      this.buttonToggler();
    })
  }

  getBusinessPOlicy() {
    if (this.state.display.return_policy || this.state.display.payment_policy || this.state.display.shipping_policy) {
      return (
        <PaymentShippingReturn
          display={this.state.display}
          data={this.state.data}
          showSave={false}
          ref={this.businessPolicyref}
          recieveFormData={this.SaveBusinessPolicy}
        />
      )
    }
    else {
      return [];
    }
  }

  getUrl() {

    if (this.state.data.type === 'Business policy') {
      this.redirect('/panel/businesspolicies/list')
    }
    else {
      this.redirect('/panel/template/list')
    }

  }

  toggleSettingModal() {
    this.state.errorPolicyfound = !this.state.errorPolicyfound;
    this.setState(this.state);
  }

  policyModaldata = (data) => {
    if (!isUndefined(data)) {
      let temparr = [];
      Object.keys(data).map(key => {
        data[key].forEach((value, index) => {
          temparr.push(
            key.toUpperCase() + " Policy : " + value.message
          )
        });
        this.state.errorPolicyfound = true;
      });
      this.state.errors_recieved_policy = temparr;
      this.setState(this.state);
    }
    else {
      notify.error('Some error has occurred');
    }
  };

  renderErrorsFound() {
    let temparr = [];
    this.state.errors_recieved_policy.forEach((value, index) => {
      temparr.push(<Banner key={index + 'Errors'} status={"critical"}>{value}</Banner>)
    });
    return temparr;
  }



  hitInternalSetDefault() {
    let id = this.state.data.id;
    let type = '';
    Object.keys(this.state.display).map(key => {
      if (this.state.display[key]) {
        switch (key) {
          case 'return_policy': type = 'return_policy';
            break;
          case 'payment_policy': type = 'payment_policy';
            break;
          case 'shipping_policy': type = 'shipping_policy';
            break;
          case 'title': type = 'title_template';
            break;
          // case 'pricing': type = 'price_template';
          //   break;
          case 'price': type = 'price_template';
            break;
          case 'inventory': type = 'inventory_template';
            break;
          case 'category': type = 'category_template';
            break;
        }
      }
    });
    if (id !== '') {
      let tempObj = {};
      tempObj[type] = id;
      requests.postRequest('ebayV1/upload/saveGlobalConfigurations', tempObj).then(data => {
        if (data.success) {
          notify.success(data.message);
        } else {
          notify.error(data.message);
        }
      });
    }
  }

  getAppProfiles() {
    let profilesFound = [];
    requests.getRequest('connector/profile/getMatchingProfiles')
      .then(data => {
        if (data.success) {
          for (let i = 0; i < data.data.length; i++) {
            profilesFound.push({
              label: data.data[i].name,
              value: (data.data[i].id).toString()
            });
          }
          this.setState({ profiles: profilesFound });
        }
      });
  }

  hitInternalSave() {
    if (this.state.data.type.includes('Business')) {
      this.businessPolicyref.current.saveAllprofiles();
    } else {
      this.templateref.current.saveConfigData();
    }
  }

  buttonToggler = () => {
    this.state.buttonLoading = !this.state.buttonLoading;
    this.setState(this.state);
  }

  setOtherProfiles(profileId) {
    let id = this.state.data.id;
    let type = '';
    Object.keys(this.state.display).map(key => {
      if (this.state.display[key]) {
        switch (key) {
          case 'return_policy': type = 'return_policy';
            break;
          case 'payment_policy': type = 'payment_policy';
            break;
          case 'shipping_policy': type = 'shipping_policy';
            break;
          case 'title': type = 'title_template';
            break;
          case 'pricing': type = 'pricing_template';
            break;
          case 'inventory': type = 'inventory_template';
            break;
          case 'category': type = 'category_template';
            break;
        }
      }
    });
    let dataReq = {
      profile_id: profileId,
      type: type,
      template_id: id
    };
    requests.postRequest('ebayV1/template/assigntemplateToProfile', dataReq).then(data => {
      if (data.success) {
        notify.success(data.message);
      } else {
        notify.error(data.message);
      }
    });
  }

  createDuplicateTemplate() {
    if (this.state.data.type !== 'Business policy') {
      requests.getRequest('ebayV1/template/copy', { template_id: this.state.data.id }).then(data => {
        if (data.success) {
          notify.success(data.message);
          this.getUrl();
        } else {
          notify.error(data.message);
        }
      })
    } else {
      notify.info('This feature is only available for already created templates.')
    }
  }

  prepareOptionsforAction() {
    let temparr = [];
    temparr.push(
      {
        content: 'Set as default', icon: '',
        onAction: this.hitInternalSetDefault.bind(this)
      }
    );
    this.state.profiles && this.state.profiles.length > 0 &&
    temparr.push(
      {
        content: 'Save to all profile', icon: '',
        onAction: this.setOtherProfiles.bind(this, 'all')
      }
    );
    this.state.profiles.forEach((profile, index) => {
      temparr.push(
        {
          content: profile.label, icon: '',
          onAction: this.setOtherProfiles.bind(this, profile.value)
        }
      );
    });

    return temparr
  }

  render() {
    // console.log('object', this.state.display)
    return (
      <Page
        title={this.state.data.id === '' ? 'Create ' + this.state.data.type : 'Edit ' + this.state.data.type}
        fullWidth={true}
        breadcrumbs={[{ content: 'Back', onAction: this.getUrl.bind(this) }]}
        primaryAction={{ content: this.state.data.id === '' ? 'Save' : 'Save', onAction: this.hitInternalSave.bind(this), loading: this.state.buttonLoading }}
        actionGroups={this.state.data.id !== '' && this.state.data.type !== 'Business policy' ? [
          {
            title: 'Actions',
            actions: this.prepareOptionsforAction()
          },
          {
            title: 'Others',
            actions: [{
              content: 'Create Duplicate template',
              onAction: () => {
                this.createDuplicateTemplate();
              }
            }]
          }
        ] : this.state.data.id !== '' && this.state.data.type == 'Business policy' ? [
          {
            title: 'Actions',
            actions: this.prepareOptionsforAction()
          }] : []}
      >
        <br />

        <FormLayout>
          {
            this.getBusinessPOlicy()
          }
          {
            this.state.display.title &&
            <Titletemplate data={this.state.data} ref={this.templateref} recieveFormdata={this.getFormData} />
          }
          {
            this.state.display.price &&
            <PricingTemplate data={this.state.data} ref={this.templateref} recieveFormdata={this.getFormData} />
          }
          {
            this.state.display.pricing &&
            <PricingTemplate data={this.state.data} ref={this.templateref} recieveFormdata={this.getFormData} />
          }
          {
            this.state.display.inventory &&
            <InventoryTemplate data={this.state.data} ref={this.templateref} recieveFormdata={this.getFormData} />
          }
          {
            this.state.display.category &&
            <CategoryTemplate data={this.state.data} infoBanner={false} ref={this.templateref} recieveFormdata={this.getFormData} />
          }
        </FormLayout>
        <Modal
          open={this.state.errorPolicyfound}
          onClose={this.toggleSettingModal.bind(this)}
          title="Errors found in policy creation"
        >
          <Modal.Section>
            <Stack distribution={"fill"}>
              {
                this.renderErrorsFound()
              }
            </Stack>
          </Modal.Section>
        </Modal>
      </Page>
    );
  }

  // <SellingDetails recieveFormData={this.getFormData}/>
  // <PaymentShippingReturn display={this.state} showSave={false} recieveFormdata={this.getFormData}/>
  // <CategoryTemplate recieveFormdata={this.getFormData}/>
  // <InventoryTemplate recieveFormdata={this.getFormData}/>
  // <Titletemplate recieveFormdata={this.getFormData}/>
  // <PricingTemplate recieveFormdata={this.getFormData}/>
  // <PaymentShippingReturn display={this.state}  recieveFormdata={this.getFormData}/>


}

export default TemplateModifier;
