import React, { Component } from 'react';
import { Page, Modal, TextContainer, ProgressBar, Card, ResourceList, Label, Button, Banner, TextStyle, Stack, ButtonGroup,FooterHelp,Link } from "@shopify/polaris";
import { requests } from "../../services/request";
import { notify } from "../../services/notify";
import "./circle.css";

let intervalRunning;
class Activities extends Component {

    constructor() {
        super();
        this.state = {
            queuedTasks: [],
            totalQueuedTasks: 0,
            recentActivities: [],
            totalRecentActivities: 0,
            activityDelete: false,
            refreshButtonLoader: false,
            clearActivityLoader: false,
        };
        this.getAllNotifications();
        this.getAllQueuedTasks();
        intervalRunning = setInterval(() => {
            const activeUrl = this.props.history.location.pathname;
            if (activeUrl === '/panel/activities') {
                this.getAllNotifications();
                this.getAllQueuedTasks();
            }
        }, 
        // 360000
        60000
        );
    }

    componentWillUnmount() {
        clearInterval(intervalRunning);
    }

    getAllQueuedTasks() {
        let {refreshButtonLoader} = this.state;
        requests.getRequest('connector/get/allQueuedTasks', {}, false, true)
            .then(data => {
                if (data.success) {
                    this.state.queuedTasks = this.modifyQueuedTaskData(data.data.rows);
                    this.state.totalQueuedTasks = data.data.count;
                    this.updateState();
                }
                refreshButtonLoader = false;
                this.setState({refreshButtonLoader})
            });
    }



    modifyQueuedTaskData(data) {
        for (let i = 0; i < data.length; i++) {
            data[i].progress = Math.ceil(data[i].progress);
        }
        return data;
    }

    getAllNotifications() {
        let {refreshButtonLoader} = this.state;
        refreshButtonLoader = true;
        this.setState({refreshButtonLoader})
        requests.getRequest('connector/get/allNotifications', { count: 3, activePage: 0 }, false, true)
            .then(data => {
                // console.log(data)
                if (data.success) {
                    this.state.recentActivities = data.data.rows;
                    this.state.totalRecentActivities = data.data.count;
                    this.updateState();
                }
            });
    }

    refreshAction() {
        console.log('called')
        this.getAllNotifications();
        this.getAllQueuedTasks();
    }

    render() {
        let {refreshButtonLoader, clearActivityLoader} = this.state;
        return (
            <Page
                fullWidth={true}
                title="Activities" primaryAction={{ content: 'Refresh', onAction: this.refreshAction.bind(this), loading: refreshButtonLoader }}>
                <Stack vertical={true} spacing={"loose"}>
                    <Stack.Item>
                        <Card title="Recent Activities" /* primaryFooterAction={{content:'View All Activities', onAction:
                            this.redirect.bind(this,"/panel/activities/recent") , disabled:this.state.totalRecentActivities < 3
                        }} secondaryFooterAction={{content:'Clear All Activities',onAction:this.handleClearAllActivity.bind(this),disabled:this.state.totalRecentActivities < 3}}*/>
                            <Card.Section>
                                <Stack vertical={true} spacing={"tight"}>
                                    {
                                        this.state.recentActivities.map((activity, index) => {
                                            return (
                                                <Banner title={activity.message} status={activity.severity} key={this.state.recentActivities.indexOf(activity)}>
                                                    <Stack vertical={false} distribution={"equalSpacing"}>
                                                        <Stack.Item>
                                                            <p style={{ fontSize: '1rem' }}>{activity.created_at}</p>
                                                        </Stack.Item>
                                                        {activity.url !== null ?
                                                            <a style={{ fontSize: '1rem' }} href={activity.url} target={'_blank'}>View Report</a>
                                                            : ''}
                                                    </Stack>
                                                </Banner>
                                            );
                                        })
                                    }
                                    {
                                        this.state.recentActivities.length === 0 &&
                                        <Banner status="info">
                                            <Label>No recent activities</Label>
                                        </Banner>
                                    }
                                </Stack>
                            </Card.Section>
                            {this.state.totalRecentActivities >= 3 &&
                                <Card.Section>
                                    <Stack vertical={true} alignment={"trailing"}>
                                        <ButtonGroup>
                                            <Button primary={false} disabled={this.state.totalRecentActivities < 3}
                                                onClick={() => {
                                                    this.setState({ activityDelete: true })
                                                }}>Clear All Activities</Button>
                                            <Button primary={true} disabled={this.state.totalRecentActivities < 3}
                                                onClick={() => {
                                                    this.redirect("/panel/activities/recent")
                                                }}>View All Activities</Button>
                                        </ButtonGroup>
                                    </Stack>
                                </Card.Section>
                            }
                        </Card>
                    </Stack.Item>
                    <Stack.Item>

                        <Card title="Currently Running Processes">
                            {
                                this.state.queuedTasks.length !== 0 ?
                                    <Card.Section>

                                        <Banner status="info">
                                            <Label>Processes will keep running in background. It may take some time. You can close the app and do any other thing in mean time.</Label>
                                        </Banner>
                                        {
                                            this.state.queuedTasks.length > 0 &&
                                            <ResourceList
                                                resourceName={{ singular: 'customer', plural: 'customers' }}
                                                items={this.state.queuedTasks}
                                                renderItem={(item) => {
                                                    const { id, message, progress } = item;
                                                    const progressClass = "c100 p" + progress + " small polaris-green";
                                                    return (
                                                        <ResourceList.Item
                                                            id={id}
                                                            accessibilityLabel={message}
                                                        >
                                                            <Stack vertical={false} spacing={"loose"}>
                                                                <div className={progressClass}>
                                                                    <span>{progress}%</span>
                                                                    <div className="slice">
                                                                        <div className="bar"></div>
                                                                        <div className="fill"></div>
                                                                    </div>
                                                                </div>
                                                                <Stack.Item fill>
                                                                    <Stack vertical={true} spacing={"loose"} >
                                                                        <TextStyle variation="strong">{message}</TextStyle>
                                                                        <ProgressBar progress={progress} />
                                                                    </Stack>
                                                                </Stack.Item>
                                                            </Stack>
                                                        </ResourceList.Item>
                                                    );
                                                }}
                                            />
                                        }
                                    </Card.Section>

                                    : <Card.Section>
                                        <Banner status="info">
                                            <Label>No processes running currently</Label>
                                        </Banner>
                                    </Card.Section>
                            }
                        </Card>
                    </Stack.Item>
                </Stack>
                <Modal
                    open={this.state.activityDelete}
                    onClose={(e) => {
                        this.setState({ activityDelete: false })
                    }}
                    title="Permission required"
                    primaryAction={{
                        content: 'Yes',
                        onAction: this.handleClearAllActivity.bind(this),
                        loading: clearActivityLoader
                    }}
                >
                    <Modal.Section>
                        <TextContainer>
                            <p>
                                Are you sure you want to delete all the activities ?
                    </p>
                        </TextContainer>
                    </Modal.Section>
                </Modal>
                <FooterHelp>
    Learn more about{' '}
    <Link external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=rcnte-activity">
    Activities
    </Link>
  </FooterHelp>
            </Page>
        );
    }
    handleClearAllActivity = () => {
        let {clearActivityLoader} = this.state;
        requests.getRequest('/connector/get/clearNotifications').then(data => {
            if (data.success) {
                notify.success(data.message);
                this.setState({activityDelete : false})
                window.location.reload();
            } else {
                notify.error(data.message);
            }
            clearActivityLoader = false;
            this.setState({clearActivityLoader})
        })
    };
    redirect(url) {
        this.props.history.push(url);
    }

    updateState() {
        const state = this.state;
        this.setState(state);
    }
}

export default Activities;
