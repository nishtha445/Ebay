import React, {Component} from 'react';
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import {
    Page,
    TextStyle,
    Button,
    ResourceList,
    Card,
    Avatar,
    Label,
    Banner, Stack
} from '@shopify/polaris';

class RecentActivities extends Component {
    constructor() {
        super();
        this.state = {
            activities: [],
            totalActivities: 0
        };
        this.getAllNotifications();
    }

    getAllNotifications() {
        requests.getRequest('connector/get/allNotifications')
            .then(data => {
                if (data.success) {
                    this.state.activities = data.data.rows;
                    this.state.totalActivities = data.data.count;
                    this.updateState();
                } else {
                    notify.error(data.message);
                }
            });
    }
    handleClearAllActivity = () => {
        requests.getRequest('/connector/get/clearNotifications').then(data => {
            if ( data.success ) {
                notify.success(data.message);
                this.redirect('/panel/queuedtasks');
            } else {
                notify.error(data.message);
            }
        });
    };
    render() {
        return (
            <Page
                fullWidth={true}
                breadcrumbs={[{content: 'Activities',onAction: this.redirect.bind(this,'/panel/activities')}]}
                title="Activities">
                    <Card secondaryFooterAction={{content:"Clear All Activities", onClick:() => {
                            this.handleClearAllActivity();
                        }}}>
                        <Card.Section>
                            <Banner>
                                <Label>{"Last " + this.state.totalActivities + " activities"}</Label>
                            </Banner>
                        </Card.Section>
                    </Card>
                <ResourceList showHeader={false}
                              items={this.state.activities}
                              renderItem={(item) => {
                                  return (
                                      <ResourceList.Item
                                          id={item.id}
                                          accessibilityLabel={item.message}>
                                          <Banner status={item.severity} title={item.message} key={item.message} >
                                              <Stack vertical={false} distribution={"equalSpacing"}>
                                                  <Stack.Item>
                                                      <p style={{fontSize:'1rem'}}>{item.created_at}</p>
                                                  </Stack.Item>
                                                  {item.url !== null?
                                                      <a  style={{fontSize:'1rem'}} href={item.url} target={'_blank'}>View Report</a>
                                                      :''}
                                              </Stack>
                                          </Banner>
                                      </ResourceList.Item>
                                  );
                              }}>

                </ResourceList>
            </Page>
        );
    }

    redirect(url) {
        this.props.history.push(url);
    }

    updateState() {
        const state = this.state;
        this.setState(state);
    }
}

export default RecentActivities;
