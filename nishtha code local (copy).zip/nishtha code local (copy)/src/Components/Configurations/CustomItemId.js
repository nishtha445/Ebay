import React, {Component} from 'react';
import CustomItemId from "../../shared/custom-item-id/custom-item-Id";
import {Page, PageActions} from "@shopify/polaris";

class CustomItemIdmain extends Component {

    constructor(props){
        super(props);
        this.state={
            button_loader:false
        }
        this.checkCustomId = this.checkCustomId.bind(this);
        this.buttonLoadertoggle = this.buttonLoadertoggle.bind(this);
        this.myRefcustomId = React.createRef();
    }

    redirect(url) {
        this.props.history.push(url);
    }

    saveCustomID(){
        this.myRefcustomId.current.saveCustomItemId();
    }
    checkCustomId(){
        this.buttonLoadertoggle()
    }

    buttonLoadertoggle(){
        this.state.button_loader=!this.state.button_loader;
        this.updateState();
    }

    updateState(){
        let temp=Object.assign({},this.state);
        this.state=temp;
        this.setState(this.state);
    }
    render() {
        return (
            <Page fullWidth={true}
                  title={'Custom Item Id'}
                  breadcrumbs={[{content: 'Configurations',onAction: this.redirect.bind(this,'/panel/config')}]}
            >
                <CustomItemId ref={this.myRefcustomId} history={this.props.history} buttonLoadertoggle={this.buttonLoadertoggle} checkCustomId={this.checkCustomId}/>

                <PageActions
                    primaryAction={{
                        content: 'Save',
                        loading:this.state.button_loader,
                        onClick: () => {
                            this.buttonLoadertoggle();
                            this.saveCustomID();
                        }

                    }}
                />
            </Page>
        );
    }
}

export default CustomItemIdmain;
