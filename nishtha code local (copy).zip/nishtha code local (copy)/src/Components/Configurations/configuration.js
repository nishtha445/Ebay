import React, { Component } from 'react';
import { requests } from "../../services/request";
import { isUndefined } from "util";
import {
  Page,
  Layout,
  Heading,
  Select,
  Tabs,
  Card,
  Stack,
  FormLayout,
  Banner,
 
  Badge,
  Button,
  Collapsible, TextField, Icon, Modal, TextContainer, Checkbox, ChoiceList,FooterHelp,Link
} from "@shopify/polaris";
import _ from 'lodash';
import SellingDetails from "../../shared/sellingsDetails/sellingdetails";
import { notify } from "../../services/notify";
import Skeleton from "../../shared/skeleton";
import { capitalizeWord } from "../../shared/static-functions";
import {
    SearchMajorMonotone, ChevronRightMinor, ChevronDownMinor
} from '@shopify/polaris-icons';
const merge = require('deepmerge');

const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');
const sync_field = ['description', 'title','main_image','weight','item_specifics','varition_pictures','quantity','price'];
let orderStatus = [
  { label: "Active", value: 'Active' },
  { label: "All", value: 'All' },
  { label: "Cancelled", value: 'Cancelled' },
  { label: "CancelPending", value: 'CancelPending' },
  { label: "Completed", value: 'Completed' },
  { label: "Custom Code", value: 'CustomCode' },
  { label: "Inactive", value: 'Inactive' },
  { label: "In Process", value: 'InProcess' },
];
const shippingPackageType = [
  { label: 'Unselect', value: '' },
  { label: 'Bulky Goods', value: 'C_BULKY_GOODS' },
  { label: 'Caravan', value: 'C_CARAVAN' },
  { label: 'Cars', value: 'C_CARS' },
  { label: 'Custom Code', value: 'C_CUSTOM_CODE' },
  { label: 'Europallet', value: 'C_EUROPALLET' },
  { label: 'Expandable Tough Bags', value: 'C_EXPANDABLE_TOUGH_BAGS' },
  { label: 'ExtraLargePack', value: 'C_EXTRA_LARGE_PACK' },
  { label: 'Furniture', value: 'C_FURNITURE' },
  { label: 'Industry Vehicles', value: 'C_INDUSTRY_VEHICLES' },
  { label: 'Large Canada PostBox', value: 'C_LARGE_CANADA_POST_BOX' },
  { label: 'Large Canada Post Bubble Mailer', value: 'C_LARGE_CANADA_POST_BUBBLE_MAILER' },
  { label: 'Large Envelope', value: 'C_LARGE_ENVELOPE' },
  { label: 'Letter', value: 'C_LETTER' },
  { label: 'MailingBoxes', value: 'C_MAILING_BOXES' },
  { label: 'MediumCanadaPostBox', value: 'C_MEDIUM_CANADA_POST_BOX' },
  { label: 'MediumCanadaPostBubbleMailer', value: 'C_MEDIUM_CANADA_POST_BUBBLE_MAILER' },
  { label: 'Motorbikes', value: 'C_MOTORBIKES' },
  { label: 'None', value: 'C_NONE' },
  { label: 'One Way Pallet', value: 'C_ONE_WAY_PALLET' },
  { label: 'Package Thick Envelope', value: 'C_PACKAGE_THICK_ENVELOPE' },
  { label: 'Padded Bags', value: 'C_PADDED_BAGS' },
  { label: 'Parcel Or Padded Envelope', value: 'C_PARCEL_OR_PADDED_ENVELOPE' },
  { label: 'Roll', value: 'C_ROLL' },
  { label: 'Small Canada PostBox', value: 'C_SMALL_CANADA_POST_BOX' },
  { label: 'Small Canada Post BubbleMailer', value: 'C_SMALL_CANADA_POST_BUBBLE_MAILER' },
  { label: 'Tough Bags', value: 'C_TOUGH_BAGS' },
  { label: 'UPS Letter', value: 'C_UPS_LETTER' },
  { label: 'USPS Flat Rate Envelope', value: 'C_USPS_FLAT_RATE_ENVELOPE' },
  { label: 'USPS Large Pack', value: 'C_USPS_LARGE_PACK' },
  { label: 'Very Large Pack', value: 'C_VERY_LARGE_PACK' },
  { label: 'Winepak', value: 'C_WINEPAK' },
];
const sync_fields = ['description', 'title', 'type', 'vendor', 'price', 'quantity', 'weight', 'weight_unit', 'sku', 'product_type', 'images', 'tags', 'all'];
let matchfromEbayOptions = [
  { label: 'Title', value: 'Title' },
  { label: 'Sku', value: 'SKU' },
];
let matchfromShopifyOptions = [
  { label: 'Title', value: 'details.title' },
  { label: 'Sku', value: 'variants.sku' },
];
class Configuration extends Component {
  handleTabChange=(e)=>{
   
    this.setState({selected:e})
  }
  constructor(props) {
    super(props);
    this.state = {
      error:'',
      validEmail:true,
      previousProfiles:{},
      profiles:{
        // shipping_policy:'',
        // payment_policy:'',
        // return_policy:'',
        // category_template:'',
        // inventory_template:'',
        // pricing_template:'',
        // title_template:''
      },
      selected:0,
     
      site_id: false,
      dropdown: {
        shipping_policy: {
          heading: 'Shipping Policy',
          selected_id: '',
          show_dropdown: false,
          options: []
        },

        payment_policy:
        {
          heading: 'Payment Policy',
          selected_id: '',
          show_dropdown: false,
          options: []
        },
        return_policy: {
          heading: 'Return Policy',
          selected_id: '',
          show_dropdown: false,
          options: []
        },
        category_template: {
          heading: 'Category Template',
          selected_id: '',
          show_dropdown: false,
          options: []
        },
        inventory_template: {
          heading: 'Inventory Template',
          selected_id: '',
          show_dropdown: false,
          options: []
        },
        pricing_template: {
          heading: 'Pricing Template',
          selected_id: '',
          show_dropdown: false,
          options: []
        },
        title_template: {
          heading: 'Title Template',
          selected_id: '',
          show_dropdown: false,
          options: []
        },
      },
      config_data: {},
      config_data_loaded: false,
      paid_client: false,
      app_setting: {
        product_sync: 'yes',
        order_sync: 'no',
        order_status: 'Completed',
        fetch_infinite_order: 'no',
        update_edited_fields: 'no',
        shipping_package_type: '',
        email_service: 'yes',
        auto_inventory: 'no',
        auto_product_create: 'yes',
        sync_fields: {
          description: false,
          title: false,
          price: false,
          type: false,
          vendor: false,
          sku: false,
          quantity: false,
          weight: false,
          weight_unit: false,
          product_type: false,
          tags: false,
          // image_main:false,
          // image_array:false,
          // additional_images:false,
          // variant_main_image:false,
          images: false,
          // variant_images: false,
          all: false
        },
      },
      marketplace_setting:{
        sync_fields: {
          description: false,
          title: false,
          price: false,
         main_image:false,
         weight:false,
         item_specifics:false,
         varition_pictures:false,
         quantity:false
         // vendor: false,
         // sku: false,
        //  quantity: false,
         // weight: false,
          //weight_unit: false,
          //product_type: false,
          //tags: false,
          // image_main:false,
          // image_array:false,
          // additional_images:false,
          // variant_main_image:false,
         // images: false,
          // variant_images: false,
         // all: false
        },
      },
      
      webhook_settings: {
        order_update: 'no',
      },
      seller_preferences: {
        match_from_ebay: {},
        order_email_error: [],
        import_collection: {
          collections_options: [],
          selected_collection: []
        },
        import_products: {
          vendor: {
            options: [],
            selected: ''
          },
          product_type: {
            options: [],
            selected: ''
          },
          import_replace_product: 'no',
          published_status: {
            options: [
              { label: 'Unselect', value: '' },
              { label: 'Published', value: 'published' },
              { label: 'Unpublished', value: 'unpublished' },
              { label: 'Any', value: 'any' },
            ],
            selected: ''
          },
          status: {
            options: [
              { label: 'Unselect', value: '' },
              { label: 'Active', value: 'active' },
              { label: 'Archived', value: 'archived' },
              { label: 'Draft', value: 'draft' },
            ],
            selected: ''
          },
        }
      },

      currency_converter: {
        want_converter: '0',
        shopify_currency: '1',
        ebay_currency: '1'
      },
      order_settings_data: {
        cancellation_reason_options: {
          ebay: [],
          shopify: [],
        },
        order_settings: {
          cancel_order_reason_mapping: {},
        },
      },
      skeleton_display: {
        order_settings_show: true,
      },
      loaders: {
        default_setting:false,
        app_setting: false,
        marketplace_setting:false,
        global_configuration: false,
        // shipping_policy: false,
        // payment_policy: false,
        // return_policy: false,
         pricing_template: false,
        // title_template: false,
        seller_preferences: false,
        // category_template: false,
        // inventory_template: false,
        order_settings: false,
        webhook_settings: false,
        currency_converter: false,
        fetcheBayDetails:false
      },
      confirmation_modal: {
        update_ebay_details: false,
      },
      sections: {
        policytemplate: false,
        order_settings: false,
        webhook_settings: false,
        app_settings: false,
        marketplace_settings:false,
        seller_preferences: false,
        global_configuration: false,
        currency_converter: false
      }
    }

  }
  getAllGlobalConfig() {
    requests.getRequest('ebayV1/get/globalConfigData').then(data => {
      if (data.success) {
        this.setConfigData(data.data);
        
      this.state.previousProfiles["payment_policy"]=data.data["payment_policy"]
      this.state.previousProfiles["shipping_policy"]=data.data["shipping_policy"]
      this.state.previousProfiles["return_policy"]=data.data["return_policy"]
      this.state.previousProfiles["category_template"]=data.data["category_template"]
      this.state.previousProfiles["inventory_template"]=data.data["inventory_template"]
      this.state.previousProfiles["pricing_template"]=data.data["price_template"]
      this.state.previousProfiles["title_template"]=data.data["title_template"]
        this.skeleton_Global_Configurations = false
      }
    });
  }

  getAppSetting() {
    requests.getRequest('ebayV1/upload/getAppSettings').then(data => {
      if (data.success) {
        this.state.app_setting.product_sync = data.data.product_sync;
        this.state.app_setting.order_sync = data.data.order_sync;
        this.state.app_setting.order_status = data.data.order_status;
        this.state.app_setting.fetch_infinite_order = !isUndefined(data.data.fetch_infinite_order) ? data.data.fetch_infinite_order : 'no';
        this.state.app_setting.update_edited_fields = !isUndefined(data.data.update_edited_fields) ? data.data.update_edited_fields : 'no';
        this.state.app_setting.shipping_package_type = !isUndefined(data.data.shipping_package_type) ? data.data.shipping_package_type : '';
        this.state.app_setting.email_service = !isUndefined(data.data.email_service) ? data.data.email_service : 'yes';
        this.state.app_setting.auto_inventory = !isUndefined(data.data.auto_inventory) ? data.data.auto_inventory : 'no';
        this.state.app_setting.auto_product_create = !isUndefined(data.data.auto_product_create) ? data.data.auto_product_create : 'yes';
        if (!isUndefined(data.data.currency_converter)) {
          this.state.currency_converter = Object.assign({}, data.data.currency_converter);
        }
        if (!isUndefined(this.state.app_setting) && !isUndefined(data.data.sync_fields) && !isUndefined(this.state.app_setting.sync_fields)) {
          this.state.app_setting.sync_fields = merge(this.state.app_setting.sync_fields, data.data.sync_fields);
        }
        this.setState(this.state);
      }
    })
  }

  saveMarketplaceSetting() {
    this.state.loaders.marketplace_setting = true;
    this.state.marketplace_setting.appToEbay='yes'
    this.setState(this.state);
    
    requests.postRequest('ebayV1/upload/saveAppSettings', this.state.marketplace_setting).then(data => {
      
      if (data.success) {
        notify.success('Marketplace Settings Updated');
      } else {
        notify.error(data.message);
      }
      this.state.loaders.marketplace_setting = false;
      this.setState(this.state);
    })
  }
  getMarketplaceSetting() {   
    requests.getRequest('ebayV1/upload/getAppSettings?appToEbay=yes').then(data => {
      
      if (data) {
           if (!isUndefined(this.state.marketplace_setting) && !isUndefined(this.state.marketplace_setting.sync_fields)) {
           this.state.marketplace_setting.sync_fields = merge(this.state.marketplace_setting.sync_fields,data.sync_fields);   
          }
          this.setState(this.state);
  }
    })
  
  }
  saveAppSetting() {
    this.state.loaders.app_setting = true;
    this.setState(this.state);
    requests.postRequest('ebayV1/upload/saveAppSettings', this.state.app_setting).then(data => {
      if (data.success) {
        notify.success(data.message);
      } else {
        notify.error(data.message);
      }
      this.state.loaders.app_setting = false;
      this.setState(this.state);
    })
  }

  getSellerPreferences() {
    requests.postRequest('frontend/app/getUserPreference').then(data => {
      if (data.success) {
        let importCollectionOptions = this.state.seller_preferences.import_collection.collections_options.slice(0)
        if ( typeof data.data['import_products'] === 'object' && Object.keys(data.data['import_products']).length === 0 ) {
          delete data.data['import_products'];
        }
        let tempObj = _.merge(this.state.seller_preferences, data.data);
        tempObj.import_collection.collections_options = importCollectionOptions.slice(0);
        this.state.seller_preferences = Object.assign({}, tempObj);
        this.setState(this.state);
      }
      this.getSourceAttributes();
    });
  }

  saveSellerPreferences() {
    this.state.loaders.seller_preferences = true;
    this.setState(this.state);
    if(this.state.validEmail===false)
    {
      notify.error('Invalid Email Address')
      this.state.loaders.seller_preferences = false;
      this.setState(this.state);
    }
    else{
   
    requests.postRequest('frontend/app/setUserPreference', this.state.seller_preferences).then(data => {
      if (data.success) {
        notify.success(data.message);
      } else {
        notify.error(data.message);
      }
      this.state.loaders.seller_preferences = false;
      this.setState(this.state);
    })
  }
  }

  saveCurrencyConvertorSetting(){
    if(this.state.currency_converter.want_converter === '1' && this.state.currency_converter.ebay_currency === '') {
      notify.error("eBay Currency required")
      return
    } else {
      this.state.loaders.currency_converter=true;
      this.setState(this.state);
      requests.postRequest('ebayV1/upload/saveAppSettings',{currency_converter:this.state.currency_converter}).then(data=>{
        if(data.success){
          notify.success('Currency Converter Updated');
        }else{
          notify.error(data.message);
        }
        this.state.loaders.currency_converter=false;
        this.setState(this.state);
      })
    }
  }

  saveWebhookSettings() {
    this.state.loaders.webhook_settings = true;
    this.setState(this.state);

    requests.postRequest('ebayV1/app/webhookSettings', { webhook_settings: { ...this.state.webhook_settings } }).then(data => {
      if (data.success) {
        notify.success(data.message);
      } else {
        notify.error(data.message);
      }

      this.state.loaders.webhook_settings = false;
      this.setState(this.state);
    })
  }
  getWebhookSettings() {
    requests.getRequest('ebayV1/app/getwebhookSettings').then(data => {
      if(data.success){
        // console.log(data.data);
        this.setState({ webhook_settings : data.data.webhook_settings});
      }
    });
  }

  getOrderCancellationReason() {

    requests.getRequest('ebayV1/get/orderCancellationReasons').then(data => {
      if (data.success) {
        this.extractShopifyEbaycancellationReason(data.data);

      }
    })
  }

  extractShopifyEbaycancellationReason(data) {

    let ebay_cancellation_reason = [];
    let shopify_cancellation_reason = [];
    let tempOBj = Object.assign({}, this.state.order_settings_data.order_settings.cancel_order_reason_mapping);

    if (!isUndefined(data['ebay_order_cancellation_reasons']) && !isUndefined(data['shopify_order_cancellation_reasons'])) {
      Object.keys(data.ebay_order_cancellation_reasons).map(key => {
        ebay_cancellation_reason.push(
          { label: data.ebay_order_cancellation_reasons[key], value: key }
        );

      });
      Object.keys(data.shopify_order_cancellation_reasons).map(key => {
        shopify_cancellation_reason.push(
          { label: data.shopify_order_cancellation_reasons[key], value: key }
        );
        if (isUndefined(tempOBj[key])) {
          tempOBj[key] = '';
        }
      });
    }
    this.state.order_settings_data.cancellation_reason_options.ebay = ebay_cancellation_reason.slice(0);
    this.state.order_settings_data.cancellation_reason_options.shopify = shopify_cancellation_reason.slice(0);
    this.state.order_settings_data.order_settings.cancel_order_reason_mapping = Object.assign({}, tempOBj);
    this.state.skeleton_display.order_settings_show = false;
    this.setState(this.state);


  }

  setOrderSettings(data) {
    Object.keys(data).map(key => {
      if (data[key]) {
        if (Array.isArray(data[key])) {
          this.state.order_settings_data.order_settings[key] = data[key].slice(0);
        } else {
          this.state.order_settings_data.order_settings[key] = Object.assign({}, data[key]);
        }
      }
    });
    this.setState(this.state);
  }

  fetchOrderSettings() {
    requests.getRequest('ebayV1/get/orderSettings').then(data => {
      if (data.success) {
        this.setOrderSettings(data.data);
      }
      this.getOrderCancellationReason();
    });
  }

  getActive() {
    requests.getRequest('plan/plan/getActive').then(data => {
      if (data.success) {
        if (data.data.custom_price > 0) {
          this.setState({ paid_client: true })
        }
      }
    })
  }

  webhookSettingsChange(key, value) {
    let { webhook_settings } = this.state;
    webhook_settings[key] = value;
    this.setState({ webhook_settings });
  }

  componentDidMount() {
    this.getSideID();

    this.getBusinessPolicy();
    this.getTemplates();
    this.getAllGlobalConfig();
    this.getAppSetting();
    this.getMarketplaceSetting();
    this.fetchOrderSettings();
    
    this.getWebhookSettings();
    this.getSellerPreferences();
    this.getVendorProducttype();
    this.getActive();

    document.title = 'Choose templates, business policies & sales details - CedCommerce';
    document.description = 'Set-up your Global Configurations such as Sales tax details, VAT details, product & order related settings etc. Select your default templates & business policies.';

    if (!document.title.includes(localStorage.getItem('shop_url'))) {
      document.title += !isUndefined(localStorage.getItem('shop_url')) ? " " + localStorage.getItem('shop_url') : "";
    }
  }
  skeleton_General_Configurations = true;
  skeleton_Global_Configurations = true;

  setConfigData(data) {
    if (!isUndefined(data)) {
      Object.keys(data).map(key => {
        if (key === 'config_data') {
          this.state.config_data = data[key] ? data[key] : '';
        } else {
          if (key === 'price_template') {
            this.state.dropdown.pricing_template.selected_id = data[key] ? data[key] : '';
          }
          else {
            this.state.dropdown[key].selected_id = data[key] ? data[key] : '';
          }
        }
      });
      this.state.config_data_loaded = true;
      this.setState(this.state);
    }

  }

  getBusinessPolicy() {
    // requests.getRequest('ebayV1/template/get',{fullData:true}).then(data => {
    requests.postRequest('ebayV1/template/get', { multitype: ['shipping', 'payment', 'return'] }).then(data => {
      if (data.success) {
        if (data.data.length !== 0) {
          this.createDropdownDataPolicy(data.data);
        }
      }

    });
  }

  getTemplates() {
    requests.postRequest('ebayV1/template/get', { multitype: ['category', 'price', 'inventory', 'title'] }).then(data => {
      if (data.success) {
        if (data.data.length !== 0) {
          this.createDropdownDataTemplate(data.data);
        }
      }
    });
  }
capitalizeWords(key)
{
  let keys=key.replace("_"," ")
  keys=capitalizeWord(keys)
  let new_key=keys.charAt(0);
  for(let i=0;i<keys.length-1;i++)
  {
      if(keys.charAt(i)===' ')
      {
        new_key+=keys.charAt(i+1).toUpperCase();
      }
      else{
        new_key+=keys.charAt(i+1)
      }
  }
  return new_key
}
  createDropdownDataPolicy(data) {
    let return_dropdown_options = [];
    let payment_dropdown_options = [];
    let shipping_dropdown_options = [];
    data.forEach((obj, index) => {
      switch (obj.type) {
        case 'return':
          if (!isUndefined(obj.data)) {
            return_dropdown_options.push(
              { label: obj.data.profileName, value: (obj.data.profileId).toString() }
            );
          }
          break
        case 'payment':
          if (!isUndefined(obj.data)) {
            payment_dropdown_options.push(
              { label: obj.data.profileName, value: (obj.data.profileId).toString() }
            );
          }
          break;
        case 'shipping':
          if (!isUndefined(obj.data)) {
            shipping_dropdown_options.push(
              { label: obj.data.profileName, value: (obj.data.profileId).toString() }
            );
          }
          break;
      }
    });
    if (return_dropdown_options.length === 0) {
      this.state.dropdown.return_policy.show_dropdown = false;
    }
    else {
      this.state.dropdown.return_policy.show_dropdown = true;
      this.state.dropdown.return_policy.options = return_dropdown_options;
    }
    if (payment_dropdown_options.length === 0) {
      this.state.dropdown.payment_policy.show_dropdown = false;
    } else {
      this.state.dropdown.payment_policy.show_dropdown = true;
      this.state.dropdown.payment_policy.options = payment_dropdown_options;
    }
    if (shipping_dropdown_options.length === 0) {
      this.state.dropdown.shipping_policy.show_dropdown = false;
    } else {
      this.state.dropdown.shipping_policy.show_dropdown = true;
      this.state.dropdown.shipping_policy.options = shipping_dropdown_options;
    }
    this.skeleton_General_Configurations = false;
    this.setState(this.state);

  }
  createDropdownDataTemplate(data) {
    let price_dropdown_options = [{ label: 'None', value: '' }];
    let title_dropdown_options = [{ label: 'None', value: '' }];
    let inventory_dropdown_options = [{ label: 'None', value: '' }];
    let category_dropdown_options = [];
    data.forEach((obj, index) => {
      switch (obj.type) {
        case 'price':
          // if(!isUndefined(obj.data))
          // {
          price_dropdown_options.push(
            { label: obj.title, value: (obj._id).toString() }
          );
          // }
          break;
        case 'category':
          // if(!isUndefined(obj.data))
          // {
          category_dropdown_options.push(
            { label: obj.title, value: (obj._id).toString() }
          );
          // }
          break;
        case 'title':
          // if(!isUndefined(obj.data))
          // {
          title_dropdown_options.push(
            { label: obj.title, value: (obj._id).toString() }
          );
          // }
          break;
        case 'inventory':
          // if(!isUndefined(obj.data))
          // {
          inventory_dropdown_options.push(
            { label: obj.title, value: (obj._id).toString() }
          );
          // }
          break;

      }
    });
    if (title_dropdown_options.length === 0) {
      this.state.dropdown.title_template.show_dropdown = false;
    } else {
      this.state.dropdown.title_template.show_dropdown = true;
      this.state.dropdown.title_template.options = title_dropdown_options;
    }
    if (inventory_dropdown_options.length === 0) {
      this.state.dropdown.inventory_template.show_dropdown = false;
    } else {
      this.state.dropdown.inventory_template.show_dropdown = true;
      this.state.dropdown.inventory_template.options = inventory_dropdown_options;
    }
    if (price_dropdown_options.length === 0) {
      this.state.dropdown.pricing_template.show_dropdown = false;
    } else {
      this.state.dropdown.pricing_template.show_dropdown = true;
      this.state.dropdown.pricing_template.options = price_dropdown_options;
    }
    if (category_dropdown_options.length === 0) {
      this.state.dropdown.category_template.show_dropdown = false;
    } else {
      this.state.dropdown.category_template.show_dropdown = true;
      this.state.dropdown.category_template.options = category_dropdown_options;
    }
    this.skeleton_General_Configurations = false;
    this.setState(this.state);

  }

  dropdownChange(key,tag, value) {
    //console.log("values",key,tag,value)
   
    let tempObj = Object.assign({}, this.state);
    tempObj.dropdown[key][tag] = value;
   
    if(this.state.previousProfiles[key]!==value)
    {
      let {profiles} = this.state;
      if(key==='pricing_template')
      {
        profiles['price_template']=value
      }
      else
      {
      profiles[key] = value;
      }
      this.setState({profiles})
      
    }
    else{
      delete this.state.profiles[key]
    }
  
    this.setState(tempObj);
  }
  appSettingChange(key,tag,value){
    if(value < 0) {
      notify.error("Enter only positive values")
      return
    }
    let tempObj = Object.assign({}, this.state);
    tempObj[key][tag] = value;
    this.setState(tempObj);
  }

  saveConfigurations() {
    this.state.loaders.default_setting=true
    this.setState(this.state);
    
    let flag=0;
     for(let key in this.state.dropdown)
     {
       if(this.state.dropdown[key].selected_id==='' && key==='shipping_policy' && key==='payment_policy' && key==='return_policy' && key==='category_template')
       { 
         flag=-1;
         notify.error(this.state.dropdown[key].heading + ' can`t be null, You need to select atleast one option')
         this.state.loaders.default_setting=false
         this.setState(this.state);
       }
      
     }
    
    if(flag===0)
     {
       
  //       let tempObj = {};
  //       this.state.loaders[key] = true;
  //       this.setState(this.state);
       
        requests.postRequest('ebayV1/upload/saveGlobalConfigurations', this.state.profiles).then(data => {
          
          if (data.success) {
            notify.success(data.message);
          } else {
            //notify.error(data.message);
          }
          this.state.loaders.default_setting=false
          this.setState(this.state);
        
         // this.state.loaders[key] = false;
         // this.setState(this.state);
        });
       

     }
     // console.log("nishtha",this.state.profiles)
}

    // if (this.state.dropdown[key].selected_id !== '' /*|| key === 'title_template'
    //   || key === 'pricing_template'
    //   || key === 'inventory_template'*/
    // ) {
      
      // if (key !== 'pricing_template') {
      //   tempObj[key] = this.state.dropdown[key].selected_id;
      // }
      // else {
      //   tempObj['price_template'] = this.state.dropdown[key].selected_id;
      // }
    
    
  


  getSellingData = (data) => {
    let {loaders} = this.state;
    loaders.global_configuration = true;
    this.setState({loaders})
    
    if (isUndefined(data.errors)) {
      requests.postRequest('ebayV1/upload/saveGlobalConfigurations', data).then(data => {
        if (data.success) {
          notify.success(data.message);
        } else {
         // notify.error(data.message);
        }
        loaders.global_configuration = false;
        this.setState({loaders})
      })
    }
    else {
      notify.error('Kindly fill all the required fields');
      loaders.global_configuration = false;
        this.setState({loaders})
    }
  }

  removeAssignedtemplate(key) {
    let tempObj = {
      section: 'global_configuration',
      details: {
        type: key,
        profile_id: '',
      }
    };
    requests.postRequest('ebayV1/template/unassignTemplatePolicy', tempObj).then(data => {
      if (data.success) {
        notify.success(data.message);
      } else {
        notify.error(data.message);
      }
      this.getAllGlobalConfig();
    });
  }

  getConfigurations() {
    let temparr = [];
    
   
   
    Object.keys(this.state.dropdown).map(key => {
      // if(key!=='return_policy') {
      
      temparr.push(
       
        <Layout.Section oneThird>
          {this.state.dropdown[key].options.length !== 0 ?
            <Card title={this.state.dropdown[key].heading}
              actions={key.includes('inventory') || key.includes('title') || key.includes('pricing') ? { content: 'Remove', onAction: this.removeAssignedtemplate.bind(this, key) } : {}}
             >
              
              
              <Card.Section>

                <Select
                  key={'dropdown_' + key + '_details'}
                  options={this.state.dropdown[key].options}
                  placeholder={"Choose.."}
                  value={this.state.dropdown[key].selected_id}
                  onChange={this.dropdownChange.bind(this, key,'selected_id')} />

              </Card.Section>


            </Card>
            :
            <Card title={this.state.dropdown[key].heading}>
              <Card.Section>
                <Banner status={"info"}>
                  <p>No {this.state.dropdown[key].heading} found, Kindly create one in <a style={{ color: 'blue', cursor: 'pointer' }} onClick={this.createNewTemplate.bind(this, this.state.dropdown[key].key)}>{this.state.dropdown[key].heading} section</a></p>
                </Banner>
              </Card.Section>
            </Card>
          }
          
        </Layout.Section>,
      
      )
      // }else{
      //     if(this.state.site_id!=='MOTORS'){
      //         temparr.push(
      //             <Layout key={key}>
      //                 <Layout.Section oneThird>
      //                     <Heading element={"h3"}>{this.state.dropdown[key].heading}</Heading>
      //                 </Layout.Section>
      //                 <Layout.Section twoThird>
      //                     {this.state.dropdown[key].options.length !== 0 ?
      //                         <Card primaryFooterAction={{
      //                             content: 'Save',
      //                             onAction: this.saveConfigurations.bind(this, key)
      //                         }}>
      //
      //                             <Card.Section>
      //
      //                                 < Select
      //                                     key={'dropdown_' + key + '_details'}
      //                                     options={this.state.dropdown[key].options}
      //                                     placeholder={"Choose.."}
      //                                     value={this.state.dropdown[key].selected_id}
      //                                     onChange={this.dropdownChange.bind(this, key, 'selected_id')}/>
      //
      //                             </Card.Section>
      //
      //
      //                         </Card>
      //                         :
      //                         <Card>
      //                             <Card.Section>
      //                                 <Banner status={"info"}>
      //                                     <p>No {this.state.dropdown[key].heading} found</p>
      //                                 </Banner>
      //                             </Card.Section>
      //                         </Card>
      //                     }
      //                 </Layout.Section>
      //             </Layout>
      //         )
      //     }
      // }
     
    })
    
    // for(let key in this.state.profiles)
    // {
    //   this.state.profiles[key]=this.state.dropdown[key].selected_id
    // }
   
  
    return temparr;
   
  }

  getSideID() {
    requests.getRequest('ebayV1/get/siteId').then(data => {
      if (data.success) {
        this.state.site_id = !isUndefined(data.data.site_id) ? data.data.site_id : false;
        this.state.user_id = !isUndefined(data.data.user_id) ? data.data.user_id : false;
        // this.state.site_id ='MOTORS';
      }
      this.setState(this.state);
    });

  }

  importeBaydetails() {
    requests.getRequest('ebayV1/import/updateEbayDetails').then(data => {
      if (data.success) {
        
        this.state.loaders.fetcheBayDetails=false;
        this.setState(this.state)
        notify.success(data.message);
      } else {
        notify.error(data.message);
      }

    })
  }

  ConfirmUpdateDetailsModal() {
    return (
      <Modal
        open={this.state.confirmation_modal.update_ebay_details}
        onClose={() => {
          this.state.confirmation_modal.update_ebay_details = false;
          this.setState(this.state);
        }}
        title="Refetch eBay details?"
        primaryAction={{
          content: 'Yes',
          onAction: () => {
            this.importeBaydetails();
            this.state.confirmation_modal.update_ebay_details = false;
            this.state.loaders.fetcheBayDetails=true;
            this.setState(this.state);
          },
        }}
        secondaryActions={[
          {
            content: 'No',
            onAction: () => {
              this.state.confirmation_modal.update_ebay_details = false;
              this.setState(this.state);
            }
          },
        ]}
      >
        <Modal.Section>
          <TextContainer>
            <p>
              Are you sure, you want to refetch and update your following eBay details ?
            </p>
            <ul>
              <li>Categories</li>
              <li>Payment Method</li>
              <li>Shipping policy</li>
              <li>Return policy</li>
              <li>Ship to Locations</li>
              <li>Excluded Ship to Locations</li>
              <li>Currency</li>
              <li>Country</li>
            </ul>
          </TextContainer>
        </Modal.Section>
      </Modal>
    );
  }

  getVendorProducttype() {
    requests.getRequest('shopify/product/getVendorProductTypeProducts').then(data => {
      if (data.success) {
        this.state.seller_preferences.import_products.product_type.options = this.prepareOptions(data.data.product_type);
        this.state.seller_preferences.import_products.vendor.options = this.prepareOptions(data.data.vendor);
        this.setState(this.state);

      }
    })
  }

  prepareOptions(data) {
    let tempOptions = [{ label: 'Unselect', value: '' }];
    data.forEach((value, index) => {
      tempOptions.push(
        { label: value, value: value }
      )
    });
    return tempOptions;
  }


  importCollections() {
    this.setState({ loader_import_collection: true });
    requests.getRequest('shopify/import/collections').then(data => {
      if (data.success) {
        notify.success(data.message);
        this.getSourceAttributes();
      } else {
        notify.error(data.message);
      }
      this.setState({ loader_import_collection: false });
    })
  }

  detailsChangedOrderIdEmail(key, index, value) {
    this.state.seller_preferences.order_email_error[index][key] = value;
    this.setState(this.state);
  }

  deleteOrderEmailSetting(index) {
    let temparr = (this.state.seller_preferences.order_email_error).filter((orderemail, indexpos) => indexpos !== index);
    this.state.seller_preferences.order_email_error = [...temparr];
    this.setState(this.state);
  }

  getOrderIdEmailStruct() {
    let temparr = [];
    this.state.validEmail=true
    let validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    (this.state.seller_preferences.order_email_error).forEach((orderemail, index) => {
      
      if(!orderemail.email.match(validRegex))
      {
        this.state.error='Invalid Email Address'
        this.state.validEmail=false
      }
      else{
        this.state.error=''
      }
      
      temparr = [...temparr,
      <Stack vertical={false} distribution={"fillEvenly"}>
        <TextField label={'Order ID'} value={orderemail.order_id} onChange={this.detailsChangedOrderIdEmail.bind(this, 'order_id', index)} />
        <TextField label={'Email'} error={this.state.error} value={orderemail.email} onChange={this.detailsChangedOrderIdEmail.bind(this, 'email', index)}/>     
        <div style={{ marginTop: '3rem' }}><Button children={'X'} onClick={this.deleteOrderEmailSetting.bind(this, index)} /></div>
      </Stack>
      
      ];
    });
    return temparr;
  }

  addorderIdEmailrow() {
    this.state.seller_preferences.order_email_error = [...this.state.seller_preferences.order_email_error, { order_id: '', email: '' }];
    this.setState(this.state);
  }


  render() {
    const tabs = [
      {
        id: 'default profile',
        content: (
            <Stack spacing="extraTight">
           <p>Default Profile</p>
          </Stack>         
        ),
      },
      {
        id: 'app settings',
        content:  (
        
          <Stack spacing="extraTight">
         <p> App Settings</p>
         </Stack>
       
      ),
      },
      {
        id: 'seller preferences',
        content:  (
        
          <Stack spacing="extraTight">
         <p>Seller Preferences</p>
        </Stack>
       
      ),
      },
      {
        id: 'global configuration',
        content: (
        
          <Stack spacing="extraTight">
         <p>Global Configuration</p>
          </Stack>
       
      ),
      },
      {
        id: 'currency converter',
        content:  (
        
          <Stack spacing="extraTight">
         <p>Currency Converter</p>
        </Stack>
       
      ),
      },
      {
        id: 'order settings',
        content:  (
        
          <Stack spacing="extraTight">
         <p>Order Settings</p>
          </Stack>
       
      ),
      },
      {
        id: 'webhook settings',
        content:  (
        
          <Stack spacing="extraTight">
         <p>Webhook Settings</p>
          </Stack>
       
      ),
      },
      {
        id: 'marketplace settings',
        content:  (
        
          <Stack spacing="extraTight">
         <p>Marketplace Settings</p>
         </Stack>
       
      ),
      },

    ];
  
    return (
      <Page fullWidth={true}
        primaryAction={{
          content: 'Fetch eBay Details', onAction: () => {
            
            this.state.confirmation_modal.update_ebay_details = true;
            
            this.setState(this.state);
            
          },
          loading:this.state.loaders.fetcheBayDetails
        }}
        titleMetadata={<p style={{ cursor: 'pointer' }} onClick={() => {
          window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=configuration-24', '_blank')
        }}><Badge status={"info"}><b style={{ color: '#0000aa', textDecoration: 'underline' }}>Need help?</b></Badge></p>}
        title={'Configuration'}>

     
<Stack alignment="fill" distribution="fill" spacing="tight">
          <Stack.Item>
          <Tabs tabs={tabs} selected={this.state.selected} onSelect={this.handleTabChange}>

          {this.state.selected===0?
                  
                  <Card key={'policy&template'} sectioned>
                    <Card.Section>
              <Card  primaryFooterAction={{
                content: 'Save',
                loading:this.state.loaders.default_setting,
                onAction: this.saveConfigurations.bind(this),
                
              }} sectioned>
                <Banner status={"info"}>
                <p>Default Profile will use at the time of product upload on eBay. Make sure Shipping, Return, Payment Policies and Category Template are not empty</p>
              </Banner>
                <Card.Section>
                  
                  <Stack vertical={false} distribution={"fill"}>
                      <Select requiredIndicator
                      label="Shipping Policy"
                      key={'dropdown_' + 'shipping_policy' + '_details'}
                      options={this.state.dropdown['shipping_policy'].options}
                      placeholder={"Choose.."}
                      value={this.state.dropdown['shipping_policy'].selected_id}
                      onChange={this.dropdownChange.bind(this, 'shipping_policy','selected_id')} />
        
                      <Select requiredIndicator
                      label="Payment Policy"
                      key={'dropdown_' + 'payment_policy' + '_details'}
                      options={this.state.dropdown['payment_policy'].options}
                      placeholder={"Choose.."}
                      value={this.state.dropdown['payment_policy'].selected_id}
                      onChange={this.dropdownChange.bind(this, 'payment_policy','selected_id')} />

                    <Select requiredIndicator
                    label="Return Policy"
                    key={'dropdown_' + 'return_policy' + '_details'}
                    options={this.state.dropdown['return_policy'].options}
                    placeholder={"Choose.."}
                    value={this.state.dropdown['return_policy'].selected_id}
                    onChange={this.dropdownChange.bind(this, 'return_policy','selected_id')} />
                
                    <Select requiredIndicator
                    label="Category Template"
                    key={'dropdown_' + 'category_template' + '_details'}
                    options={this.state.dropdown['category_template'].options}
                    placeholder={"Choose.."}
                    value={this.state.dropdown['category_template'].selected_id}
                    
                    onChange={this.dropdownChange.bind(this, 'category_template','selected_id')} />
                  
                    <Select
                    label="Inventory Template"
                    key={'dropdown_' + 'inventory_template' + '_details'}
                    options={this.state.dropdown['inventory_template'].options}
                    placeholder={"Choose.."}
                    value={this.state.dropdown['inventory_template'].selected_id}
                    onChange={this.dropdownChange.bind(this, 'inventory_template','selected_id')} />
          
                    <Select label="Pricing Template"
                    key={'dropdown_' + 'pricing_template' + '_details'}
                    options={this.state.dropdown['pricing_template'].options}
                    placeholder={"Choose.."}
                    value={this.state.dropdown['pricing_template'].selected_id}
                    onChange={this.dropdownChange.bind(this, 'pricing_template','selected_id')} />
                   
                    <Select label="Title Template"
                    key={'dropdown_' + 'title_template' + '_details'}
                    options={this.state.dropdown['title_template'].options}
                    placeholder={"Choose.."}
                    value={this.state.dropdown['title_template'].selected_id}
                    onChange={this.dropdownChange.bind(this, 'title_template','selected_id')} />
                 
            </Stack>
            </Card.Section>
            </Card>
                      </Card.Section>   
                          
               </Card>:
               this.state.selected===3?
               <Card key={'globalconfig'} sectioned>
               <Stack alignment="baseline" distribution="fillEvenly"  >
                 
               <Card.Section>
                <SellingDetails data={this.state.config_data} loaders={this.state.loaders.global_configuration} recieveFormData={this.getSellingData} />
              </Card.Section>
          
               </Stack>
              
          </Card>:
          this.state.selected===1?
          <Card sectioned key={'app_settings'}>
          <Stack alignment="baseline" distribution="fillEvenly"  >
            
          <Card.Section>
              <Card primaryFooterAction={{ content: 'Save', onAction: this.saveAppSetting.bind(this), loading: this.state.loaders.app_setting }}>
                <Card.Section>
                  <Stack vertical={false} distribution={"fillEvenly"} >
                    <Select
                      key={'webhooksetting'}
                      options={[{ label: 'Yes', value: 'yes' }, { label: 'No', value: 'no' }]}
                      label={'Auto product syncing'}
                      placeholder={"Choose.."}
                      value={this.state.app_setting.product_sync}
                      onChange={this.appSettingChange.bind(this, 'app_setting', 'product_sync')} />
                    <Select
                      key={'ordersync'}
                      options={[{ label: 'Yes', value: 'yes' }, { label: 'No', value: 'no' }]}
                      label={'Auto order syncing'}
                      placeholder={"Choose.."}
                      value={this.state.app_setting.order_sync}
                      onChange={this.appSettingChange.bind(this, 'app_setting', 'order_sync')} />
                    {/* {(this.state.paid_client || this.state.user_id == 11977) &&
                      <Select
                        key={'Auto Inventory'}
                        options={[{ label: 'Yes', value: 'yes' }, { label: 'No', value: 'no' }]}
                        // label={'Auto inventory Sync on eBay'}
                        //label={'Auto inventory syncing'}
                        placeholder={"Choose.."}
                        value={this.state.app_setting.auto_inventory}
                        onChange={this.appSettingChange.bind(this, 'app_setting', 'auto_inventory')} />
                    } */}
                      <Select
                      // key={'update_edited_fields'}
                      options={[{ label: 'Yes', value: 'yes' }, { label: 'No', value: 'no' }]}
                      label={'Auto product create'}
                      placeholder={'Select...'}
                      value={this.state.app_setting.auto_product_create}
                      onChange={this.appSettingChange.bind(this, 'app_setting', 'auto_product_create')} />
                    {/*<Select*/}
                    {/*  key={'orderstatus'}*/}
                    {/*  options={orderStatus}*/}
                    {/*  label={'Order status'}*/}
                    {/*  helpText={"Select the status of order you want to fetch"}*/}
                    {/*  placeholder={"Choose.."}*/}
                    {/*  value={this.state.app_setting.order_status}*/}
                    {/*  onChange={this.appSettingChange.bind(this, 'app_setting', 'order_status')}/>*/}
                    <Select
                      key={'fetchInfinteOrder'}
                      options={[{ label: 'No', value: 'yes' }, { label: 'Yes', value: 'no' }]}
                      label={'Track inventory from Shopify'}
                      placeholder={"Choose.."}
                      value={this.state.app_setting.fetch_infinite_order}
                      onChange={this.appSettingChange.bind(this, 'app_setting', 'fetch_infinite_order')} />
                    <Select
                      key={'selectShippingpackageType'}
                      options={shippingPackageType}
                      label={'Package Type'}
                      placeholder={'Select...'}
                      value={this.state.app_setting.shipping_package_type}
                      onChange={this.appSettingChange.bind(this, 'app_setting', 'shipping_package_type')} />
                    {/*<Select*/}
                    {/*  key={'email_service'}*/}
                    {/*  options={[{label:'Enable',value:'yes'},{label:'Disable',value:'no'}]}*/}
                    {/*  label={'Email Service'}*/}
                    {/*  placeholder={'Select...'}*/}
                    {/*  value={this.state.app_setting.email_service}*/}
                    {/*  onChange={this.appSettingChange.bind(this,'app_setting','email_service')}/>*/}
                    <Select
                      key={'update_edited_fields'}
                      options={[{ label: 'Yes', value: 'yes' }, { label: 'No', value: 'no' }]}
                      label={'Update Edited fields'}
                      placeholder={'Select...'}
                      value={this.state.app_setting.update_edited_fields}
                      onChange={this.appSettingChange.bind(this, 'app_setting', 'update_edited_fields')} />
                  </Stack>
                </Card.Section>
                {this.state.app_setting.product_sync === 'yes' &&
                  <Card.Section title={'Fields enabled for syncing from Shopify'}>
                    <Layout>
                      <Layout.Section>
                        <Banner status={"warning"}>
                          <p><b>Please note : </b><b>All</b> fields checkbox has higher precedence than any other field</p>
                        </Banner>
                      </Layout.Section>
                      <Layout.Section>
                        <Card title="Fields" sectioned>
                          <Stack vertical={false} alignment={"equalSpacing"}>
                            {
                              sync_fields.map(key => {
                                if (key !== 'all') {
                                  return <Checkbox label={capitalizeWord(key)}
                                    checked={this.state.app_setting.sync_fields[key]}
                                    onChange={(e) => {
                                      let { app_setting } = this.state;

                                      app_setting.sync_fields[key] = e;

                                      Object.keys(app_setting.sync_fields).map(key => {
                                        if (!app_setting.sync_fields[key]) {
                                          app_setting.sync_fields['all'] = false;
                                        }
                                      });
                                      this.setState({ app_setting });
                                    }} />
                                }
                              })
                            }
                          </Stack>
                        </Card>
                      </Layout.Section>
                      <Layout.Section secondary>
                        <Card title="All fields" sectioned>
                          <Checkbox label={capitalizeWord('all')}
                            helpText={'Selecting this option will sync entire product from Shopify and will ignore any other selected fields'}
                            checked={this.state.app_setting.sync_fields['all']}
                            onChange={(e) => {
                              let { app_setting } = this.state;

                              Object.keys(app_setting.sync_fields).map(key => {
                                app_setting.sync_fields[key] = e;
                              })

                              app_setting.sync_fields['all'] = e;
                              this.setState({ app_setting });
                            }}
                          />
                        </Card>
                      
                      </Layout.Section>
                    </Layout>
                
                  </Card.Section>
  }
  </Card>
  </Card.Section>
   </Stack>
 </Card>:
     
         
         
    this.state.selected===7?
      <Card key={'marketplace_settings'}>
          <Card.Section>
              <Card primaryFooterAction={{ content: 'Save',
               onAction: this.saveMarketplaceSetting.bind(this), loading: this.state.loaders.marketplace_setting }
              }>
                <Card.Section>
                  <Stack vertical={false} distribution={"fillEvenly"} >
                    <Card.Section title={'From App to Marketplace'}>
                    <Layout>
                      <Layout.Section>
                        <Banner status={"warning"}>
                          <p><b>Please note : </b><b>All</b> fields checkbox has higher precedence than any other field</p>
                        </Banner>
                      </Layout.Section>
                      <Layout.Section>
                        <Card title="Fields" sectioned>
                          <Stack vertical={false} alignment={"equalSpacing"}>
                            {
                              sync_field.map(key => {
                                
                               
                                  return <Checkbox label={this.capitalizeWords(key)}
                                    checked={this.state.marketplace_setting.sync_fields[key]}
                                    onChange={(e) => {
                                      
                                      let { marketplace_setting } = this.state;

                                      marketplace_setting.sync_fields[key] = e;

                                      // Object.keys(marketplace_setting.sync_fields).map(key => {
                                      //   if (!marketplace_setting.sync_fields[key]) {
                                      //     marketplace_setting.sync_fields['all'] = false;
                                      //   }
                                      // });
                                      this.setState({ marketplace_setting });
                                      
                                    }} />
                                
                              })
                            }
                          </Stack>
                        </Card>
                        </Layout.Section>
                        </Layout>
                        </Card.Section>
                     
                        </Stack>
                        </Card.Section>
                        </Card>
                        </Card.Section>
                        </Card>
      :
     this.state.selected===2?
     <Card sectioned key={'seller_preferences'}>
     <Stack alignment="baseline" distribution="fillEvenly"  >
       
     <Card.Section>
              <Card
                primaryFooterAction={{
                  content: 'Save',
                  onAction: this.saveSellerPreferences.bind(this),
                  loading: this.state.loaders.seller_preferences
                }}
              >
                <Card.Section title={'Import products filters'}>
                  <Stack vertical={false} distribution={"fillEvenly"}>
                    <Select label={'Import and replace product'}
                      options={[{ label: 'Yes', value: 'yes' }, { label: 'No', value: 'no' }]}
                      placeholder={'Select...'}
                      helpText={'*this option will help if you want to delete and replace all product'}
                      value={this.state.seller_preferences.import_products.import_replace_product}
                      onChange={(e) => {
                        this.state.seller_preferences.import_products.import_replace_product = e;
                        this.setState(this.state);
                      }}
                    />
                    <Select label={'Product type'}
                      options={this.state.seller_preferences.import_products.product_type.options}
                      placeholder={'Select...'}
                      helpText={'*by default all product types are imported'}
                      value={this.state.seller_preferences.import_products.product_type.selected}
                      onChange={(e) => {
                        console.log(e)
                        this.state.seller_preferences.import_products.product_type.selected = e;
                        this.setState(this.state);
                      }}
                    />
                    <Select label={'Published status'}
                      options={this.state.seller_preferences.import_products.published_status.options}
                      placeholder={'Select...'}
                      helpText={'*by default all published product are imported'}
                      value={this.state.seller_preferences.import_products.published_status.selected}
                      onChange={(e) => {
                        console.log(e)
                        this.state.seller_preferences.import_products.published_status.selected = e;
                        this.setState(this.state);
                      }}
                    />
                    <Select label={'Product Status'}
                      options={this.state.seller_preferences.import_products.status.options}
                      placeholder={'Select...'}
                      helpText={'*by default all product types are imported'}
                      value={this.state.seller_preferences.import_products.status.selected}
                      onChange={(e) => {
                        this.state.seller_preferences.import_products.status.selected = e;
                        this.setState(this.state);
                      }}
                      // disabled={this.state.seller_preferences.import_products.published_status.selected}
                    />
                    <Select label={'Vendor'}
                      options={this.state.seller_preferences.import_products.vendor.options}
                      placeholder={'Select...'}
                      value={this.state.seller_preferences.import_products.vendor.selected}
                      helpText={'*by default all products of all vendor are imported'}
                      onChange={(e) => {
                        console.log(e)
                        this.state.seller_preferences.import_products.vendor.selected = e;
                        this.setState(this.state);
                      }}
                    />
                  </Stack>
                </Card.Section>
                <Card.Section title={'Import Collection products'}>
                  <Banner
                    title="If you have made any changes or some collections seems to be missing then you need to re-import them so as to keep the app in Sync."
                    status="warning"
                    action={{ content: 'Import collections', onAction: this.importCollections.bind(this), loading: this.state.loader_import_collection }}
                  />
                  <div style={{maxHeight: 400, overflowY: 'scroll'}}>
                    <ChoiceList title e={''}
                      choices={this.state.seller_preferences.import_collection.collections_options}
                      selected={this.state.seller_preferences.import_collection.selected_collection}
                      onChange={(e) => {

                        let choicesMade = [];
                        e.forEach(choice => {
                          let isChoiceExisting = this.state.seller_preferences.import_collection.collections_options.filter(optionavailable => optionavailable.value === choice);
                          if (isChoiceExisting.length > 0) {
                            choicesMade.push(choice);
                          }
                        })
                        console.log(choicesMade);
                        this.state.seller_preferences.import_collection.selected_collection = choicesMade.slice(0);
                        this.setState(this.state);
                      }}
                      allowMultiple={true}
                    />
                  </div>
                </Card.Section>
                {Object.keys(this.state.seller_preferences.match_from_ebay).length === 0 &&
                  <Card.Section title={'Match products from Shopify'}>
                    <Banner
                      title={'Preferences for matching products from eBay is set by default in order Title > SKU and both are matched , To set custom preferences click on Add Attribute'}
                      action={{
                        content: 'Add Attribute', onAction: (e) => {
                          this.handleAdd('match_from_ebay')
                        }
                      }}
                    />
                  </Card.Section>
                }
                {Object.keys(this.state.seller_preferences.match_from_ebay).length > 0 &&
                  <Card.Section>
                    <Card title={'Match products from eBay'}
                      actions={{
                        content: 'Add Attribute', onAction: (e) => {
                          this.handleAdd('match_from_ebay')
                        },
                        disabled: Object.keys(this.state.seller_preferences.match_from_ebay).length === 2,
                      }}>
                      <FormLayout>
                        <FormLayout.Group condensed={true}>
                          {

                            Object.keys(this.state.seller_preferences.match_from_ebay).map(preferenceKey => {
                              return (
                                <Card.Section>
                                  <Card actions={{
                                    content: 'Remove', onAction: (e) => {
                                      this.handleRemove('match_from_ebay', preferenceKey)
                                    }
                                  }}>
                                    <Card.Section title={`Preference # ${preferenceKey}`}>
                                      <Stack vertical={false} distribution={"fillEvenly"}>
                                        <Select placeholder={'Select...'} label={`Ebay attribute`}
                                          options={matchfromEbayOptions}
                                          onChange={(e) => {
                                            this.state.seller_preferences.match_from_ebay[preferenceKey]['ebay_attribute'] = e;
                                            this.setState(this.state);
                                          }}
                                          value={this.state.seller_preferences.match_from_ebay[preferenceKey]['ebay_attribute']}
                                        />
                                        <Select placeholder={'Select...'} label={`Shopify attribute`}
                                          options={matchfromShopifyOptions}
                                          onChange={(e) => {
                                            this.state.seller_preferences.match_from_ebay[preferenceKey]['shopify_attribute'] = e;
                                            this.setState(this.state);
                                          }}
                                          value={this.state.seller_preferences.match_from_ebay[preferenceKey]['shopify_attribute']}
                                        />
                                      </Stack>
                                    </Card.Section>
                                  </Card>
                                </Card.Section>
                              );
                            })
                          }
                        </FormLayout.Group>
                      </FormLayout>
                    </Card>
                  </Card.Section>
                }
                {/* <Card.Section title={'Import Collection products'}>
                  <Banner
                    title="If you have made any changes or some collections seems to be missing then you need to re-import them so as to keep the app in Sync."
                    status="warning"
                    action={{ content: 'Import collections', onAction: this.importCollections.bind(this), loading: this.state.loader_import_collection }}
                  />
                  <div style={{maxHeight: 400, overflowY: 'scroll'}}>
                    <ChoiceList title e={''}
                      choices={this.state.seller_preferences.import_collection.collections_options}
                      selected={this.state.seller_preferences.import_collection.selected_collection}
                      onChange={(e) => {

                        let choicesMade = [];
                        e.forEach(choice => {
                          let isChoiceExisting = this.state.seller_preferences.import_collection.collections_options.filter(optionavailable => optionavailable.value === choice);
                          if (isChoiceExisting.length > 0) {
                            choicesMade.push(choice);
                          }
                        })
                        console.log(choicesMade);
                        this.state.seller_preferences.import_collection.selected_collection = choicesMade.slice(0);
                        this.setState(this.state);
                      }}
                      allowMultiple={true}
                    />
                  </div>
                </Card.Section> */}
                <Card.Section title={'Resolve order and email error'} >
                  <Stack vertical={true}>
                    <Button onClick={this.addorderIdEmailrow.bind(this)}>Add</Button>
                    {
                      this.getOrderIdEmailStruct()
                    }
                  </Stack>
                </Card.Section>
                {/* <Card.Section title={'Import products filters'}>
                  <Stack vertical={false} distribution={"fillEvenly"}>
                    <Select label={'Import and replace product'}
                      options={[{ label: 'Yes', value: 'yes' }, { label: 'No', value: 'no' }]}
                      placeholder={'Select...'}
                      helpText={'*this option will help if you want to delete and replace all product'}
                      value={this.state.seller_preferences.import_products.import_replace_product}
                      onChange={(e) => {
                        this.state.seller_preferences.import_products.import_replace_product = e;
                        this.setState(this.state);
                      }}
                    />
                    <Select label={'Product type'}
                      options={this.state.seller_preferences.import_products.product_type.options}
                      placeholder={'Select...'}
                      helpText={'*by default all product types are imported'}
                      value={this.state.seller_preferences.import_products.product_type.selected}
                      onChange={(e) => {
                        console.log(e)
                        this.state.seller_preferences.import_products.product_type.selected = e;
                        this.setState(this.state);
                      }}
                    />
                    <Select label={'Published status'}
                      options={this.state.seller_preferences.import_products.published_status.options}
                      placeholder={'Select...'}
                      helpText={'*by default all published product are imported'}
                      value={this.state.seller_preferences.import_products.published_status.selected}
                      onChange={(e) => {
                        console.log(e)
                        this.state.seller_preferences.import_products.published_status.selected = e;
                        this.setState(this.state);
                      }}
                    />
                    <Select label={'Product Status'}
                      options={this.state.seller_preferences.import_products.status.options}
                      placeholder={'Select...'}
                      helpText={'*by default all product types are imported'}
                      value={this.state.seller_preferences.import_products.status.selected}
                      onChange={(e) => {
                        this.state.seller_preferences.import_products.status.selected = e;
                        this.setState(this.state);
                      }}
                      // disabled={this.state.seller_preferences.import_products.published_status.selected}
                    />
                    <Select label={'Vendor'}
                      options={this.state.seller_preferences.import_products.vendor.options}
                      placeholder={'Select...'}
                      value={this.state.seller_preferences.import_products.vendor.selected}
                      helpText={'*by default all products of all vendor are imported'}
                      onChange={(e) => {
                        console.log(e)
                        this.state.seller_preferences.import_products.vendor.selected = e;
                        this.setState(this.state);
                      }}
                    />
                  </Stack>
                </Card.Section> */}
              </Card>
            </Card.Section>

      </Stack>
      </Card>:
      this.state.selected===4?
      <Card sectioned key={'currency_converter'}>
      <Stack distribution="fillEvenly">
      {this.state.currency_converter.want_converter === '1' &&
              <Banner status={"info"}>
                <p><b>eBay Currency</b> is the value of 1 shopify currency value. i.e. 1 EUR = 1.1 USD</p>
              </Banner>
            }
            <Card.Section>
              <Card primaryFooterAction={{ content: 'Save', onAction: this.saveCurrencyConvertorSetting.bind(this), loading: this.state.loaders.currency_converter }}>
                <Card.Section>
                  <Stack distribution={"fill"}>
                    <Select
                      key={'wantconvertor'}
                      options={[{ label: 'Yes', value: '1' }, { label: 'No', value: '0' }]}
                      label={'Enable Currency Converter'}
                      placeholder={"Choose.."}
                      value={this.state.currency_converter.want_converter}
                      onChange={this.appSettingChange.bind(this, 'currency_converter', 'want_converter')} />

                    {this.state.currency_converter.want_converter === '1' &&
                      <TextField
                        value={1}
                        type="number"
                        disabled={true}
                        className={this.textField}
                        InputLabelProps={{ shrink: true, }}
                        InputProps={{ readOnly: true, }}
                        label={"Shopify Currency"} />
                    }
                    {this.state.currency_converter.want_converter === '1' &&
                    <TextField
                      helpText={"fill the current conversion rate"}
                      value={this.state.currency_converter.ebay_currency}
                      onChange={this.appSettingChange.bind(this, 'currency_converter', 'ebay_currency')}
                      type="number" min="0"
                      label={"eBay Currency"}/>
                    }
                  </Stack>
                </Card.Section>
              </Card>
            </Card.Section>

</Stack>

</Card>

 
:

this.state.selected===5?



          this.getOrderSettings()




:
this.state.selected===6?

<Card sectioned key={'webhook_settings'}>
<Stack alignment="baseline" distribution="fillEvenly"  >
<Card.Section>
              <Card primaryFooterAction={{ content: 'Save', onAction: this.saveWebhookSettings.bind(this), loading: this.state.loaders.webhook_settings }}>
                <Card.Section>
                  <Stack vertical={false} distribution={"fillEvenly"} >
                    <Select
                      key={'Order update'}
                      options={[{ label: 'Yes', value: 'yes' }, { label: 'No', value: 'no' }]}
                      label={'Enable order update'}
                      placeholder={"Choose.."}
                      helpText={"*Enable this setting only if you want to sync any update related to order made on Shopify to be recieved on App as well on eBay"}
                      value={this.state.webhook_settings.order_update}
                      onChange={this.webhookSettingsChange.bind(this, 'order_update')} />
                  </Stack>
                </Card.Section>
              </Card>
            </Card.Section>

</Stack>

</Card>:
<h1>Error</h1>


          }
          </Tabs>
          </Stack.Item>
          </Stack>
          <FooterHelp>
    Learn more about{' '}
    <Link external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=configuration-24">
      Configuration
    </Link>
  </FooterHelp>
  {
          this.state.confirmation_modal.update_ebay_details && this.ConfirmUpdateDetailsModal()
        }
      </Page>
    );
  }

  getSourceAttributes() {
    requests
      .getRequest("ebayV1/get/getSourceAttributes", {
        marketplace: 'shopify'
      })
      .then(data => {
        if (data.success) {
          for (let i = 0; i < data.data.length; i++) {
            if (!isUndefined(data.data[i].options) && data.data[i].code === 'collections') {
              let dictioned_options = this.dictionedData(data.data[i].options);
              this.state.seller_preferences.import_collection.collections_options = dictioned_options.slice(0);
            }
          }
        }
      });
  }

  dictionedData(data) {
    let Obj = {};
    data.forEach((option, index) => {
      Obj[option.label] = index;
    });
    let Ordered_Array = [];
    Object.keys(Obj).sort().forEach(key => {
      data[Obj[key]]['label'] = data[Obj[key]]['label'] + "-" + data[Obj[key]]['value']
      Ordered_Array.push(data[Obj[key]]);
    });
    return Ordered_Array;
  }

  handleAdd(userPreference = 'match_from_ebay') {
    switch (userPreference) {
      case 'match_from_ebay':
        let tempObj = {};
        let attributeAdded = '';
        tempObj = Object.assign({}, this.state.seller_preferences.match_from_ebay);
        let ObjtoAdd = { shopify_attribute: '', ebay_attribute: '' };
        if (Object.keys(tempObj).length < 2) {
          if (Object.keys(tempObj).length === 0) {
            tempObj['1'] = { ...ObjtoAdd };
          } else {
            tempObj['2'] = { ...ObjtoAdd };
          }
        }

        this.state.seller_preferences.match_from_ebay = Object.assign({}, tempObj);
        matchfromEbayOptions.forEach((key, index) => {
          if (key.value === attributeAdded) {
            matchfromEbayOptions[index]['disabled'] = true;
          }
        });
        this.setState(this.state);
        break;
    }
    this.setState(this.state);
  }

  handleRemove(userPreference = 'match_from_ebay', key) {
    switch (userPreference) {
      case 'match_from_ebay':
        let tempObj = {};
        let resturctureObj = {};
        let attributeRemoved = this.state.seller_preferences.match_from_ebay[key];
        tempObj = Object.assign({}, this.state.seller_preferences.match_from_ebay);
        if (Object.keys(tempObj).length > -1) {
          if (tempObj.hasOwnProperty(key)) {
            delete tempObj[key];
            if (Object.keys(tempObj).length > 0) {
              let pos = 1;
              Object.keys(tempObj).map(PosKey => {
                resturctureObj[pos] = tempObj[PosKey];
                ++pos;
              });
            }
            this.state.seller_preferences.match_from_ebay = Object.assign({}, resturctureObj);

          }
        }
        matchfromEbayOptions.forEach((key, index) => {
          if (key.value === attributeRemoved) {
            if (matchfromEbayOptions[index]['disabled']) {
              matchfromEbayOptions[index]['disabled'] = false;
            }
          }
        });
        this.setState(this.state);
        break;
    }
    this.setState(this.state);
  }

  toggleOptions(selectedOption) {
    matchfromEbayOptions.forEach((key, index) => {
      if (matchfromEbayOptions[index]['value'] === selectedOption) {
        matchfromEbayOptions[index]['disabled'] = true;
      } else {
        matchfromEbayOptions[index]['disabled'] = false;
      }
    });
  }

  saveOrderSetting() {
    this.state.loaders.order_settings = true;
    this.setState(this.state);
    requests.postRequest('ebayV1/upload/saveOrderSettings', { order_settings: this.state.order_settings_data.order_settings }).then(data => {
      if (data.success) {
        notify.success(data.message);
      } else {
        notify.error(data.message);
      }
      this.state.loaders.order_settings = false;
      this.setState(this.state);
    })
  }

  getOrderSettings() {
    let temparr = [];

    if (!this.state.skeleton_display.order_settings_show) {
      temparr.push(
        <Card key={'order_settings'}>
        
            <Card.Section>
              <Card primaryFooterAction={{ content: 'Save', onAction: this.saveOrderSetting.bind(this), loading: this.state.loaders.order_settings }}>
                <Card.Section title={'Map order cancellation reason'}>
                  <FormLayout>
                    <FormLayout.Group>
                      {
                        this.getOrderCancellationSettings()
                      }
                    </FormLayout.Group>
                  </FormLayout>
                </Card.Section>
              </Card>
            </Card.Section>
     
        </Card>
      )
    } else {
      temparr.push(
        <Skeleton case="collapsible" />
      )
    }

    return temparr;
  }

  getOrderCancellationSettings() {
    let temparr = [];
    this.state.order_settings_data.cancellation_reason_options.shopify.forEach((shopify_reason, index) => {
      temparr.push(
        <Select
          key={'index_' + shopify_reason['label']}
          options={this.state.order_settings_data.cancellation_reason_options.ebay}
          label={shopify_reason['label']}
          placeholder={"Choose.."}
          value={this.state.order_settings_data.order_settings.cancel_order_reason_mapping[shopify_reason['value']]}
          onChange={this.ordercancellationReasonChange.bind(this, shopify_reason['value'])} />
      )
    });
    return temparr;
  }
  createNewTemplate(key) {
    let tempObj = { display: key, type: 'Template' }
    let message = cryptr.encrypt(JSON.stringify(tempObj));
    this.redirect('/panel/template/modifier?message=' + encodeURI(message));
  }
  ordercancellationReasonChange(shopify_reason, value) {
    this.state.order_settings_data.order_settings.cancel_order_reason_mapping[shopify_reason] = value;
    this.setState(this.state);
  }
}

export default Configuration;