import React, {Component,ReactDOM} from 'react';
import {TopBar, DisplayText, Badge, ThemeProvider,Button,Stack,Icon,Tooltip, FooterHelp,Link} from "@shopify/polaris";
import {withRouter} from "react-router-dom";
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import {isUndefined} from "util";
import './topbar.css'
import { PhoneMajorTwotone,MobileBackArrowMajorMonotone} from '@shopify/polaris-icons';
//const messages = ["Increase your products visibility with Google Free Listings. Start with our FREE PLAN.","Successfully Exported Data,Download the CSV by clicking on View Report","If you already have an existing plan you can upgrade or downgrade your plan","If you want a custom plan feel free to contact us"];

class TopBarPanel extends Component {
   
    constructor(props){
        super(props);
        this.state={
            counter:0,
            id:0,
            username:'User',
            account:'Account',
            role:'User',
            initials:'',
            userMenuOpen: false,
            showMobileNavigation: false,
            //isSideMenuOpen:true,
            header:{
                message:'',
                url:'',
                link:''
            },
            footer:''
        }
       
        this.getUserDetails();
        this.getHeaderFooter();
    }
    componentDidMount(){
        setInterval(() => {
            this.setState({counter:(this.state.counter===this.state.header['message'].length-1?0:this.state.counter+1)})
            
        }, 5000);

    }
    getUserDetails() {      
        requests.getRequest('user/getDetails', undefined, false, true)
            .then(data => {
                if (data.success){
                    this.state.id=data.data.id
                    this.state.username=data.data.username!==''?data.data.username:'User';
                    this.state.role=!isUndefined(data.data.role_id)?this.getRole(parseInt(data.data)):'User';
                    this.state.initials=data.data.username!==''?this.getInitials(data.data.username):'';
                    this.setState(this.state);
                } else {
                    notify.error(data.message);
                }
            });
            
    }
   
    getHeaderFooter(){
        requests.getRequest('frontend/app/showFooter')
        .then(data => {
            //this.setState({})
            let url=[]
            let link=[]
            let message=[]
            for(let messages in data.message.header)
            {
                 url[messages]=data.message.header[messages].slice(data.message.header[messages].search("url:")+4)
                 link[messages]=data.message.header[messages].slice(data.message.header[messages].search("url_")+4,data.message.header[messages].search("_url"))
                 message[messages]=data.message.header[messages].slice(0,data.message.header[messages].search("url_"))
            }
            let {header}=this.state
            header['message']=message
            header['url']=url
            header['link']=link
            this.setState({header})
            this.setState({footer:data.message.footer})
    })
}
    getRole(data){
        
        switch (data) {
            case 2: return 'Admin';
            break;
            case 3 : return 'User'
            default : return 'User'
        }
    }
 
    toggleUserMenu = () => {
        
        this.setState(({userMenuOpen}) => ({userMenuOpen: !userMenuOpen}));
    };
    logout(){
        this.props.logout();
    }
    // function1(){
    //     let userAgentString = 
    //     navigator.userAgent;
    //     document.getElementById("test").style.display='flex'
    //     let firefoxAgent = 
    //     userAgentString.indexOf("Firefox") > -1;
    //     if(firefoxAgent)
    //     {
    //         if(this.state.isSideMenuOpen===true)
    //         {
    //         document.getElementById("xyz").style.marginLeft='-10px'
    //         document.getElementById("xyz").style.transition='1.0s'
    //         document.getElementById("test").style.setProperty("width","40px","important")
    //         document.getElementById("test").style.setProperty("overflow","hidden","important")
    //         }
    //         else
    //         {
    //         document.getElementById("xyz").style.marginLeft='140px'
    //         document.getElementById("test").style.setProperty("width","250px","important")
    //         document.getElementById("test").style.setProperty("overflow","hidden","important")
    //         }
    //         this.setState({check:this.state.check+1})
    //         this.setState({isSideMenuOpen:!this.state.isSideMenuOpen})
        
    //     }
    //     else{
    //         if(this.state.isSideMenuOpen===true)
    //         {
    //         document.getElementById("xyz").style.marginLeft='-10px'
    //         document.getElementById("xyz").style.transition='0.4s'
    //         document.getElementById("test").style.setProperty("width","50px","important")
    //         document.getElementById("test").style.setProperty("overflow","hidden","important")
    //         }
    //         else
    //         {
    //         document.getElementById("xyz").style.marginLeft='140px'
    //         document.getElementById("test").style.setProperty("width","250px","important")
    //         document.getElementById("test").style.setProperty("overflow","hidden","important")
    //         }
    //         this.setState({check:this.state.check+1})
    //         this.setState({isSideMenuOpen:!this.state.isSideMenuOpen})
    //     }
    // }
  
    render() {
        const iconContent = () => {
            return (
              <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <circle cx="10" cy="10" r="10" fill="#084e8a" />
                <circle cx="10" cy="10" r="6" fill="currentColor" />
                <circle cx="10" cy="10" r="3" />
              </svg>
            );
          };
        const userMenuMarkup = (
          <div onClick={(e)=>{
            this.redirect('/panel/accounts')
            e.preventDefault();
          }
          }>
            <TopBar.UserMenu
                // name={<React.Fragment><p>Account</p></React.Fragment>}
                name={<React.Fragment><p>
                    {/* Welcome */}
                    {this.state.username}
                    </p></React.Fragment>}
                // detail={ this.state.username}
                initials={this.state.initials}
            />
          </div>
        );
        const secondaryMenuMarkup = (
            <TopBar.Menu
              activatorContent={
              
                window.matchMedia("only screen and (max-width: 480px)").matches?
                <Tooltip content="Book a Call"><Button plain monochrome onClick={(e)=>{  window.open('https://calendly.com/scale-business-with-cedcommerce/marketplace-integration?utm_campaign=Shopify-eBayI&utm_source=ebay-shopify-integration&month=2021-12', '_blank')
                e.preventDefault();}}><Icon source={PhoneMajorTwotone}/></Button></Tooltip>:
                  <Button onClick={(e)=>{window.open('https://calendly.com/scale-business-with-cedcommerce/marketplace-integration?utm_campaign=Shopify-eBayI&utm_source=ebay-shopify-integration&month=2021-12', '_blank')
                 e.preventDefault();}} size="medium">
                      <Stack wrap={false} alignment="center" spacing="extraTight" distribution="fill"> 
                      
                        <Icon source={iconContent}/>
                  <p style={{width:'80px'}}>Book a Call</p>  </Stack>
                </Button>  
                  
                    
                       
               
                 
              }
             // actions={this.handleClick.bind(this)}
            //   open={isSecondaryMenuOpen}
            //   onOpen={toggleIsSecondaryMenuOpen}
            //   onClose={toggleIsSecondaryMenuOpen}
            //   actions={[
            //     {
            //       items: [{content: 'Community forums'}],
            //     },
            //   ]}
            />
          );
        const searchFieldMarkup = (
         <>
           <h1 className="header" >{this.state.header['message'][this.state.counter]}<a target={"_blank"} href={this.state.header['url'][this.state.counter]} style={{color:'white',textDecoration:'underline'}}>{this.state.header['link'][this.state.counter]}</a></h1>
           </>
          );
        return (
         
            // <ThemeProvider theme={{colors: {primary: '#2e72d2'}}}>
          
            <TopBar on data={this.state.id}
                showNavigationToggle={window.matchMedia("only screen and (max-width:599px)").matches?true:false}
                secondaryMenu={secondaryMenuMarkup}
                userMenu={userMenuMarkup}
                onNavigationToggle={this.props.toggleMobileNavigation}
                searchField={searchFieldMarkup}
                
               
            />
           
            // </ThemeProvider>
         
        );
    }

    getInitials (string) {
        var names = string.split(' '),
            initials = names[0].substring(0, 1).toUpperCase();

        if (names.length > 1) {
            initials += names[names.length - 1].substring(0, 1).toUpperCase();
        }
        return initials;
    }

    toggleState = (key) => {
        return () => {
            this.setState((prevState) => ({[key]: !prevState[key]}));
        };
    };

    redirect(url){
        this.props.history.push(url);
    }
}

export default withRouter(TopBarPanel);
