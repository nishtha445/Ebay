import React, {Component} from 'react';
import {Frame,FooterHelp,Link} from "@shopify/polaris";
import NavigationPanel from "./navigation";
import TopBarPanel from "./topbar";
import {globalState} from "../../services/globalstate";
import {Redirect, Route, Switch, withRouter} from "react-router-dom";
import Profiles from "../Profiles/profiles";
import Activities from "../Activities/activities";
import Orders from "../Orders/order";
import ImportUpload from "../ImportUpload/importupload";
import Products from "../Products/products";
import Help from "../Help/help";
import AccountsPanel from "../Accounts/accounts";

import Dashboard from "../Dashboard/dashboard";
import {requests} from "../../services/request";
import {isUndefined} from "util";
import Plans from "../Plan/plans";
import ReportAnIssue from "../Help/report-issue";
import RecentActivities from "../Activities/recentactivites";
import Configuration from "../Configurations/configuration";
import CustomItemIdmain from "../Configurations/CustomItemId";
import TemplateModifier from "../../templates/templateModifier";
import PaymentShippingReturn from "../../templates/paymentShippingReturntemplate";
import TemplateList from "../TemplateList/templatelist";
import BusinessPolicy from "../BusinessPolicy/businesspolicy";
import CreateProfile from "../Profiles/createProfile";
import ViewProfile from "../Profiles/ViewProfile";
import ViewProducts from "../Products/view-products";
import ViewOrder from "../Orders/view-order";
import CancelmainOrder from "../Orders/cancel-main-order";
import failedProducts from "../Products/failed-products";
import newProducts from "../Products/new-products";
import BillingHistory from "../Plan/billing-history";
import FooterBar from "./footerbar";
import bulkUpdate from "../Products/bulkupdate";
import OrderEnquiry from "../Orders/order_enquiry";
import Registrations from "../Registration/registrations";
import Ebaymessages from "../eBayMessages/ebaymessages";
import Taxtables from "../Products/taxtables";
import NewProducts from '../Products/NewProducts';
import NewOrders from '../Orders/NewOrders';
import NewBusinessPolicy from '../BusinessPolicy/newbusinesspolicy';
import NewProfiles from '../Profiles/NewProfile';
import NewTemplateList from '../TemplateList/NewTemplateList';
import NewViewProducts from '../Products/NewViewProducts';
import {connect} from "react-redux";

class Panel extends Component {
  constructor(props){
    super(props);
    this.state={
      showMobileNavigation:false,
      registration_complete:true,
      show_footer: false,
      footer_message: '',
      isNavigationOpen:false,
      userId:0
    };
    this.checkStepCompleted();
    this.getFooterMessage();
    this.getUserId();
  }

  getFooterMessage(){

   
      requests.getRequest('frontend/app/showFooter')
           .then(response =>{
          //   if(response.success) {
             this.setState({ show_footer: Object.keys(response.message).includes('footer'), footer_message: response.message.footer});
          //  }
          });
  }
  getUserId(){


    requests.getRequest('user/getDetails', undefined, false, true)
    .then(data => {
      if (data.success) {
        this.state.userId=data.data.id
        this.setState(this.state)
        // requests.getRequest(`ebayV1/upload/getAppSettings?user_id=${data.data.id}`)
        // .then(data=>{
        //   if(data.skype!=='N/A')
        //   {
        //     socialMediaDetails.skype=data.skype

        //   }
        //   else if(data.whatsapp!=='N/A')
        //   {
        //       socialMediaDetails.whatsapp=data.whatsapp

        //   }
        // })
      } 
    });
  }




  checkStepCompleted() {
    let path = '/App/User/Step';
    requests.getRequest('frontend/app/getStepCompleted', {path: path}).then(data => {
      if (data.success) {
        if (data.data !== null && !isUndefined(data.data)) {
          if(parseInt(data.data)<6){
            this.redirect('/auth/registration')
          }
          else{
            this.state.registration_complete=true;
            this.setState(this.state);
          }
        }
      }
      else{
        this.redirect('/auth/registration');
      }

    });

  }
  toggleState = (key) => {

    this.setState((prevState) => ({[key]: !prevState[key]}));

  };
  redirect(url){
    this.props.history.push(url);
  }
  render() {
    let { show_footer,  footer_message, activity} = this.state;
    const topBarMarkup = <TopBarPanel 
      toggleMobileNavigation={()=>{
        this.toggleState('showMobileNavigation')}} 
        logout={(url)=>{
      globalState.removeLocalStorage('auth_token');
      globalState.removeLocalStorage('user_authenticated');
      this.redirect("/auth/login")
    }}/>;
    const navigationMarkup = (
      <NavigationPanel navigationOpen={this.state.isNavigationOpen} element={document.getElementById("xyz")} show_footer={this.state.show_footer} userId={this.state.userId}/>
    );
    const footerMarkup = show_footer ? <FooterBar message={footer_message}/> : false;
    return (
     
      this.state.registration_complete &&
      <Frame topBar={topBarMarkup}
             navigation={navigationMarkup}
             globalRibbon={footerMarkup}
             showMobileNavigation={this.state.showMobileNavigation} 
             onNavigationDismiss={()=>{this.toggleState('showMobileNavigation')}}
      >
        <div id="xyz">
        <Switch>
          <Route exact path="/panel/" render={() => (
            <Redirect to="/panel/dashboard"/>
          )}/>
          <Route exact path='/panel/dashboard' component={Dashboard}/>
          <Route exact path='/panel/accounts' component={AccountsPanel}/>
         
          <Route exact path='/panel/help' component={Help}/>
          <Route exact path='/panel/help/report' component={ReportAnIssue}/>
          {/* <Route exact path='/panel/prevproducts' component={Products}/> */}
          <Route exact path='/panel/products' component={NewProducts}/>
          {/* <Route exact path='/panel/products/view' component={ViewProducts}/> */}
          <Route exact path='/panel/products/view' component={NewViewProducts}/>
          <Route exact path='/panel/products/taxtables' component={Taxtables}/>
          <Route exact path='/panel/products/failed' component={failedProducts}/>
          <Route exact path='/panel/products/new' component={newProducts}/>
          /*<Route exact path='/panel/products/bulkupdate' component={bulkUpdate}/>*/
          <Route exact path='/panel/config' component={Configuration}/>
          <Route exact path='/panel/config/customItemId' component={CustomItemIdmain}/>
          <Route exact path='/panel/exhangestation' component={ImportUpload}/>
          {/* <Route exact path='/panel/prevorders' component={Orders}/> */}
          <Route exact path='/panel/orders' component={NewOrders}/>
          <Route exact path='/panel/orders/view' component={ViewOrder}/>
          <Route exact path='/panel/orders/enquiry' component={OrderEnquiry}/>
          <Route exact path='/panel/orders/cancelmainorder' component={CancelmainOrder}/>
          <Route exact path='/panel/plans' component={Plans}/>
          <Route exact path='/panel/plans/billing' component={BillingHistory}/>
          {/* <Route exact path='/panel/profiles' component={Profiles}/> */}
          <Route exact path='/panel/profiles' component={NewProfiles}/>
          <Route exact path='/panel/profiles/createprofile' component={CreateProfile}/>
          <Route exact path='/panel/profiles/viewprofile' component={ViewProfile}/>
          <Route exact path='/panel/activities' component={Activities}/>
          <Route exact path='/panel/activities/recent' component={RecentActivities}/>
          <Route exact path='/panel/template/business' component={PaymentShippingReturn}/>
          <Route exact path='/panel/ebayMessages' component={Ebaymessages}/>

          <Route exact path='/panel/template/modifier' component={TemplateModifier}/>
          {/* <Route exact path='/panel/template/prevlist' component={TemplateList}/> */}
          <Route exact path='/panel/template/list' component={NewTemplateList}/>
          {/* <Route exact path='/panel/businesspolicies/list' component={BusinessPolicy}/> */}
          <Route exact path='/panel/businesspolicies/list' component={NewBusinessPolicy}/>
          <Redirect from ="**" to="/panel/dashboard"/>
        </Switch>
        </div>
       
      </Frame>
    

    );
  }
}

const mapStateToProps = state => {
  let { activity } = state;
  return ({ activity    });
}

// export default withRouter(Panel);
export default connect(mapStateToProps)(withRouter(Panel));
