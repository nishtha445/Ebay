import React, {Component} from 'react';
import {Badge, Stack} from "@shopify/polaris";
import './footerbar.css'
class FooterBar extends Component {
    render() {
        
        return (
            
            <div id="footer">
            <div style={{backgroundColor:'#002140',color:'white',paddingBottom:'2.5rem',minHeight:'8.5rem'}}>
                <Stack vertical={true} alignment={"center"} distribution={"fill"} wrap={true}>
                    <p  style={{color:'white',padding:'0',fontSize:'1.2rem',wordBreak:'break-word',textAlign:'left',wordWrap:'break-word',paddingRight:'5rem'}}><Badge status={"attention"}>Note</Badge><b> {this.props.message}</b></p>
                </Stack>
            </div>
            </div>
        );
    }
}

export default FooterBar;
