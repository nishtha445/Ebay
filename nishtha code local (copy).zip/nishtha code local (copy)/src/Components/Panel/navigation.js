import React, { Component } from 'react';
import { Navigation, TopBar,Tooltip,TextStyle,Icon,Stack} from "@shopify/polaris";

import { withRouter } from "react-router-dom";
import { requests } from "../../services/request";
import { isUndefined } from "util";
import { notify } from "../../services/notify";
import './navigation.css'
import {
  CashDollarMajorMonotone, PhoneMajorMonotone, LegalMajorMonotone, ChatMajorMonotone, OnlineStoreMajorMonotone, CircleInformationMajorMonotone,
  CircleAlertMajorMonotone, QuestionMarkMajorMonotone, ProductsMajorMonotone, OrdersMajorMonotone,HomeMajorMonotone, SettingsMajorMonotone,ListMajorMonotone,PopularMajorMonotone,CalendarMajorMonotone,AppsMajorMonotone, ConversationMinor, MobilePlusMajorTwotone,ArrowLeftMinor, ArrowRightMinor
} from '@shopify/polaris-icons';
import { environment } from '../../environments/environment';
// import {getSocialMediaDetails
// } from '../Auth/Login/login';
import  MainContext from '../Auth/Login/login';
import { contextType } from 'react-data-grid';

class NavigationPanel extends Component {

  static contextType=MainContext;
  
  defaultState = {
    emailFieldValue: 'dharma@jadedpixel.com',
    nameFieldValue: 'Jaded Pixel',
  };
  constructor(props) {
    super(props);
    this.state = {
      isSideMenuOpen:true,
      storeName: this.defaultState.nameFieldValue,
      username: "User",
      plan_expire: true,
     
    }
    this.getUserDetails();
    this.getproductServiceCredits();
  }

  getUserDetails() {
    requests.getRequest('user/getDetails', undefined, false, true)
      .then(data => {
        if (data.success) {
          this.state.username = data.data.username !== '' ? data.data.username : 'User';
          this.setState(this.state);
        } else {
          notify.error(data.message);
        }
      });
  }

  getorderServiceCredits() {

  }
  componentDidMount(){
    console.log("context",this.context)
        // requests.getRequest(`ebayV1/upload/getAppSettings?user_id=${this.props.userId}`)
        // .then(data=>{
        //   if(data.skype!=='N/A')
        //   {
        //     socialMediaDetails.skype=data.skype
        //   }
        //   else if(data.whatsapp!=='N/A')
        //   {
        //       socialMediaDetails.whatsapp=data.whatsapp
        //   }
        // })     
  }
  function1(){
    
    // let abc=getSocialMediaDetails()
    // console.log("hello",abc)
    let userAgentString = 
    navigator.userAgent;
    document.getElementById("test").style.display='flex'
    let firefoxAgent = 
    userAgentString.indexOf("Firefox") > -1;
    if(firefoxAgent)
    {
     
        if(this.state.isSideMenuOpen===true)
        {
          
        document.getElementById("xyz").style.marginLeft='-10px'
        document.getElementById("xyz").style.transition='0.6s'
        document.getElementById("test").style.setProperty("width","45px","important")
        if(this.props.show_footer){
       document.getElementById("footer").style.marginLeft='-150px'
       document.getElementById("footer").style.marginRight='0px'
       document.getElementById("footer").style.setProperty("width","1350px")
      }
        document.getElementById("arrow").style.setProperty("width","40px","important")
        document.getElementById("test").style.setProperty("overflow","hidden","important")
        }
      
        else
        {
         
        document.getElementById("xyz").style.marginLeft='140px'
        document.getElementById("test").style.setProperty("width","250px","important")
        document.getElementById("arrow").style.setProperty("width","170px","important")
        if(this.props.show_footer){
       document.getElementById("footer").style.setProperty("width","1300px")
       document.getElementById("footer").style.marginLeft='0px'
        }
        document.getElementById("test").style.setProperty("overflow","hidden","important")
        }
      
        this.setState({check:this.state.check+1})
        this.setState({isSideMenuOpen:!this.state.isSideMenuOpen})
    
    }
    else{
        if(window.matchMedia("only screen and (min-width:599px)").matches)
        {
        if(this.state.isSideMenuOpen===true)
        {
        document.getElementById("xyz").style.marginLeft='-5px'
        document.getElementById("xyz").style.transition='0.6s'
        document.getElementById("test").style.setProperty("width","55px","important")
        document.getElementById("arrow").style.setProperty("width","50px","important")
       
        if(this.props.show_footer){
          document.getElementById("footer").style.setProperty("width","1370px","important")
          document.getElementById("footer").style.marginLeft='-150px'
          document.getElementById("footer").style.marginRight='0px'

        }
        document.getElementById("test").style.setProperty("overflow","hidden","important")
       
        }
        else
        {
         
        document.getElementById("xyz").style.marginLeft='140px'
        document.getElementById("test").style.setProperty("width","250px","important")
        document.getElementById("arrow").style.setProperty("width","190px","important")
        document.getElementById("test").style.setProperty("overflow","hidden","important")
        if(this.props.show_footer){
        document.getElementById("footer").style.setProperty("width","1350px","important")
        document.getElementById("footer").style.marginLeft='0px'
        }
        
        }
      }
        this.setState({check:this.state.check+1})
        this.setState({isSideMenuOpen:!this.state.isSideMenuOpen})
    }
}
  getproductServiceCredits() {
    requests.getRequest('frontend/app/getPlanExpire')
      .then(response => {
        if (response.success) {
          this.setState({ plan_expire: response.data.plan_expire }, () => {
            if (response.data.plan_expire) this.redirect('/panel/plans?exp=hash');
          });
        }
      });
  }

  toggleState = (key) => {
    return () => {
      this.setState((prevState) => ({ [key]: !prevState[key] }));
    };
  };
  
  render() {
   
    let { plan_expire } = this.state;
   
    // console.log('object', this.props.location.pathname)
    return (
    
    <div id="test">
      <Navigation location={this.props.location.pathname}>
        <div id="test1">
        <Navigation.Section 
          // separator
          // title={"Welcome "+this.state.username}
          items={[
            {
            
             label:
               
               <Stack wrap={false}><Tooltip content="Dashboard" dismissOnMouseOut><div onClick={this.redirect.bind(this, '/panel/dashboard')}><Icon source={HomeMajorMonotone}></Icon></div></Tooltip><b style={this.props.location.pathname.includes('dashboard') ? { color: '#5E6CC5' } : {}}>Dashboard
               </b></Stack>,
              //icon: <Icon source={HomeMajorMonotone}></Icon>,
              
              disabled: plan_expire,
            
              // url: `/panel/dashboard`,
              onClick: this.redirect.bind(this, '/panel/dashboard'),
              
              
              // exactMatch: true
            },
            // {
            //     label: 'Account',
            //     icon: 'profile',
            //     url: '/panel/accounts',
            //     subNavigationItems: [
            //         {
            //             url: "/panel/accounts/",
            //             label: "Settings",
            //             onClick:this.redirect.bind(this,'/panel/products'),
            //         }
            //     ],
            // },
            // {
            //   label: 'prev Products',
            //   icon: ProductsMajorMonotone,
            //     disabled : plan_expire,
            //   onClick:this.redirect.bind(this,'/panel/prevproducts'),
            // },
            {
              // label: 'Products',
              label: <Stack wrap={false}><Tooltip content="Products" dismissOnMouseOut><div onClick={this.redirect.bind(this, '/panel/products')}><Icon source={ProductsMajorMonotone}></Icon></div></Tooltip><b style={this.props.location.pathname.includes('products') && !this.props.location.pathname.includes('products/view') && !this.props.location.pathname.includes('products/taxtables') && !this.props.location.pathname.includes('products/failed') ? { color: '#5E6CC5' } : {}}>Products</b></Stack>,
              //icon:ProductsMajorMonotone,
              disabled: plan_expire,
              // url: () => { this.newRedirect('panel/products') }
              onClick: this.redirect.bind(this, '/panel/products'),
              // exactMatch: true

            },
            // {
            //   label: 'Prev Orders',
            //   icon: OrdersMajorMonotone,
            //     disabled : plan_expire,
            //   onClick:this.redirect.bind(this,'/panel/prevorders'),
            // },
            {
              // label: 'Orders',
              label: <Stack wrap={false}><Tooltip content="Orders" dismissOnMouseOut><div onClick={this.redirect.bind(this, '/panel/orders')}><Icon source={OrdersMajorMonotone}></Icon></div></Tooltip><b style={this.props.location.pathname.includes('orders') && !this.props.location.pathname.includes('orders/view') && !this.props.location.pathname.includes('orders/enquiry') && !this.props.location.pathname.includes('orders/cancelmainorder') ? { color: '#5E6CC5' } : {}}>Orders</b></Stack>,
              //icon: OrdersMajorMonotone,
              disabled: plan_expire,
               onClick: this.redirect.bind(this, '/panel/orders'),
              // exactMatch: true

            }
          ]}
          />
          <Navigation.Section

          items={[

            // {
            //     label: 'Import/Upload',
            //     icon: 'refresh',
            //     onClick:this.redirect.bind(this,'/panel/exhangestation'),
            // },

         
        // action={{
        //     icon: 'conversation',
        //     accessibilityLabel: 'Contact support',
        //     onClick: this.toggleState('modalActive'),
        // }}
       

       
            // {
            //   label: 'Business policy',
            //   icon: OnlineStoreMajorMonotone,
            //   disabled : plan_expire,
            //   onClick:this.redirect.bind(this,'/panel/businesspolicies/list'),
            // },
            {
              // label: 'Business policy',
              label:<Stack wrap={false}><Tooltip content="Business Policy" dismissOnMouseOut><div onClick={this.redirect.bind(this, '/panel/businesspolicies/list')}><Icon source={OnlineStoreMajorMonotone}></Icon></div></Tooltip> <b style={this.props.location.pathname.includes('businesspolicies/list') ? { color: '#5E6CC5' } : {}}>Business policy</b></Stack>,
              //icon: OnlineStoreMajorMonotone,
              disabled: plan_expire,
              // url: `/panel/businesspolicies/list`,
              onClick: this.redirect.bind(this, '/panel/businesspolicies/list'),
              exactMatch: true

            },
            // {
            //   label: 'prev Templates',
            //     disabled : plan_expire,
            //   icon: '<svg viewBox=\'0 0 20 20\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M19 11h-7c-0.553 0-1 0.447-1 1v7c0 0.553 0.447 1 1 1h7c0.553 0 1-0.447 1-1v-7c0-0.553-0.447-1-1-1v0zM8 11v0c0.553 0 1 0.447 1 1v7c0 0.553-0.447 1-1 1h-7c-0.553 0-1-0.447-1-1v-7c0-0.553 0.447-1 1-1h7zM8 0v0c0.553 0 1 0.447 1 1v7c0 0.553-0.447 1-1 1h-7c-0.553 0-1-0.447-1-1v-7c0-0.553 0.447-1 1-1h7zM2 18h5v-5h-5v5zM2 7h5v-5h-5v5zM13 18v-5h5v5h-5zM12 6c-0.553 0-1-0.447-1-1s0.447-1 1-1h2v-2c0-0.553 0.447-1 1-1s1 0.447 1 1v2h2c0.553 0 1 0.447 1 1s-0.447 1-1 1h-2v2c0 0.553-0.447 1-1 1s-1-0.447-1-1v-2h-2z\' /></svg>',
            //   onClick:this.redirect.bind(this,'/panel/template/prevlist'),
            // },
            {
              // label: 'Templates',
              label:<Stack wrap={false}><Tooltip content="Templates" dismissOnMouseOut><div onClick={this.redirect.bind(this, `/panel/template/list`)}><Icon source={AppsMajorMonotone}></Icon></div></Tooltip> <b style={this.props.location.pathname.includes('template/list') ? { color: '#5E6CC5' } : {}}>Templates</b></Stack>,
              disabled: plan_expire,
              // icon: '<svg viewBox=\'0 0 20 20\' xmlns=\'http://www.w3.org/2000/svg\'><path d=\'M19 11h-7c-0.553 0-1 0.447-1 1v7c0 0.553 0.447 1 1 1h7c0.553 0 1-0.447 1-1v-7c0-0.553-0.447-1-1-1v0zM8 11v0c0.553 0 1 0.447 1 1v7c0 0.553-0.447 1-1 1h-7c-0.553 0-1-0.447-1-1v-7c0-0.553 0.447-1 1-1h7zM8 0v0c0.553 0 1 0.447 1 1v7c0 0.553-0.447 1-1 1h-7c-0.553 0-1-0.447-1-1v-7c0-0.553 0.447-1 1-1h7zM2 18h5v-5h-5v5zM2 7h5v-5h-5v5zM13 18v-5h5v5h-5zM12 6c-0.553 0-1-0.447-1-1s0.447-1 1-1h2v-2c0-0.553 0.447-1 1-1s1 0.447 1 1v2h2c0.553 0 1 0.447 1 1s-0.447 1-1 1h-2v2c0 0.553-0.447 1-1 1s-1-0.447-1-1v-2h-2z\' /></svg>',
              // url: `/panel/template/list`,
              onClick: this.redirect.bind(this, `/panel/template/list`),
              exactMatch: true

            },
            // {
            //   label: 'Profiles',
            //     disabled : plan_expire,
            //   icon: '<svg height="599pt" viewBox="0 0 599.78412 599" width="599pt" xmlns="http://www.w3.org/2000/svg"><path d="m139.785156 80.277344h319.507813v19.96875h-319.507813zm0 0"/><path d="m139.785156 120.214844h319.507813v19.96875h-319.507813zm0 0"/><path d="m139.785156 160.152344h319.507813v19.96875h-319.507813zm0 0"/><path d="m139.785156 200.089844h279.570313v19.96875h-279.570313zm0 0"/><path d="m139.785156 240.03125h259.601563v19.96875h-259.601563zm0 0"/><path d="m139.785156 279.96875h239.628906v19.96875h-239.628906zm0 0"/><path d="m509.214844 449.707031c-5.511719 0-9.984375 4.464844-9.984375 9.984375v89.863282c0 16.539062-13.410157 29.953124-29.953125 29.953124-16.542969 0-29.953125-13.414062-29.953125-29.953124v-39.941407c0-5.519531-4.472657-9.984375-9.984375-9.984375h-329.492188v-449.308594c.539063-17.019531 14.726563-30.402343 31.75-29.953124h377.875c-6.605468 8.589843-10.203125 19.117187-10.242187 29.953124v89.863282c0 5.515625 4.472656 9.984375 9.984375 9.984375 5.515625 0 9.984375-4.46875 9.984375-9.984375v-39.9375h69.894531c5.511719 0 9.984375-4.472656 9.984375-9.984375v-39.941407c-.035156-27.558593-22.363281-49.890624-49.925781-49.921874h-417.554688c-28.046875-.4492192-51.175781 21.875-51.71875 49.921874v449.308594h-69.894531c-5.515625 0-9.984375 4.464844-9.984375 9.984375v39.941407c.0351562 27.554687 22.363281 49.886718 49.921875 49.921874h419.355469c27.558594-.035156 49.890625-22.367187 49.921875-49.921874v-89.863282c0-5.519531-4.46875-9.984375-9.984375-9.984375zm69.894531-399.386719v29.957032h-59.910156v-29.957032c0-16.546874 13.414062-29.953124 29.953125-29.953124 16.542968 0 29.957031 13.40625 29.957031 29.953124zm-559.140625 499.234376v-29.957032h399.386719v29.957032c.039062 10.835937 3.636719 21.355468 10.242187 29.953124h-379.675781c-16.539063 0-29.953125-13.414062-29.953125-29.953124zm0 0"/><path d="m589.09375 329.890625h-399.386719c-5.511719 0-9.984375 4.464844-9.984375 9.984375v79.878906c0 5.511719 4.472656 9.984375 9.984375 9.984375h399.386719c5.511719 0 9.984375-4.472656 9.984375-9.984375v-79.878906c0-5.519531-4.472656-9.984375-9.984375-9.984375zm-9.984375 79.878906h-379.417969v-59.910156h19.96875v9.984375h19.972656v-9.984375h19.96875v9.984375h19.96875v-9.984375h19.96875v9.984375h19.96875v-9.984375h19.96875v9.984375h19.96875v-9.984375h19.96875v9.984375h19.972657v-9.984375h19.96875v9.984375h19.96875v-9.984375h19.96875v9.984375h19.96875v-9.984375h19.96875v9.984375h19.96875v-9.984375h19.96875v9.984375h19.972656v-9.984375h19.96875zm0 0"/><path d="m407.453125 321.824219c1.351563 0 2.6875-.273438 3.925781-.8125l49.230469-21.074219.152344-.074219c1.035156-.460937 1.988281-1.101562 2.804687-1.894531.097656-.089844.230469-.117188.328125-.21875l112.996094-112.988281 14.117187-14.117188c11.703126-11.695312 11.703126-30.664062 0-42.367187-11.851562-11.308594-30.5-11.308594-42.351562 0l-14.128906 14.121094-112.953125 112.953124c-.105469.101563-.132813.230469-.222657.332032-.792968.816406-1.4375 1.765625-1.898437 2.804687l-.097656.148438-21.078125 49.285156c-1.320313 3.082031-1 6.621094.84375 9.425781 1.847656 2.796875 4.976562 4.480469 8.332031 4.484375zm18.96875-28.957031 5.542969-12.980469 7.386718 7.390625zm136.363281-150.46875c3.945313-3.773438 10.160156-3.773438 14.105469 0 3.898437 3.898437 3.898437 10.21875 0 14.117187l-7.058594 7.070313-14.128906-14.128907zm-21.199218 21.175781 14.128906 14.128906-98.851563 98.847656-14.128906-14.128906zm0 0"/></svg>',
            //   onClick:this.redirect.bind(this,'/panel/profiles'),
            // },
            {
              // label: 'Profiles',
              label: <Stack wrap={false}><Tooltip content="Profiles"><div onClick={this.redirect.bind(this, '/panel/profiles')}><Icon source={ListMajorMonotone}></Icon></div></Tooltip><b style={this.props.location.pathname.includes('profiles') && !this.props.location.pathname.includes('profiles/viewprofile') && !this.props.location.pathname.includes('profiles/createprofile') ? { color: '#5E6CC5' } : {}}>Profiles</b></Stack>,

              disabled: plan_expire,
             // icon: ListMajorMonotone,
              onClick: this.redirect.bind(this, '/panel/profiles'),
              // url: `${this.props.location.pathname}/panel/profiles`,
              exactMatch: true

            }
          ]}
          />
          <Navigation.Section
            items={[
            {
              // label: 'Configuration',
              label: <Stack wrap={false}><Tooltip content="Configuration"><div onClick={this.redirect.bind(this, '/panel/config')}><Icon source={SettingsMajorMonotone}></Icon></div></Tooltip><b style={this.props.location.pathname.includes('config') && !this.props.location.pathname.includes('config/customItemId') ? { color: '#5E6CC5' } : {}}>Configuration</b></Stack>,

              disabled: plan_expire,
              //icon: SettingsMajorMonotone,
              onClick: this.redirect.bind(this, '/panel/config'),
              // url: `${this.props.location.pathname}/panel/config`,
              exactMatch: true

            },
            // {
            //   // label: 'eBay Messages',
            //   label: <b style={this.props.location.pathname.includes('ebayMessages') ? { color: '#5E6CC5' } : {}}>eBay Messages</b>,
            //   disabled: plan_expire,
            //   icon: ChatMajorMonotone,
            //   onClick: this.redirect.bind(this, '/panel/ebayMessages'),
            //   // url: `${this.props.location.pathname}/panel/ebayMessages`,
            //   exactMatch: true

            // },

            {
              // label: 'Activities',
              label:<Stack wrap={false}><Tooltip content="Activities"><div onClick={this.redirect.bind(this, '/panel/activities')}><Icon source={PopularMajorMonotone}></Icon></div></Tooltip> <b style={this.props.location.pathname.includes('activities') && !this.props.location.pathname.includes('activities/recent') ? { color: '#5E6CC5' } : {}}>Activities</b></Stack>,
              //icon: PopularMajorMonotone,
              disabled: plan_expire,
              onClick: this.redirect.bind(this, '/panel/activities'),
              // url: `${this.props.location.pathname}/panel/activities`,
              exactMatch: true

            },
            {
              // label: 'Help',
              label: <Stack wrap={false}><Tooltip content="Help"><div onClick={this.redirect.bind(this, '/panel/help')}><Icon source={QuestionMarkMajorMonotone}></Icon></div></Tooltip><b style={this.props.location.pathname.includes('help') && !this.props.location.pathname.includes('help/report') ? { color: '#5E6CC5' } : {}}>Help</b></Stack>,
             // icon: QuestionMarkMajorMonotone,
              disabled: plan_expire,
              onClick: this.redirect.bind(this, '/panel/help'),
              // url: `${this.props.location.pathname}/panel/help`,
              exactMatch: true
            }
          ]}
          />
          <Navigation.Section
            items={[
            {
              // label: 'Choose a plan',
              label: <Stack wrap={false}><Tooltip content="Choose a plan"><div onClick={this.redirect.bind(this, '/panel/plans')}><Icon source={CashDollarMajorMonotone}></Icon></div></Tooltip><b style={this.props.location.pathname.includes('plans') && !this.props.location.pathname.includes('plans/billing') ? { color: '#5E6CC5' } : {}}>Choose a plan</b></Stack>,
              //icon: CashDollarMajorMonotone,
              onClick: this.redirect.bind(this, '/panel/plans'),
              // url: `${this.props.location.pathname}/panel/plans`,
              exactMatch: true

            },
            {
              // label: 'Contact us',
              label: <Stack wrap={false}><Tooltip content="Contact Us"><div onClick={this.redirect.bind(this, '/panel/help/report')}><Icon source={PhoneMajorMonotone}></Icon></div></Tooltip><b style={this.props.location.pathname.includes('help/report') ? { color: '#5E6CC5' } : {}}>Contact Us</b></Stack>,
             // icon: PhoneMajorMonotone,
              onClick: this.redirect.bind(this, '/panel/help/report'),
              // url: `${this.props.location.pathname}/panel/help/report`,
              exactMatch: true

            },
            // {
              
            //   // label: 'Contact us',
            //   label: <Stack wrap={false}>
            //   <Tooltip content={socialMediaDetails.skype!==''?'Skype':socialMediaDetails.whatsapp!==''?'WhatsApp':''}>
            //     <div onClick={(e) => {
            //       if(socialMediaDetails.skype!=='')
            //       {
            //         window.open(socialMediaDetails.skype, '_blank')
            //         e.preventDefault();
            //       }
            //       else if(socialMediaDetails.whatsapp!=='')
            //       {
            //         window.open(socialMediaDetails.whatsapp, '_blank');
            //        e.preventDefault();
            //       }
            //   }}><Icon source={socialMediaDetails.skype!==''||socialMediaDetails.whatsapp!==''?ConversationMinor:null}></Icon></div></Tooltip>{socialMediaDetails.skype!==''?<b>Skype</b>:socialMediaDetails.whatsapp!==''?<b>WhatsApp</b>:''}</Stack>,
            //  // icon: PhoneMajorMonotone,
            //   onClick:()=>{ 
            //     if(socialMediaDetails.skype!=='')
            //     {
            //       window.open(socialMediaDetails.skype, '_blank')
            //       //e.preventDefault();
            //     }
            //     else if(socialMediaDetails.whatsapp!=='')
            //     {
            //       window.open(socialMediaDetails.whatsapp, '_blank');
            //      // e.preventDefault();
            //   // url: `${this.props.location.pathname}/panel/help/report`,
            //     }
            //   },
        

            // },
            // {
            //   // label: 'Contact us',
            //   label:<Stack wrap={false}><Tooltip content="Book a Call"><Icon source={PhoneMajorMonotone}></Icon></Tooltip><b>Book A Call</b>,
            //   icon: CalendarMajorMonotone,
            //   onClick: () => {
            //     window.open('https://calendly.com/scale-business-with-cedcommerce/marketplace-integration?utm_campaign=Shopify-eBayI&utm_source=ebay-shopify-integration&month=2021-12', '_blank')
            //   },
            //   // url: `${this.props.location.pathname}/panel/help/report`,
             

            // },
            // {
            //   label: 'eBay User Policy',
            //   disabled: plan_expire,
            //   icon: LegalMajorMonotone,
            //   onClick: () => {
            //     window.open('https://www.ebay.com/help/policies/member-behaviour-policies/user-agreement?id=4259', '_blank')
            //   },
           // },
            
          ]}
            />
            </div>
            {window.matchMedia("only screen and (min-width: 767px)").matches &&
            <div id="arrow" onClick={this.function1.bind(this)}>
           
            <Icon source={this.state.isSideMenuOpen?ArrowLeftMinor:ArrowRightMinor}/>
            </div>}
      </Navigation>
     
      </div>
     
     
     
     
    );
  }
  redirect(url) {

    this.props.history.push(url);
  }

  preventReload(event) {
    console.log(event)
  }

}

export default withRouter(NavigationPanel);
