import React, {Component} from 'react';
import StyleRoot from "radium/es/components/style-root";
import {Card, DisplayText, Stack,Page} from "@shopify/polaris";
import Cancel from "../../assets/img/warning.png";
import Radium from "radium";
import {fadeInRight, flipInX,bounceInLeft} from "react-animations";



const styles = {
    fadeInRight: {
        animation: 'x 3s',
        animationName: Radium.keyframes(fadeInRight, 'fadeInRight')
    },
    flipInX:{
        animation: 'x 3s',
        animationName: Radium.keyframes(flipInX, 'flipInX')
    },
    bounceInLeft:{
        animation: 'x 3s',
        animationName: Radium.keyframes(bounceInLeft, 'bounceInLeft')
    }
}
class Versioncheck extends Component {

    constructor(props){
        super(props);
        this.state= {
            enableExceptionBanner: false,
        }
    }


    componentDidMount(){
        this.checkBrowsersversion()
    }

    checkBrowsersversion(){


        var nVer = navigator.appVersion;
        var nAgt = navigator.userAgent;
        var browserName  = navigator.appName;
        var fullVersion  = ''+parseFloat(navigator.appVersion);
        var majorVersion = parseInt(navigator.appVersion,10);
        var nameOffset,verOffset,ix;

// In Opera 15+, the true version is after "OPR/"
        if ((verOffset=nAgt.indexOf("OPR/"))!=-1) {
            browserName = "Opera";
            fullVersion = nAgt.substring(verOffset+4);
        }
// In older Opera, the true version is after "Opera" or after "Version"
        else if ((verOffset=nAgt.indexOf("Opera"))!=-1) {
            browserName = "Opera";
            fullVersion = nAgt.substring(verOffset+6);
            if ((verOffset=nAgt.indexOf("Version"))!=-1)
                fullVersion = nAgt.substring(verOffset+8);
        }
// In MSIE, the true version is after "MSIE" in userAgent
        else if ((verOffset=nAgt.indexOf("MSIE"))!=-1) {
            browserName = "Microsoft Internet Explorer";
            fullVersion = nAgt.substring(verOffset+5);
        }
// In Chrome, the true version is after "Chrome"
        else if ((verOffset=nAgt.indexOf("Chrome"))!=-1) {
            browserName = "Chrome";
            fullVersion = nAgt.substring(verOffset+7);
        }
// In Safari, the true version is after "Safari" or after "Version"
        else if ((verOffset=nAgt.indexOf("Safari"))!=-1) {
            browserName = "Safari";
            fullVersion = nAgt.substring(verOffset+7);
            if ((verOffset=nAgt.indexOf("Version"))!=-1)
                fullVersion = nAgt.substring(verOffset+8);
        }
// In Firefox, the true version is after "Firefox"
        else if ((verOffset=nAgt.indexOf("Firefox"))!=-1) {
            browserName = "Firefox";
            fullVersion = nAgt.substring(verOffset+8);
        }
// In most other browsers, "name/version" is at the end of userAgent
        else if ( (nameOffset=nAgt.lastIndexOf(' ')+1) <
            (verOffset=nAgt.lastIndexOf('/')) )
        {
            browserName = nAgt.substring(nameOffset,verOffset);
            fullVersion = nAgt.substring(verOffset+1);
            if (browserName.toLowerCase()==browserName.toUpperCase()) {
                browserName = navigator.appName;
            }
        }
// trim the fullVersion string at semicolon/space if present
        if ((ix=fullVersion.indexOf(";"))!=-1)
            fullVersion=fullVersion.substring(0,ix);
        if ((ix=fullVersion.indexOf(" "))!=-1)
            fullVersion=fullVersion.substring(0,ix);

        majorVersion = parseInt(''+fullVersion,10);
        if (isNaN(majorVersion)) {
            fullVersion  = ''+parseFloat(navigator.appVersion);
            majorVersion = parseInt(navigator.appVersion,10);
        }


        console.log(browserName);
        console.log(majorVersion);

    }

    renderExceptionBanner(){
        setTimeout(()=>{
            this.state.enableExceptionBanner=true;
            this.setState(this.state);
        },5000)
        return (
            <StyleRoot>
                {this.state.enableExceptionBanner?
                    <div style={styles.flipInX}>
                        <Card>
                            <Card.Section>
                                <div style={{textAlign:'center',minHeight:'35rem',marginTop:'10rem'}}>
                                    <Stack alignment={"center"} vertical={true}>
                                        <img src={Cancel} style={{height:'5rem',width:'5rem'}} />
                                        <DisplayText size={"extraLarge"}>
                                            Oops !!
                                        </DisplayText>
                                        <DisplayText size='small'>
                                            <b>Unauthorized access attempt</b>
                                        </DisplayText>
                                        <DisplayText size='small'>
                                            Kindly revisit the app from your shopify store's apps section
                                        </DisplayText>
                                    </Stack>
                                </div>
                            </Card.Section>
                        </Card>
                    </div>:''}
            </StyleRoot>
        );
    }

    render() {
        return (
            <Page
                title=""
            >{this.renderExceptionBanner()}
            </Page>
        );
    }
}

export default Versioncheck;
