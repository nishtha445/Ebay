import { isUndefined } from "util";
import React, { Component } from 'react';
import { Badge, Icon, Stack, TextStyle, Tooltip, TextField } from "@shopify/polaris";
import { DeleteMajorMonotone, EditMajorMonotone, ViewMajorMonotone } from "@shopify/polaris-icons";

function policyNameDetails(incellElement, params) {
    let data = params.data.name;
    let obj = data.title;
    let defaultConfig = data.defaultConfig;
    let policy_type = obj.type + '_policy';
    if (defaultConfig[policy_type] && (obj.data.profileId).toString() === defaultConfig[policy_type]) {
        return (
            <React.Fragment>
                {/* {obj.data.profileName} */}
                <Stack vertical={false} spacing="extraTight">
                    <Tooltip content={obj.data.profileName} preferredPosition="above">
                        <div style={{ cursor: 'pointer', overflow: 'hidden', whiteSpace: 'nowrap', clear: "both" }} onClick={(e) => {
                            incellElement('edit', params.data);
                            e.preventDefault();
                        }} onMouseOver={e => {
                            e.target.style.textDecoration = 'underline';
                        }} onMouseOut={e => {
                            e.target.style.textDecoration = 'none';
                        }}>
                            <TextStyle variation="strong">{obj.data.profileName}</TextStyle>
                        </div>
                    </Tooltip>
                    <Badge status={"attention"}>Default</Badge>
                </Stack>
            </React.Fragment>
        )
    } else {
        return (
            // <React.Fragment>
            <Tooltip content={obj.data.profileName} preferredPosition="above">
                <div style={{ cursor: 'pointer', overflow: 'hidden', whiteSpace: 'nowrap', clear: "both" }} onClick={(e) => {
                    incellElement('edit', params.data);
                    e.preventDefault();
                }} onMouseOver={e => {
                    e.target.style.textDecoration = 'underline';
                }} onMouseOut={e => {
                    e.target.style.textDecoration = 'none';
                }}>
                    <TextStyle variation="strong">{obj.data.profileName}</TextStyle>
                </div>
            </Tooltip>
        )
        // {obj.data.profileName}
        // </React.Fragment>
    }
}

function actionRenderer(incellFunc, params) {
    return (
        <Stack vertical={false} alignment={"center"} distribution={"center"} >
            <Tooltip content={"Preview"} >
                <p onClick={incellFunc.bind(this, 'preview', params.data)} style={{cursor:'pointer'}}>
                    <Icon source={ViewMajorMonotone} />
                </p>
            </Tooltip>
            <Tooltip content={"Edit"}>
                <p onClick={incellFunc.bind(this, 'edit', params.data)} style={{cursor:'pointer'}}>
                    <Icon source={EditMajorMonotone} />
                </p>
            </Tooltip>
            <Tooltip content={"Delete"}>
                <p onClick={incellFunc.bind(this, 'delete', params.data)} style={{cursor:'pointer'}}>
                    <Icon source={DeleteMajorMonotone} />
                </p>
            </Tooltip>
        </Stack>
    );
}

export class myHeaderComponent extends Component {
    render() {
        return (
            <div>
                hjk
            </div>
        )
    }
}

export function gridPropColumns(incellElement = () => { }) {
    return [
        {
            headerName: 'Policy ID', field: "id",
            cellStyle: { 'white-space': 'normal' }, autoHeight: true,
            sortable: true,
            resizable: true,
        },
        {
            headerName: 'Name', field: "filtername",
            cellRendererFramework: policyNameDetails.bind(this, incellElement.bind(this)),
            cellStyle: { 'white-space': 'normal' }, autoHeight: true,
            sortable: true,
            filter: 'agTextColumnFilter',
            width: 800,
        },
        {
            headerName: "Actions", field: "actions",
            autoHeight: true,
            width: 150,
            pinned: 'right',
            cellRendererFramework: actionRenderer.bind(this, incellElement.bind(this)),
        }
    ]
};

// {
//     id: 'All',
//     content: 'All',
//     title: 'All',
//     accessibilityLabel: 'All',
//     panelID: 'all-policies',
//     type: 'all',
// },

export const policylistTabs = [
    {
        id: 'All',
        content: 'All',
        title: 'All',
        panelID: 'all',
        type: 'all',
    },
    {
        id: 'Shipping',
        content: 'Shipping',
        title: 'Shipping',
        panelID: 'shipping-policies',
        type: 'shipping',
    },
    {
        id: 'Payment',
        content: 'Payment',
        title: 'Payment',
        panelID: 'payment-policies',
        type: 'payment'
    },
    {
        id: 'Return',
        content: 'Return',
        title: 'Return',
        panelID: 'Return',
        type: 'return'
    },
];

export function getTabSelectedFilter(type) {
    switch (type) {
        case 'uploaded': return { 'filter[uploaded][1]': 'yes' };
        case 'notuploaded': return { 'filter[uploaded][1]': 'no' };
        case 'ended': return { 'filter[ended][1]': 'yes' };
        case 'error': return { 'filter[hasError][1]': 'yes' };
        default: return {};
    }
}

export function extractValuesfromRequest(rows = [], defaultConfig = {}) {
    let modifiedRows = [];
    rows.forEach(row => {
        let { title, type, data } = row;
        if (data && data.hasOwnProperty("profileId")) {
            let { profileId } = data
            modifiedRows.push({
                id: profileId,
                type,
                name: { 'title': row, 'defaultConfig': defaultConfig },
                filtername: title
            });
        }
    });
    return modifiedRows;
}



export function attachCountTabTitle(tabs, type, rows) {
    let count = 0;
    if (type !== 'all') {
        rows.forEach(row => {
            if (row.type === type) count++;
        })
    }
    else {
        count = rows.length;
    }
    tabs.forEach((tab, index) => {
        if (tab.type === type) tabs[index].content = <p>{tabs[index].title} <Badge status={"info"}>{`${count}`}</Badge></p>
    })
    return tabs;
}

export function getTypeoftabs(tab) {
    return policylistTabs[tab]['type'];
}


export const filterCondition = [
    // { label: 'equals', value: "1" },
    // { label: 'not equals', value: "2" },
    {
        label: 'contains', value: "3"
    },
    // {
    //     label: 'does not contains', value: "4"
    // },
    // {
    //     label: 'starts with', value: "5"
    // },
    // {
    //     label: 'ends with', value: "6"
    // }
];


export const filterOptions = [
    {
        headerName: "Name", field: "name"
    },
];

export function extractValuesforPreviewModal(data) {
    let { name } = data;
    let { title } = name;
    console.log('title', title)
    let previewContent = {};
    let paymentDetails = {};
    let shippingDetails = {};
    let returnDetails = {};
    let type = title['type'];
    switch (type) {
        case "payment":
            paymentDetails['immediatePay'] = title['data']['paymentInfo']['immediatePay'];
            paymentDetails['paymentInstructions'] = title['data']['paymentInfo']['paymentInstructions'];
            paymentDetails['paypalEmailAddress'] = title['data']['paymentInfo']['paypalEmailAddress'];
            previewContent['paymentDetails'] = paymentDetails;
            break;
        case "shipping":
            shippingDetails['EligibleForPickupDropOff'] = title['data']['shippingPolicyInfo']['EligibleForPickupDropOff'];
            shippingDetails['GlobalShipping'] = title['data']['shippingPolicyInfo']['GlobalShipping'];
            shippingDetails['dispatchTimeMax'] = title['data']['shippingPolicyInfo']['dispatchTimeMax'];
            shippingDetails['domesticRateTable'] = title['data']['shippingPolicyInfo']['domesticRateTable'];
            shippingDetails['domesticShippingType'] = title['data']['shippingPolicyInfo']['domesticShippingType'];
            shippingDetails['intlRateTable'] = title['data']['shippingPolicyInfo']['intlRateTable'];
            shippingDetails['shippingPolicyCurrency'] = title['data']['shippingPolicyInfo']['shippingPolicyCurrency'];
            shippingDetails['shippingProfileDiscountInfo'] = {};
            let shippingProfileDiscountInfo = {};
            shippingProfileDiscountInfo['applyDomesticPromoShippingProfile'] = title['data']['shippingPolicyInfo']['shippingProfileDiscountInfo']['applyDomesticPromoShippingProfile'];
            shippingProfileDiscountInfo['applyIntlPromoShippingProfile'] = title['data']['shippingPolicyInfo']['shippingProfileDiscountInfo']['applyIntlPromoShippingProfile'];
            shippingProfileDiscountInfo['domesticFlatCalcDiscountProfileId'] = title['data']['shippingPolicyInfo']['shippingProfileDiscountInfo']['domesticFlatCalcDiscountProfileId'];
            shippingProfileDiscountInfo['intlFlatCalcDiscountProfileId'] = title['data']['shippingPolicyInfo']['shippingProfileDiscountInfo']['intlFlatCalcDiscountProfileId'];
            shippingDetails['shippingProfileDiscountInfo'] = shippingProfileDiscountInfo;

            previewContent['shippingDetails'] = shippingDetails;
            break;
        case "return":
            returnDetails['description'] = title['data']['returnPolicyInfo']['description'];
            returnDetails['refundOption'] = title['data']['returnPolicyInfo']['refundOption'];
            returnDetails['returnsAcceptedOption'] = title['data']['returnPolicyInfo']['returnsAcceptedOption'];
            returnDetails['returnsWithinOption'] = title['data']['returnPolicyInfo']['returnsWithinOption'];
            returnDetails['shippingCostPaidByOption'] = title['data']['returnPolicyInfo']['shippingCostPaidByOption'];

            previewContent['returnDetails'] = returnDetails;
            break;
        default:
            break;
    }

    previewContent['profileDesc'] = title['data']['profileDesc'];

    return previewContent;
}