import React, { Component } from 'react';
import {
    Button,
    Card,
    Collapsible,
    FooterHelp,
    Layout,
    Page,
    Stack,
    Badge,
    Heading,
    Tooltip,
    Modal,
    Select, Banner,
    TextContainer, TextField, Icon, Link, TextStyle, EmptyState
} from "@shopify/polaris";
import {
    EditMinor, AddMajorMonotone
} from '@shopify/polaris-icons';
import { requests } from "../../services/request";
import { isUndefined } from "util";
import { notify } from "../../services/notify";
import Skeleton from "../../shared/skeleton";
import ModalVideo from "react-modal-video";
import Grid from '../../Subcomponents/Aggrid/grid'
import { attachCountTabTitle, extractValuesforPreviewModal, extractValuesfromRequest, filterCondition, filterOptions, getTabSelectedFilter, getTypeoftabs, gridPropColumns, policylistTabs } from './BusinessPolicyHelper';
import { prepareChoiceoption } from '../../Subcomponents/Aggrid/gridHelper';
import { json } from '../../environments/static-json';
import LoadingOverlay from 'react-loading-overlay';
import ReactJson from 'react-json-view';
import CustomNoRowsOverlay from '../../Subcomponents/Aggrid/CustomNoRowsOverlay';

let gridApi = '';


const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');
let siteID = false;
let domain = [];
let deleteModalShow = false;
let deleteProfileId = '';
let deleteProfileIDKey = '';
let defaultConfig = {};
class NewBusinessPolicy extends Component {
    grid_loader = false;

    constructor(props) {
        super(props);
        this.state = {
            shipping_policy: {
                heading: 'Shipping Policy',
                options: false,
                show: false
            },
            payment_policy: {
                heading: 'Payment Policy',
                options: false,
                show: false
            },
            return_policy: {
                heading: 'Return Policy',
                options: false,
                show: false
            },

            // utkarsh
            tabs: policylistTabs,
            columnsAG: gridPropColumns(this.incellElement.bind(this)),
            rowsAG: [],
            selectedTab: 0,
            all_rows: [],
            filtersProps: { attributeoptions: [], filters: [], filterCondition: filterCondition },
            previewModal: false,
            fetchBusinessPolicyButtonLoader: false,
            deleteButtonLoader: false,
            jsonViewStructure: {},
            frameworkComponents: {
                customNoRowsOverlay: CustomNoRowsOverlay,
            },
            noRowsOverlayComponent: 'customNoRowsOverlay',
            noRowsOverlayComponentParams: {
                noRowsMessageFunc: () => <EmptyState heading="No Policy Found"
                // image="https://cdn.shopify.com/s/assets/admin/empty-states-fresh/emptystate-abandoncheckout-de95c7af243bfbc1a127a7bd1a6a9b7a5769ddc295a303268fdf26913f16801c.svg"
                >
            </EmptyState>,
            },
        };

    }

    renderDeletePolicyModal() {
        return (

            <Modal
                open={deleteModalShow}
                onClose={() => {
                    deleteModalShow = false;
                    deleteProfileId = '';
                    this.setState(this.state);
                }}
                title="Permission required"
            >
                <Modal.Section>
                    <TextContainer>
                        {
                            this.getDeleteModalContent()
                        }
                    </TextContainer>
                </Modal.Section>
            </Modal>

        );
    }

    renderPreviewModal() {
        let { previewModal, jsonViewStructure } = this.state;
        return (
            <Modal
                open={previewModal}
                onClose={() => {
                    this.setState({ previewModal: false })
                }}
                title="Profile Preview"
            >
                <Modal.Section>
                    <ReactJson src={jsonViewStructure} theme={"monokai"} />
                </Modal.Section>
            </Modal>

        );
    }
    async incellElement(field, data) {
        let { id: value, type: key } = data;
        console.log(field, data);
        key = key + '_policy';
        switch (field) {
            case 'preview':
                this.setState({
                    previewModal: true,
                    jsonViewStructure: data.name.title.data
                })
                break;
            case 'edit':
                let tempObj = { display: key, id: value.toString(), type: 'Business policy' }
                let message = cryptr.encrypt(JSON.stringify(tempObj));
                this.redirect('/panel/template/modifier?message=' + encodeURI(message));
                break;
            case 'delete':
                deleteProfileId = value.toString();
                deleteProfileIDKey = key;
                deleteModalShow = true;
                this.setState(this.state);
                break;
            default: break;
        }
    }

    video = { Modal: false, id: '' };

    textSearchValue = {
        shipping_policy: '',
        payment_policy: '',
        return_policy: '',
    };
    policy_options = {
        shipping_policy: [],
        payment_policy: [],
        return_policy: [],
    };

    componentDidMount() {
        this.prepareFilters();

        this.getAllGlobalConfig();
        this.getSideID();

        document.title = 'Edit an existing business policy or create new - CedCommerce';
        document.description = 'Business Policy section helps you to edit an existing business policy or you can create a new business policy (Shipping/Return/Payment) as per your choice.';

        if (!document.title.includes(localStorage.getItem('shop_url'))) {
            document.title += !isUndefined(localStorage.getItem('shop_url')) ? " " + localStorage.getItem('shop_url') : "";
        }
    }

    getAllGlobalConfig() {
        requests.getRequest('ebayV1/get/globalConfigData').then(data => {
            if (data.success) {
                defaultConfig = Object.assign({}, data.data);
                this.getBusinessPolicy();
            }
        });
    }

    getSideID() {
        requests.getRequest('ebayV1/get/siteId').then(data => {
            if (data.success) {
                siteID = !isUndefined(data.data.site_id) ? data.data.site_id : false;
                domain = json.country.filter(name => name.siteId === siteID)
            }
        });
        this.setState(this.state);
    }

    redirect(url) {

        this.props.history.push(url);
    }

    createDropdownData(data) {
        let return_dropdown_options = [];
        let payment_dropdown_options = [];
        let shipping_dropdown_options = [];
        data.forEach((obj, index) => {
            switch (obj.type) {
                case 'return':
                    if (!isUndefined(obj.data)) {
                        if (defaultConfig['return_policy'] && (obj.data.profileId).toString() === defaultConfig['return_policy']) {
                            return_dropdown_options.push(
                                { label: <React.Fragment>{obj.data.profileName}<Badge status={"attention"}>Default</Badge></React.Fragment>, value: (obj.data.profileId).toString(), default: true, textValue: obj.data.profileName }
                            );
                        } else {
                            return_dropdown_options.push(
                                { label: obj.data.profileName, value: (obj.data.profileId).toString(), default: false }
                            );
                        }
                    }
                    break
                case 'payment':
                    if (!isUndefined(obj.data)) {
                        if (defaultConfig['payment_policy'] && (obj.data.profileId).toString() === defaultConfig['payment_policy']) {
                            payment_dropdown_options.push(
                                { label: <React.Fragment>{obj.data.profileName}<Badge status={"attention"}>Default</Badge></React.Fragment>, value: (obj.data.profileId).toString(), default: true, textValue: obj.data.profileName }
                            );
                        } else {
                            payment_dropdown_options.push(
                                { label: obj.data.profileName, value: (obj.data.profileId).toString(), default: false }
                            );
                        }
                    }
                    break;
                case 'shipping':
                    if (!isUndefined(obj.data)) {
                        if (defaultConfig['shipping_policy'] && (obj.data.profileId).toString() === defaultConfig['shipping_policy']) {
                            shipping_dropdown_options.push(
                                { label: <React.Fragment>{obj.data.profileName}<Badge status={"attention"}>Default</Badge></React.Fragment>, value: (obj.data.profileId).toString(), default: true, textValue: obj.data.profileName }
                            );
                        } else {
                            shipping_dropdown_options.push(
                                { label: obj.data.profileName, value: (obj.data.profileId).toString(), default: false }
                            );
                        }
                    }
                    break;

            }
        });
        if (return_dropdown_options.length !== 0) {
            this.state.return_policy.options = return_dropdown_options;
            this.policy_options.return_policy = return_dropdown_options;
        } else {
            this.state.return_policy.options = false;
            this.policy_options.return_policy = [];
        }
        if (payment_dropdown_options.length !== 0) {
            this.state.payment_policy.options = payment_dropdown_options;
            this.policy_options.payment_policy = payment_dropdown_options;
        }
        else {
            this.state.payment_policy.options = false;
            this.policy_options.payment_policy = [];
        }
        if (shipping_dropdown_options.length !== 0) {
            this.state.shipping_policy.options = shipping_dropdown_options;
            this.policy_options.shipping_policy = shipping_dropdown_options;
        } else {
            this.state.shipping_policy.options = false;
            this.policy_options.shipping_policy = [];
        }
        this.skeleton_Check = false;
        this.setState(this.state, () => {
            // console.log('object', this.state)
        });
    }

    getBusinessPolicy() {
        this.grid_loader = true;
        this.updateState();
        requests.postRequest('ebayV1/template/get', { multitype: ['shipping', 'payment', 'return'] }).then(data => {
            if (data.success) {
                // this.createDropdownData(data.data);
                let { tabs } = this.state;

                let rows = data.data;
                let extractRowData = extractValuesfromRequest(rows, defaultConfig);
                tabs = [...attachCountTabTitle(tabs, 'all', extractRowData)];
                tabs = [...attachCountTabTitle(tabs, 'shipping', extractRowData)];
                tabs = [...attachCountTabTitle(tabs, 'payment', extractRowData)];
                tabs = [...attachCountTabTitle(tabs, 'return', extractRowData)];
                this.setState({ all_rows: [...extractRowData], rowsAG: [...extractRowData], tabs, selectedTab: 0 }, () => {
                    this.tabSelected(0)
                });
                this.skeleton_Check = false;
                this.setState(this.state)
                this.grid_loader = false;
                this.updateState();
            }
        })
    }

    resetModalDefaults() {
        deleteModalShow = false;
        deleteProfileIDKey = '';
        deleteProfileId = '';
        this.setState(this.state);
    }

    actionPerform(action, key, value) {
        switch (action) {
            case 'edit':
                let tempObj = { display: key, id: value, type: 'Business policy' }
                let message = cryptr.encrypt(JSON.stringify(tempObj));
                this.redirect('/panel/template/modifier?message=' + encodeURI(message));
                break;
            case 'delete':
                this.setState({ deleteButtonLoader: true })
                requests.getRequest('ebayV1/delete/businessPolicy', { profile_id: value }).then(data => {
                    if (data.success) {
                        notify.success(data.message);
                    } else {
                        notify.error(data.message);
                    }
                    this.resetModalDefaults();
                    this.getBusinessPolicy();
                    this.setState({ deleteButtonLoader: false })
                });

                break;
        }

    }

    getDeleteModalContent() {

        let tempArr = [];
        let { deleteButtonLoader } = this.state;
        if (defaultConfig[deleteProfileIDKey] && defaultConfig[deleteProfileIDKey] === deleteProfileId) {
            tempArr.push(
                <Stack vertical={true} alignment={"center"} distribution={"center"}>
                    <p className="text-center">
                        Selected policy is a <b>Default {this.state[deleteProfileIDKey].heading}</b>, Delete operation is not allowed for a default policy.
                    </p>
                    <p className="text-center">For enabling delete operation , set another policy as <b>Default {this.state[deleteProfileIDKey].heading}</b> from the <b>Configurfation section</b> and retry.</p>
                    <Button primary={true} loading={deleteButtonLoader} disabled={true} onClick={
                        this.actionPerform.bind(this, 'delete', deleteProfileIDKey, deleteProfileId)
                    }>
                        Yes
                    </Button>
                </Stack>
            )
        }
        else {
            tempArr.push(
                <Stack vertical={true} alignment={"center"}>
                    <p>
                        Are you sure, you want to delete this {this.state[deleteProfileIDKey].heading}?
                    </p>
                    <Button primary={true} loading={deleteButtonLoader} onClick={
                        this.actionPerform.bind(this, 'delete', deleteProfileIDKey, deleteProfileId)
                    }>
                        Yes
                    </Button>
                </Stack>
            )
        }

        return tempArr;
    }

    handleSearchProfile(key, value) {
        this.textSearchValue[key] = value;
        this.updateState();
        this.filterOptions(key, value);
    }

    updateState() {
        const state = this.state;
        this.setState(state);
    }

    filterOptions(key, search) {
        let temparr = [];
        if (this.state[key].options) {
            if (search !== '') {
                this.policy_options[key].forEach((option, index) => {
                    if (option.default === false && ((option.label).toLowerCase()).includes(search.toLowerCase())) {
                        temparr.push(option);
                    } else {
                        if (option.default && ((option.textValue).toLowerCase()).includes(search.toLowerCase())) {
                            temparr.push(option);
                        }
                    }
                })
            } else {
                temparr = this.policy_options[key];
            }
        }
        if (temparr.length === 0) {
            if (this.policy_options[key].length !== 0) {
                this.state[key].options = [];
            } else {
                this.state[key].options = false;
            }
        } else {
            this.state[key].options = temparr.slice(0);
        }
    }

    skeleton_Check = true;


    // utkarsh
    filterTabProducts() {
        let { selectedTab, all_rows, rowsAG } = this.state;
        let getType = getTypeoftabs(selectedTab);
        // let rows;
        if (getType !== 'all') {
            rowsAG = all_rows.filter(data => data.type === getType);
        } else {
            rowsAG = all_rows.slice(0);
        }
        this.setState({ rowsAG });
    }

    prepareFilters() {
        let { filtersProps } = this.state;
        filtersProps['attributeoptions'] = [...prepareChoiceoption(filterOptions, 'headerName', "field")];
        this.setState({ filtersProps });
    }

    getGridApi(api) {
        gridApi = api;
    }

    tabSelected(tabs) {
        this.setState({ selectedTab: tabs }, () => {
            this.filterTabProducts();
        });
    }

    newRenderPolicy() {
        let { columnsAG, rowsAG, tabs, selectedTab, filtersProps } = this.state;

        return (
            <LoadingOverlay
                active={this.grid_loader}
                spinner
                text='Loading please wait...'
            >
                <Grid
                    tag={'Business Policy(s)'}
                    showTabs={true}
                    tabs={tabs}
                    selectedTab={selectedTab}
                    tabSelected={this.tabSelected.bind(this)}
                    columns={columnsAG}
                    rows={rowsAG}
                    // showFilters
                    // customRowHeight={80}
                    // filterData={this.filterData.bind(this)}
                    // filtersProps={filtersProps}
                    // selectedActions={selectedActions}
                    // onSelectAction={this.onSelectedAction.bind(this)}
                    getGridApi={this.getGridApi.bind(this)}
                    // paginationProps={paginationProps}
                    // onpaginationChange={this.onPaginationChange.bind(this)}
                    // suppressSizeToFit={true}
                    suppressMovableColumns={true}
                    suppressRowClickSelection={true}
                    enableCellTextSelection={true}
                    rowSelection={"multiple"}
                    // selectedRows={selectedRows}
                    // cellClickedEvent={this.cellClickedEvent.bind(this)}

                    // rowSelected={this.getSelectedRows.bind(this)}
                    frameworkComponents={this.state.frameworkComponents}
                    noRowsOverlayComponent={this.state.noRowsOverlayComponent}
                    noRowsOverlayComponentParams={
                        this.state.noRowsOverlayComponentParams
                    }
                />
            </LoadingOverlay>
        )
    }
    render() {
        let { previewModal, rowsAG, fetchBusinessPolicyButtonLoader } = this.state;
        return (
            <Page
                fullWidth={true}
                primaryAction={{ content: 'Fetch Business Policies', onAction: this.importBusinessPolicies.bind(this), loading: fetchBusinessPolicyButtonLoader }}
                actionGroups={[
                    {
                        title: 'Add policies',
                        icon: AddMajorMonotone,
                        actions: [
                            {
                                content: 'Payment',
                                icon: AddMajorMonotone,
                                onAction: () => {
                                    let key = 'payment_policy';
                                    let tempObj = { display: key, type: 'Business policy' }
                                    let message = cryptr.encrypt(JSON.stringify(tempObj));
                                    this.redirect('/panel/template/modifier?message=' + encodeURI(message));
                                }
                            },
                            {
                                content: 'Return',
                                icon: AddMajorMonotone,
                                onAction: () => {
                                    let key = 'return_policy';
                                    let tempObj = { display: key, type: 'Business policy' }
                                    let message = cryptr.encrypt(JSON.stringify(tempObj))
                                    this.redirect('/panel/template/modifier?message=' + encodeURI(message));
                                }
                            },
                            {
                                content: 'Shipping',
                                icon: AddMajorMonotone,
                                onAction: () => {
                                    let key = 'shipping_policy';
                                    let tempObj = { display: key, type: 'Business policy' }
                                    let message = cryptr.encrypt(JSON.stringify(tempObj));
                                    this.redirect('/panel/template/modifier?message=' + encodeURI(message));
                                }
                            }
                        ],
                    }
                ]}
                titleMetadata={<Stack vertical={false}><p style={{ cursor: 'pointer' }} onClick={() => {
                    window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=bsns-policies', '_blank')
                }}><Badge status={"info"}><b style={{ color: '#0000aa', textDecoration: 'underline' }}>Need help?</b></Badge></p>
                    {/* <p style={{ color: '#3B7DC4', textDecoration: 'underline', cursor: 'pointer' }} onClick={this.openvideoModal.bind(this, 'cw2MiFRBAqY')}><Badge status={"info"}><b style={{ color: '#0000aa', textDecoration: 'underline' }}>Help Video?</b></Badge></p> */}
                </Stack>}
                title={'Business Policy'}>
                <Banner status={"info"}>
                    <p className="text-justify"><b>Business policies</b> let your buyers know how they can pay you, how long it will take you to ship an item, the delivery services you offer - including shipping and packaging costs - and whether you accept returns.So instead of applying the same on each listing you can simply create policies and apply it on multiple listing.</p>
                </Banner>
                {domain.length > 0 && domain[0].hasOwnProperty('domainName') && <Banner status="info">You can create business policy directly on eBay seller panel <Link url={`https://www.bizpolicy.ebay${domain[0]['domainName']}/businesspolicy/manage`} external><TextStyle variation="strong">Click Here</TextStyle></Link></Banner>}
                <br />
                {
                    // (this.skeleton_Check)
                    // ? <Skeleton case="businesspolicy" /> : 
                    // ? <Skeleton case="newbusinesspolicy" /> : 
                    // && 
                    // siteID &&
                    this.newRenderPolicy()
                    // this.renderPOlicy()
                }
                <Stack distribution="center">
                 <FooterHelp>
    Learn more about{' '}
    <Link external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=bsns-policies">
    Business Policy
    </Link>
  </FooterHelp>
  </Stack>
                {deleteModalShow && this.renderDeletePolicyModal()}
                {previewModal && this.renderPreviewModal()}
                <ModalVideo channel='youtube' isOpen={this.video.Modal} videoId={this.video.id} onClose={this.closevideoModal.bind(this)} />
            </Page>
        );
    }

    openvideoModal(id) {
        this.video.Modal = true;
        this.video.id = id;
        this.setState(this.state);
    }

    closevideoModal() {
        this.video.Modal = false;
        this.video.id = '';
        this.setState(this.state);
    }
    importBusinessPolicies() {
        let { fetchBusinessPolicyButtonLoader } = this.state;
        fetchBusinessPolicyButtonLoader = true;
        this.setState({ fetchBusinessPolicyButtonLoader })
        requests.getRequest('ebayV1/import/businessPolicies').then(data => {
            if (data.success) {
                notify.success(data.message);
                this.getAllGlobalConfig();
            }
            else {
                notify.error(data.message);
            }
            fetchBusinessPolicyButtonLoader = false;
            this.setState({ fetchBusinessPolicyButtonLoader })

        });
    }

}

export default NewBusinessPolicy;
