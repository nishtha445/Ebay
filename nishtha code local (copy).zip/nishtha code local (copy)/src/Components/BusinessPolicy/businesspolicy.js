import React, {Component} from 'react';
import {
    Button,
    Card,
    Collapsible,
    Layout,
    Page,
    Stack,
    Badge,
    Heading,
    Tooltip,
    Modal,
    Select, Banner,
    TextContainer, TextField, Icon
} from "@shopify/polaris";
import {
    EditMinor
} from '@shopify/polaris-icons';
import {requests} from "../../services/request";
import {isUndefined} from "util";
import {notify} from "../../services/notify";
import Skeleton from "../../shared/skeleton";
import ModalVideo from "react-modal-video";


const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');
let siteID=false;
let deleteModalShow=false;
let deleteProfileId='';
let deleteProfileIDKey='';
let defaultConfig={};
class BusinessPolicy extends Component {

    constructor(props){
        super(props);
        this.state={
            shipping_policy:{
                heading:'Shipping Policy',
                options:false,
                show:false
            },
            payment_policy:{
                heading:'Payment Policy',
                options:false,
                show:false
            },
            return_policy:{
                heading:'Return Policy',
                options:false,
                show:false
            },

        };

    }

    video={Modal:false,id:''};

    textSearchValue={
        shipping_policy:'',
        payment_policy:'',
        return_policy:'',
    };
    policy_options={
        shipping_policy:[],
        payment_policy:[],
        return_policy: [],
    };

    componentDidMount(){

        this.getAllGlobalConfig();
        this.getSideID();

        document.title='Edit an existing business policy or create new - CedCommerce';
        document.description='Business Policy section helps you to edit an existing business policy or you can create a new business policy (Shipping/Return/Payment) as per your choice.';

        if(!document.title.includes(localStorage.getItem('shop_url'))) {
            document.title += !isUndefined(localStorage.getItem('shop_url')) ? " " + localStorage.getItem('shop_url') : "";
        }
    }

    getAllGlobalConfig(){
        requests.getRequest('ebayV1/get/globalConfigData').then(data => {
            if(data.success){
                defaultConfig=Object.assign({},data.data);
                this.getBusinessPolicy();
            }
        });
    }

    getSideID() {
        requests.getRequest('ebayV1/get/siteId').then(data => {
            if (data.success) {
                siteID = !isUndefined(data.data.site_id) ? data.data.site_id : false;
                // siteID ='MOTORS';
            }
        });
        this.setState(this.state);
    }

    getProfiles(key){
        let temparr=[];
        if( this.state[key].options){
            this.state[key].options.forEach((value,index)=>{
                temparr.push(
                    <Card.Section key={'Options'+index}>
                        <Stack spacing={"loose"}>
                            <Stack.Item fill>
                                <p style={{cursor:'pointer'}} onClick={this.actionPerform.bind(this,'edit',key,this.state[key].options[index].value)}>
                                    {
                                        this.state[key].options[index].label
                                    }
                                </p>
                            </Stack.Item>
                            <Tooltip content={'Edit'}><Button  plain={true}  icon={EditMinor} size={"slim"} primary onClick={this.actionPerform.bind(this,'edit',key,this.state[key].options[index].value)}/></Tooltip>

                            <Tooltip content={'Delete'}><Button plain={true} icon={"delete"} size={"slim"} destructive onClick={()=>{
                                deleteProfileId=this.state[key].options[index].value;
                                deleteProfileIDKey=key;
                                deleteModalShow=true;
                                this.setState(this.state);
                                // this.actionPerform.bind(this,'delete',key,this.state[key].options[index].value)
                            }}/></Tooltip>

                        </Stack>
                    </Card.Section>
                )
            });
        }
        return temparr;
    }

    handleToggleClick = (Key) => {
        this.state[Key].show=!this.state[Key].show;
        this.textSearchValue[Key]='';
        this.setState(this.state);
        this.handleSearchProfile(Key,'');

    };

    redirect(url){

        this.props.history.push(url);
    }

    createDropdownData(data){
        let return_dropdown_options=[];
        let payment_dropdown_options=[];
        let shipping_dropdown_options=[];
        data.forEach((obj,index)=>{
            switch (obj.type) {
                case 'return':
                    if(!isUndefined(obj.data))
                    {
                        if(defaultConfig['return_policy'] && (obj.data.profileId).toString()===defaultConfig['return_policy']){
                            return_dropdown_options.push(
                                {label:<React.Fragment>{obj.data.profileName}<Badge status={"attention"}>Default</Badge></React.Fragment>, value: (obj.data.profileId).toString(),  default:true ,textValue:obj.data.profileName}
                            );
                        }else {
                            return_dropdown_options.push(
                                {label: obj.data.profileName, value: (obj.data.profileId).toString(), default:false}
                            );
                        }
                    }
                    break
                case 'payment':
                    if(!isUndefined(obj.data))
                    {
                        if(defaultConfig['payment_policy'] && (obj.data.profileId).toString()===defaultConfig['payment_policy']){
                            payment_dropdown_options.push(
                                {label:<React.Fragment>{obj.data.profileName}<Badge status={"attention"}>Default</Badge></React.Fragment>, value: (obj.data.profileId).toString(), default:true ,textValue:obj.data.profileName}
                            );
                        }else {
                            payment_dropdown_options.push(
                                {label: obj.data.profileName, value: (obj.data.profileId).toString(), default:false}
                            );
                        }
                    }
                    break;
                case 'shipping':
                    if(!isUndefined(obj.data))
                    {
                        if(defaultConfig['shipping_policy'] && (obj.data.profileId).toString()===defaultConfig['shipping_policy']){
                            shipping_dropdown_options.push(
                                {label:<React.Fragment>{obj.data.profileName}<Badge status={"attention"}>Default</Badge></React.Fragment>, value: (obj.data.profileId).toString(), default:true ,textValue:obj.data.profileName}
                            );
                        }else {
                            shipping_dropdown_options.push(
                                {label: obj.data.profileName, value: (obj.data.profileId).toString(), default:false }
                            );
                        }
                    }
                    break;

            }
        });
        if(return_dropdown_options.length!==0){
            this.state.return_policy.options=return_dropdown_options;
            this.policy_options.return_policy=return_dropdown_options;
        }else{
            this.state.return_policy.options=false;
            this.policy_options.return_policy=[];
        }
        if(payment_dropdown_options.length!==0){
            this.state.payment_policy.options=payment_dropdown_options;
            this.policy_options.payment_policy=payment_dropdown_options;
        }
        else{
            this.state.payment_policy.options=false;
            this.policy_options.payment_policy=[];
        }
        if(shipping_dropdown_options.length!==0){
            this.state.shipping_policy.options=shipping_dropdown_options;
            this.policy_options.shipping_policy=shipping_dropdown_options;
        }else{
            this.state.shipping_policy.options=false;
            this.policy_options.shipping_policy=[];
        }
        this.skeleton_Check=false;
        this.setState(this.state);
    }

    getBusinessPolicy(){
      requests.postRequest('ebayV1/template/get',{multitype:['shipping','payment','return']}).then(data => {
            if(data.success){
                this.createDropdownData(data.data);
            }
        })
    }

    resetModalDefaults(){
        deleteModalShow=false;
        deleteProfileIDKey='';
        deleteProfileId='';
        this.setState(this.state);
    }

    getDeleteModalContent(){

        let tempArr=[];
        if(defaultConfig[deleteProfileIDKey] && defaultConfig[deleteProfileIDKey]=== deleteProfileId ){
            tempArr.push(
                <Stack vertical={true} alignment={"center"} distribution={"center"}>
                    <p className="text-center">
                        Selected policy is a <b>Default {this.state[deleteProfileIDKey].heading}</b>, Delete operation is not allowed for a default policy.
                    </p>
                    <p className="text-center">For enabling delete operation , set another policy as <b>Default {this.state[deleteProfileIDKey].heading}</b> from the <b>Configuration section</b> and retry.</p>
                    <Button primary={true} disabled={true} onClick={
                        this.actionPerform.bind(this, 'delete', deleteProfileIDKey, deleteProfileId)
                    }>
                        Yes
                    </Button>
                </Stack>
            )
        }
        else {
            tempArr.push(
                <Stack vertical={true} alignment={"center"}>
                    <p>
                        Are you sure, you want to delete this {this.state[deleteProfileIDKey].heading}?
                    </p>
                    <Button primary={true} onClick={
                        this.actionPerform.bind(this, 'delete', deleteProfileIDKey, deleteProfileId)
                    }>
                        Yes
                    </Button>
                </Stack>
            )
        }

        return tempArr;
    }

    renderDeletePolicyModal() {
        return (

            <Modal
                open={deleteModalShow}
                onClose={() => {
                    deleteModalShow=false;
                    deleteProfileId='';
                    this.setState(this.state);
                }}
                title="Permission required"
            >
                <Modal.Section>
                    <TextContainer>
                        {
                            this.getDeleteModalContent()
                        }
                        {/*<Stack vertical={true} alignment={"center"}>*/}
                        {/*<p>*/}
                        {/*Are you sure, you want to delete this {this.state[deleteProfileIDKey].heading}?*/}
                        {/*</p>*/}
                        {/*<Button primary={true} onClick={*/}
                        {/*this.actionPerform.bind(this,'delete',deleteProfileIDKey,deleteProfileId)*/}
                        {/*}>*/}
                        {/*Yes*/}
                        {/*</Button>*/}
                        {/*</Stack>*/}
                    </TextContainer>
                </Modal.Section>
            </Modal>

        );
    }


    actionPerform(action,key,value){

        switch(action){
            case 'edit':
                let tempObj={display:key,id:value,type:'Business policy'}
                let message=cryptr.encrypt(JSON.stringify(tempObj));
                this.redirect('/panel/template/modifier?message='+encodeURI(message));
                break;
            case 'delete':
                requests.getRequest('ebayV1/delete/businessPolicy',{profile_id:value}).then(data=>{
                    if(data.success){
                        notify.success(data.message);
                    }else{
                        notify.error(data.message);
                    }
                    this.resetModalDefaults();
                    this.getBusinessPolicy();
                });

                break;
        }

    }

    handleSearchProfile(key,value){
        this.textSearchValue[key]=value;
        this.updateState();
        this.filterOptions(key,value);
    }

    updateState() {
        const state = this.state;
        this.setState(state);
    }

    filterOptions(key,search) {
        console.log(key, search);
        let temparr = [];
        if (this.state[key].options) {
            if (search !== '') {
                this.policy_options[key].forEach((option, index) => {
                    // console.log('option', option);
                    if (option.default === false && ((option.label).toLowerCase()).includes(search.toLowerCase())) {
                        temparr.push(option);
                    } else {
                        if (option.default && ((option.textValue).toLowerCase()).includes(search.toLowerCase())) {
                            temparr.push(option);
                        }
                    }
                    console.log('temparr',temparr);
                })
            } else {
                temparr = this.policy_options[key];
            }
        }
        if (temparr.length === 0) {
            if(this.policy_options[key].length!==0){
                this.state[key].options=[];
            }else{
                this.state[key].options=false;
            }
        } else {
            this.state[key].options = temparr.slice(0);
        }
    }

    renderPOlicy(){
        let temparr=[];
        // console.log(this.state);
        Object.keys(this.state).map(key=>{
            // if(siteID !== 'MOTORS') {
                temparr.push(
                    <Card key={'card-' + key}>
                        <Card.Section>
                            <div style={{cursor: 'pointer'}} onClick={this.handleToggleClick.bind(this, key)}
                                 aria-expanded={this.state[key].show}>
                                <Stack distribution={"equalSpacing"}>
                                    <b>{this.state[key].heading} <Badge
                                        status="info">{this.state[key].options ? this.policy_options[key].length : '0'}</Badge></b>
                                    <Button plain icon={this.state[key].show ? "chevronDown" : "chevronRight"}/>
                                </Stack>
                            </div>
                        </Card.Section>
                        <Collapsible open={this.state[key].show} id={key}>
                            {this.state[key].options ?
                                <Card actions={[{
                                    content: 'Create new',
                                    onAction: this.createNew.bind(this, key)
                                }]}>
                                    <Card.Section>
                                        <TextField value={this.textSearchValue[key]} onChange={this.handleSearchProfile.bind(this,key)} placeholder={'Search...'}  prefix={<Icon color={"tealDark"} source={'search'}/>} />
                                    </Card.Section>
                                    <Card.Section>
                                        <div style={{maxHeight: 200, overflowY: 'scroll'}}>
                                            {
                                                this.getProfiles(key)
                                            }
                                        </div>
                                    </Card.Section>
                                </Card>

                                :
                                <Card>
                                    <Card.Section>
                                        <div style={{textAlign: 'center'}}>
                                            <img style={{cursor: 'pointer'}}
                                                 src={require('../../assets/img/createnew.png')}
                                                 onClick={this.createNew.bind(this, key)} height={30} width={30}/>
                                            <Heading>Create new</Heading>
                                        </div>
                                    </Card.Section>
                                </Card>
                            }
                        </Collapsible>
                    </Card>
                )
            // }else{
            //     if(key !== 'return_policy') {
            //         temparr.push(
            //             <Card key={'card-' + key}>
            //                 <Card.Section>
            //                     <div style={{cursor: 'pointer'}} onClick={this.handleToggleClick.bind(this, key)}
            //                          aria-expanded={this.state[key].show}>
            //                         <Stack distribution={"equalSpacing"}>
            //                             <b>{this.state[key].heading} <Badge
            //                                 status="info">{this.state[key].options ? this.state[key].options.length : '0'}</Badge></b>
            //                             <Button plain icon={this.state[key].show ? "chevronDown" : "chevronRight"}/>
            //                         </Stack>
            //                     </div>
            //                 </Card.Section>
            //                 <Collapsible open={this.state[key].show} id={key}>
            //                     {this.state[key].options ?
            //
            //                         <Card actions={[{
            //                             content: 'Create new',
            //                             onAction: this.createNew.bind(this, key)
            //                         }]}>
            //                             <Card.Section>
            //                                 <TextField value={this.textSearchValue[key]} onChange={this.handleSearchProfile.bind(this,key)} placeholder={'Search...'}  prefix={<Icon color={"tealDark"} source={'search'}/>} />
            //                             </Card.Section>
            //                             <Card.Section>
            //                                 <div style={{maxHeight: 200, overflowY: 'scroll'}}>
            //                                     {
            //                                         this.getProfiles(key)
            //                                     }
            //                                 </div>
            //                             </Card.Section>
            //                         </Card>
            //
            //                         :
            //                         <Card>
            //                             <Card.Section>
            //                                 <div style={{textAlign: 'center'}}>
            //                                     <img style={{cursor: 'pointer'}}
            //                                          src={require('../../assets/img/createnew.png')}
            //                                          onClick={this.createNew.bind(this, key)} height={30}
            //                                          width={30}/>
            //                                     <Heading>Create new</Heading>
            //                                 </div>
            //                             </Card.Section>
            //                         </Card>
            //                     }
            //                 </Collapsible>
            //             </Card>
            //         )
            //     }
            // }

        });

        return temparr;
    }
    skeleton_Check=true;
    render() {
        return (
            <Page
                fullWidth={true}
                primaryAction={{content:'Fetch Business Policies',onAction:this.importBusinessPolicies.bind(this)}}
                titleMetadata={<Stack vertical={false}><p style={{cursor:'pointer'}} onClick={()=>{
                  window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=bsns-policies','_blank')
                }}><Badge status={"info"}><b style={{color:'#0000aa', textDecoration:'underline'}}>Need help?</b></Badge></p>
                  <p style={{color:'#3B7DC4',textDecoration:'underline', cursor: 'pointer'}} onClick={this.openvideoModal.bind(this,'cw2MiFRBAqY')}><Badge status={"info"}><b style={{color:'#0000aa', textDecoration:'underline'}}>Help Video?</b></Badge></p>
                </Stack>}
                title={'Business Policy'}>
                <Banner status={"info"}>
                    <p className="text-justify"><b>Business policies</b> let your buyers know how they can pay you, how long it will take you to ship an item, the delivery services you offer - including shipping and packaging costs - and whether you accept returns.So instead of applying the same on each listing you can simply create policies and apply it on multiple listing.</p>
                </Banner>
                <br/>
                { (this.skeleton_Check)?<Skeleton case="businesspolicy"/>:siteID && this.renderPOlicy()}
                {deleteModalShow && this.renderDeletePolicyModal()}
              <ModalVideo channel='youtube' isOpen={this.video.Modal} videoId={this.video.id}  onClose={this.closevideoModal.bind(this)} />
            </Page>
        );
    }

    openvideoModal(id){
        this.video.Modal=true;
        this.video.id=id;
        this.setState(this.state);
    }

    closevideoModal(){
        this.video.Modal=false;
        this.video.id='';
        this.setState(this.state);
    }
    importBusinessPolicies(){
        requests.getRequest('ebayV1/import/businessPolicies').then(data=>{
            if(data.success){
                notify.success(data.message);
                this.getAllGlobalConfig();
            }
            else{
                notify.error(data.message);
            }
        });
    }

    createNew(key){
        let tempObj={display:key,type:'Business policy'}
        let message=cryptr.encrypt(JSON.stringify(tempObj));
        this.redirect('/panel/template/modifier?message='+encodeURI(message));
    }
}

export default BusinessPolicy;
