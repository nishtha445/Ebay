import React, {Component} from 'react';
import {
  Button,
  Checkbox,
  Tooltip,
  EmptyState,
  Select,
  Modal,
  Page,
  Stack,
  Icon,
  Card,
  DatePicker,
  TextField,
  ChoiceList
} from "@shopify/polaris";
import Grid from "../../shared/react-data-grid/grid";
import Filter from "../../shared/react-data-grid/filter";
import {
  ViewMajorMonotone,DeleteMajorMonotone,PhoneMajorMonotone
} from '@shopify/polaris-icons';
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import {isUndefined} from "util";
const {
  DraggableHeader: { DraggableContainer }
} = require("react-data-grid-addons");

const fieldGroups = [
  {label:'DEFAULT',value:'DEFAULT'},
  {label:'SUMMARY',value:'SUMMARY'}
];
const inquiry_status = [
  {label:'CLOSED',value:'CLOSED'},
  {label:'CLOSED_WITH_ESCALATION',value:'CLOSED_WITH_ESCALATION'},
  {label:'CS_CLOSED',value:'CS_CLOSED'},
  {label:'OPEN',value:'OPEN'},
  {label:'OTHER',value:'OTHER'},
  {label:'PENDING',value:'PENDING'},
  {label:'WAITING_BUYER_RESPONSE',value:'WAITING_BUYER_RESPONSE'},
  {label:'WAITING_SELLER_RESPONSE',value:'WAITING_SELLER_RESPONSE'},
]

const defaultData = {
  width :50,
  filterable:true,
  editable: false,
  sortable: false,
  resizable: true,
  draggable: false,
  attachment:false

};
const defaultParams = {
  rowHeight:50,
  minHeight:window.innerHeight - 170,
  headerRowHeight:50,
  headerFiltersHeight:50,
  enableCellSelect:false,
};

class OrderEnquiry extends Component {

  filters = {
    column_filters: {}
  };
  gridSettings = {
    activePage: 1,
    count: 5
  };
  visibleColumns = ['date', 'subject','details','type','status','actions'];
  customButton = [];
  hideFilters= [];
  columnTitles = {

    date: {
      title: 'Date',
      sortable: true
    },
    subject: {
      title: 'Subject',
      sortable: true
    },
    details: {
      title: 'Details',
      sortable: true
    },
    type: {
      title: 'Type',
      sortable:true,
    },
    status: {
      title: 'Status',
      sortable:false,
    },
    actions: {
      title: 'Actions',
      sortable:false,
    }
  };
  column=[
    {
      key: "check",
      name: <Checkbox id={"all"}
                      checked={false}
                      onChange={this.allSelector.bind(this,'all_selector')}/>,
      frozen: true,
      editable: false,
      width: 50,
      sortable: false,
      draggable: false,
      filterable: false,
    },
    {
      key: "actions",
      name: "Actions",
      frozen: true,
      editable: false,
      width :250,
      filterable: false,
      sortable: false

    },
    {
      key: "date",
      name: "Date",
      frozen: false,
      editable: false,
      width :200,
      filterable: false,
      filterRenderer: Filter,
      sortable: false,

    },
    {
      key: "buyer",
      name: "Buyer",
      frozen: false,
      editable: false,
      width :250,
      filterRenderer: Filter,
      filterable: false,
      sortable: false,
      attachment:true

    },
    {
      key: "seller",
      name: "Seller",
      frozen: false,
      editable: false,
      width :250,
      filterable: false,
      sortable: false

    },
    {
      key: "item_id",
      name: "Item ID",
      frozen: false,
      editable: false,
      width :250,
      filterable: false,
      sortable: false

    },
    {
      key: "status",
      name: "Status",
      frozen: false,
      editable: false,
      width :250,
      filterable: false,
      sortable: false

    }

  ];
  constructor(props){
    super(props);
    this.state = {
      massAction : [
        {label: 'Check inquiry eligibility', value: 'inquiry_eligibile'}
      ],
      searchInquiry:{
        filter_on_basis:'',
        group:'DEFAULT',
        from:'',
        to:'',
        inquiry_status:'CLOSED',
        item_id:'',
        order_id:'',
        transaction_id:'',
        offset:'',
        date_from_to:{
          selected :{
            start:new Date(),
            end:new Date(),
          },
          month:(new Date()).getMonth(),
          year:(new Date()).getFullYear()
        },
      },
      send_message : {
        text: '',
      },
      escalate : {
        text: '',
        reason:''
      },
      shipment_info : {
        content: '',
        ship_carrier_name:'',
        tracking_no:'',
        ship_date:''
      },
      inquire_refund : {
        text: '',
      },
      refund_info : {
        text: '',
      },
      close_inquiry:{
        text:'',
        reason:''
      },
      massActionmodal :{
        check_inquiry_eligible:'Do you want to check this inquiry\'s eligibility',
      },
      action_selected:'',
      order_enquiries : [],
      modalOpen:false,
      rowIndexSelected:'',
      modaltype:'',
      checkbox:{ },
      pagination: {
        page: 1,
        totalNumberOfPages: 0,
        totalNumberOfProducts: 0,
        totalNumberOfItems: 0,
        pageSize: 25,
      },
      selected: 0,
      selectedTab:0,
      check:[],
      rows:[],
      appliedFilters: {},
      expandedRows: {},
      selectedIndexes: [],
      columns: this.column.map(c => ({...defaultData, ...c})),
      visibleColumns:{'check':1,'date':1,'buyer':1, 'seller':1,'item_id':1,'status':1,'actions':1},
      pagination_show:"",
      preparedFilter:{},
      rawData:[],
      toolbar_suffix:"Order enquiry"
    }
  }

  redirect(url, data) {
    this.props.history.push(url);
  }

  componentDidMount() {
  }

  fetchOrderEnquiryfetchOrderEnquiry(){
    requests
      .postRequest('ebayV1/upload/getInquiry',{inquiry_id:"123412312"}).then(data=>{
      console.log(data);
    })
  }
  resetModaldetails(){
    let type = this.state.modaltype;
    switch (type) {
      case 'search_inquiry':
        this.state.searchInquiry = {
          filter_on_basis: '',
          group: 'DEFAULT',
          from: '',
          to: '',
          inquiry_status: 'CLOSED',
          item_id: '',
          order_id: '',
          transaction_id: '',
          offset: '',
          date_from_to: {
            selected: {
              start: new Date(),
              end: new Date(),
            },
            month: (new Date()).getMonth(),
            year: (new Date()).getFullYear()
          },
        };
        break;
      case 'close_inquiry':
        this.state[type] = {
          text: '',
          reason: ''
        };
        this.state.rowIndexSelected = '';
        break;
      case 'inquiry_eligibile':
        break;
    }

    this.state.modalOpen = false;
    this.setState(this.state)

  }

  resetActiondetails(type){
    switch (type) {
      case 'send_message':
        this.state[type] = {
          text: ''
        };
        break;
      case 'escalate':
        this.state[type] = {
          text: '',
          reason: ''
        };
        break;
      case 'shipment_info':
        this.state[type] = {
          content: '',
          ship_carrier_name:'',
          tracking_no:'',
          ship_date:''
        };
        break;
      case 'inquire_refund':
        this.state[type] = {
          text:''
        };
        break;
      case 'refund_info':
        this.state[type] = {
          text:''
        };
        break;
      case 'close_inquiry':
        this.state[type] = {
          text:'',
          reason:''
        };
        break;
    }
    this.state.action_selected = '';
    this.state.rowIndexSelected = '';
    this.state.modalOpen = false;
    this.setState(this.state)
  }

  renderModal(){
    let type = this.state.modaltype;
    let tempObj= {title:''};
    switch (type) {
      case 'actions_active':
        tempObj.title = 'Perform actions';
        break;
      case 'search_inquiry':
        tempObj.title = 'Search Inquiry';
        break;
      case 'close_inquiry':
        tempObj.title = 'Close Inquiry';
        break;
      case 'inquiry_eligibile':
        tempObj.title = 'Inquiry eligibility';
        break;
    }
    return (
      <Modal
        title={tempObj.title}
        open={this.state.modalOpen}
        onClose={() => {
          this.resetModaldetails()
        }
        }
      >
        <Modal.Section >
          {
            this.renderForm(type)
          }
        </Modal.Section>
      </Modal>
    );
  }

  updateForm(form_type,form_field,value){
    this.state[form_type][form_field] = value;
    this.setState(this.state);
  }

  dateManagement(field,sub_field,extra_subfield =false,value,subvalue =false){
    if(extra_subfield) {
      this.state[field][sub_field][extra_subfield] = value;
      if(extra_subfield === 'month' && subvalue){
        this.state[field][sub_field]['year'] = subvalue
      }
    }else {
      this.state[field][sub_field] = value;
    }
    this.setState(this.state);
  }

  validationCheck(type){
    let error = 0 ;
    switch (type) {
      case 'search_inquiry':
        let tempObj = Object.assign({},this.state.searchInquiry);
        let dateObj = Object.assign({},tempObj['date_from_to']);
        tempObj.from = dateObj.selected.start;
        tempObj.to = dateObj.selected.end;
        if(tempObj.filter_on_basis === ''){
          error = 1;
        }else{
          switch(tempObj.filter_on_basis){
            case 'order_transaction_id':
              if(tempObj.order_id === '' || tempObj.transaction_id === ''  ) error=1;
              break;
            case 'field_groups':
              if(tempObj.group === '' ) error=1;
              break;
            case 'inquiry_status':
              if(tempObj.inquiry_status === '' ) error=1;
              break;
            case 'date_range':
              if(tempObj.from === '' || tempObj.to === ''  ) error=1;
              break;
            case 'item_id':
              if(tempObj.item_id === '' ) error=1;
              break;
          }
        }
        break;
    }
    if(error){
      notify.error('Kindly fill all the required fields');
    }
    return error;
  }


  performActions(action){
    switch(action){
      case 'send_message':
        this.sendMessage('send_message');
        break;
      case 'escalate':
        this.escalateMessage('escalate');
        break;
      case 'shipment_info':
        this.provideShipmentInfo('shipment_info');
        break;
      case 'inquire_refund':
        this.inquireRefund('inquire_refund');
        break;
      case 'refund_info':
        this.refundInfo('refund_info');
        break;
      case 'close_inquiry':
        this.closeInquiry('close_inquiry');
        break;
    }
  }

  sendMessage(type){
    requests.postRequest('ebayV1/upload/sendMessage',{inquiry_id:'2131231231',content:this.state[type]['text']}).then(data=>{
       if(data.success){
         notify.success(data.message);
       }else{
         notify.error(data.message);
       }
      this.resetActiondetails(type);
    });

  }
  provideShipmentInfo(type){
    requests.postRequest('ebayV1/upload/provideShipmentInfo',{...{inquiry_id:'2131231231'},...this.state.shipment_info}).then(data=>{
      if(data.success) {
        notify.success(data.message);
      }else{
        notify.error(data.message);
      }
      this.resetActiondetails(type);
    });

  }
  escalateMessage(type){
    requests.postRequest('ebayV1/upload/escalateInquiry',{inquiry_id:'2131231231',content:this.state[type]['text'],escalation_reason:this.state[type]['reason']}).then(data=>{
      if(data.success) {
        notify.success(data.message);
      }else{
        notify.error(data.message);
      }
      this.resetActiondetails(type);
    });

  }
  inquireRefund(type){
    requests.postRequest('ebayV1/upload/issueInquiryRefund',{inquiry_id:'2131231231',content:this.state[type]['text']}).then(data=>{
      if(data.success) {
        notify.success(data.message);
      }else{
        notify.error(data.message);
      }
      this.resetActiondetails(type);
    });
  }
  refundInfo(type) {
    requests.postRequest('ebayV1/upload/provideRefundInfo', {
      inquiry_id: '2131231231',
      content: this.state[type]['text']
    }).then(data => {
      if(data.success) {
        notify.success(data.message);
      }else{
        notify.error(data.message);
      }
      this.resetActiondetails(type);
    });
  }
  closeInquiry(type) {
    requests.postRequest('ebayV1/upload/closeInquiry', {
      inquiry_id: '2131231231',
      content: this.state[type]['text'],
      close_reason : this.state[type]['reason']
    }).then(data => {
      if(data.success) {
        notify.success(data.message);
      }else{
        notify.error(data.message);
      }
      this.resetModaldetails();
    });
  }

  renderForm(type){
    let temparr =[];
    switch(type){
      case 'search_inquiry':
        temparr.push(
          <Card primaryFooterAction={{content:'Search Inquiry',disabled:this.state.searchInquiry.filter_on_basis ==='' ,onAction:()=>{
              if(!this.validationCheck('search_inquiry')) {
                this.searchInquiry()
              }
            }}}>
            <Card.Section title={"Inquiry details"}>
              <Stack vertical={true} >
                <Select label={'Filter on basis of'} placeholder={'Please select...'} options={
                  [
                    {label:'Item-Transaction ID',value:'item_transaction_id'},
                    {label:'Field groups',value:'field_groups'},
                    {label:'Inquiry status',value:'inquiry_status'},
                    {label:'Date range',value:'date_range'},
                    {label:'Order ID',value:'order_id'},
                    {label:'All',value:'all'},
                  ]
                } value={this.state.searchInquiry.filter_on_basis}
                        onChange={(e)=>{
                          this.state.searchInquiry.filter_on_basis=e;
                          this.setState(this.state);
                        }}
                />
                <Stack.Item>
                  {this.state.searchInquiry.filter_on_basis === 'item_transaction_id' &&
                  <Stack vertical={false} distribution={"fillEvenly"} >
                    <TextField
                      label={'Transaction Id *'}
                      value={this.state.searchInquiry.transaction_id}
                      onChange={this.updateForm.bind(this, 'searchInquiry', 'transaction_id')}
                    />
                    <TextField
                      label={'Item Id *'}
                      value={this.state.searchInquiry.item_id}
                      onChange={this.updateForm.bind(this, 'searchInquiry', 'item_id')}
                    />
                  </Stack>
                  }
                  {this.state.searchInquiry.filter_on_basis === 'order_id' &&
                  <Stack vertical={false} distribution={"fillEvenly"}>
                    <TextField
                      label={'Order Id *'}
                      value={this.state.searchInquiry.order_id}
                      onChange={this.updateForm.bind(this, 'searchInquiry', 'order_id')}
                    />
                  </Stack>
                  }
                  <Stack vertical={false} distribution={"fillEvenly"}>
                    {this.state.searchInquiry.filter_on_basis === 'field_groups' &&
                    <Select
                      label={'Field Group *'}
                      options={fieldGroups}
                      onChange={this.updateForm.bind(this, 'searchInquiry', 'group')}
                      value={this.state.searchInquiry.group}
                    />
                    }
                    {this.state.searchInquiry.filter_on_basis === 'inquiry_status' &&
                    <Select
                      label={'Inquiry status *'}
                      options={inquiry_status}
                      onChange={this.updateForm.bind(this, 'searchInquiry', 'inquiry_status')}
                      value={this.state.searchInquiry.inquiry_status}
                    />
                    }
                    {this.state.searchInquiry.filter_on_basis === 'date_range' &&
                    <DatePicker month={this.state.searchInquiry.date_from_to.month}
                                year={this.state.searchInquiry.date_from_to.year}
                                onChange={this.dateManagement.bind(this, 'searchInquiry', 'date_from_to', 'selected')}
                                onMonthChange={this.dateManagement.bind(this, 'searchInquiry', 'date_from_to', 'month')}
                                selected={this.state.searchInquiry.date_from_to.selected} allowRange={true}/>
                    }
                  </Stack>
                </Stack.Item>
              </Stack>
            </Card.Section>
          </Card>
        );
        break;
      case 'actions_active':
        temparr.push(
          <Card primaryFooterAction={{content:'Perform action',onAction:this.performActions.bind(this,this.state.action_selected[0])}} >
            <Card.Section>
              <ChoiceList
                title="Choose an action"
                choices={[
                  {label: 'Send message', value: 'send_message'},
                  {label: 'Escalate', value: 'escalate'},
                  {label: 'Provide shipment info', value: 'shipment_info'},
                  {label: 'Issue inquire refund', value: 'inquire_refund'},
                  {label: 'Provide refund info', value: 'refund_info'},
                ]}
                selected={this.state.action_selected}
                onChange={(e) =>{this.setState({action_selected : e})}}
              />
            </Card.Section>
            <Card.Section title={this.state.action_selected[0]}>
              {
                this.state.action_selected[0] === 'send_message' &&
                <TextField placeholder={'Type your message here'} label={''} readOnly={false} onChange={this.updateForm.bind(this,'send_message','text')} value={this.state.send_message.text}/>
              }
              {
                this.state.action_selected[0] === 'escalate' &&
                <Stack vertical={false} distribution={"fillEvenly"}>
                  <TextField placeholder={'Type your message here'} label={''} readOnly={false} onChange={this.updateForm.bind(this,'escalate','text')} value={this.state.escalate.text}/>
                  <TextField placeholder={'Type escalation reason'} label={''} readOnly={false} onChange={this.updateForm.bind(this,'escalate','reason')} value={this.state.escalate.reason}/>
                </Stack>
              }
              {
                this.state.action_selected[0] === 'shipment_info' &&
                <Stack distribution={"fillEvenly"} vertical={true}>
                  <TextField placeholder={'Type your message here'} label={''} readOnly={false} onChange={this.updateForm.bind(this,'shipment_info','content')} value={this.state.shipment_info.content}/>
                  <TextField placeholder={'Tracking id'} label={''} readOnly={false} onChange={this.updateForm.bind(this,'shipment_info','tracking_no')} value={this.state.shipment_info.tracking_no}/>
                  <TextField placeholder={'Ship carrier name'} label={''} readOnly={false} onChange={this.updateForm.bind(this,'shipment_info','ship_carrier_name')} value={this.state.shipment_info.ship_carrier_name}/>
                  <TextField placeholder={'Type your message here'} type={"date"} label={''} readOnly={false} onChange={this.updateForm.bind(this,'shipment_info','ship_date')} value={this.state.shipment_info.ship_date}/>
                </Stack>
              }
              {
                this.state.action_selected[0] === 'inquire_refund' &&
                <TextField placeholder={'Type your message here'} label={''} readOnly={false} onChange={this.updateForm.bind(this,'inquire_refund','text')} value={this.state.inquire_refund.text}/>
              }
              {
                this.state.action_selected[0] === 'refund_info' &&
                <TextField placeholder={'Type your message here'} label={''} readOnly={false} onChange={this.updateForm.bind(this,'refund_info','text')} value={this.state.refund_info.text}/>
              }
            </Card.Section>
          </Card>
        );
        break;
      case 'close_inquiry':
        temparr.push(
          <Card  primaryFooterAction={{content:'Close inquiry',onAction:this.closeInquiry.bind(this,'close_inquiry')}}>
            <Card.Section>
              <Stack vertical={true} distribution={"fill"}>
                <TextField placeholder={'Type your message here'} label={'Message'} readOnly={false} onChange={this.updateForm.bind(this,'close_inquiry','text')} value={this.state.close_inquiry.text}/>
                <Select label={'Please choose a reason'} placeholder={'Select...'} onChange={this.updateForm.bind(this,'close_inquiry','reason')}
                        options={[
                          {label:'ITEM_ARRIVED',value:'ITEM_ARRIVED'},
                          {label:'OTHER',value:'OTHER'},
                          {label:'WORKED_OUT_WITH_SELLER',value:'WORKED_OUT_WITH_SELLER'},
                          {label:'WOULD_RATHER_KEEP_THE_ITEM',value:'WOULD_RATHER_KEEP_THE_ITEM'}
                        ]}
                        value={this.state.close_inquiry.reason}
                />
              </Stack>
            </Card.Section>
          </Card>
        )
        break;
      case 'inquiry_eligibile':
        temparr.push(
          <Stack vertical={true} alignment={"center"}>
            <Stack.Item>
              {this.state.massActionmodal.check_inquiry_eligible}
            </Stack.Item>
            <Stack.Item>
              <Button onClick={this.checkInquiryeligibility.bind(this)} primary={true}>Yes</Button>
            </Stack.Item>
          </Stack>
        )
        break;
    }
    return temparr;
  }

  checkInquiryeligibility(){
    let transaction_id ='asdasdasd';
    let item_id = '43654345';
    requests.postRequest('ebayV1/upload/checkInquiryEligibility',{transaction_id:transaction_id,item_id:item_id}).then(data=>{
      if(data.success){
        notify.success(data.message);
      }else{
        notify.error(data.message);
      }
      this.resetActiondetails('inquiry_eligibile');
    })
  }

  dataExtraction(type){
    let tempObj = Object.assign({},this.state[type]);
    let returnObj ={};
    switch (type) {
      case 'searchInquiry':
        let dateObj = Object.assign({},tempObj['date_from_to']);
        tempObj.from = dateObj.selected.start;
        tempObj.to = dateObj.selected.end;
        switch(tempObj.filter_on_basis){
          case 'item_transaction_id':
            returnObj['item_id'] = tempObj.item_id;
            returnObj['transaction_id'] = tempObj.transaction_id;
            break;
          case 'field_groups':
            returnObj['group'] = tempObj.group;
            break;
          case 'inquiry_status':
            returnObj['inquiry_status'] = tempObj.inquiry_status;
            break;
          case 'date_range':
            returnObj['from'] = tempObj.from;
            returnObj['to'] = tempObj.to;
            break;
          case 'order_id':
            returnObj['order_id'] = tempObj.order_id;
            break;
        }
        break;
    }
    return returnObj;
  }

  setRows(data){
    let temparr =[];
    let inquiries = data.rows;
    inquiries.forEach((inquiry,index)=>{
      temparr.push(
        {
          check:<div title={"checkbox"}> <Checkbox checked={(this.state.checkbox.hasOwnProperty(inquiry.inquiryId))}
                                                   label={inquiry.inquiryId}
                                                   id={inquiry.inquiryId}
                                                   onChange={this.handleChangeCheck}
                                                   labelHidden={true}/> </div>,
          actions:
            <div style={{padding:'5px'}}>
              <Stack alignment={"center"} distribution={"fillEvenly"} >
                {/*<Button plain={true}><Tooltip content={'View'}><Icon source={ViewMajorMonotone}/></Tooltip></Button>*/}
                <Button onClick={this.modalActivation.bind(this,'actions_active',index)} plain={true} ><Tooltip content={'Get Inquiry'}><Icon source={PhoneMajorMonotone}/></Tooltip></Button>
                <Button onClick={this.modalActivation.bind(this,'close_inquiry',index)}   plain={true}><Tooltip content={'Delete'}><Icon source={DeleteMajorMonotone}/></Tooltip></Button>
              </Stack></div>
          ,
          date:inquiry.creationDate.value,
          buyer:inquiry.buyer,
          seller:inquiry.seller,
          item_id:inquiry.itemId,
          status:inquiry.inquiryStatusEnum,
        }
      );
    });
    this.state.pagination = {
      page: this.state.pagination.page,
      totalNumberOfItems : data.data.count,
      totalNumberOfPages : Math.ceil(data.data.count/this.state.pagination.pageSize),
      totalNumberOfProducts: 0,
      pageSize: this.state.pagination.pageSize,
    }
    this.state.rows = temparr.slice(0);
    this.setState(this.state);
  }

  searchInquiry(){
    let tempObj = this.dataExtraction('searchInquiry');
    tempObj['limit'] = this.state.pagination['pageSize'];
    tempObj['offset'] = this.state.pagination['page'];

    requests.postRequest('ebayV1/upload/searchInquiry',tempObj).then(data=>{
      if(data.success){
        if(!isUndefined(data.data) && data.data!==null ) {
          this.setRows(data.data);
        }
      }else{
        notify.info(data.message);
      }
    })
  }

  modalActivation(type,rowIndex = false){
    this.state.modaltype = type;
    this.state.modalOpen = true;
    if(rowIndex) {
      this.state.rowIndexSelected = rowIndex;
    }
    this.setState(this.state);
  }

  render() {
    return (
      <Page title={'Order Enquiry'} fullWidth={true} breadcrumbs={[{content: 'Orders', onAction:this.redirect.bind(this,'/panel/orders')}]}
            primaryAction={{content:'Search Inquiry',onAction:this.modalActivation.bind(this,'search_inquiry')}}
      >
        <Stack vertical={true}>
          <DraggableContainer onHeaderDrop={this.onHeaderDrop}>
            <Grid
              suffix={this.state.toolbar_suffix}
              columns={this.state.columns}
              rowGetter={i => this.state.rows[i]}
              rowsCount={this.state.rows.length}
              massAction={this.state.massAction}
              onGridRowsUpdated={this.onGridRowsUpdated}
              hideLoader={this.state.hideLoader}
              onAddFilter={filter => this.handleFilterChange(filter)}
              onClearFilters={(e) => {this.setState({appliedFilters:{}},()=>{ })}}
              onCheckCellIsEditable={(e) => {return this.onCheckCellIsEditable(e)}}
              onGridSort={(sortColumn, sortDirection) => this.sortRows(sortColumn, sortDirection)}
              getValidFilterValues={columnKey => this.getValidFilterValues(this.state.rows, columnKey)}
              getSubRowDetails={this.getSubRowDetails(this.state.expandedRows)}
              visibleColumns={this.state.visibleColumns}
              // onCellExpand={args => this.onCellExpand(args)}
              hideColumnToggleButton={true}
              filtercolumnSize={defaultParams}
              getCellClick={this.getCellClick}
              paginationProps={this.state.pagination}
              handlePagination={this.handlePagination}
              handleColumn={this.handleColumn}
              performMassAction={this.performMassAction}
              selected_count={Object.values(this.state.checkbox).length}
              rowSelection={{
                showCheckbox: false,
                enableShiftSelect: true,
                onRowsSelected: this.onRowsSelected,
                onRowsDeselected: this.onRowsDeselected,
                selectBy: {
                  indexes: this.state.selectedIndexes
                }
              }}
              emptyRowsView={this.EmptyRowsView}
            />
          </DraggableContainer>
        </Stack>
        {
          this.state.modalOpen && this.renderModal()
        }
      </Page>
    );
  }

  onGridRowsUpdated = ( fieldName, fromRow, toRow, updated ) => {
    // //console.log(fieldName, fromRow, toRow, updated);
    this.setState(state => {
      const rows = state.rows.slice();
      for (let i = fromRow; i <= toRow; i++) {
        rows[i] = { ...rows[i], ...updated };
      }
      return { rows };
    });
  };

  onHeaderDrop = (source, target) => {
    const stateCopy = Object.assign({}, this.state);
    const columnSourceIndex = this.state.columns.findIndex(
      i => i.key === source
    );
    const columnTargetIndex = this.state.columns.findIndex(
      i => i.key === target
    );

    stateCopy.columns.splice(
      columnTargetIndex,
      0,
      stateCopy.columns.splice(columnSourceIndex, 1)[0]
    );

    const emptyColumns = Object.assign({}, this.state, { columns: [] });
    this.setState(emptyColumns);

    const reorderedColumns = Object.assign({}, this.state, {
      columns: stateCopy.columns
    });
    this.setState(reorderedColumns);
  };

  allSelector(field,value){
    if(value){
      this.state.columns[0]['name']=(<Checkbox id={"all"}
                                               checked={true}
                                               onChange={this.allSelector.bind(this,'all_selector')}
      />)
      this.state.tempOrderData.map((e)=>{
        this.state.checkbox[e["source_order_id"]]=true;
      });
      this.updateState();
    }
    else
    {
      this.state.columns[0]['name']=(<Checkbox id={"all"}
                                               checked={false}
                                               onChange={this.allSelector.bind(this,'all_selector')}/>)
      this.state.tempOrderData.map((e)=>{
        if(e.source_order_id in this.state.checkbox){
          delete this.state.checkbox[e.source_order_id];
        }

      })
      if(Object.values(this.state.checkbox).length == 0){
        this.state.massAction = [];
      }
      this.updateState();
    }

  }

  handleChangeCheck = (value,e) => {
    if(value){
      this.state.checkbox[e]=value;
      let temp=0;
      this.state.tempOrderData.map((e)=> {
        if ((e.source_order_id in this.state.checkbox)) {
          temp+=1;
        }
      });
      this.state.massAction=[{label: 'Check inquiry eligibility', value: 'inquiry_eligibile'}];
      if(temp == Object.keys(this.state.tempOrderData).length && Object.keys(this.state.tempOrderData).length != 0 ){
        this.state.All_Selected=true;
      }
    }
    else{
      delete this.state.checkbox[e];
      this.state.All_Selected=false;
      if(Object.values(this.state.checkbox).length == 0){
        this.state.massAction = [];
      }
    }
    this.updateState();
    this.all_Selected();

  };

  all_Selected(){
    if(this.state.All_Selected){
      this.state.columns[0]['name']=(<Checkbox id={"all"}
                                               checked={true}
                                               onChange={this.allSelector.bind(this,'all_selector')}/>)
    }
    else{
      this.state.columns[0]['name']=(<Checkbox id={"all"}
                                               checked={false}
                                               onChange={this.allSelector.bind(this,'all_selector')}/>)
    }
    this.updateState();
  }
  updateState() {
    const state = this.state;
    this.setState(state);
  }
  getCellClick = (e) => {
    console.log(e);
  }

  // set the Drop down Filter Value here

  getValidFilterValues = (rows, columnId) => {
    let val = rows
      .map(r => r[columnId])
      .filter((item, i, a) => {
        return i === a.indexOf(item);
      });
    return val;
  };

  sortRows = ( sortColumn, sortDirection) => {
    // //console.log(sortColumn, sortDirection);
  };

  onCheckCellIsEditable = (event) => {
    // return false;
    let flag = true;
    if ( event.row.variants && event.column.key !== 'title' )
      flag = false;
    if ( event.row.type === 'child' && event.column.key === 'title' )
      flag = false;
    return flag;
  };

  onRowsSelected = rows => {
    // //console.log(rows);
    this.setState({
      selectedIndexes: this.state.selectedIndexes.concat(
        rows.map(r => r.rowIdx)
      )
    });
  };

  onRowsDeselected = rows => {
    // //console.log(rows);
    let rowIndexes = rows.map(r => r.rowIdx);
    this.setState({
      selectedIndexes: this.state.selectedIndexes.filter(
        i => rowIndexes.indexOf(i) === -1
      )
    });
  };

  handlePagination = (pageProps) => {
    this.setState({pagination:pageProps},() => {
      this.searchInquiry();
    });
  };

  handleColumn=(columnProps)=>{
    // //console.log(columnProps);
    this.setState({visibleColumns:columnProps},()=>{
      this.setVisibleColumns();
    })

  }

  performMassAction = (action) => {
    switch(action){
      case 'inquiry_eligibile':
        this.modalActivation('inquiry_eligibile');
        break;
    }
  }
  ;

  EmptyRowsView = () => {
    return (
      <EmptyState heading="No enquiry found"
                  action={{ content: 'Refresh' ,onAction:()=> {
                      this.setState({appliedFilters:{}});
                    }}}
                  image="https://cdn.shopify.com/s/assets/admin/empty-states-fresh/emptystate-abandoncheckout-de95c7af243bfbc1a127a7bd1a6a9b7a5769ddc295a303268fdf26913f16801c.svg">
      </EmptyState>
    );
  };

  getSubRowDetails = expandedRows1 => rowItem => {
    let { expandedRows } = this.state;
    const isExpanded = expandedRows && expandedRows[rowItem.id]
      ? expandedRows[rowItem.id]
      : false;
    return {
      group: rowItem.variants && rowItem.variants.length > 0,
      expanded: isExpanded,
      children: rowItem.variants,
      field: "title",
      treeDepth: rowItem.treeDepth || 0,
      siblingIndex: rowItem.siblingIndex,
      numberSiblings: rowItem.numberSiblings
    };
  };

  updateSubRowDetails(subRows, parentTreeDepth) {
    const treeDepth = parentTreeDepth || 0;
    subRows.forEach((sr, i) => {
      sr.treeDepth = treeDepth + 1;
      sr.siblingIndex = i;
      sr.numberSiblings = subRows.length;
    });
  }
}

export default OrderEnquiry;
