import React from 'react'
import { Modal, Banner, Card, Checkbox, Stack, Select, Thumbnail, Icon, Badge, Tooltip, TextStyle } from "@shopify/polaris";
import Notfound from "../../assets/img/notfound.png"
import {
    MinusMinor, AlertMinor
} from '@shopify/polaris-icons';
import { isUndefined } from 'util';

export let ebayId='';
export const orderlistTabs = [
    {
        id: 'Unfulfilled',
        content: 'Unfulfilled',
        title: 'Unfulfilled',
        accessibilityLabel: 'Unfulfilled',
        panelID: 'Unfulfilled',
        type: 'unfulfilled',
    },
    {
        id: 'Fulfilled',
        content: 'Fulfilled',
        title: 'Fulfilled',
        panelID: 'Fulfilled',
        type: 'fulfilled',
    },
    {
        id: 'Failed',
        content: 'Failed',
        title: 'Failed',
        panelID: 'Failed',
        type: 'failed'
    },
    {
        id: 'Cancelled',
        content: 'Cancelled',
        title: 'Cancelled',
        panelID: 'Cancelled',
        type: 'cancelled'
    },
];

function customerNameDetails(incellElement, params) {
    let row = params.data.customer_name.row;
    return row.client_details.name !== '' ? row.client_details.name :
        // <div title={'Not available'} className="w-100 text-center">
        <Icon source={MinusMinor} />
    {/* </div> */ }
}

function shopifyOrderNameDetails(incellElement, params) {
    let row = params.data.shopify_order_name.row;
    return (!isUndefined(row["shopify_order_name"])) ? <p>{row['shopify_order_name']}</p> : <div title={'Not available'} ><Icon source={MinusMinor} /></div>;
    // return (!isUndefined(row["shopify_order_name"])) ? <Stack vertical={true} spacing="extraTight"><p>{row['shopify_order_name']}</p><p> Order ID - {!isUndefined(row['target_order_id']) ? row['target_order_id'] : ""}</p></Stack> : <div title={'Not available'} ><Icon source={MinusMinor} /></div>
}

function shopifyOrderIDDetails(incellElement, params) {
    let row = params.data.shopify_order_name.row;
    return (!isUndefined(row["target_order_id"]) && row["target_order_id"] !== '') ? <p>{!isUndefined(row['target_order_id']) ? row['target_order_id'] : ""}</p>: <div title={'Not available'} ><Icon source={MinusMinor} /></div>
}

function getStatus(incellElement, status, params) {
    // console.log('object', params)
    let { errors } = params.value.row;
    switch (status) {
        case 'pendingShipment': return <div onClick={(e) => {
            // incellElement('fulfillment', errors);
            e.preventDefault();
        }}><Badge status={"info"} progress="partiallyComplete">Unfulfilled</Badge></div>; break;
        case 'canceled': return <div onClick={(e) => {
            // incellElement('fulfillment', errors);
            e.preventDefault();
        }}><Badge status={"warning"} progress="complete">Canceled</Badge></div>; break;
        case 'failed': return <div onClick={(e) => {
            incellElement('Failed', errors);
            ebayId=params.value.row.additional_data.OrderID
            e.preventDefault();
        }}><Badge status={"warning"} progress="complete">Failed</Badge></div>; break;
        case 'fulfilled': return <div onClick={(e) => {
            // incellElement('fulfillment', errors);
            e.preventDefault();
        }}><Badge status={"success"} progress="complete">Fulfilled</Badge></div>; break;
        case 'inProgress': return <div onClick={(e) => {
            // incellElement('fulfillment', errors);
            e.preventDefault();
        }}><Badge status={"attention"} progress="incomplete">Unfulfilled</Badge></div>; break;
        default: return <div onClick={(e) => {
            // incellElement('fulfillment', errors);
            e.preventDefault();
        }}><Badge status={"attention"} progress="partiallyComplete">{status}</Badge></div>
    }
};

function fulfillment(incellElement, params) {
    let row = params.data.fulfillment.row;
    if (row['source_order_id'] !== '' && row['target_order_id'] === '') {
        row['status'] = 'failed';
    }
    return getStatus(incellElement, row['status'], params)
}

function ebayOrderIdDetails(incellElement, params) {
    let { row } = params.value;
    // console.log('params', row);
    let { source_order_id } = row;
    return (
        <Tooltip content={"View Order"}>
            <div style={{ cursor: 'pointer' }} onClick={(e) => {
                incellElement('edit', row);
                e.preventDefault();
            }} onMouseOver={e => {
                e.target.style.textDecoration = 'underline';
            }} onMouseOut={e => {
                e.target.style.textDecoration = 'none';
            }}>
                <TextStyle variation="strong">{source_order_id}</TextStyle>
            </div>
        </Tooltip>
    )
}
export function gridPropColumns(incellElement = () => { }, innerWidth) {
    let deductedWidth = innerWidth;
    let ebayOrderIdDetailsWidth = deductedWidth/1.1;
    let shopifyOrderNameDetailsWidth = deductedWidth/2;
    let shopifyOrderIDDetailsWidth = deductedWidth/2;
    let fulfillmentWidth = deductedWidth/3;
    let customerNameDetailsWidth = deductedWidth/2;
    let importedAtWidth = deductedWidth/2;
    if(innerWidth >= 425) {
        deductedWidth = innerWidth - (innerWidth*15/100);
        ebayOrderIdDetailsWidth = deductedWidth/1.2;
        shopifyOrderNameDetailsWidth = deductedWidth/2;
        shopifyOrderIDDetailsWidth = deductedWidth/2;
        fulfillmentWidth = deductedWidth/3;
        customerNameDetailsWidth = deductedWidth/2;
        importedAtWidth = deductedWidth/2;
    }
    if(innerWidth >= 768) {
        deductedWidth = innerWidth - (innerWidth*15/100);
        ebayOrderIdDetailsWidth = deductedWidth/2;
        shopifyOrderNameDetailsWidth = deductedWidth/4;
        shopifyOrderIDDetailsWidth = deductedWidth/4;
        fulfillmentWidth = deductedWidth/5;
        customerNameDetailsWidth = deductedWidth/4;
        importedAtWidth = deductedWidth/3;
    } 
    if(innerWidth >= 1366) {
        deductedWidth = innerWidth - (innerWidth*15/100);
        ebayOrderIdDetailsWidth = deductedWidth/4;
        shopifyOrderNameDetailsWidth = deductedWidth/7;
        shopifyOrderIDDetailsWidth = deductedWidth/7;
        fulfillmentWidth = deductedWidth/8;
        customerNameDetailsWidth = deductedWidth/6;
        importedAtWidth = deductedWidth/6;
    }
    return [
        {
            headerName: "eBay order ID", field: "source_order_id",
            // cellRendererFramework: imageDetails.bind(this, incellElement.bind(this)),
            pinned: 'left', resizable: true, cellStyle: { 'white-space': 'normal' }, headerCheckboxSelection: true, checkboxSelection: true, autoHeight: true,
            cellRendererFramework: ebayOrderIdDetails.bind(this, incellElement.bind(this)),
            // width: 300
            width: ebayOrderIdDetailsWidth,
            resizable: true, 
        },
        {
            headerName: 'Shopify Order Name', field: 'shopify_order_name',
            cellRendererFramework: shopifyOrderNameDetails.bind(this, incellElement.bind(this)),
            // width: 180
            width: shopifyOrderNameDetailsWidth,
            resizable: true, 
        },
        {
            headerName: 'Shopify Order ID', field: 'shopify_order_name',
            cellRendererFramework: shopifyOrderIDDetails.bind(this, incellElement.bind(this)),
            // width: 350
            width: shopifyOrderIDDetailsWidth,
            resizable: true, 
        },
        {
            headerName: "Fulfillment", field: 'fulfillment',
            cellRendererFramework: fulfillment.bind(this, incellElement.bind(this)),
            // width: 300
            width: fulfillmentWidth,
            resizable: true, 
        },
        {
            headerName: "Customer Name", field: 'customer_name',
            cellRendererFramework: customerNameDetails.bind(this, incellElement.bind(this)),
            // width: 300
            width: customerNameDetailsWidth,
            resizable: true, 
        },
        {
            headerName: 'Imported At', field: 'importedAt',
            // cellRendererFramework: ebayStatusDetails.bind(this, incellElement.bind(this)),
            // width: 300
            width: importedAtWidth,
            resizable: true, 
        },
    ]
};


export function getTabSelectedFilter(type) {
    switch (type) {
        case 'unfulfilled': return { 'filter[status][1]': 'inProgress' };
        case 'fulfilled': return { 'filter[status][1]': 'fulfilled' };
        case 'failed': return { 'filter[failed][1]': '1' };
        case 'cancelled': return { 'filter[status][1]': 'cancelled' };
        default: return {};
    }
}

export const pageSizeOptionOrders = [50, 100, 150, 200];

export function getpaginationInfo(totalrecords, pageSize) {
    let pages = Math.ceil(parseInt(totalrecords) / parseInt(pageSize));
    return { pages, totalrecords };
}


export function extractValuesfromRequest(rows = []) {
    // console.log(rows)
    let modifiedRows = [];
    rows.forEach(row => {
        let { source_order_id, imported_at } = row
        modifiedRows.push({
            source_order_id: { 'row': row },
            shopify_order_name: { 'row': row },
            importedAt: imported_at,
            customer_name: { 'row': row },
            fulfillment: { 'row': row }
        })
    });
    return modifiedRows;
}

export const filterCondition = [
    { label: 'equals', value: "1" },
    { label: 'not equals', value: "2" },
    {
        label: 'contains', value: "3", disable_for: ['variants.quantity', 'listing_id']
    },
    {
        label: 'does not contains', value: "4", disable_for: ['variants.quantity', 'listing_id']
    },
    {
        label: 'starts with', value: "5", disable_for: ['variants.quantity', 'listing_id']
    },
    {
        label: 'ends with', value: "6", disable_for: ['variants.quantity', 'listing_id']
    }
];

export const filterOptions = [
    {
        headerName: "eBay order ID", field: "source_order_id",
    },
    {
        headerName: "Shopify Order Name", field: "shopify_order_name",
    },
    {
        headerName: "Shopify Order ID", field: "target_order_id",
    },
    {
        headerName: "Customer Name", field: "client_details.name",
    },
];

export function getFilterforRequest(filters = []) {
    let tempObj = {};
    filters.forEach(filter => {
        tempObj[`filter[${filter['attribute']}][${filter['condition']}]`] = filter['value'];
    });
    return tempObj;
}