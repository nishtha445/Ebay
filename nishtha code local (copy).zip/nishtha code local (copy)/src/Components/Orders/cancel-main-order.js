import React, {Component} from 'react';
import * as queryString from "query-string";
import {Page, Card, TextField, Select, Banner, Badge, Stack, FormLayout, Layout, Heading} from "@shopify/polaris";
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import {isUndefined} from "util";
let data='';
const reason_options = [
    {label: 'Incorrect shipping address', value: 'malformedShippingAddress'},
    {label: 'Inventory does not exist', value: 'noInventory'},
    {label: 'Wrong Price', value: 'priceError'},
    {label: 'Incorrect tax', value: 'taxError'},
    {label: 'Shipping address unreachable', value: 'undeliverableShippingAddress'},
    {label: 'P.O box address is not supported', value: 'unsupportedPoBoxAddress'},
    {label: 'Other', value: 'other'},
    {label: 'No reason', value: 'customerInitiatedCancel'},
];
class CancelmainOrder extends Component {
    constructor(props)
    {
        super(props);
        this.state={
            order_data:{},
            reason:'other',
            reason_text:'Other',
            reason_text_error:false,
            hide_reason_text:false
        }

    }

    componentDidMount(){
        this.getQueryParams();
    }

    getQueryParams(){
        let queryParams = queryString.parse(this.props.location.search);
        if(!isUndefined(queryParams['id'])){
            data=JSON.parse(queryParams['id']);
            this.get_order_data();
        }else{
            this.redirect('/panel/orders');
        }
    }

    handleChange_reason = (reason) => {
        switch(reason) {
            case 'other':  this.setState({ reason_text :'Other'});
                break;
            case 'customerInitiatedCancel':  this.setState({ reason_text :'No Reason',
                hide_reason_text:true
            });
                break;
        }
        if(reason!=='customerInitiatedCancel'){
            this.setState({hide_reason_text:false })
        }
        this.setState({ reason:reason})
    };
    get_order_data(){
        requests.getRequest('connector/order/getOrderById?_id='+data).then(data=>{
            this.setState({order_data:data.data})
        });
    }
    redirect(url) {
        this.props.history.push(url);
    }
    handleChange_reason_text(e){
        this.setState({
            reason_text:e,
            reason_text_error:false,
        })
    }
    order_cancel_request()
    {
        if(this.state.reason_text!=='') {
            let order_cancel_data = {};
            order_cancel_data['source'] = this.state.order_data['source'];
            order_cancel_data['order_id'] = this.state.order_data['source_order_id'];
            order_cancel_data['merchant_id'] = this.state.order_data['merchant_id'];
            order_cancel_data['reason'] = this.state.reason;
            order_cancel_data['reason_text'] = this.state.reason_text;

            requests.postRequest('google/order/manualcancelOrder', order_cancel_data).then(data => {
                if (data.success === true) {
                    notify.success(data.message);
                }
                else {
                    notify.error(data.message);
                }
            })
        }else{
            notify.warn('Kindly fill all the required Feilds');
            this.setState({reason_text_error:true })
        }
    }
    getStatus = (status) => {
        let react = <sapn/>;
        switch (status) {
            case 'pendingShipment': return <React.Fragment>{react}<Badge status={"info"} progress="partiallyComplete"> Pending Shipment </Badge></React.Fragment>;break;
            case 'canceled': return <React.Fragment>{react}<Badge status={"warning"} progress="complete">Canceled</Badge></React.Fragment>;break;
            case 'fulfilled': return <React.Fragment>{react}<Badge status={"success"} progress="complete">Fulfilled</Badge></React.Fragment>;break;
            case 'inProgress': return <React.Fragment>{react}<Badge status={"attention"} progress="complete">in Progress</Badge></React.Fragment>;break;
            default: return <React.Fragment>{react}<Badge status={"attention"} progress="partiallyComplete">{status}</Badge></React.Fragment>;
        }
    };

    render() {
        if(Object.keys(this.state.order_data).length>0){
            return (
                <Page
                    fullWidth={true}
                    title='Order Cancellation'
                    breadcrumbs={[{content: 'Back', onAction:this.redirect.bind(this,'/panel/orders/view?id='+data)}]}
                >
                    <FormLayout>

                        <Banner status={"info"}>
                            <h5>
                                On Submitting Request for Order Cancellation , Order will be cancelled only on <b>Google</b> and not on <b>Shopify</b>
                            </h5>
                        </Banner>

                        <Layout>
                            <Layout.Section twoThird>
                                <Card title={<Heading element={"h2"}>#{this.state.order_data._id}</Heading>}>
                                    <Card.Section>
                                        <FormLayout>
                                            <Stack distribution={"equalSpacing"}>
                                                <Heading element={"p"}>Order id</Heading>
                                                <p style={{fontSize:'1.3rem'}}>{this.state.order_data.source_order_id}</p>
                                            </Stack>
                                            <Stack distribution={"equalSpacing"}>
                                                <Heading element={"p"}>Status</Heading>
                                                <p style={{fontSize:'1.3rem'}}>{this.getStatus(this.state.order_data.status)}</p>
                                            </Stack>
                                            <Stack distribution={"equalSpacing"}>
                                                <Heading element={"p"}>Import details</Heading>
                                                <p style={{fontSize:'1.3rem'}}>{this.state.order_data.imported_at}</p>
                                            </Stack>
                                        </FormLayout>
                                    </Card.Section>
                                </Card>
                            </Layout.Section>
                            <Layout.Section oneThird>
                                <Card title="Pricing Details">
                                    <Card.Section title="Total price">
                                        {this.state.order_data.total_price}
                                    </Card.Section>
                                    <Card.Section title="Inclusive tax">
                                        {(this.state.order_data.total_tax).toFixed(2)}
                                    </Card.Section>
                                </Card>
                            </Layout.Section>
                        </Layout>

                        <Card title="Reason" primaryFooterAction={{content:'Cancel Order',onAction:this.order_cancel_request.bind(this), destructive: true}}>
                            <Card.Section>
                                <Stack vertical={true} spacing={"loose"}>
                                    <Select
                                        label="Select a reason"
                                        options={reason_options}
                                        onChange={this.handleChange_reason}
                                        value={this.state.reason}
                                    />

                                    {!this.state.hide_reason_text &&

                                    <TextField
                                        label="Provide details for the Reason selected"
                                        type="text"
                                        value={this.state.reason_text}
                                        id="reason_text"
                                        error={this.state.reason_text_error?'*required feild':''}
                                        onChange={this.handleChange_reason_text.bind(this)}
                                        placeholder="Please provide reason for Cancellation"
                                        autoFocus={true}
                                    />}
                                </Stack>
                            </Card.Section>
                        </Card>

                    </FormLayout>
                </Page>
            );
        }
        else{
            return true;}
    }
}

export default CancelmainOrder;
