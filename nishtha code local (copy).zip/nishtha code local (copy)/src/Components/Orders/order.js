import React, {Component} from 'react';
import {
  Banner,
  Card,
  Modal,
  Page,
  Pagination,
  Select,
  TextContainer,
  Label, Badge, Button, Tabs,
  Stack, Icon, TextField, EmptyState, Checkbox, DisplayText, ProgressBar
} from '@shopify/polaris';
import {requests} from '../../services/request';
import ReactJson from 'react-json-view';
import {notify} from '../../services/notify';
import { NavLink } from 'react-router-dom';
import SmartDataTable from '../../shared/smartTable';
import {isUndefined} from "util";
import {paginationShow} from "../../shared/static-functions";
import ReadMoreReact from "read-more-react";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'jquery/dist/jquery.slim.min';
import 'popper.js/dist/umd/popper.min';
import 'bootstrap/dist/js/bootstrap.min';

import Grid from "../../shared/react-data-grid/grid";
import {conditioncheck, createDemoRows} from "../../shared/react-data-grid/createDemoRows";
import Filter from "../../shared/react-data-grid/filter";
import NumericFilter from "../../shared/react-data-grid/filters/numericFilter";

const defaultData = {
  width :200,
  filterable:true,
  editable: false,
  sortable: false,
  resizable: true,
  draggable: false,
  attachment:false

};
const defaultParams = {
  rowHeight:50,
  minHeight:window.innerHeight - 170,
  headerRowHeight:50,
  headerFiltersHeight:50,
  enableCellSelect:false,
};

const {
  DraggableHeader: { DraggableContainer }
} = require("react-data-grid-addons");


class Orders extends Component {
  filters = {
    column_filters: {}
  };
  gridSettings = {
    activePage: 1,
    count: 10
  };
  pageLimits = [
    {label: 20, value: '20'},
    {label: 40, value: '40'},
    {label: 60, value: '60'},
    {label: 80, value: '80'},
    {label: 100, value: '100'}
  ];
  massActions = [
    // {label: 'Sync with Shopify', value: 'syncshopify'},
    {label: 'Remove for app', value: 'removeorderapp', disabled: true},
    {label: 'Sync shipment', value:'syncshipment', disabled: false}
  ];
  orderListTabs = [
    {
      id: 'Unfulfilled',
      content: 'Unfulfilled',
      accessibilityLabel: 'Unfulfilled',
      link: '',
      panelID: 'Unfulfilled'
    },
    {
      id: 'Fulfilled',
      content: 'Fulfilled',
      accessibilityLabel: 'Fulfilled',
      link: '',
      panelID: 'Fulfilled'
    },

    {
      id: 'Failed',
      content: 'Failed',
      accessibilityLabel: 'Failed',
      link: '',
      panelID: 'Failed'
    },
    {
      id: 'Cancelled',
      content: 'Cancelled',
      accessibilityLabel: 'Cancelled',
      link: '',
      panelID: 'Cancelled'
    },

    /*,
     {
     id: 'Sandbox',
     content: 'Sandbox',
     accessibilityLabel: 'Sandbox',
     link: '',
     panelID: 'Sandbox'
     }*/
  ];

  visibleColumns = ['source_order_id','shopify_order_name','imported_at','customer_name','fulfillment'];
  customButton = [];
  hideFilters = ['imported_at'/*,'status_view','qty','total_price'*/,'target_order_id'/*,'customer_name'*/,'fulfillment'];
  columnTitles = {
    id: {
      title: 'ID',
      sortable: true
    },
    source_order_id: {
      title: 'eBay order ID',
      sortable: true
    },
    shopify_order_name: {
      title: 'Shopify Order Name',
      sortable: true
    },
    customer_name: {
      title: 'Customer Name',
      sortable: true
    },
    /*   qty: {
           title: 'Quantity',
           sortable: true,
           type: 'int'
       },
       total_price: {
           title: 'Price',
           sortable: true,
           type: 'int'
       },
       total_weight: {
           title: 'Weight',
           sortable: true
       },
       total_tax: {
           title: 'Tax',
           sortable: true
       },
       currency: {
           title: 'currency',
           sortable: true
       },*/
    target_order_id: {
      title: 'Shopify order ID',
      sortable: true,
      type: 'react'
    },
    fulfillment: {
      title: 'Fulfillment',
      sortable: true,
      type: 'react'
    },
    /*   status_view: {
           title: 'Status',
           sortable: true,
           type:'react'
       },*/
    imported_at: {
      title: 'Imported At',
      sortable: true
    },
  };
  filtersChanged = false;

  column=[
    {
      key: "check",
      name: <Checkbox id={"all"}
                      checked={false}
                      onChange={this.allSelector.bind(this,'all_selector')}/>,
      frozen: true,
      editable: false,
      width: 50,
      sortable: false,
      draggable: false,
      filterable: false,
    },
    {
      key: "source_order_id",
      name: "eBay order ID",
      frozen: true,
      editable: false,
      width :200,
      filterable: true,
      filterRenderer: Filter,
      sortable: false,

    },
    {
      key: "shopify_order_name",
      name: "Shopify Order Name",
      frozen: false,
      editable: false,
      width :250,
      filterRenderer: Filter,
      filterable: true,
      sortable: false,
      attachment:true

    },
    {
      key: "fulfillment",
      name: "Fulfillment",
      frozen: false,
      editable: false,
      width :250,
      filterable: false,
      sortable: false

    },
    {
      key: "customer_name",
      name: "Customer Name",
      frozen: false,
      editable: false,
      width :250,
      filterRenderer: Filter,
      filterable: true,
      sortable: false

    },
    {
      key: "importedAt",
      name: "Imported At",
      frozen: false,
      editable: false,
      width :250,
      filterable: false,
      sortable: false

    },

  ]

  constructor(props) {
    super(props);
    this.state = {
      order:[],
      rows:[],
      delete_order_ids:[],
      showdeleteOrderModal:false,
      orderError:false,
      orderErrorJson:false,
      totalPage:0,
      selectedProducts:[],
      selectedTab: 0,
      isSandbox: false,
      pagination_show: 0,
      showLoaderBar:true,
      hideLoader: false,
      line_item_collapsible:'',
      tempOrderData:[],
      AllSelect:false,
      syncwithShopify:false,
      removeorderapp: false,
      syncshipment:false,
      tempSelectedProducts:[],
      source_shop_id:0,
      sync_order_from:5,
      showSyncOrders:false,
      columns: this.column.map(c => ({...defaultData, ...c})),
      visibleColumns:{'check':1,'source_order_id':1,'shopify_order_name':1,'importedAt':1, 'customer_name':1,'fulfillment':1},
      pagination: {
        page: 1,
        totalNumberOfPages: 0,
        totalNumberOfProducts: 0,
        totalNumberOfItems: 0,
        pageSize: 25,
      },
      credits_info:{
        order:{
          available:0,
          total:0,
          percent:0
        },
      },
      showMassAction:false,
      massAction:[
        // {label: 'Sync with Shopify', value: 'syncshopify'},
        {label: 'Remove for app', value: 'removeorderapp', disabled: true},
        {label: 'Sync shipment', value:'syncshipment', disabled: false}
      ],
      preparedFilter:{},
      checkbox:{ },
      All_Selected:false,
      toolbar_suffix:"Order",
      selected_count:0
    };
    this.getOrders();
    this.getSourceShopId();

  }
  // componentWillMount() {
  //     requests.getRequest('frontend/app/getGoogleOrderConfig', false, false, true).then(data => {
  //         if ( data.success ) {
  //             this.setState({isSandbox:data.data.sandbox});
  //         }
  //     })
  // }
  getOrders() {
    this.setState({rows: createDemoRows("",true,"Order_grid")});
    window.showGridLoader = true;
    this.setState({
      showLoaderBar:false,
      hideLoader:false
    });
    let sandbox = 0;
    let final_request;
    let {pagination}=this.state;
    // let fulfilled = (this.state.selectedTab === 1) ? {'filter[status][1]':'fulfilled'} : {};
    // let unfulfilled = (this.state.selectedTab === 0) ? {'filter[status][1]':'inProgress'} : {};
    // let status = (this.state.selectedTab === 3) ? {'filter[status][1]':'cancelled'} : {};
    // let failedStatus = (this.state.selectedTab === 2) ? {'filter[failed][1]':'1'} : {};
    let Status={};
    let failed={};
    const pageSettings = Object.assign({}, {count:pagination.pageSize,activePage:pagination.page});
    const Status1 = this.prepareFilterObject("status",1)
    const Failed1 = this.prepareFilterObject("failed",1)

    switch(this.state.selectedTab){
      case 0:
        Status[Status1]="inProgress";
        final_request=requests.getRequest('connector/order/getOrders',Object.assign( Status,pageSettings, this.state.appliedFilters), undefined, false, true)
        break;
      case 1:
        Status[Status1]="fulfilled";
        final_request=requests.getRequest('connector/order/getOrders',Object.assign( Status,pageSettings, this.state.appliedFilters), undefined, false, true)
        break;
      case 2:
        failed[Failed1]=1;
        final_request=requests.getRequest('connector/order/getOrders',Object.assign( failed,pageSettings, this.state.appliedFilters), undefined, false, true)
        break;
      case 3:
        Status[Status1]="cancelled";
        final_request=requests.getRequest('connector/order/getOrders',Object.assign( Status,pageSettings, this.state.appliedFilters), undefined, false, true)
        break;
    }

    // requests.getRequest('connector/order/getOrders',{ ...fulfilled ,...unfulfilled,...status,...failedStatus, ...{activePage:
    //         this.gridSettings.activePage} ,...{count: this.gridSettings.count}, ...(this.filterString(this.filters.column_filters))}, false, true)
    final_request.then(data => {
      if (data.success) {
        window.showGridLoader = false;
        this.setState({
          tempOrderData:data.data.rows,
          countTocheck:(data.data.rows).length,
          rows : this.dataMapping(data.data.rows,false,"Order_grid"),
          order:this.modifyProductsData(data.data.rows,''),
          totalPage:data.data.count,
        });
        this.state.pagination.totalNumberOfItems=data.data.count;
        this.state.pagination.totalNumberOfPages=Math.ceil(data.data.count/this.state.pagination.pageSize);
        this.updateState();

        // if(this.state.selectedTab == 2 ) {
        //   let temp = 0;
        //   data.data.rows.map((e) => {
        //     if ((e.source_order_id in this.state.checkbox)) {
        //       temp += 1;
        //     }
        //   });
        //   if (temp == Object.keys(data.data.rows).length && Object.keys(data.data.rows).length != 0) {
        //     this.setState({All_Selected: true});
        //   } else {
        //     this.setState({All_Selected: false});
        //   }
        //   this.all_Selected();
        // }
        // if ( !isUndefined(this.props.location.state) && Object.keys(this.props.location.state).length > 0  ) {
        //     this.manageStateChange(this.props.location.state['parent_props']);
        // }
      } else {
        window.showGridLoader = false;
        setTimeout(() => {
          window.handleOutOfControlLoader = true;
        },3000);
        this.setState({
          showLoaderBar:false,
          hideLoader:true,
          pagination_show: paginationShow(0,0,0,false)
        });
        notify.error(data.message);
      }
    })
  }

  getStatus = (status) => {
    switch (status) {
      case 'pendingShipment': return <Badge status={"info"} progress="partiallyComplete">Unfulfilled</Badge>;break;
      case 'canceled': return <Badge status={"warning"} progress="complete">Canceled</Badge>;break;
      case 'failed': return <Badge status={"warning"} progress="complete">Failed</Badge>;break;
      case 'fulfilled': return <Badge status={"success"} progress="complete">Fulfilled</Badge>;break;
      case 'inProgress': return <Badge status={"attention"} progress="incomplete">Unfulfilled</Badge>;break;
      default: return <Badge status={"attention"} progress="partiallyComplete">{status}</Badge>
    }
  };

  componentDidMount(){
    this.getServiceCredits();
    document.title='Fetch the orders received on eBay - CedCommerce';
    document.description='Order section helps you to keep a track of your orders (Fulfilled/Unfulfilled/Failed/Cancelled). It updates you about each new order received on eBay.';
    if(!document.title.includes(localStorage.getItem('shop_url'))) {
      document.title += !isUndefined(localStorage.getItem('shop_url')) ? " " + localStorage.getItem('shop_url') : "";
    }
  }

  getServiceCredits() {
    requests.getRequest('frontend/app/getServiceCredits',{service_code:'ebay_order_sync'},false,true).then(ordercredits=>{
      if(ordercredits.success){

        let orderObj={
          available:ordercredits.data.available_credits,
          total:ordercredits.data.available_credits + ordercredits.data.total_used_credits,
          percent:((ordercredits.data.available_credits)/(ordercredits.data.available_credits + ordercredits.data.total_used_credits))*100
        };
        this.state.credits_info.order=Object.assign({},orderObj);
      }
      this.setState(this.state);
    });
  }

  filterString(value) {
    let tempObj={};
    let filter = '';
    Object.keys(value).forEach(data => {
      if ( value[data].value !== '' ) {

        tempObj={...tempObj,...{[`filter[${data}][${value[data].operator}]`]: value[data].value}}
        // filter += '&filter[' + data + '][' + value[data].operator + ']=' + value[data].value;
      }
    });
    return tempObj;
    // return filter;
  }
  handleToggleClick = (line_item_collapsible) => {

    if ( this.state.line_item_collapsible === line_item_collapsible ) {
      this.setState({line_item_collapsible:''});
    } else {
      this.setState({line_item_collapsible:line_item_collapsible});
    }
    const orders = this.modifyProductsData(this.state.tempOrderData, line_item_collapsible);
    this.setState({order:orders});
  };
  modifyProductsData(data,line_item_collapsible) {
    let products = [];
    let Hash_Remove;

    for (let i = 0; i < data.length; i++) {
      let rowData = {};
      let rows = [];
      rowData['id']=data[i]._id
      Object.keys(data[i].line_items).forEach((key,index) => {
        rows.push([
          data[i].line_items[key]['mpn']!==null? data[i].line_items[key]['mpn']:" - ",
          data[i].line_items[key]['quantity_ordered'],
          data[i].line_items[key]['total_price']
        ]);
      });
      rowData['source_order_id'] =/* <div onClick={this.operations.bind(this,data[i]._id,'button_1')} style={{cursor:"pointer"}}>{
               */ data[i].source_order_id/*}</div>*/
      /*rowData['qty'] = data[i]['qty'];
      rowData['total_price'] = data[i].total_price;
      rowData['total_weight'] = data[i].total_weight;
      rowData['total_tax'] = data[i]['total_tax'];
      rowData['currency'] = data[i]['currency'];*/
      rowData['customer_name'] =data[i].client_details.name!==''?data[i].client_details.name:<div className="w-100 text-center">
        <Icon source="subtract" />
      </div>;
      if ( isNaN(parseInt(data[i]['target_order_id'])) ) {
        rowData['target_order_id'] = <div className="w-100 text-center">
          <Icon source="subtract" />
        </div>;
      } else {
        rowData['target_order_id'] = <Label>
          {data[i]['target_order_id']}
        </Label>;
      }
      if (isUndefined(data[i]['shopify_order_name']) ) {
        rowData['shopify_order_name'] = <React.Fragment>
          {/*  <FontAwesomeIcon icon={faMinus} size="2x" color="#cccccc"/>*/}
          <Icon source="subtract" />
          <div className="w-100" onClick={this.handleToggleClick.bind(this,i)}>
            <h2 style={{color:"#868686", cursor:"pointer"}}>Order ID - {data[i]['target_order_id']}</h2>
            {line_item_collapsible === i && this.state.line_item_collapsible !== i &&
            <Card>
              <table className="table table-responsive-lg">
                <tr>
                  <th> Mpn </th>
                  <th> Quantity </th>
                  <th> Price </th>
                </tr>
                {rows.map(e => (<tr>
                  <td> {<div onClick={e=>e.stopPropagation()}> <ReadMoreReact
                    text={e[0]}
                    min={20}
                    ideal={20}
                    max={20} /></div>}</td>
                  <td> {e[1]} </td>
                  <td> {e[2]} </td>
                </tr>))}
              </table>
            </Card>}
          </div>
        </React.Fragment>;
      } else {
        Hash_Remove=data[i]['shopify_order_name'];
        rowData['shopify_order_name'] =<React.Fragment>
          <div onClick={this.handleToggleClick.bind(this,i)}>
            {Hash_Remove}
            <h2 style={{color:"#868686", cursor:"pointer"}}>Order ID - {data[i]['target_order_id']}</h2>
            {line_item_collapsible === i && this.state.line_item_collapsible !== i &&
            <Card>
              <table className="table table-responsive-lg">
                <tr>
                  <th> Mpn </th>
                  <th> Quantity </th>
                  <th> Price </th>
                </tr>
                {rows.map(e => (<tr>
                  <td> {<div onClick={e=>e.stopPropagation()}> <ReadMoreReact
                    text={e[0]}
                    min={20}
                    ideal={20}
                    max={20} /></div>}</td>
                  <td> {e[1]} </td>
                  <td> {e[2]} </td>
                </tr>))}
              </table>
            </Card>}
          </div>
        </React.Fragment>;
      }
      rowData['imported_at'] = /*<div onClick={this.operations.bind(this,data[i]._id,'button_1')} style={{cursor:"pointer"}}>{
               */ new Date(data[i].created_at).toLocaleDateString()/*}</div>*/
      // if ( !isUndefined(data[i]['fulfillments'])
      //     && typeof data[i]['fulfillments'] === 'object'
      //     && Object.keys(data[i]['fulfillments']).length > 0 ) {
      //     rowData['status_view']=<div onClick={this.operations.bind(this,data[i]._id,'button_1')} style={{cursor:"pointer"}}>{
      //         this.getStatus('fulfilled')}</div>
      // } else {
      //     rowData['status_view'] =<div onClick={this.operations.bind(this,data[i]._id,'button_1')} style={{cursor:"pointer"}}>{
      //         this.getStatus(data[i]['status'])}</div>
      // }
      if(data[i]['source_order_id'] !== '' && data[i]['target_order_id'] === ''){
        data[i]['status'] = 'failed';
      }
      rowData['fulfillment'] =this.getStatus(data[i]['status']);
      products.push(rowData);
    }
    return products;
  }
  operations = (data, event) => {
    switch (event) {
      default :this.redirect('/panel/orders/view?id=' + data['id']);break;
    }
  };

  updateState() {
    const state = this.state;
    this.setState(state);
  }

  feildsChange(key,value){
    this.state[key]=value;
    this.updateState();
  }

  renderSyncOrderModal() {
    return (
      <div>
        <Modal
          open={this.state.showSyncOrders}
          onClose={() => {
            this.state.showSyncOrders = false;
            this.state.sync_order_from =5;
            this.updateState();
          }}
          title="Sync orders"
          /* primaryAction={{disabled:this.state.importProductsDetails.source === '',content:'Import Products',
               onAction: this.importProducts.bind(this)

           }}*/
        >
          <Modal.Section>
            <Stack vertical={true} distribution={"center"} alignment={"center"}>
              <p>
                You are about to perform Order sync
              </p>
              <TextField
                key={'Sync orders from '}
                value={this.state.sync_order_from}
                placeholder={''}
                error={this.state.sync_order_from<0 || this.state.sync_order_from>30 ?'*incorrect input':''}
                type={"number"}
                label={'Specify number of days(0-30) for which you want your order to be synced'}
                onChange={this.feildsChange.bind(this,'sync_order_from')}/>
              <Button disabled={this.state.sync_order_from === '' || this.state.sync_order_from<0 || this.state.sync_order_from>30} onClick={this.orderSync.bind(this)} primary>
                Sync
              </Button>
            </Stack>
          </Modal.Section>
        </Modal>
      </div>
    );
  }

  deleteOrderIds(){
    requests.postRequest('ebayV1/delete/deleteOrder',{order_ids:this.state.delete_order_ids}).then(data=>{
      if(data.success){
        notify.success(data.message);
      }else{
        notify.error(data.message);
      }
      this.state.showdeleteOrderModal = false;
      this.state.delete_order_ids =[];
      this.updateState();
    })
  }

  renderdeleteOrderIdsModal() {
    return (
      <div>
        <Modal
          open={this.state.showdeleteOrderModal}
          onClose={() => {
            this.state.showdeleteOrderModal = false;
            this.state.delete_order_ids =[];
            this.updateState();
          }}
          title="Delete Order"
          primaryAction={{content:'Delete',
            onAction: this.deleteOrderIds.bind(this)
          }}
        >
          <Modal.Section>
            <Stack vertical={true} distribution={"fillEvenly"} >
              <Banner status={"warning"} title={'Provide the Shopify Order ID of the order you want to delete. Please note that this process can\'t be reverted'}/>
              <TextField
                key={'deleteOrderID'}
                value={this.state.delete_order_ids[0]}
                placeholder={'Provide order id for deletion...'}
                label={''}
                onChange={(e)=>{this.state.delete_order_ids[0] = e; this.updateState()}}/>
            </Stack>
          </Modal.Section>
        </Modal>
      </div>
    );
  }

  handleTabChange(event) {
    //console.log(event);
    this.state.selectedTab=event;
    // this.state.AllSelect=(event===3 || event === 2)?true:false;
    if(event===2 || event === 0 || event === 1) {
      this.state.visibleColumns={'check':1,'source_order_id':1,'shopify_order_name':1,'importedAt':1, 'customer_name':1,'fulfillment':1};
      this.state.showMassAction = true;
      this.state.massAction = [
        // {label: 'Sync with Shopify', value: 'syncshopify'},
        {label: 'Sync shipment', value:'syncshipment',disabled: false}
      ];
      if(event === 2) {
        this.state.massAction = [
          // {label: 'Sync with Shopify', value: 'syncshopify'},
          {label: 'Remove for app', value: 'removeorderapp', disabled: false},
          {label: 'Sync shipment', value:'syncshipment',disabled: false}
        ];
      }
    }
    else{
      this.state.visibleColumns={'source_order_id':1,'shopify_order_name':1,'importedAt':1, 'customer_name':1,'fulfillment':1}
      this.state.massAction=[
        // {label: 'Sync with Shopify', value: 'syncshopify'},
        {label: 'Remove for app', value: 'removeorderapp',disabled:true},
        {label: 'Sync shipment', value:'syncshipment',disabled:true}
      ];
    }

    this.state.showLoaderBar=false;
    this.state.rows=createDemoRows("",true,"Order_grid");
    this.state.pagination={
      page: 1,
      totalNumberOfPages: 0,
      totalNumberOfProducts: 0,
      totalNumberOfItems: 0,
      pageSize: 25,
    }
    this.updateState();
    this.setState(this.state,()=>{
      this.getOrders();
      this.setVisibleColumns();
    });

  }

  orderSync() {
    requests.getRequest('connector/order/sync', {marketplace: 'ebay', target: 'shopify',sync_order_from:this.state.sync_order_from}, false, true)
      .then(data => {
        if (data.success) {
          if ( data.code === 'order_sync_started' ) {
            setTimeout(() => {
              this.redirect('/panel/activities');
            }, 500);
          }
          notify.success(data.message);
        } else {
          notify.error(data.message);
        }
        this.state.showSyncOrders = false;
        this.state.sync_order_from ='';
        this.updateState();
      })
  }

  setmodal(event,data){
    this.state[event]=data;
    const state = this.state;
    this.setState(state);
  }

  getModalBody(data){
    let temparr =[];
    switch (data) {
      case 'syncwithShopify':
        temparr.push(
          <div className="col-12 text-center">
            <h2>You have selected {this.state.selectedOrder.length} {this.state.selectedOrder.length>1?"Orders":"Order"}</h2>
            <h2>Do you want to Sync them with Shopify? </h2>
          </div>
        );
        break;
      case 'removeorderapp':
        temparr.push(
          <div className="col-12 text-center">
            <h2>You have selected {this.state.selectedOrder.length} {this.state.selectedOrder.length>1?"Orders":"Order"}</h2>
            <h2>Do you want to remove them from App? </h2>
          </div>
        );
        break;
      case 'syncshipment':
        temparr.push(
          <div className="col-12 text-center">
            <h2>You have selected {this.state.selectedOrder.length} {this.state.selectedOrder.length>1?"Orders":"Order"}</h2>
            <h2>Do you want to Sync their Status on App from Shopify?</h2>
          </div>
        );
        break;
    }
    return temparr;
  }

  renderModal(data) {
    return (
      <Modal
        open={this.state[data]}
        onClose={() => {
          this.setmodal(data,false);
        }}
      >
        <Modal.Section>
          <div className="row p-5">
            {
              this.getModalBody(data)
            }
            <div className="col-12 text-center pt-5">
              <Button onClick={()=>{this.hitModalfunction(data)}} primary>
                Yes
              </Button>
            </div>
          </div>
        </Modal.Section>
      </Modal>
    );
  }

  hitModalfunction(data){
    switch (data) {
      case 'syncwithShopify':
        this.syncProductconfirmed();
        break;
      case 'removeorderapp':
        this.removeOrderApp();
        break;
      case 'syncshipment':
        this.syncOrderShipment();
        break;
    }
  }



  getSourceShopId(){
    requests.getRequest('connector/get/services', { 'filters[type]': 'importer' },false,true)
      .then(data => {
        if (data.success === true) {
          this.setState({
            source_shop_id:data['data']['shopify_importer']['shops'][0]['id'],
          });
        }
        else{
          notify.error("Unable to get the shop Id");
        }
      })
  }
  syncProductconfirmed(){
    let final=[];
    for (var key in this.state.checkbox) {
      final.push(key)
    }
    /*let final=[];
    for(let i=0;i<this.state.tempOrderData.length;i++){
        this.state.tempSelectedProducts.forEach(function(item ,key){
            if(temp[i].source_order_id===item){
                final.push(temp[i].source_order_id)
            }
        });
    }*/
    requests.postRequest('ebayV1/upload/selectAndSyncOrder',{order_ids:final}).then(data=>{
      if(data.success){
        notify.success(data.message);
        if(data.code==="order_sync_started"){
          this.redirect('/panel/activities');
        }
      }
      else {
        notify.error(data.message);
      }
    });

    this.setmodal('syncwithShopify',false);
  }
  closesyncProductModal() {
    // this.state.topublishRow = {};
    this.state.syncwithShopify = false;
    const state = this.state;
    this.setState(state);
  }
  pageSettingsChange(event) {
    this.gridSettings.count = event;
    this.gridSettings.activePage = 1;
    this.getOrders();
  }

  manageStateChange = (old_state) => {
    this.filters = Object.assign({}, old_state['filters']);
    this.gridSettings = Object.assign({}, old_state['gridSettings']);
    this.props.location.state = undefined;
    this.getOrders();
  };

  //-----grid function-----------//

  allSelector(field,value){
    if(value){
      this.state.columns[0]['name']=(<Checkbox id={"all"}
                                               checked={true}
                                               onChange={this.allSelector.bind(this,'all_selector')}
      />)
      this.state.tempOrderData.map((e)=>{
        this.state.checkbox[e["source_order_id"]]=true;
      })
      this.state.massAction=[
        // {label: 'Sync with Shopify', value: 'syncshopify'},
        {label: 'Remove for app', value: 'removeorderapp'},
        {label: 'Sync shipment', value:'syncshipment'}
      ];
      this.updateState();
      this.setState({rows:this.dataMapping(this.state.tempOrderData,false,"Order_grid")});
    }
    else
    {
      this.state.columns[0]['name']=(<Checkbox id={"all"}
                                               checked={false}
                                               onChange={this.allSelector.bind(this,'all_selector')}/>)
      this.state.tempOrderData.map((e)=>{
        if(e.source_order_id in this.state.checkbox){
          delete this.state.checkbox[e.source_order_id];
        }

      })
      // if(Object.values(this.state.checkbox).length == 0){
      //   this.state.massAction = [];
      // }
      this.updateState();
      this.setState({rows:this.dataMapping(this.state.tempOrderData,false,"Order_grid")});


    }

  }

  handleChangeCheck = (value,e) => {
    if(value){
      this.state.checkbox[e]=value;
      let temp=0;
      this.state.tempOrderData.map((e)=> {
        if ((e.source_order_id in this.state.checkbox)) {
          temp+=1;
        }
      });


      if(temp == Object.keys(this.state.tempOrderData).length && Object.keys(this.state.tempOrderData).length != 0 ){
        this.state.All_Selected=true;
      }
    }
    else{
      delete this.state.checkbox[e];
      this.state.All_Selected=false;
      // if(Object.values(this.state.checkbox).length == 0){
      //   this.state.massAction = [];
      // }
    }
    this.updateState();
    this.all_Selected();
    this.setState({
      rows:this.dataMapping(this.state.tempOrderData,false,"Order_grid")
    });

  };

  prepareFilterObject(coloumn,index){
    let filterObtained='';
    if (coloumn !== '') {
      switch (coloumn) {
        case 'shopify_order_name':
          filterObtained=(index === undefined)?'filter[' + coloumn + ']':'filter[' + coloumn + ']['+ index +']';
          break
        case 'source_order_id':
          filterObtained=(index === undefined)?'filter[' + coloumn + ']':'filter[' + coloumn + ']['+ index +']';
          break;
        case 'customer_name':
          coloumn = 'client_details.name';
          filterObtained=(index === undefined)?'filter[' + coloumn + ']':'filter[' + coloumn + ']['+ index +']';
          break;
        case 'sandbox':
          filterObtained='filter[' + coloumn + '][1]';
          break;
        case 'failed':
          filterObtained=(index === undefined)?'filter[' + coloumn + ']':'filter[' + coloumn + ']['+ index +']';
          break;
        case 'fulfillments':
          filterObtained=(index === undefined)?'filter[' + coloumn + ']':'filter[' + coloumn + ']['+ index +']';
          break;
        case 'status':
          filterObtained=(index === undefined)?'filter[' + coloumn + ']':'filter[' + coloumn + ']['+ index +']';
          break;
      }
    }
    return filterObtained;
  }

  dataMapping(data,loading="false",whichOne){
    if(whichOne=="Order_grid"){
      return data.map(row => {
        let data = {};
        data["check"]=<div title={"checkbox"}> <Checkbox checked={(this.state.checkbox.hasOwnProperty(row['source_order_id']))?true:false}
                                                         label={row["source_order_id"]}
                                                         id={row["source_order_id"]}
                                                         onChange={this.handleChangeCheck}
                                                         labelHidden={true}/> </div>
        data['source_order_id'] = row["source_order_id"];
        data['shopify_order_name']=(!isUndefined(row["shopify_order_name"]))?<div title={"Order details"}>{row['shopify_order_name']}<br/> Order ID - {!isUndefined(row['target_order_id'])?row['target_order_id']:""}</div>:<div title={'Not available'} ><Icon source="subtract" /></div>;
        data['importedAt']=row["imported_at"];
        data['customer_name'] =row.client_details.name!==''?row.client_details.name:<div  title={'Not available'} className="w-100 text-center">
          <Icon source="subtract" />
        </div>
        if(row['source_order_id'] !== '' && row['target_order_id'] === ''){
          row['status'] = 'failed';
        }
        data['fulfillment'] =<div title={"status"}>{this.getStatus(row['status'])}</div>;
        // data['extended_order_id'] =!isUndefined(row);
        if(!isUndefined(row.errors)){
          data['errors'] = row.errors;
        }
        return data;
      })
    }
  }

  all_Selected(){
    if(this.state.All_Selected){
      this.state.columns[0]['name']=(<Checkbox id={"all"}
                                               checked={true}
                                               onChange={this.allSelector.bind(this,'all_selector')}/>)
    }
    else{
      this.state.columns[0]['name']=(<Checkbox id={"all"}
                                               checked={false}
                                               onChange={this.allSelector.bind(this,'all_selector')}/>)
    }
    this.updateState();
  }


  setVisibleColumns(){
    let check=[];
    for(let key in this.column) {
      if (this.column[key]["key"] in this.state.visibleColumns ) {
        check.push({...defaultData,...this.column[key]})
      }
    }
    this.setState({columns:check},()=>{
      //console.log(this.state.columns)
    })
  }

  getSubRowDetails = expandedRows1 => rowItem => {
    let { expandedRows } = this.state;
    const isExpanded = expandedRows && expandedRows[rowItem.id]
      ? expandedRows[rowItem.id]
      : false;
    return {
      group: rowItem.variants && rowItem.variants.length > 0,
      expanded: isExpanded,
      children: rowItem.variants,
      field: "title",
      treeDepth: rowItem.treeDepth || 0,
      siblingIndex: rowItem.siblingIndex,
      numberSiblings: rowItem.numberSiblings
    };
  };

  updateSubRowDetails(subRows, parentTreeDepth) {
    const treeDepth = parentTreeDepth || 0;
    subRows.forEach((sr, i) => {
      sr.treeDepth = treeDepth + 1;
      sr.siblingIndex = i;
      sr.numberSiblings = subRows.length;
    });
  }

  onCellExpand = args => {
    let { rows, expandedRows } = this.state;
    const rowKey = args.rowData.id;
    const rowIndex = rows.indexOf(args.rowData);
    const subRows = args.expandArgs.children;
    if (expandedRows && !expandedRows[rowKey]) {
      expandedRows[rowKey] = true;
      this.updateSubRowDetails(subRows, args.rowData.treeDepth);
      rows.splice(rowIndex + 1, 0, ...subRows);
    } else if (expandedRows[rowKey]) {
      expandedRows[rowKey] = false;
      rows.splice(rowIndex + 1, subRows.length);
    }
    this.setState({expandedRows:expandedRows,rows:rows});
    return { expandedRows, rows };
  };

  handleFilterChange = filter => {
    //console.log(filter);
    let {appliedFilters,preparedFilter}  = this.state;
    preparedFilter[filter["key"]]=[this.prepareFilterObject(filter["key"],filter["operator"]),filter["rawValue"]];
    if(filter["rawValue"]===""){
      delete preparedFilter[filter["key"]];
    }
    appliedFilters={};
    this.setState({preparedFilter,appliedFilters},()=>{
      for( let i in this.state.preparedFilter){
        if(this.state.preparedFilter.hasOwnProperty(i)){
          appliedFilters[this.state.preparedFilter[i][0]]=this.state.preparedFilter[i][1];
        }
      }
      this.setState({appliedFilters},()=>{
        this.getOrders();
      });
    });

  };

  redirect(url, data) {
    /*if ( !isUndefined(data) ) {
        this.props.history.push(
            url,
            JSON.parse(JSON.stringify(data))
        );
    } else {
        this.props.history.push(url);
    }*/
    this.props.history.push(url);
  }

  getCellClick = (e) => {
    console.log('e', e);
    console.log('object', this.state.tempOrderData[e.rowIdx]["_id"])
    if(e.idx > 0 && (this.state.selectedTab !== 2) ){
      // this.redirect('/panel/orders/view?id='+this.state.tempOrderData[e.rowIdx]["_id"]);
    }else if(this.state.selectedTab === 2  && e.idx>0 && e.idx!==3 ){
      // this.redirect('/panel/orders/view?id='+this.state.tempOrderData[e.rowIdx]["_id"]);
    }
    if(e.idx > 0 && (this.state.selectedTab === 2)){
      switch(e.idx){
        case 3:
          if(!isUndefined(this.state.tempOrderData[e.rowIdx]['errors'])){
            console.log('object', this.state.tempOrderData[e.rowIdx]['errors'])
            // this.setState({orderErrorJson:this.state.tempOrderData[e.rowIdx]['errors'],orderError:true})
          }
          break;

      }
    }

  }

  // on Grid Update
  onGridRowsUpdated = ( fieldName, fromRow, toRow, updated ) => {
    //console.log(fieldName, fromRow, toRow, updated);
    this.setState(state => {
      const rows = state.rows.slice();
      for (let i = fromRow; i <= toRow; i++) {
        rows[i] = { ...rows[i], ...updated };
      }
      return { rows };
    });
  };

  onHeaderDrop = (source, target) => {
    const stateCopy = Object.assign({}, this.state);
    const columnSourceIndex = this.state.columns.findIndex(
      i => i.key === source
    );
    const columnTargetIndex = this.state.columns.findIndex(
      i => i.key === target
    );

    stateCopy.columns.splice(
      columnTargetIndex,
      0,
      stateCopy.columns.splice(columnSourceIndex, 1)[0]
    );

    const emptyColumns = Object.assign({}, this.state, { columns: [] });
    this.setState(emptyColumns);

    const reorderedColumns = Object.assign({}, this.state, {
      columns: stateCopy.columns
    });
    this.setState(reorderedColumns);
  };

  // set the Drop down Filter Value here
  getValidFilterValues = (rows, columnId) => {
    let val = rows
      .map(r => r[columnId])
      .filter((item, i, a) => {
        return i === a.indexOf(item);
      });
    return val;
  };

  sortRows = ( sortColumn, sortDirection) => {
    //console.log(sortColumn, sortDirection);
  };

  onCheckCellIsEditable = (event) => {
    // return false;
    let flag = true;
    if ( event.row.variants && event.column.key !== 'title' )
      flag = false;
    if ( event.row.type === 'child' && event.column.key === 'title' )
      flag = false;
    return flag;
  };

  onRowsSelected = rows => {
    this.setState({
      selectedIndexes: this.state.selectedIndexes.concat(
        rows.map(r => r.rowIdx)
      ),
      selectedOrderIds:this.state.selectedOrderIds.concat(
        rows.map(r => r["row"]["source_order_id"])
      )
    });
  };

  onRowsDeselected = rows => {
    let rowIndexes = rows.map(r => r.rowIdx);
    let Ids=rows.map(r => r["row"]["source_order_id"]);
    this.setState({
      selectedIndexes: this.state.selectedIndexes.filter(
        i => rowIndexes.indexOf(i) === -1
      ),
      selectedOrderIds:this.state.selectedOrderIds.filter(
        i => Ids.indexOf(i) === -1
      )
    });
  };

  handlePagination = (pageProps) => {
    this.setState({pagination:pageProps},() => {
      this.getOrders();
    });
  };

  handleColumn=(columnProps)=>{
    //console.log(columnProps);
    this.setState({visibleColumns:columnProps},()=>{
      this.setVisibleColumns();
    })
  }

  EmptyRowsView = () => {
    return (
      <EmptyState heading="No data found " action={{ content: 'Refresh filter',onAction:()=>{
          this.setState({appliedFilters:{}},()=>{
            this.getOrders();
          });
        } }} image="https://cdn.shopify.com/s/assets/admin/empty-states-fresh/emptystate-abandoncheckout-de95c7af243bfbc1a127a7bd1a6a9b7a5769ddc295a303268fdf26913f16801c.svg">
      </EmptyState>
    );
  };

  performMassAction = (action) => {

    let tmp=[];
    for (var key in this.state.checkbox) {
      tmp.push(key)
    }
    this.setState({ selectedOrder:tmp},()=>{
      if(this.state.selectedOrder.length > 0 ) {
        switch (action) {
          case 'syncshopify':
            this.setmodal('syncwithShopify',true);
            break;
          case 'removeorderapp':
            this.setmodal('removeorderapp',true);
            break;
          case 'syncshipment':
            this.setmodal('syncshipment',true);
            break;
          default://console.log(action,this.state.selectedProducts);
        }
      }
      else{
        notify.info("No product is selected");
      }
    });

  };

  removeOrderApp(){

    let final=[];
    for (var key in this.state.checkbox) {
      final.push(key)
    }

    requests.postRequest('ebayV1/delete/deleteOrderFromApp',{order_ids : final}).then(data=>{
      if(data.success){
        notify.success(data.message);
      }else{
        notify.success(data.message);
      }
    });
    this.setmodal('removeorderapp',false);
  }


  syncOrderShipment(){

    let final=[];
    for (var key in this.state.checkbox) {
      final.push(key)
    }

    requests.postRequest('ebayV1/get/syncShipmentMultipleOrders',{order_ids : final}).then(data=>{
      if(data.success){

        this.getOrders()

        notify.info(data.message);
      }else{
        notify.info(data.message);
      }
      this.setmodal('syncshipment',false);
    });

  }


  render() {
    return (
      <Page
        fullWidth={true}
        titleMetadata={<p style={{cursor:'pointer'}} onClick={()=>{
          window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=orders-28','_blank')
        }}><Badge status={"info"}><b style={{color:'#0000aa', textDecoration:'underline'}}>Need help?</b></Badge></p>}
        title="Orders"
        secondaryActions={[
          // {content:<Badge status={"new"}><b>Order enquiry</b></Badge>,onAction:()=>{
          // this.redirect('/panel/orders/enquiry');
          // }},
          {content:<Badge status={"info"}><b>Delete shopify order</b></Badge>,onAction:()=>{
              this.state.showdeleteOrderModal = true;
              this.updateState();
            }}
        ]}
        primaryAction={{content: 'Import eBay order(s)', onAction:()=>{this.state.showSyncOrders =true; this.updateState()}}}>
        <div className="mb-4">
          {/*{this.state.isSandbox?<Banner status={"warning"}>*/}
          {/*<h5>*/}
          {/*Default mode for Order Syncing is Sandbox mode currently. You can change it*/}
          {/*<NavLink to={'/panel/configuration'}> here</NavLink>.*/}
          {/*</h5>*/}
          {/*</Banner>:null}*/}
          <Stack vertical={true} spacing={"loose"}>
            <Stack.Item>
              <Banner title={`${this.state.credits_info.order.available} / ${this.state.credits_info.order.total} order credits available`}/>
              <ProgressBar progress={this.state.credits_info.order.percent} size="small" />
            </Stack.Item>
            <Banner  status={"info"}>
              <ul>
                <li>
                  New Order(s), whose payment has been done, is synced from eBay to Shopify within 30 minutes.
                </li>
                <li>
                  For syncing old order(s) <span style={{color:"#0000FF",cursor:'pointer'}}  onClick={() => {this.redirect('/panel/help/report');}} >contact us</span>.
                </li>
                <li>
                  It is recommended that sellers must fulfill orders after 1 hour of their creation.
                </li>
              </ul>
            </Banner>
          </Stack>
        </div>
        <React.Fragment>
          <Stack vertical={true}>
            <Tabs tabs={this.orderListTabs} selected={this.state.selectedTab} onSelect={this.handleTabChange.bind(this)} />
            {this.state.syncwithShopify && this.renderModal('syncwithShopify')}
            {this.state.removeorderapp && this.renderModal('removeorderapp')}
            {this.state.syncshipment && this.renderModal('syncshipment')}
            <DraggableContainer onHeaderDrop={this.onHeaderDrop}>
              <Grid
                suffix={this.state.toolbar_suffix}
                columns={this.state.columns}
                rowGetter={i => this.state.rows[i]}
                rowsCount={this.state.rows.length}
                massAction={this.state.massAction}
                onGridRowsUpdated={this.onGridRowsUpdated}
                hideLoader={this.state.hideLoader}
                onAddFilter={filter => this.handleFilterChange(filter)}
                onClearFilters={(e) => {this.setState({appliedFilters:{}},()=>{ this.getOrders()})}}
                onCheckCellIsEditable={(e) => {return this.onCheckCellIsEditable(e)}}
                onGridSort={(sortColumn, sortDirection) => this.sortRows(sortColumn, sortDirection)}
                getValidFilterValues={columnKey => this.getValidFilterValues(this.state.rows, columnKey)}
                getSubRowDetails={this.getSubRowDetails(this.state.expandedRows)}
                visibleColumns={this.state.visibleColumns}
                // onCellExpand={args => this.onCellExpand(args)}
                hideColumnToggleButton={true}
                filtercolumnSize={defaultParams}
                getCellClick={this.getCellClick}
                paginationProps={this.state.pagination}
                handlePagination={this.handlePagination}
                handleColumn={this.handleColumn}
                performMassAction={this.performMassAction}
                selected_count={Object.values(this.state.checkbox).length}
                rowSelection={{
                  showCheckbox: false,
                  enableShiftSelect: true,
                  onRowsSelected: this.onRowsSelected,
                  onRowsDeselected: this.onRowsDeselected,
                  selectBy: {
                    indexes: this.state.selectedIndexes
                  }
                }}
                emptyRowsView={this.EmptyRowsView}
              />
            </DraggableContainer>
          </Stack>
        </React.Fragment>
        {this.state.orderError && this.OrderErrorModal()}
        {this.state.showdeleteOrderModal && this.renderdeleteOrderIdsModal()}
        {this.renderSyncOrderModal()}
      </Page>
    );
  }

  OrderErrorModal() {
    return (
      <Modal
        title={<p>Errors in Order creation<sub>(Shopify response)</sub></p>}
        open={this.state.orderError}
        onClose={() => {
          this.setState({orderErrorJson:false,orderError:false})
        }}
      >
        <Modal.Section >
          <ReactJson  style={{maxHeight:200,overflowY:'scroll'}} src={this.state.orderErrorJson} />
        </Modal.Section>
      </Modal>
    );
  }


  redirect(url, data) {
    if ( !isUndefined(data) ) {
      this.props.history.push(
        url,
        JSON.parse(JSON.stringify(data))
      );
    } else {
      this.props.history.push(url);
    }
  }
}

export default Orders;
