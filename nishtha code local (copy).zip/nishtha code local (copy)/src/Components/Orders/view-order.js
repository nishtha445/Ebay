import React, {Component} from 'react';
import {
    Page,
    Card,
    Pagination,
    Select,
    PageActions,
    Thumbnail,
    Badge,
    Stack,
    Heading,
    DisplayText,
    FormLayout,
    Layout,
    Button, Collapsible,Banner,List
} from "@shopify/polaris";
import './order.css';
import { isUndefined } from 'util';
import SmartDataTable from "../../shared/smartTable";
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import {globalState} from "../../services/globalstate";
import * as queryString from "query-string";
import {ChevronDownMinor, ChevronRightMinor} from "@shopify/polaris-icons";

class ViewOrder extends Component {

    gridSettings = {
        activePage: 1,
        count: '5'
    };
    pageLimits = [
        {label: 5, value: '5'},
        {label: 10, value: '10'},
        {label: 15, value: '15'},
        {label: 20, value: '20'},
        {label: 25, value: '25'}
    ];
    mainorder_status=1;
    visibleColumns = ['source_item_id','title','mpn', 'total_price', 'quantity_ordered'];
    columnTitles = {
        source_item_id: {
            title: 'ID',
            sortable: false,
            type : 'int'
        },
        title: {
            title: 'Title',
            sortable: false,
            type : 'string'
        },
        mpn: {
            title: 'MPN',
            sortable: false,
            type : 'string'
        },
        total_price: {
            title: 'Price',
            sortable: false,
            type : 'int'
        },
        quantity_ordered: {
            title: 'Quantity',
            sortable: false,
            type : 'int'
        },
    };
    processing = ['Processing','Completed','Return'];
    constructor(props) {
        super(props);
        this.state = {
            showFulfillmentButton:false,
            activeMoreActions:false,
            OrderID:'',
            actual_data:{},
            entire_data:{},
            totalPage:0,
            shipping_details:{},
            payment_details:{},
            fulfillments:{},
            open:{
                fulfillments:false,
                payment_details:{
                    self:false,
                    pricing:false,
                    payment_methods:false,
                    billing_address:false,
                },
                shipping_details:{
                    self:false,
                    shipping_address:false
                }
            },

            fulfil:[],
            order: {
                source_order_id: '',
                paid_at:'',
                status:'',
                source:'',
            },
            client_details: {
                contact_email: '',
                browser_ip:''
            },
            item: []
        };
    }
    calculate_total_price(data) {
        let total_price=0;
        if('line_items' in data){
            if(Object.keys(data['line_items']).length!==0){
                Object.keys(data['line_items']).map(key=>{
                    total_price+=Number(data['line_items'][key]['total_price']);
                });
            }
        }
        total_price=/*total_price.toFixed(2)*/data['total_price'];
        return total_price;
    }

    componentDidMount(){
        this.getQueryparams()
    }
    getQueryparams(){
        let queryparams = queryString.parse(this.props.location.search);
        if(!isUndefined(queryparams['id'])) {
            this.state.OrderID = queryparams['id'];

        }else{
            this.redirect('/panel/orders');
        }
        this.setState(this.state);
        if(this.state.OrderID!=='') {
            this.getProducts()
        }
    }

    async updateOrderData(){
        let orderId = this.state.OrderID;
        let { success, message } = await requests.postRequest("ebayV1/upload/updateShopifySingleOrder", { _id : orderId} );
        if(success) notify.success(message);
        else notify.error(message);
    }

    getProducts() {
        requests.getRequest('connector/order/getOrderById?_id=' + this.state.OrderID).then(data => {
            if ( data.success ) {
                this.state.actual_data=Object.assign({},data.data);
                this.state.entire_data=data.data;
                this.setState(this.state);
                this.state.entire_data['total_price']=this.calculate_total_price(data.data);
                if ( !isUndefined(data.data['fulfillments'])
                    && typeof data.data['fulfillments'] === 'object'
                    && Object.keys(data.data['fulfillments']).length > 0 ) {
                    this.state.entire_data['status']=this.getStatus('fulfilled', data.data['financial_status'], data.data);
                    this.state.fulfil.push(data.data['fulfillments'][0]['tracking_company']);
                    this.state.fulfil.push(data.data['fulfillments'][0]['tracking_number']);
                } else {
                    this.state.entire_data['status']=this.getStatus(data.data['status'], data.data['financial_status'], data.data);
                }
                this.mainorder_status=data.data.status;
                this.modifyOrderData(data.data);
                this.extractShippingdetails(data.data);
                this.extractPricingdetails(data.data);
                this.extractFulfillments(data.data);
                this.setState(this.state);
            } else {
                notify.error(data.message);
            }
        });
    }

    extractFulfillments(data) {
        if (!isUndefined(data['fulfillments'])
            && typeof data['fulfillments'] === 'object'
            && Object.keys(data['fulfillments']).length > 0) {
            this.state.fulfillments = Object.assign({}, data['fulfillments'][0]);
            this.setState(this.state,()=>{
            });
        }
    }


    extractPricingdetails(data){
        let payment_method = {};
        let taxes_applied = [];
        if(!isUndefined(data.payment_method)){
            payment_method['payment_method']=!isUndefined(data.payment_method.payment_method)?data.payment_method.payment_method:'Not available';
            payment_method['billing_address']=!isUndefined(data.payment_method.billing_address)?Object.assign({},data.payment_method.billing_address):{};
        }
        if(!isUndefined(data.tax_lines)){
            Object.keys(data.tax_lines).map(sales_tax=>{
                taxes_applied.push({
                    title:data.tax_lines[sales_tax]['title'],
                    price:data.tax_lines[sales_tax]['price']
                })
            })
        }
        this.state.payment_details = {
            pricing_details:{
                price:this.state.entire_data.total_price,
                inclusive_tax:parseFloat(this.state.entire_data.total_tax).toFixed(2),
                total_price:this.state.entire_data.total_price
            },
            payment_method: payment_method['payment_method'],
            taxes_applied: taxes_applied.slice(0),
            billing_address: Object.assign({},payment_method['billing_address']),

        }
        this.setState(this.state,()=>{
        });
    }
    extractShippingdetails(data){
        let shipping_address = {};
        let shipping_services = {};
        if(!isUndefined(data.delivery_details)){
            shipping_address['shipping_address'] = {};
            shipping_address['shipping_address']['full_name'] = !isUndefined(data.delivery_details['full_name'])?data.delivery_details['full_name']:'Not available';
            shipping_address['shipping_address']['country'] = !isUndefined(data.delivery_details['country'])?data.delivery_details['country']:'Not available';
            shipping_address['shipping_address']['phone_number'] = !isUndefined(data.delivery_details['phone_number'])?data.delivery_details['phone_number']:'Not available';
            shipping_address['shipping_address']['zip_code'] = !isUndefined(data.delivery_details['zip'])?data.delivery_details['zip']:'Not available';
            shipping_address['shipping_address']['city'] = !isUndefined(data.delivery_details['city'])?data.delivery_details['city']:'Not available';
            shipping_address['shipping_address']['address1'] = !isUndefined(data.delivery_details['address1'])?data.delivery_details['address1']:'Not available';
            shipping_address['shipping_address']['address2'] = !isUndefined(data.delivery_details['address2'])?data.delivery_details['address2']:'Not available';
            if(data.hasOwnProperty('additional_data')
              && data['additional_data'].hasOwnProperty('MultiLegShippingDetails')
             && data['additional_data']['MultiLegShippingDetails'].hasOwnProperty('SellerShipmentToLogisticsProvider')
             && data['additional_data']['MultiLegShippingDetails']['SellerShipmentToLogisticsProvider'].hasOwnProperty('ShipToAddress')
             && data['additional_data']['MultiLegShippingDetails']['SellerShipmentToLogisticsProvider']['ShipToAddress'].hasOwnProperty('ReferenceID')
            ){
              shipping_address['shipping_address']['reference_id'] = data['additional_data']['MultiLegShippingDetails']['SellerShipmentToLogisticsProvider']['ShipToAddress']['ReferenceID'];
            }
        }
        if(!isUndefined(data.shipping_cost_details)){
            shipping_services['shipping_services']=Object.assign({},data.shipping_cost_details);
        }
        let tempObj = {...shipping_address, ...shipping_services};
        this.state.shipping_details = Object.assign({},tempObj);
        this.setState(this.state,()=>{
        })
    }


    getStatus = (status, financial_status, OtherDetails ={}) => {

        let react = <sapn/>;
        if(OtherDetails.hasOwnProperty("errors") || OtherDetails.target_order_id === ''){
            status = 'failed';
        }

        switch (financial_status) {
            case 'paid':  react = <Badge progress="complete" status="success">Paid</Badge>;break;
            default:react = <Badge>{financial_status}</Badge>;break;
        }

        if(status==='inProgress'){
            this.state.showFulfillmentButton=true;
            this.setState(this.state);
        }

        switch (status) {
            case 'pendingShipment': return <React.Fragment>{react}<Badge status={"info"} progress="partiallyComplete"> Pending Shipment </Badge></React.Fragment>;break;
            case 'canceled': return <React.Fragment>{react}<Badge status={"warning"} progress="complete">Canceled</Badge></React.Fragment>;break;
            case 'failed': return <React.Fragment>{react}<Badge status={"warning"} progress="complete">Failed</Badge></React.Fragment>;break;
            case 'fulfilled': return <React.Fragment>{react}<Badge status={"success"} progress="complete">Fulfilled</Badge></React.Fragment>;break;
            case 'inProgress': return <React.Fragment>{react}<Badge status={"attention"} progress="complete">in Progress</Badge></React.Fragment>;break;
            default: return <React.Fragment>{react}<Badge status={"attention"} progress="partiallyComplete">{status}</Badge></React.Fragment>;
        }
    };
    modifyOrderData(data) {

        let state = this.state;
        let arr = [];
        Object.keys(this.state.order).forEach(e => {
            if ( !isUndefined(data[e]) && data[e] !== null && data[e] !== '') {
              this.state.order[e] = e === 'paid_at'?(new Date(data[e])).toString():data[e];
            }
        });
        Object.keys(this.state.client_details).forEach(e => {
            if ( !isUndefined(data[e]) && data[e] !== null && data[e] !== '') {
                this.state.client_details[e] = data[e];
            } else { this.state.client_details[e] = 'Not Assign' }
        });
        if ( !isUndefined(data.line_items) ) {
            Object.keys(data.line_items).forEach(e => {
                arr.push({
                    source_item_id:!isUndefined(data.line_items[e]['source_item_id'])?data.line_items[e]['source_item_id']:'',
                    title:!isUndefined(data.line_items[e]['title'])?data.line_items[e]['title']:'',
                    mpn:!isUndefined(data.line_items[e]['mpn'])?data.line_items[e]['mpn']:'',
                    total_price:!isUndefined(data.line_items[e]['total_price'])?data.line_items[e]['total_price']:'',
                    quantity_ordered:!isUndefined(data.line_items[e]['quantity_ordered'])?data.line_items[e]['quantity_ordered']:'',
                    // all_data:!isUndefined(data.line_items[e])?data.line_items[e]:'',

                })
            });
            this.state.item = arr;
        }
        this.setState(this.state);
    }
    cancelcompleteorder(){
        this.redirect('/panel/orders/cancelmainorder?id='+this.state.OrderID);
    }
    fullfillorder(){
        let fullfilldata={};
        fullfilldata['order_id']= this.state.OrderID;
        fullfilldata['source']= this.state.entire_data.source;
        fullfilldata['merchant_id']= this.state.entire_data.merchant_id;
        fullfilldata['order_data']= this.state.entire_data;
        fullfilldata['shop_id']=this.state.entire_data['shop_id'];
        requests.postRequest('connector/order/fullfillOrder',fullfilldata).then(data=>{
            if(data.success===true)
            {
                notify.success(data.message);
            }
            else{
                notify.error(data.message);
            }
        })
    }
    operations = (data, event) => {
        switch (event) {
            case 'cancel':
                break;
            case 'ship':globalState.log('fullfill');
                globalState.log(this.state.OrderID);
                break;
        }
    };

    cancelOrder(){
        requests.getRequest('google/order/cancelOrder').then(data => {
// console.log(data);
        })
    }

    render_cancelOrder(){
        let temp=[]
        if('fulfillments' in this.state.entire_data)
        {
            return temp;
        }else{

            if(this.state.actual_data.status !=="canceled"){
                temp.push(
                    {content:'Cancel order',onAction: this.cancelcompleteorder.bind(this),destructive:true}
                );
            }
        }
        return temp;

    }

    cancelSync(){
        requests.getRequest('ebayV1/upload/syncCancellation',{order_id: this.state.entire_data.target_order_id}).then(data=>{
            if(data.success){
                notify.success(data.message);
            }else{
                notify.error(data.message);
            }
        })
    }

    hitSyncFulfillmemt(){
        requests.getRequest('ebayV1/upload/syncFulfillment', {order_id: this.state.entire_data.target_order_id}).then(data=>{
            if(data.success){
                notify.success(data.message);
            }else{
                notify.error(data.message);
            }
        })
    }

    toggleMoreActionsPopover = () => {
        this.setState(({active}) => {
            return {activeMoreActions: !active};
        });
    };

    getbillingaddress(data){
        let temparr=[];
        Object.keys(data).map(key => {
            temparr.push(
                <Card.Section title={key.replace("_"," ")}>
                    <p>{data[key]}</p>
                </Card.Section>
            )
        });
        return temparr;
    }

    getshippingaddress(data){
        let temparr=[];
        Object.keys(data).map(key => {
            temparr.push(
                <Card.Section title={key.replace("_"," ")}>
                    <p>{data[key]}</p>
                </Card.Section>
            )
        });
        return temparr;
    }

    gettaxesApplied(data){
        let temparr =[];
        data.forEach((taxes,index)=>{
            temparr.push(
                <List.Item>{taxes.title}</List.Item>
            );
        })

        return <List>{temparr}</List>
    }

    getPaymentDetails(){
        let temparr =[];
        Object.keys(this.state.payment_details).map(key=>{
            switch(key){
                case 'pricing_details':
                    temparr.push(
                        <Card.Section title={key.replace("_"," ")}>
                            <Stack vertical={true} spacing={"tight"}>
                                <Stack distribution={"equalSpacing"}>
                                    <p style={{fontSize:'1.5rem'}}>Price</p>
                                    <p style={{fontSize:'1.3rem'}}>{this.state.entire_data.total_price}</p>
                                </Stack>
                                <Stack distribution={"equalSpacing"}>
                                    <p style={{fontSize:'1.5rem'}}>Inclusive tax</p>
                                    <p style={{fontSize:'1.3rem'}}>{parseFloat(this.state.entire_data.total_tax).toFixed(2)}</p>
                                </Stack>
                            </Stack>
                        </Card.Section>
                    );
                    break;
                case 'payment_method':
                    temparr.push(
                        <Card.Section title={key.replace("_"," ")}>
                            <p>
                                {
                                    this.state.payment_details[key]
                                }
                            </p>
                        </Card.Section>
                    );
                    break;
                case 'billing_address':
                    temparr.push(
                        <Card.Section>
                            <div style={{cursor:'pointer'}} onClick={(e)=>{
                                this.state.open.payment_details.billing_address = !this.state.open.payment_details.billing_address;
                                this.setState(this.state);
                                e.stopPropagation();
                            }} ariaExpanded={this.state.open.payment_details.billing_address}>
                                <Card title={<p style={{fontSize:'1.2rem',paddingBottom:'2rem'}}><b>{key.replace("_"," ").toUpperCase()}</b></p>} actions={[{content:<Button plain icon={this.state.open.payment_details.billing_address?ChevronDownMinor:ChevronRightMinor}/>}]}>
                                    <Collapsible open={this.state.open.payment_details.billing_address} id={"billing_address"}>
                                        <Card>
                                            {
                                                this.getbillingaddress(this.state.payment_details[key])
                                            }
                                        </Card>
                                    </Collapsible>
                                </Card>
                            </div>
                        </Card.Section>
                    );
                    break;
                case 'taxes_applied':
                    temparr.push(
                        <Card.Section title={key.replace("_"," ")}>
                            {
                                this.gettaxesApplied(this.state.payment_details[key])
                            }
                        </Card.Section>
                    );
                    break;
            }
        });
        return temparr;
    }

    getFulfillmentsDetails(){
        let temparr=[];
        Object.keys(this.state.fulfillments).map(key=>{

            if(key === 'tracking_company' || key === 'tracking_number'  || key === 'updated_at' || key === 'created_at') {
                temparr.push(
                    <Card.Section title={key.replace("_"," ")}>
                        <p>
                            {
                                this.state.fulfillments[key]
                            }
                        </p>
                    </Card.Section>
                )
            }
        });
        if(temparr.length === 0){
            temparr.push(
                <Card.Section>
                    <Banner status={"info"}>
                        No fulfillment details found
                    </Banner>
                </Card.Section>
            )
        }
        return temparr;
    }

    getShippingdetails(){
        let temparr=[];
        Object.keys(this.state.shipping_details).map(key=>{
            switch(key){
                case 'shipping_services':
                    temparr.push(
                        <Card.Section title={key.replace('_'," ")}>
                            <Stack vertical={true}>
                            <Stack distribution={"equalSpacing"}>
                                <p style={{fontSize:'1.35rem'}}>Service</p>
                                <p style={{fontSize:'1.3rem'}}>{this.state.shipping_details[key].title}</p>
                            </Stack>
                            <Stack distribution={"equalSpacing"}>
                                <p style={{fontSize:'1.35rem'}}>Cost</p>
                                <p style={{fontSize:'1.3rem'}}>{this.state.shipping_details[key].cost}</p>
                            </Stack>
                            </Stack>
                        </Card.Section>
                    );
                    break;
                case 'shipping_address':
                    temparr.push(
                        <Card.Section>
                            <div style={{cursor:'pointer'}} onClick={(e)=>{
                                this.state.open.shipping_details.shipping_address = !this.state.open.shipping_details.shipping_address;
                                this.setState(this.state);
                                e.stopPropagation();
                            }} ariaExpanded={this.state.open.shipping_details.shipping_address}>
                                <Card title={<p style={{fontSize:'1.2rem',paddingBottom:'2rem'}}><b>{key.replace("_"," ").toUpperCase()}</b></p>} actions={[{content:<Button plain icon={this.state.open.shipping_details.shipping_address?ChevronDownMinor:ChevronRightMinor}/>}]}>
                                    <Collapsible open={this.state.open.shipping_details.shipping_address} id={"shipping_address"}>
                                        <Card>
                                            {
                                                this.getshippingaddress(this.state.shipping_details[key])
                                            }
                                        </Card>
                                    </Collapsible>
                                </Card>
                            </div>
                        </Card.Section>
                    );
                    break;
            }
        })
        temparr.push()

        return temparr;
    }

    renderMiddleOrderView(){
        let temparr = [];
        if(!isUndefined(this.state.payment_details)){

            temparr.push(
                <div style={{marginTop:'1rem',marginBottom:'1rem'}}>
                    <React.Fragment key='payment_details' >
                        <div style={{cursor:'pointer'}} onClick={()=>{
                            this.state.open.payment_details.self = !this.state.open.payment_details.self;
                            this.setState(this.state);
                        }} ariaExpanded={this.state.open.payment_details.self}>
                            <Card title={<p style={{fontSize:'1.6rem',paddingBottom:'2rem'}}><b>Payment details</b></p>} actions={[{content:<Button plain icon={this.state.open.payment_details.self?ChevronDownMinor:ChevronRightMinor}/>}]}>
                                <Collapsible open={this.state.open.payment_details.self} id={"payment_details"}>
                                    <Card>
                                        {
                                            this.getPaymentDetails()
                                        }
                                    </Card>
                                </Collapsible>
                            </Card>
                        </div>
                    </React.Fragment>
                </div>
            )

        }
        if(!isUndefined(this.state.shipping_details)){
            temparr.push(
                <div style={{marginTop:'1rem',marginBottom:'1rem'}}>
                    <React.Fragment key='shipping_details' >
                        <div style={{cursor:'pointer'}} onClick={()=>{
                            this.state.open.shipping_details.self = !this.state.open.shipping_details.self;
                            this.setState(this.state);
                        }} ariaExpanded={this.state.open.shipping_details.self}>
                            <Card title={<p style={{fontSize:'1.6rem',paddingBottom:'2rem'}}><b>Shipping details</b></p>} actions={[{content:<Button plain icon={this.state.open.shipping_details.self?ChevronDownMinor:ChevronRightMinor}/>}]}>
                                <Collapsible open={this.state.open.shipping_details.self} id={"payment_details"}>
                                    <Card>
                                        {
                                            this.getShippingdetails()
                                        }
                                    </Card>
                                </Collapsible>
                            </Card>
                        </div>
                    </React.Fragment>
                </div>
            )

        }
        if(!isUndefined(this.state.fulfillments)){
            temparr.push(
                <div style={{marginTop:'1rem',marginBottom:'1rem'}}>
                    <React.Fragment key='fulfillments' >
                        <div style={{cursor:'pointer'}} onClick={()=>{
                            this.state.open.fulfillments = !this.state.open.fulfillments;
                            this.setState(this.state);
                        }} ariaExpanded={this.state.open.fulfillments}>
                            <Card title={<p style={{fontSize:'1.6rem',paddingBottom:'2rem'}}><b>Fulfillments</b></p>} actions={[{content:<Button plain icon={this.state.open.fulfillments?ChevronDownMinor:ChevronRightMinor}/>}]}>
                                <Collapsible open={this.state.open.fulfillments} id={"fulfillments"}>
                                    <Card>
                                        {
                                            this.getFulfillmentsDetails()
                                        }
                                    </Card>
                                </Collapsible>
                            </Card>
                        </div>
                    </React.Fragment>
                </div>
            )
        }

        return temparr;
    }

    render() {
        const tabs = [
            {
              id: 'order timeline',
              content: (
                  <Stack spacing="extraTight">
                 <p>Order Timeline</p>
                </Stack>         
              ),
            },
            {
              id: 'account details',
              content:  (
              
                <Stack spacing="extraTight">
               <p> Account Details</p>
               </Stack>
             
            ),
            },
            {
              id: 'line orders',
              content:  (
              
                <Stack spacing="extraTight">
               <p>Line Orders</p>
              </Stack>
             
            ),
            },
            {
              id: 'payment details',
              content: (
              
                <Stack spacing="extraTight">
               <p>Payment Details</p>
                </Stack>
             
            ),
            },
          
            {
              id: 'shipping details',
              content:  (
              
                <Stack spacing="extraTight">
               <p>Shipping Details</p>
              </Stack>
             
            ),
            },
            {
              id: 'fulfillments',
              content:  (
              
                <Stack spacing="extraTight">
               <p>Fullfillments</p>
                </Stack>
             
            ),
            },
      
          ];
        return (
            <Page fullWidth={true} title={'View Order'} breadcrumbs={[{content: 'Orders', onAction:this.redirect.bind(this,'/panel/orders')}]}
                /* primaryAction={ this.state.showFulfillmentButton?{content:'Sync shipment', onAction:this.hitSyncFulfillmemt.bind(this)}:{}}*/
                secondaryActions={[{content:<Badge status={"info"}><b style={{color:'#0000aa', textDecoration:'underline'}}>Need help?</b></Badge>,onAction:()=>{
                    window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=ord-det','_blank')
                }}]}

                  actionGroups={(this.state.actual_data.status==="inProgress" && this.state.entire_data.target_order_id!=='')|| true?[
                      {
                          title: 'More actions',
                          actions: [ 
                            //   { content : 'Update order', onAction: this.updateOrderData.bind(this)},
                              {content: 'Sync cancellation', onAction:this.cancelSync.bind(this)},this.state.showFulfillmentButton || true?{content:'Sync shipment', onAction:this.hitSyncFulfillmemt.bind(this)}:{}],
                      },
                  ]:[]}
                  titleMetadata={this.state.entire_data.status}
                /* primaryAction={ Object.keys(this.state.actual_data).length>0?this.render_cancelOrder():[]}*/
            >
                
                <FormLayout>
                    <Layout>
                        <Layout.Section twoThird>
                            <Card title={'Order timeline'}>
                                <Card.Section>
                                    <FormLayout>
                                        <Stack distribution={"equalSpacing"}>
                                            <Heading element={"p"}>Order id</Heading>
                                            <p style={{fontSize:'1.3rem'}}>{this.state.order.source_order_id}</p>
                                        </Stack>
                                        <Stack distribution={"equalSpacing"}>
                                            <Heading element={"p"}>Order placed at</Heading>
                                            <p style={{fontSize:'1.3rem'}}>{this.state.order.paid_at}</p>
                                        </Stack>
                                        {/*<Stack distribution={"equalSpacing"}>*/}
                                        {/*<Heading element={"p"}>Order status</Heading>*/}
                                        {/*<p style={{fontSize:'1.3rem'}}>{this.state.entire_data.status}</p>*/}
                                        {/*</Stack>*/}
                                        <Stack distribution={"equalSpacing"}>
                                            <Heading element={"p"}>Purchased from</Heading>
                                            <p style={{fontSize:'1.3rem'}}>{this.state.order.source}</p>
                                        </Stack>
                                        <Stack distribution={"equalSpacing"}>
                                            <Heading element={"p"}>Line items ordered</Heading>
                                            <p style={{fontSize:'1.3rem'}}>{Object.keys(this.state.entire_data).length!==0?Object.keys(this.state.entire_data['line_items']).length:null}</p>
                                        </Stack>
                                      <Stack distribution={"equalSpacing"}>
                                        <Heading element={"p"}>eBay reference Id</Heading>
                                        <p style={{fontSize:'1.3rem'}}>{Object.keys(this.state.entire_data).length!==0 && !isUndefined(this.state.entire_data['additional_data']) && !isUndefined(this.state.entire_data['additional_data']['ExtendedOrderID'])?this.state.entire_data['additional_data']['ExtendedOrderID']:'Not available'}</p>
                                      </Stack>
                                    </FormLayout>
                                </Card.Section>
                            </Card>
                        </Layout.Section>
                        <Layout.Section oneThird>
                            <FormLayout>
                                <Card title={'Account details'} actions={[{content:<img  style={{height:'35px',width:'35px'}} src={require("../../assets/img/user.png")}/>}]}>
                                    <Card.Section title={'Customer'}>
                                        {Object.keys(this.state.entire_data).length!==0?this.state.entire_data.client_details.name:null}
                                    </Card.Section>
                                    <Card.Section title={'Contact information'}>
                                        {Object.keys(this.state.entire_data).length!==0?this.state.entire_data.client_details['contact_email']:null}
                                    </Card.Section>
                                </Card>
                            </FormLayout>
                        </Layout.Section>

                    </Layout>
                    <Layout>
                        <Layout.Section>
                            <Card title='Line orders'>

                                <Card.Section>
                                    <SmartDataTable
                                        data={this.state.item}
                                        uniqueKey="sku"
                                        columnTitles={this.columnTitles}
                                        className='ui compact selectable table'
                                        showViewColumns={false}
                                        ViewColumnsHide={true}
                                        withLinks={true}
                                        vieworderaction={false}
                                        operations={this.operations}
                                        customButton={this.customButton}
                                        hideResetFilter={true}
                                        visibleColumns={this.visibleColumns}
                                        getVisibleColumns={(event) => {
                                            this.visibleColumns = event;
                                        }}
                                        sortable
                                    />
                                    {/*<Stack vertical={false} distribution={"center"}>*/}
                                        {/*<Pagination*/}
                                            {/*hasPrevious={1 < this.gridSettings.activePage}*/}
                                            {/*onPrevious={() => {*/}
                                                {/*this.gridSettings.activePage--;*/}
                                                {/*this.getProducts();*/}
                                            {/*}}*/}
                                            {/*hasNext={this.state.totalPage/this.gridSettings.count > this.gridSettings.activePage}*/}
                                            {/*onNext={() => {*/}
                                                {/*this.gridSettings.activePage++;*/}
                                                {/*this.getProducts();*/}
                                            {/*}}*/}
                                        {/*/>*/}
                                        {/*<Select*/}
                                            {/*options={this.pageLimits}*/}
                                            {/*value={this.gridSettings.count}*/}
                                            {/*onChange={this.pageSettingsChange.bind(this)}>*/}
                                        {/*</Select>*/}

                                    {/*</Stack>*/}
                                </Card.Section>

                            </Card>
                        </Layout.Section>
                    </Layout>
                    <FormLayout>
                        <FormLayout.Group>
                            {
                                this.renderMiddleOrderView()
                            }
                        </FormLayout.Group>
                    </FormLayout>



                </FormLayout>
            </Page>
        );
    }
    pageSettingsChange(event) {
        this.gridSettings.count = event;
        this.gridSettings.activePage = 1;
        this.getProducts();
    }
    redirect(url) {
        if ( !isUndefined(this.props.location.state) && Object.keys(this.props.location.state).length > 0 ) {
            this.props.history.push(url, JSON.parse(JSON.stringify(this.props.location.state)))
        } else {
            this.props.history.push(url);
        }
    }
}

export default ViewOrder;
