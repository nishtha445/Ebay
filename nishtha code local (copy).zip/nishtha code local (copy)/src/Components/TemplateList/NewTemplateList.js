import React, { Component } from 'react';
import {
    EditMinor
} from '@shopify/polaris-icons';
import {
    Page,
    Layout,
    Card,
    Stack,
    Button,
    Collapsible,
    Heading,
    FormLayout,
    FooterHelp,
    Link,
    Icon,
    Banner,
    Badge,
    Tooltip, TextField,
    Modal, TextContainer, EmptyState
} from "@shopify/polaris";
import { requests } from "../../services/request";
import { isUndefined } from "util";
//import SimpleCrypto from "simple-crypto-js";
import { notify } from "../../services/notify";
import Skeleton from "../../shared/skeleton";
import Grid from '../../Subcomponents/Aggrid/grid'
import { attachCountTabTitle, extractValuesfromRequest, getTypeoftabs, gridPropColumns, templatetabs } from './templateHelper';
import {
    AddMajorMonotone
} from '@shopify/polaris-icons';
import LoadingOverlay from 'react-loading-overlay';
import ReactJson from 'react-json-view';
import CustomNoRowsOverlay from '../../Subcomponents/Aggrid/CustomNoRowsOverlay';

let gridApi = '';

const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');
let deleteModalShow = false;
let deleteProfileId = '';
let deleteProfileIDKey = '';
let defaultConfig = {};

let deleteNotSafe_data = {};
let deleteNotSafeModal = false;
class NewTemplateList extends Component {
    // grid_loader = false;

    constructor(props) {
        super(props);
        this.state = {
            category: {
                heading: 'Category Templates',
                options: false,
                show: false,
                delete_heading: 'Category Template',
                key_word: 'category_template'
            },

            inventory: {
                heading: 'Inventory Templates',
                options: false,
                show: false,
                delete_heading: 'Inventory Template',
                key_word: 'inventory_template'
            },
            price: {
                heading: 'Pricing Templates',
                options: false,
                show: false,
                delete_heading: 'Pricing Template',
                key_word: 'price_template'
            },
            title: {
                heading: 'Title Templates',
                options: false,
                show: false,
                delete_heading: 'Title Template',
                key_word: 'title_template'
            },

            // utkarsh
            tabs: templatetabs,
            selectedTab: 0,
            columnsAG: gridPropColumns(this.incellElement.bind(this)),
            rowsAG: [],
            all_rows: [],
            grid_loader: false,
            previewModal: false,
            jsonViewStructure: {},
            frameworkComponents: {
                customNoRowsOverlay: CustomNoRowsOverlay,
            },
            noRowsOverlayComponent: 'customNoRowsOverlay',
            noRowsOverlayComponentParams: {
                noRowsMessageFunc: () => <EmptyState heading="No Templates Found"
                // image="https://cdn.shopify.com/s/assets/admin/empty-states-fresh/emptystate-abandoncheckout-de95c7af243bfbc1a127a7bd1a6a9b7a5769ddc295a303268fdf26913f16801c.svg"
                >
            </EmptyState>,
            },
        };
        // this.getBusinessPolicy();
    }
    skeleton_Check = true;
    textSearchValue = {
        title: '',
        pricing: '',
        inventory: '',
        category: ''
    };
    template_options = {
        title: [],
        pricing: [],
        inventory: [],
        category: [],
    };


    componentDidMount() {
        this.getAllGlobalConfig();
        document.title = 'Create/Edit templates on eBay Marketplace Integration - CedCommerce';
        document.description = 'Users can create or edit Title, Inventory, Price & Category Templates to make selling on eBay automated.';
        if (!document.title.includes(localStorage.getItem('shop_url'))) {
            document.title += !isUndefined(localStorage.getItem('shop_url')) ? " " + localStorage.getItem('shop_url') : "";
        }
    }

    getAllGlobalConfig() {
        requests.getRequest('ebayV1/get/globalConfigData').then(data => {
            if (data.success) {
                defaultConfig = Object.assign({}, data.data);
                this.getBusinessPolicy();
            }
        });
    }

    renderPreviewModal() {
        let { previewModal, jsonViewStructure } = this.state;
        return (
            <Modal
                open={previewModal}
                onClose={() => {
                    this.setState({ previewModal: false })
                }}
                title="Profile Preview"
            >
                <Modal.Section>
                    <ReactJson src={jsonViewStructure} theme={"monokai"} />
                </Modal.Section>
            </Modal>

        );
    }

    getBusinessPolicy() {
        // requests.postRequest('ebayV1/template/get',{fullData:true}).then(data => {
        this.state.grid_loader = true;
        this.updateState();
        requests.postRequest('ebayV1/template/get', { multitype: ['category', 'price', 'inventory', 'title'] }).then(data => {
            if (data.success) {
                // this.createDropdownData(data.data);
                let { tabs } = this.state;

                let rows = data.data;
                let extractRowData = extractValuesfromRequest(rows, defaultConfig);
                tabs = [...attachCountTabTitle(tabs, 'all', rows)];
                tabs = [...attachCountTabTitle(tabs, 'category', rows)];
                tabs = [...attachCountTabTitle(tabs, 'title', rows)];
                tabs = [...attachCountTabTitle(tabs, 'price', rows)];
                tabs = [...attachCountTabTitle(tabs, 'inventory', rows)];
                this.setState({ all_rows: [...extractRowData], rowsAG: [...extractRowData], tabs, selectedTab: 0 }, () => {
                    // console.log('tabs', this.state.tabs)
                    this.tabSelected(0);
                });
                // console.log('extractRowData', extractRowData);
                this.skeleton_Check = false;
                this.setState(this.state)
                this.state.grid_loader = false;
                this.updateState();
            }
        })
    }

    createDropdownData(data) {
        let title_dropdown_options = [];
        let category_dropdown_options = [];
        let inventory_dropdown_options = [];
        let pricing_dropdown_options = [];
        data.forEach((obj, index) => {
            switch (obj.type) {
                case 'title':
                    // if(!isUndefined(obj.data))
                    // {
                    if (defaultConfig['title_template'] && (obj._id).toString() === defaultConfig['title_template']) {
                        title_dropdown_options.push(
                            { label: <React.Fragment>{obj.title}<Badge status={"attention"}>Default</Badge></React.Fragment>, value: (obj._id).toString(), default: true, textValue: obj.title }
                        );
                    } else {
                        title_dropdown_options.push(
                            { label: obj.title, value: (obj._id).toString(), default: false }
                        );
                    }
                    // }
                    break;
                case 'inventory':
                    // if(!isUndefined(obj.data))
                    // {
                    if (defaultConfig['inventory_template'] && (obj._id).toString() === defaultConfig['inventory_template']) {
                        inventory_dropdown_options.push(
                            { label: <React.Fragment>{obj.title}<Badge status={"attention"}>Default</Badge></React.Fragment>, value: (obj._id).toString(), default: true, textValue: obj.title }
                        );
                    } else {
                        inventory_dropdown_options.push(
                            { label: obj.title, value: (obj._id).toString(), default: false }
                        );
                    }
                    // }
                    break;
                case 'category':
                    // if(!isUndefined(obj.data))
                    // {
                    if (defaultConfig['category_template'] && (obj._id).toString() === defaultConfig['category_template']) {
                        category_dropdown_options.push(
                            { label: <React.Fragment>{obj.title}<Badge status={"attention"}>Default</Badge></React.Fragment>, value: (obj._id).toString(), default: true, textValue: obj.title }
                        );
                    } else {
                        category_dropdown_options.push(
                            { label: obj.title, value: (obj._id).toString(), default: false }
                        );
                    }
                    // }
                    break;
                case 'price':
                    // if(!isUndefined(obj.data))
                    // {
                    if (defaultConfig['price_template'] && (obj._id).toString() === defaultConfig['price_template']) {
                        pricing_dropdown_options.push(
                            { label: <React.Fragment>{obj.title}<Badge status={"attention"}>Default</Badge></React.Fragment>, value: (obj._id).toString(), default: true, textValue: obj.title }
                        );
                    } else {
                        pricing_dropdown_options.push(
                            { label: obj.title, value: (obj._id).toString(), default: false }
                        );
                    }
                    // }
                    break;

            }
        });
        // console.log(category_dropdown_options);
        if (title_dropdown_options.length !== 0) {
            this.state.title.options = title_dropdown_options.slice(0);
            this.template_options.title = title_dropdown_options.slice(0);
        }
        else {
            this.state.title.options = false;
            this.template_options.title = [];
        }
        if (pricing_dropdown_options.length !== 0) {
            this.state.pricing.options = pricing_dropdown_options.slice(0);
            this.template_options.pricing = pricing_dropdown_options.slice(0);
        }
        else {
            this.state.pricing.options = false;
            this.template_options.pricing = [];
        }
        if (inventory_dropdown_options.length !== 0) {
            this.state.inventory.options = inventory_dropdown_options.slice(0);
            this.template_options.inventory = inventory_dropdown_options.slice(0);
        }
        else {
            this.state.inventory.options = false;
            this.template_options.inventory = [];
        }
        if (category_dropdown_options.length !== 0) {
            this.state.category.options = category_dropdown_options.slice(0);
            this.template_options.category = category_dropdown_options.slice(0);
        }
        else {
            this.state.category.options = false;
            this.template_options.category = [];
        }
        this.skeleton_Check = false;
        this.setState(this.state);
    }


    // utkarsh

    tabSelected(tabs) {
        this.setState({ selectedTab: tabs }, () => {
            this.filterTabProducts();
        });
    }

    filterTabProducts() {
        let { selectedTab, all_rows, rowsAG } = this.state;
        let getType = getTypeoftabs(selectedTab);
        // let rows;
        if (getType !== 'all') {
            rowsAG = all_rows.filter(data => data.type === getType);
        } else {
            rowsAG = all_rows.slice(0);
        }
        this.setState({ rowsAG });
    }

    async incellElement(field, data) {
        // console.log('incellElement', data);
        let { id: value, type: key } = data;
        switch (field) {
            case 'preview':
                requests.getRequest('ebayV1/get/template', { template_id: data.name.title._id }).then(data => {
                    if (data.success) {
                        if (!isUndefined(data.data.data)) {
                            this.setState({
                                previewModal: true,
                                jsonViewStructure: data.data.data
                            })
                        }
                    }
                })

                // this.setState({
                //     previewModal: true,
                //     jsonViewStructure: data.name.title
                // })
                break;
            case 'edit':
                let tempObj = { display: key, id: value.toString(), type: 'Template' }
                let message = cryptr.encrypt(JSON.stringify(tempObj));
                this.redirect('/panel/template/modifier?message=' + encodeURI(message));
                break;
            case 'delete':
                deleteProfileId = value;
                deleteProfileIDKey = key;
                deleteModalShow = true;
                this.setState(this.state);
            default: break;
        }
    }

    getGridApi(api) {
        gridApi = api;
    }
    newRenderTemplateList() {
        let { columnsAG, rowsAG, tabs, selectedTab, grid_loader } = this.state;
        return (
            <LoadingOverlay
                active={grid_loader}
                spinner
                text='Loading please wait...'
            ><Grid
                    tag={'Template(s)'}
                    columns={columnsAG}
                    rows={rowsAG}
                    showTabs={true}
                    tabs={tabs}
                    selectedTab={selectedTab}
                    tabSelected={this.tabSelected.bind(this)}
                    getGridApi={this.getGridApi.bind(this)}
                    // suppressSizeToFit={true}
                    suppressMovableColumns={true}
                    suppressRowClickSelection={true}
                    enableCellTextSelection={true}
                    // rowSelection={"multiple"}
                    // cellClickedEvent={this.cellClickedEvent.bind(this)}
                    frameworkComponents={this.state.frameworkComponents}
                    noRowsOverlayComponent={this.state.noRowsOverlayComponent}
                    noRowsOverlayComponentParams={
                        this.state.noRowsOverlayComponentParams
                    }
                />
            </LoadingOverlay>
        )
    }

    render() {
        let { previewModal } = this.state;
        return (
            <Page
                fullWidth={true}
                title={'Templates'}
                titleMetadata={<p style={{ cursor: 'pointer' }} onClick={() => {
                    window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=tmpltee', '_blank')
                }}><Badge status={"info"}><b style={{ color: '#0000aa', textDecoration: 'underline' }}>Need help?</b></Badge></p>}
                actionGroups={[
                    {
                        title: 'Add templates',
                        icon: AddMajorMonotone,
                        actions: [
                            {
                                content: 'Category', icon: AddMajorMonotone, onAction: () => {
                                    let key = 'category';
                                    let tempObj = { display: key, type: 'Template' }
                                    let message = cryptr.encrypt(JSON.stringify(tempObj));
                                    this.redirect('/panel/template/modifier?message=' + encodeURI(message));
                                }
                            },
                            {
                                content: 'Inventory', icon: AddMajorMonotone, onAction: () => {
                                    let key = 'inventory';
                                    let tempObj = { display: key, type: 'Template' }
                                    let message = cryptr.encrypt(JSON.stringify(tempObj));
                                    this.redirect('/panel/template/modifier?message=' + encodeURI(message));
                                }
                            },
                            {
                                content: 'Pricing', icon: AddMajorMonotone, onAction: () => {
                                    let key = 'pricing';
                                    let tempObj = { display: key, type: 'Template' }
                                    let message = cryptr.encrypt(JSON.stringify(tempObj));
                                    this.redirect('/panel/template/modifier?message=' + encodeURI(message));
                                }
                            },
                            {
                                content: 'Title', icon: AddMajorMonotone, onAction: () => {
                                    let key = 'title';
                                    let tempObj = { display: key, type: 'Template' }
                                    let message = cryptr.encrypt(JSON.stringify(tempObj));
                                    this.redirect('/panel/template/modifier?message=' + encodeURI(message));
                                }
                            },
                        ],
                    }
                ]}
            >
                <Banner status={"info"}>
                    <b>Templates</b> are used while updating or creating the listings on eBay with a set of attributes related to inventory, price, title, and category.
                </Banner>
                <br />
                {
                    // (this.skeleton_Check) ? <Skeleton case="templates" /> :
                    this.newRenderTemplateList()
                    // this.renderTemplateList()
                }
                {deleteModalShow && this.renderDeletePolicyModal()}
                {deleteNotSafeModal && this.renderDeleteNotsafeModal()}
                {previewModal && this.renderPreviewModal()}
                <FooterHelp>
    Learn more about{' '}
    <Link external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=tmpltee">
    Templates
    </Link>
  </FooterHelp>
            </Page>
        );
    }
    handleToggleClick = (Key) => {

        this.state[Key].show = !this.state[Key].show;
        this.textSearchValue[Key] = '';
        this.setState(this.state);
        this.handleSearchProfile(Key, '');

    };

    redirect(url) {

        this.props.history.push(url);
    }
    createNew(key) {
        let tempObj = { display: key, type: 'Template' }
        let message = cryptr.encrypt(JSON.stringify(tempObj));
        this.redirect('/panel/template/modifier?message=' + encodeURI(message));
    }

    getDeleteModalContent() {

        let tempArr = [];
        if (defaultConfig[this.state[deleteProfileIDKey].key_word] && defaultConfig[this.state[deleteProfileIDKey].key_word] === deleteProfileId) {
            tempArr.push(
                <Stack vertical={true} alignment={"center"} distribution={"center"}>
                    <p className="text-center">
                        Selected template is a <b>Default {deleteProfileIDKey} template</b>, Delete operation is not allowed for a default template.
                    </p>
                    <p className="text-center">For enabling delete operation , set another template as default {deleteProfileIDKey} template from the <b>Configuration section</b> and retry.</p>
                    <Button primary={true} disabled={true} onClick={
                        this.actionPerform.bind(this, 'delete', deleteProfileIDKey, deleteProfileId)
                    }>
                        Yes
                    </Button>
                </Stack>
            )
        }
        else {
            tempArr.push(
                <Stack vertical={true} alignment={"center"}>
                    <p>
                        Are you sure, you want to delete this {this.state[deleteProfileIDKey].delete_heading}?
                    </p>
                    <Button primary={true} onClick={
                        this.actionPerform.bind(this, 'delete', deleteProfileIDKey, deleteProfileId)
                    }>
                        Yes
                    </Button>
                </Stack>
            )
        }

        return tempArr;
    }

    newgetDeleteModalContent() {
        let tempArr = [];
        let { deleteTemplateLoader } = this.state;
        if (defaultConfig[this.state[deleteProfileIDKey].key_word] && defaultConfig[this.state[deleteProfileIDKey].key_word] == deleteProfileId) {
            tempArr.push(
                <Stack vertical={true} alignment={"center"} distribution={"center"}>
                    <p className="text-center">
                        Selected template is a <b>Default {deleteProfileIDKey} template</b>, Delete operation is not allowed for a default template.
                    </p>
                    <p className="text-center">For enabling delete operation , set another template as default {deleteProfileIDKey} template from the <b>Configuration section</b> and retry.</p>
                    <Button primary={true} disabled={true} onClick={
                        this.actionPerform.bind(this, 'delete', deleteProfileIDKey, deleteProfileId)
                    }>
                        Yes
                    </Button>
                </Stack>
            )
        }
        else {
            tempArr.push(
                <Stack vertical={true} alignment={"center"}>
                    <p>
                        Are you sure, you want to delete this {this.state[deleteProfileIDKey].delete_heading}?
                    </p>
                    <Button primary={true} loading={deleteTemplateLoader} onClick={
                        this.actionPerform.bind(this, 'delete', deleteProfileIDKey, deleteProfileId)
                    }>
                        Yes
                    </Button>
                </Stack>
            )
        }
        return tempArr;
    }
    renderDeletePolicyModal() {
        return (

            <Modal
                open={deleteModalShow}
                onClose={() => {
                    deleteModalShow = false;
                    deleteProfileIDKey = '';
                    deleteProfileId = '';
                    this.setState(this.state);
                }}
                title="Permission required"
            >
                <Modal.Section>
                    <TextContainer>
                        {
                            // this.getDeleteModalContent()
                            this.newgetDeleteModalContent()
                        }
                    </TextContainer>
                </Modal.Section>
            </Modal>

        );
    }

    renderDeleteNotsafeModal() {
        return (
            <Modal
                open={deleteNotSafeModal}
                onClose={() => {
                    deleteNotSafeModal = false;
                    deleteNotSafe_data = {};
                    this.setState(this.state);
                }}
                title="Deletion is Prohibited"
            >
                <Modal.Section>
                    <TextContainer>
                        {
                            this.getDeleteNotsafeContent()
                        }
                    </TextContainer>
                </Modal.Section>
            </Modal>

        );
    }

    getDeleteNotsafeContent() {
        let tempObj = Object.assign({}, deleteNotSafe_data);
        let tempText = 'Template is included in ' + tempObj['template_in_profile'] + ' profile(s).';
        if (!isUndefined(tempObj['profile_in_uploaded'])) {
            tempText += ' These profile(s) are used to upload ' + tempObj['profile_in_uploaded'] + ' product(s)';
        }
        return <Banner status={"warning"} title={'Warning'}>
            {tempText}
        </Banner>;
    }

    resetModalDefaults() {
        deleteModalShow = false;
        deleteProfileIDKey = '';
        deleteProfileId = '';
        this.setState(this.state);
    }

    handleSearchProfile(key, value) {
        this.textSearchValue[key] = value;
        this.updateState();
        this.filterOptions(key, value);
    }

    filterOptions(key, search) {
        let temparr = [];
        if (this.state[key].options) {
            if (search !== '') {
                this.template_options[key].forEach((option, index) => {
                    if (option.default === false && ((option.label).toLowerCase()).includes(search.toLowerCase())) {
                        temparr.push(option);
                    } else {
                        if (option.default && ((option.textValue).toLowerCase()).includes(search.toLowerCase())) {
                            temparr.push(option);
                        }
                    }
                })
            } else {
                temparr = this.template_options[key];
            }
        }
        if (temparr.length === 0) {
            if (this.template_options[key].length !== 0) {
                this.state[key].options = [];
            } else {
                this.state[key].options = false;
            }

        } else {
            this.state[key].options = temparr.slice(0);
        }

        this.updateState();

    }
    updateState() {
        const state = this.state;
        this.setState(state);
    }

    actionPerform(action, key, value) {
        switch (action) {
            case 'edit':
                let tempObj = { display: key, id: value, type: 'Template' }
                let message = cryptr.encrypt(JSON.stringify(tempObj));
                this.redirect('/panel/template/modifier?message=' + encodeURI(message));
                break;
            case 'delete':
                let { deleteTemplateLoader } = this.state;
                deleteTemplateLoader = true;
                this.setState({ deleteTemplateLoader })
                requests.getRequest('ebayV1/template/delete', { template_id: value }).then(data => {
                    if (data.success) {
                        notify.success(data.message);

                        this.getBusinessPolicy();
                    } else {
                        if (data.code === 'template_deletion_not_safe') {
                            deleteNotSafe_data = data.data;
                            deleteNotSafeModal = true;
                            this.setState(this.state);
                        } else {
                            notify.error(data.message);
                        }
                    }
                    deleteTemplateLoader = false;
                    this.setState({ deleteTemplateLoader })
                    this.resetModalDefaults();
                });

                break;
        }

    }

    getProfiles(key) {
        let temparr = [];
        if (this.state[key].options) {
            this.state[key].options.forEach((value, index) => {
                temparr.push(
                    <Card.Section key={'Options' + index}>
                        <Stack spacing={"loose"}>
                            <Stack.Item fill>
                                <p style={{ cursor: 'pointer' }} onClick={this.actionPerform.bind(this, 'edit', key, this.state[key].options[index].value)}>
                                    {
                                        this.state[key].options[index].label
                                    }
                                </p>
                            </Stack.Item>
                            <Tooltip content={'Edit'}><Button plain={true} icon={EditMinor} size={"slim"} primary onClick={this.actionPerform.bind(this, 'edit', key, this.state[key].options[index].value)} /></Tooltip>

                            <Tooltip content={'Delete'}><Button plain={true} icon={"delete"} size={"slim"} destructive onClick={() => {
                                deleteProfileId = this.state[key].options[index].value;
                                deleteProfileIDKey = key;
                                deleteModalShow = true;
                                this.setState(this.state);
                                // this.actionPerform.bind(this,'delete',key,this.state[key].options[index].value)
                            }} /></Tooltip>
                            {/*<Tooltip content={'Delete'}> <Button plain={true} icon={"delete"} size={"slim"} destructive onClick={this.actionPerform.bind(this,'delete',key,this.state[key].options[index].value)}/></Tooltip>*/}

                        </Stack>
                    </Card.Section>
                )
            });
        }
        return temparr;
    }

    renderTemplateList() {
        let temparr = [];
        Object.keys(this.state).map(key => {
            temparr.push(
                <Card key={'card-' + key}>
                    <Card.Section>
                        <div style={{ cursor: 'pointer' }} onClick={this.handleToggleClick.bind(this, key)}
                            aria-expanded={this.state[key].show}>
                            <Stack distribution={"equalSpacing"}>
                                <b>{this.state[key].heading} <Badge status="info">{this.state[key].options ? this.template_options[key].length : '0'}</Badge></b>
                                <Button plain icon={this.state[key].show ? "chevronDown" : "chevronRight"} />
                            </Stack>
                        </div>
                    </Card.Section>
                    <Collapsible open={this.state[key].show} id={key}>
                        {this.state[key].options ?

                            <Card actions={[{ content: 'Create new', onAction: this.createNew.bind(this, key) }]}>
                                <Card.Section>
                                    <TextField value={this.textSearchValue[key]} onChange={this.handleSearchProfile.bind(this, key)} placeholder={'Search...'} prefix={<Icon color={"tealDark"} source={'search'} />} />
                                </Card.Section>
                                <Card.Section>
                                    <div style={{ maxHeight: 200, overflowY: 'scroll' }}>
                                        {
                                            this.getProfiles(key)
                                        }
                                    </div>
                                </Card.Section>
                            </Card>

                            :
                            <Card>
                                <Card.Section>
                                    <div style={{ textAlign: 'center' }}>
                                        <img style={{ cursor: 'pointer' }} src={require('../../assets/img/createnew.png')} onClick={this.createNew.bind(this, key)} height={30} width={30} />
                                        <Heading>Create new</Heading>
                                    </div>
                                </Card.Section>
                            </Card>
                        }
                    </Collapsible>
                </Card>
            )

        });

        return temparr;
    }
}

export default NewTemplateList;
