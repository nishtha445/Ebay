
import React from 'react';
import { Badge, Icon, Stack, TextStyle, Tooltip } from "@shopify/polaris";
import { DeleteMajorMonotone, EditMajorMonotone, ViewMajorMonotone } from "@shopify/polaris-icons";

function actionRenderer(incellFunc, params) {
    // console.log('params', params.data)
    return (
        <Stack vertical={false} alignment={"center"} distribution={"fill"} >
            <Tooltip content={"Preview"}>
                <p onClick={incellFunc.bind(this, 'preview', params.data)} style={{cursor:'pointer'}}>
                    <Icon source={ViewMajorMonotone} />
                </p>
            </Tooltip>
            <Tooltip content={"Edit"}>
                <p onClick={incellFunc.bind(this, 'edit', params.data)} style={{cursor:'pointer'}}>
                    <Icon source={EditMajorMonotone} />
                </p>
            </Tooltip>
            <Tooltip content={"Delete"}>
                <p onClick={incellFunc.bind(this, 'delete', params.data)} style={{cursor:'pointer'}}>
                    <Icon source={DeleteMajorMonotone} />
                </p>
            </Tooltip>
        </Stack>
    );
}

function templateNameDetails(incellElement, params) {

    let data = params.data.name;
    let obj = data.title;
    let defaultConfig = data.defaultConfig;
    let policy_type = obj.type + '_template';
    if (defaultConfig[policy_type] && (obj._id).toString() === defaultConfig[policy_type]) {
        return (
            <React.Fragment>
                <Tooltip content={obj.title} preferredPosition='above'>
                    <span style={{ cursor: 'pointer', overflow: 'hidden', whiteSpace: 'nowrap', clear: "both"  }} onClick={(e) => {
                        incellElement('edit', params.data);
                        e.preventDefault();
                    }} onMouseOver={e => {
                        e.target.style.textDecoration = 'underline';
                    }} onMouseOut={e => {
                        e.target.style.textDecoration = 'none';
                    }}>
                        <TextStyle variation="strong">
                            {/* {obj.title.length > 40 ? obj.title.slice(0, 40) + "...." : obj.title} */}
                            {obj.title}
                        </TextStyle>
                    </span>
                    <Badge status={"attention"}>Default</Badge>
                </Tooltip>
            </React.Fragment>
        )
    } else {
        return <React.Fragment>
            <Tooltip content={obj.title} preferredPosition='above'>
                <div style={{ cursor: 'pointer', overflow: 'hidden', whiteSpace: 'nowrap', clear: "both"  }} onClick={(e) => {
                    incellElement('edit', params.data);
                    e.preventDefault();
                }} onMouseOver={e => {
                    e.target.style.textDecoration = 'underline';
                }} onMouseOut={e => {
                    e.target.style.textDecoration = 'none';
                }}>
                    <TextStyle variation="strong">
                        {/* {obj.title.length > 40 ? obj.title.slice(0, 40) + "...." : obj.title} */}
                        {obj.title}
                    </TextStyle>
                </div>
            </Tooltip>
        </React.Fragment>
    }
}

export function gridPropColumns(incellElement = () => { }) {
    return [
        {
            headerName: "Template ID", field: "id",
            cellStyle: { 'white-space': 'normal' }, autoHeight: true,
            sortable: true,
            resizable: true,
        },
        {
            headerName: "Name", field: "filtername",
            cellRendererFramework: templateNameDetails.bind(this, incellElement.bind(this)),
            cellStyle: { 'white-space': 'normal' }, autoHeight: true,
            sortable: true,
            filter: 'agTextColumnFilter',
            width: 800,
        },
        {
            headerName: "Actions", field: "actions",
            autoHeight: true,
            width: 150,
            pinned: 'right',
            cellRendererFramework: actionRenderer.bind(this, incellElement.bind(this))
        }
    ]
};


export const templatetabs = [
    // {
    //     id: 'all-template',
    //     content: 'All',
    //     title: 'All',
    //     accessibilityLabel: 'All templates',
    //     panelID: 'all-template-content',
    //     type: 'all',
    // },
    {
        id: 'category-template',
        content: 'Category',
        title: 'Category',
        panelID: 'category-template-content',
        type: 'category',
    },
    {
        id: 'inventory-template',
        content: 'Inventory',
        title: 'Inventory',
        panelID: 'inventory-template-content',
        type: 'inventory',
    },
    {
        id: 'pricing_template',
        content: 'Pricing',
        title: 'Pricing',
        panelID: 'pricing-template-content',
        type: 'price',
    },
    {
        id: 'title-template',
        content: 'Title',
        title: 'Title',
        panelID: 'title-template-content',
        type: 'title',
    }
];

export function getTypeoftabs(tab) {
    return templatetabs[tab]['type'];
}

export function extractValuesfromRequest(rows = [], defaultConfig = {}) {
    // console.log(rows)
    let modifiedRows = [];
    rows.forEach(row => {
        // console.log('row', row);
        let { _id, title, type } = row;
        modifiedRows.push({
            id: _id,
            type,
            name: { 'title': row, 'defaultConfig': defaultConfig },
            filtername: title,
        });
    });
    return modifiedRows;
}

export function attachCountTabTitle(tabs, type, rows) {
    let count = 0;
    if (type !== 'all') {
        rows.forEach(row => {
            if (row.type === type) count++;
        })
    }
    else count = rows.length;
    tabs.forEach((tab, index) => {
        if (tab.type === type) tabs[index].content = <p>{tabs[index].title} <Badge status={"info"}>{`${count}`}</Badge></p>
    })
    return tabs;
}
