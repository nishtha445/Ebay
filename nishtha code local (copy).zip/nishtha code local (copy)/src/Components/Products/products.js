import React, {Component} from 'react';
import {
  Banner,
  Card,
  Modal,
  Page,
  Select,
  TextContainer,
  Label, Badge, Button, Tabs, ChoiceList,
  Thumbnail,
  Stack, FormLayout,
  Icon, DisplayText, Checkbox, EmptyState, ProgressBar
} from '@shopify/polaris';
import {requests} from '../../services/request';
import Notfound from "../../assets/img/notfound.png"
import {notify} from '../../services/notify';
import {isUndefined} from "util";
import {capitalizeWord, paginationShow} from "../../shared/static-functions";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'jquery/dist/jquery.slim.min';
import 'popper.js/dist/umd/popper.min';
import 'bootstrap/dist/js/bootstrap.min';
import Skeleton from "../../shared/skeleton";
import ModalVideo from "react-modal-video";
import Grid from "../../shared/react-data-grid/grid";
import {createDemoRows} from "../../shared/react-data-grid/createDemoRows";
import Filter from "../../shared/react-data-grid/filter";
import NumericFilter from "../../shared/react-data-grid/filters/numericFilter";
import {Filters} from "react-data-grid-addons";
import LoadingOverlay from "react-loading-overlay";
import {TaxMajorMonotone} from "@shopify/polaris-icons";
import {filterUpdated} from "../../store/reducers/ebay/products/filters";
import {connect} from "react-redux";
import {getStructureofModal, modalPolaris} from "./producthelper";
import {parse} from "query-string";
var flatten = require('flat');

const {DraggableHeader: {DraggableContainer}} = require("react-data-grid-addons");

const {SingleSelectFilter} = Filters;
const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');

let Syncfieldsdetails = [
  {label: 'Title', value: 'title'},
  {label: 'Description', value: 'long_description'},
  {label: 'Product type', value: 'product_type'},
  {label: 'Vendor', value: 'vendor'},
  {label: 'Tags', value: 'tags'},
];
let Syncfieldsvariants = [
  {label: 'SKU', value: 'sku'},
  {label: 'Quantity', value: 'quantity'},
  {label: 'Price', value: 'price'},
  {label: 'Weight', value: 'weight'},
  {label: 'Weight unit', value: 'weight_unit'},
]

const defaultParams = {
  rowHeight: 80,
  minHeight: window.innerHeight - 170,
  headerRowHeight: 50,
  headerFiltersHeight: 50,
  enableCellSelect: false,
  minColumnWidth: 30
}

const defaultData = {
  width: 100,
  filterable: true,
  editable: false,
  sortable: false,
  resizable: false,
  draggable: false,
};

const sortingOptions = [
  {label: 'SKU', value: 'variants.0.sku'},
  {label: 'Title', value: 'details.title'},
  {label: 'Sort disabled', value: ''}
];
const sortingOptionsHighLow = [
  {label: 'High to low', value: 'DEC'},
  {label: 'Low to High', value: 'INC'},
  {label: 'Preference disabled', value: ''}
];

const reason_end_listing = [
  {label: 'Incorrect', value: 'Incorrect'},
  {label: 'Lost or broken', value: 'LostOrBroken'},
  {label: 'Not available', value: 'NotAvailable'},
  {label: 'Other listing error', value: 'OtherListingError'},
  {label: 'Sell to high bidder', value: 'SellToHighBidder'},
  {label: 'Sold', value: 'Sold'},
];

export class Products extends Component {

  grid_loader = false;
  filters = {
    full_text_search: '',
    marketplace: 'all',
    column_filters: {}
  };
  video={Modal:false,id:''};
  gridSettings = {
    count: '25',
    activePage: 1
  };
  pageLimits = [
    {label: 25, value: '25'},
    {label: 50, value: '50'},
    {label: 100, value: '100'},
    {label: 200, value: '200'},
    {label: 500, value: '500'},
  ];
  massActions = [
    {label: 'Upload and revise on eBay', value: 'upload'},
    {label: 'Sync inventory', value: 'Inventorysync'},
    {label: 'Sync details', value: 'syncshopify'},
    {label: 'Sync Images', value: 'syncimages'},
    {label: 'End from eBay', value: 'unpublish'},
    {label: 'Export details csv', value: 'exportcsv'},
    {label: 'Relist on eBay', value: 'relist', disabled: true},
    // {label: 'Upload on eBay', value: 'only_upload'},
    // {label: 'Update on eBay', value: 'only_update'},
  ];
  profilesList = [];
  orderListTabs = [
    {
      id: 'All',
      content: 'All',
      accessibilityLabel: 'All',
      link: '',
      panelID: 'All'
    },
    {
      id: 'Uploaded',
      content: 'Uploaded',
      accessibilityLabel: 'Uploaded',
      link: '',
      panelID: 'Uploaded'
    },
    {
      id: 'Not Uploaded',
      content: 'Not Uploaded',
      accessibilityLabel: 'Not Uploaded',
      link: '',
      panelID: 'Not Uploaded'
    },
    {
      id: 'Ended',
      content: 'Ended',
      accessibilityLabel: 'Ended',
      link: '',
      panelID: 'Ended'
    },
    {
      id: 'Error',
      content: 'Error',
      accessibilityLabel: 'Error',
      link: '',
      panelID: 'Error'
    },
  ];
  column = [
    {
      key: "check",
      name: <Checkbox id={"all"}
                      checked={false}
                      onChange={this.allSelector.bind(this, 'all_selector')}/>,
      frozen: true,
      editable: false,
      width: 50,
      sortable: false,
      draggable: false,
      filterable: false,
    },
    {
      key: "main_image",
      name: "Image",
      frozen: true,
      editable: false,
      width: 80,
      sortable: false,
      draggable: false,
      filterable: false,
    },
    {
      key: "title",
      frozen: false,
      width: 100,
      filterRenderer: Filter,
      name: "Title",
    },
    {
      key: "product_type",
      sortable: true,
      name: "Product type",
      width: 100,
      filterRenderer: Filter,
    },
    {
      frozen: false,
      key: "quantity",
      sortable: false,
      name: "Inventory",
      width: 100,
      filterRenderer: NumericFilter,

    },
    {
      key: "ebay_status",
      sortable: false,
      name: "eBay Status",
      width: 100,
      filterable: false,

    },
    {
      key: "sku",
      sortable: false,
      name: "SKU",
      width: 100,
      filterRenderer: Filter,
    },
    {
      key: "ebay_item_id",
      sortable: false,
      name: "eBay Item ID",
      width: 100,
      filterRenderer: NumericFilter
    },
    {
      key: "tags",
      sortable: false,
      name: "Tags",
      width: 100,
      filterRenderer: Filter,
    },
    {
      key: "ebay_profile",
      width: 100,
      filterRenderer: Filter,
      name: "Profile",
    },
    {
      key: "vendor",
      sortable: true,
      name: "Vendor",
      width: 100,
      filterRenderer: Filter,
    },

  ];

  columnTitles = {
    _id: {
      title: 'Id',
      label: 'Id',
      id: '_id',
      sortable: false,
    },
    source_product_id: {
      title: 'Source product ID',
      label: 'Source product ID',
      id: 'source_product_id',
      sortable: false,
    },
    main_image: {
      title: 'Image',
      sortable: false,
      type: 'image'
    },
    title: {
      title: 'Title',
      sortable: true,
      type: 'react'
    },
    ebay_profile: {
      title: 'Profile',
      sortable: true,
      type: 'string'
    },
    sku: {
      title: 'SKU',
      sortable: true,
      type: 'react'
    },
    // price: {
    //     title: 'Price',
    //     sortable: false,
    //     type: 'int'
    // },
    // quantity: {
    //     title: 'Quantity',
    //     sortable: false,
    //     type: 'int'
    // },
    // type: {
    //     title: 'Type',
    //     sortable: true,
    //     type:'string'
    // },bulkInventorySync
    listing_id: {
      title: 'Listing ID',
      label: 'Listing ID',
      id: 'listing_id',
      sortable: false,
    },
    ebay_item_id: {
      title: 'eBay Item ID',
      label: 'View',
      id: 'ebay_item_id',
      sortable: false,
    },
    inventory: {
      title: 'Inventory',
      sortable: true,
      type: 'string'
    },
    // parent_id:{
    //     title:'Parent ID',
    //     sortable:false,
    // },
    product_type: {
      title: 'Product type',
      sortable: true,
      type: 'react'
    },
    ebay_status: {
      title: 'eBay Status',
      sortable: true,
      type: 'react'
    },
    // unpublish:{
    //     title: 'Unpublish',
    //     label:'Unpublish',
    //     id:'unpublish',
    //     sortable: false,
    //     type:'button'
    // },
    // status:{
    //     title: 'View Status',
    //   Component  label:'Status',
    //     id:'status',
    //     sortable: false,
    //     type:'button'
    // },
  };

  constructor(props) {
    super(props);
    this.state = {
      site_id: '',
      user_id: '',
      syncImagesModal : false,
      bulk_action_marketplace: '',
      sync_fields: {
        all: false,
        details: [],
        variants: []
      },
      product_status: ['published'],
      optional_filter: false,
      use_product_type_filter: false,
      use_vendor_filter: false,
      vendor: '',
      product_type: '',
      import_and_replace: 'no',
      vendor_options: false,
      product_type_options: false,
      sortby: '',
      high_low_sort: '',
      reason_end_listing: 'Incorrect',

      bulkAction: {
        modal: false,
        type: '',
        text: ''
      },
      relistProductData: false,
      showListingRedirectModal: false,
      selectExportCSV : {
        itemIdpresentCount: 0,
        listOfItemIds: []
      },
      selectExportModal:false,
      uploadUsingDiffprofile: {
        profile_name: '',
        profile_id: '',
        data: {},
        data_selected: false
      },
      ListingRedirectUrl: '',
      ListingRedirectId: '',
      selectedProductDetails: {
        listing_ids: [],
        source_product_ids: []
      },
      bulkUnpublish: {
        itemIdpresentCount: 0,
        listOfItemIds: []
      },
      bulkInventorySync: {
        itemIdpresentCount: 0,
        listOfItemIds: []
      },
      bulkSync: {
        itemIdpresentCount: 0,
        listOfItemIds: []
      },
      SelectUpload: {
        itemIdpresentCount: 0,
        listOfItemIds: []
      },
      bulkRelist: {
        itemIdpresentCount: 0,
        listOfItemIds: []
      },
      SelectUploadProfileData: {
        matchingProfile: [],
        profileData: [],
        selected_profile:''
      },
      modalInfo : {
        open : false,

        title : ''
      },
      uploadandUpdateData : {
        all_profiles : [],
        matching_profiles : {},
        choose_another_profile:false,
        selected_profile: '',
        type : '',
        message : '',
      },
      credits_info: {
        products: {
          available: 0,
          total: 0,
          percent: 0
        }
      },
      statusShowModal: false,
      statusModalTitle: '',
      statusShowData: [],
      products: [],
      rows: [],
      appliedFilters: this.props.filters,
      installedApps: [],
      selectedApp: 0,
      searchValue: '',
      selectedTab: 0,
      selectedIds: [],
      profile_suggestion_show: {},
      deleteProductData: false,
      exportProductDataCsv: false,
      toDeleteRow: {},
      publishProductData: false,
      syncwithShopify: false,
      syncAllwithShopify: false,
      InventorySyncModal: false,
      topublishRow: {},
      totalPage: 0,
      statusView: {open: false, data: <h1>Hello</h1>},
      showLoaderBar: true,
      hideLoader: false,
      selectandUpload: false,
      source_shop_id: 0,
      target_shop_id: 0,
      source: '',
      marketplace: '',
      isLoading: "loading",
      importServicesList: [],
      importerShopLists: [],
      uploadServicesList: [],
      uploaderShopLists: [],
      EnableMultiselect: false,
      showImportProducts: false,
      showUploadProducts: false,
      uploadProductDetails: {
        source: '',
        source_shop: '',
        source_shop_id: '',
        target: '',
        target_shop: '',
        target_shop_id: '',
        selected_profile: '',
        profile_type: ''
      },
      importProductsDetails: {
        source: '',
        shop: '',
        shop_id: ''
      },
      columns: this.column.map(c => ({...defaultData, ...c})),
      visibleColumns: {
        'check': 1,
        'main_image': 1,
        'title': 1,
        'product_type':1,
        'sku': 1,
        'tags': 1,
        "ebay_item_id": 1,
        "ebay_profile": 1,
        "inventory": 1,
        "quantity": 1,
        "ebay_status": 1,
        "vendor": 1
      },
      pagination: {
        page: 1,
        totalNumberOfPages: 0,
        totalNumberOfProducts: 0,
        totalNumberOfItems: 0,
        pageSize: 25,
      },
      pagination_show: "",
      preparedFilter: {},
      expandedRows: {},
      checkbox: {},
      All_Selected: false,
      toolbar_suffix: "Product(s)",
      selected_count: 0,
      total_product_count : 999999
    };
    this.getProducts();
    this.getInstalledApps();
    this.operations = this.operations.bind(this);
    this.handleStatusViewChange = this.handleStatusViewChange.bind(this);
    this.getAllImporterServices();
    this.getAllUploaderServices();
  }


  componentDidMount() {
    this.getServiceCredits();
    this.getSideID();
    this.getProductsCount();
    this.getVendorProducttype();
    this.getCollections();

    document.title = 'Manage Shopify products on eBay Marketplace Integration App';
    document.description = 'Minimize your efforts to sell Shopify products on eBay with eBay Marketplace Integration App, which helps to easily list, sync & manage your products on eBay.';
    if (!document.title.includes(localStorage.getItem('shop_url'))) {
      document.title += !isUndefined(localStorage.getItem('shop_url')) ? " " + localStorage.getItem('shop_url') : "";
    }
  }

  modalhandler(open, data){
    let { modalInfo, uploadandUpdateData } = this.state;
    modalInfo.open = open;
    modalInfo.title = open ?  data.title : '';
    if(!open){
      uploadandUpdateData = {
        all_profiles : [],
        matching_profiles : {},
        choose_another_profile: false,
        selected_profile: '',
        type : '',
        message : '',
      };
    }
    this.setState({ modalInfo, uploadandUpdateData });
  }

  getCollections(){
    requests
      .getRequest("ebayV1/get/getSourceAttributes", {
        marketplace: 'shopify'
      })
      .then(data => {
        if(data.success){
          data.data.forEach(option => {
            if(option.code === 'collections'){
              let dictioned_options =  this.dictionedData(option.options);
              this.setState({collection_options : dictioned_options});
            }
          })
        }
      });
  }

  dictionedData(data){
    let Obj ={};
    data.forEach((option,index)=>{
      Obj[option.label] = index;
    });
    let Ordered_Array = [];
    Object.keys(Obj).sort().forEach(key =>{
      data[Obj[key]]['label'] = data[Obj[key]]['label']+"-"+data[Obj[key]]['value']
      Ordered_Array.push(data[Obj[key]]);
    });
    return Ordered_Array;
  }

  getServiceCredits() {
    requests.getRequest('frontend/app/getServiceCredits', {service_code: 'ebay_uploader'}, false, true)
      .then(response => {
        if (response.success) {

          let productObj = {
            available: response.data.available_credits,
            total: response.data.available_credits + response.data.total_used_credits,
            percent: ((response.data.available_credits) / (response.data.available_credits + response.data.total_used_credits)) * 100
          };
          this.state.credits_info.products = Object.assign({}, productObj);
        }
        this.setState(this.state);
      });
  }

  getSideID() {
    requests.getRequest('ebayV1/get/siteId').then(data => {
      if (data.success) {
        this.state.site_id = !isUndefined(data.data.site_id) ? data.data.site_id : '';
        // this.state.site_id ='MOTORS';
      }
      this.setState(this.state);
    });

  }

  handleChangeSyncfields(key, data) {
    switch (key) {
      case 'details':
        this.state.sync_fields.details = data.slice(0);
        break;
      case 'variants':
        this.state.sync_fields.variants = data.slice(0);
        break;
    }
    this.setState(this.state);
  }

  handleTwoLevelChange(field, subfield, value){
    switch (field){
      case 'uploadandUpdateData':
        let { uploadandUpdateData } = this.state;
        uploadandUpdateData[subfield] = value;
        this.setState({ uploadandUpdateData });
        break;
      default: break;
    }
  }

  getSyncfieldsCompo() {
    let temparr = [];
    temparr.push(
      <ChoiceList
        key={'details-syncfields'}
        allowMultiple
        title={''}
        choices={Syncfieldsdetails}
        selected={this.state.sync_fields.details}
        onChange={this.handleChangeSyncfields.bind(this, 'details')}
      />
    );
    temparr.push(
      <ChoiceList
        key={'variants-syncfields'}
        allowMultiple
        title={''}
        choices={Syncfieldsvariants}
        selected={this.state.sync_fields.variants}
        onChange={this.handleChangeSyncfields.bind(this, 'variants')}
      />
    );
    return <Card title={'Kindly select the fields you want to sync'}>
      <Card.Section>
        <FormLayout>
          <Checkbox
            checked={this.state.sync_fields.all}
            label="Sync all fields"
            onChange={this.handleChangeSyncall.bind(this)}
          />
          <FormLayout.Group condensed>{temparr}</FormLayout.Group>
        </FormLayout>
      </Card.Section>
    </Card>;
  }

  getTableProfileSuggestion(data, rowIndex, show) {
    let temparr = [];
    if (show) {
      let profile_handler = [];
      data.profile_suggestions.forEach((profile, index) => {
        profile_handler.push(
          <tr>
            <td>{profile.name}</td>
          </tr>
        )
      });
      temparr.push(
        <div>
          <div className="row">
            <div className="col-12 col-md-12">
              <p style={{color: '#2DB8D0', cursor: 'pointer', textDecoration: 'underline'}}
                 onClick={this.getTableProfileSuggestion.bind(this, data, rowIndex, false)}>Suggestions</p>
            </div>
            <div className={"col-12 col-md-12"}>
              <table className="table table-responsive-lg border">
                <tbody>
                {profile_handler}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )

    } else {
      temparr.push(
        <div>
          <div className="row">
            <div className="col-12 col-md-12">
              <p style={{color: '#2DB8D0', cursor: 'pointer', textDecoration: 'underline'}}
                 onClick={this.getTableProfileSuggestion.bind(this, data, rowIndex, true)}>Suggestions</p>
            </div>
          </div>
        </div>
      )
    }

    this.state.rows[rowIndex].ebay_profile = temparr.slice(0);
    this.setState(this.state);
  }

  getProfileSuggestion(data, rowIndex) {

    let temparr = [];
    if (!isUndefined(data.profile_name)) {
      temparr.push(data.profile_name)
    } else {
      if (!isUndefined(data.profile_suggestions) && data.profile_suggestions.length > 0) {
        temparr.push(
          <div>
            <div className="row">
              <div className="col-12 col-md-12">
                <p style={{color: '#2DB8D0', cursor: 'pointer', textDecoration: 'underline'}}
                   onClick={this.getTableProfileSuggestion.bind(this, data, rowIndex, true)}>Suggestions</p>
              </div>
            </div>
          </div>
        )
      } else {
        temparr.push(
          <div title={"Not available"} className="w-100 text-center"><Icon source="subtract"/></div>
        )
      }
    }

    return temparr;
  }

  handleChangeSyncall(key) {
    let tempDetails = [];
    let tempvariants = [];
    let selectedvariantsSync = [];
    let selecteddetailsSync = [];

    if (key) {
      Syncfieldsvariants.forEach((variantoption, index) => {
        selectedvariantsSync.push(variantoption.value);
        variantoption.disabled = true
        tempvariants.push(
          variantoption
        )
      });
      Syncfieldsdetails.forEach((detailsoption, index) => {
        selecteddetailsSync.push(detailsoption.value);
        detailsoption.disabled = true
        tempDetails.push(
          detailsoption
        )
      });

    } else {
      Syncfieldsvariants.forEach((variantoption, index) => {
        variantoption.disabled = false
        tempvariants.push(
          variantoption
        )
      });

      Syncfieldsdetails.forEach((detailsoption, index) => {
        detailsoption.disabled = false
        tempDetails.push(
          detailsoption
        )
      });
    }
    Syncfieldsdetails = tempDetails.slice(0);
    Syncfieldsvariants = tempvariants.slice(0);
    this.state.sync_fields.details = selecteddetailsSync.slice(0);
    this.state.sync_fields.variants = selectedvariantsSync.slice(0);
    this.state.sync_fields.all = key;
    this.setState(this.state);
  }

  getAllImporterServices() {
    requests.getRequest('connector/get/services', {'filters[type]': 'importer'})
      .then(data => {
        if (data.success === true) {
          this.state.importServicesList = [];
          for (let i = 0; i < Object.keys(data.data).length; i++) {
            let key = Object.keys(data.data)[i];
            if (!isUndefined(key) && key === 'shopify_importer') {
              this.state.importServicesList.push({
                label: data.data[key].title,
                value: data.data[key].marketplace,
                shops: data.data[key].shops
              });
            }
          }
          this.updateState();
        } else {
          notify.error('Your product upload limit has expired. Upgrade your plan');
        }
      });
  }

  getAllUploaderServices() {
    requests.getRequest('connector/get/services', {'filters[type]': 'uploader'})
      .then(data => {
        if (data.success === true) {
          this.state.uploadServicesList = [];
          for (let i = 0; i < Object.keys(data.data).length; i++) {
            let key = Object.keys(data.data)[i];
            if (!isUndefined(key) && key === 'ebay_uploader') {
              this.state.uploadServicesList.push({
                label: data.data[key].title,
                value: data.data[key].marketplace,
                shops: data.data[key].shops
              });
            }
          }
          this.updateState();
          if (this.state.uploadServicesList.length === 0) {
            notify.info('Your product upload limit has expired. Upgrade your plan');
          }
        } else {
          notify.error('Your product upload limit has expired. Upgrade your plan');
        }
      });
  }

  handleChangeProductimportStatus(data) {
    this.state.product_status = data;
    this.setState(this.state);
  }

  renderImportProductsModal() {
    return (
      <div>
        <Modal
          open={this.state.showImportProducts}
          onClose={() => {
            this.state.showImportProducts = false;
            this.state.product_status = ['published']
            this.updateState();
          }}
          title="Import Products"
          /* primaryAction={{disabled:this.state.importProductsDetails.source === '',content:'Import Products',
                         onAction: this.importProducts.bind(this)

                     }}*/
        >
          <Modal.Section>
            <Stack vertical={true} distribution={"fill"}>
              <Banner status={"info"}
                      title=" You are about to import product's from Shopify, Are you sure ?"/>
              {/*<Card actions={((isUndefined(this.state.vendor_options) || this.state.vendor_options.length === 0) ||*/}
              {/*  (isUndefined(this.state.product_type_options) || this.state.product_type_options.length === 0)) && {*/}
              {/*  content: 'Refetch vendor and product type',*/}
              {/*  onAction: this.initiatefetchVendorProductType.bind(this)*/}
              {/*}}>*/}
              {/*  <Card.Section title={'filters'}>*/}
              {/*    <Stack vertical={true}>*/}
              {/*      <Stack.Item>*/}
              {/*        <Checkbox label={'Optional filter'} checked={this.state.optional_filter}*/}
              {/*                  onChange={(e) => {*/}
              {/*                    this.setState({optional_filter: e});*/}
              {/*                  }}/>*/}
              {/*      </Stack.Item>*/}
              {/*      {this.state.optional_filter &&*/}
              {/*      <Stack.Item>*/}
              {/*        <Stack vertical={false} spacing={"loose"}>*/}
              {/*          <Checkbox label={'Vendor'} checked={this.state.use_vendor_filter}*/}
              {/*                    onChange={(e) => {*/}
              {/*                      this.setState({use_vendor_filter: e})*/}
              {/*                    }}/>*/}
              {/*          <Checkbox label={'Product type'}*/}
              {/*                    checked={this.state.use_product_type_filter}*/}
              {/*                    onChange={(e) => {*/}
              {/*                      this.setState({use_product_type_filter: e})*/}
              {/*                    }}/>*/}
              {/*        </Stack>*/}
              {/*      </Stack.Item>*/}
              {/*      }*/}
              {/*    </Stack>*/}
              {/*  </Card.Section>*/}
              {/*  {this.state.optional_filter &&*/}
              {/*  <Card.Section title={'Optional filters'}>*/}
              {/*    {((!isUndefined(this.state.vendor_options) && this.state.vendor_options.length > 0) ||*/}
              {/*      (!isUndefined(this.state.product_type_options) && this.state.product_type_options.length>0)) ?*/}
              {/*      <FormLayout>*/}
              {/*        <FormLayout.Group condensed={true}>*/}
              {/*          {this.state.product_type_options && this.state.use_product_type_filter &&*/}
              {/*          <Select label={'Product type'}*/}
              {/*                  options={this.state.product_type_options}*/}
              {/*                  value={this.state.product_type}*/}
              {/*                  placeholder={'Select....'}*/}
              {/*                  onChange={(e) => {*/}
              {/*                    this.setState({product_type: e});*/}
              {/*                  }}/>*/}
              {/*          }*/}

              {/*          <Select label={'Import and replace current products'}*/}
              {/*                  options={[{label: 'Yes', value: 'yes'}, {*/}
              {/*                    label: 'No',*/}
              {/*                    value: 'no'*/}
              {/*                  }]}*/}
              {/*                  value={this.state.import_and_replace}*/}
              {/*                  placeholder={'Select....'}*/}
              {/*                  onChange={(e) => {*/}
              {/*                    this.setState({import_and_replace: e});*/}
              {/*                  }}/>*/}

              {/*          {this.state.vendor_options && this.state.use_vendor_filter &&*/}
              {/*          <Select label={'Vendors'}*/}
              {/*                  options={this.state.vendor_options}*/}
              {/*                  value={this.state.vendor}*/}
              {/*                  placeholder={'Select....'}*/}
              {/*                  onChange={(e) => {*/}
              {/*                    this.setState({vendor: e});*/}
              {/*                  }}/>*/}
              {/*          }*/}
              {/*        </FormLayout.Group>*/}
              {/*      </FormLayout>*/}
              {/*      :*/}
              {/*      <Banner status={'info'}*/}
              {/*              title={'Custom filters data not available click fetch data action and retry in some time'}/>*/}
              {/*    }*/}
              {/*  </Card.Section>*/}
              {/*  }*/}
              {/*  <Card.Section title={'Necessary filter'}>*/}
              {/*    <ChoiceList*/}
              {/*      title={'Kindly select the status of product you want to import'}*/}
              {/*      choices={[*/}
              {/*        {label: 'Published', value: 'published'},*/}
              {/*        {label: 'Unpublished', value: 'unpublished'},*/}
              {/*        {label: 'All', value: 'any'},*/}
              {/*      ]}*/}
              {/*      allowMultiple={false}*/}
              {/*      selected={this.state.product_status}*/}
              {/*      onChange={this.handleChangeProductimportStatus.bind(this)}*/}
              {/*    />*/}
              {/*  </Card.Section>*/}
              {/*</Card>*/}
              <Button disabled={this.state.importProductsDetails.source === ''}
                      onClick={this.importProducts.bind(this)} primary>
                Yes
              </Button>
            </Stack>
          </Modal.Section>
        </Modal>
      </div>
    );
  }

  handleImportChange(key, value) {
    this.state.importProductsDetails[key] = value;
    if (key === 'source') {
      this.state.importerShopLists = [];
      this.state.importProductsDetails.shop = '';
      this.state.importProductsDetails.shop_id = '';
      for (let i = 0; i < this.state.importServicesList.length; i++) {
        if (this.state.importServicesList[i].value === value) {
          for (let j = 0; j < this.state.importServicesList[i].shops.length; j++) {
            this.state.importerShopLists.push({
              label: this.state.importServicesList[i].shops[j].shop_url,
              value: this.state.importServicesList[i].shops[j].shop_url,
              shop_id: this.state.importServicesList[i].shops[j].id
            });
          }
          break;
        }
      }
      if (this.state.importerShopLists.length > 0) {
        this.state.importProductsDetails.shop = this.state.importerShopLists[0].value;
        this.state.importProductsDetails.shop_id = this.state.importerShopLists[0].shop_id;
      }
    } else if (key === 'shop') {
      for (let i = 0; i < this.state.importerShopLists.length; i++) {
        if (this.state.importerShopLists[i].value === value) {
          this.state.importProductsDetails.shop_id = this.state.importerShopLists[i].shop_id;
          break;
        }
      }
    }
    this.updateState();
  }

  getFilters() {
    let tempObj = {};
    let checkFilterUsed = false;
    if (this.state.optional_filter) {
      if (this.state.use_vendor_filter) {
        if (this.state.vendor !== '') {
          tempObj['vendor'] = this.state.vendor;
        }
        checkFilterUsed = true;
      }
      if (this.state.use_product_type_filter) {
        if (this.state.product_type !== '') {
          tempObj['product_type'] = this.state.product_type;
        }
        checkFilterUsed = true;
      }
    }
    if (checkFilterUsed) {
      return tempObj;
    } else {
      return false;
    }

  }

  importProducts() {

    // let filter = this.getFilters();
    requests.postRequest('connector/product/import',
      {
        marketplace: this.state.importProductsDetails.source,
        shop: this.state.importProductsDetails.shop,
        shop_id: this.state.importProductsDetails.shop_id,
        product_status: this.state.product_status[0],
        // filter: filter,
        import_and_replace: this.state.import_and_replace,
      })
      .then(data => {
        this.state.showImportProducts = false;
        this.updateState();
        if (data.success === true) {
          if (data.code === 'product_import_started') {
            notify.info('Import process started. Check progress in activities section.');
            setTimeout(() => {
              this.redirect('/panel/activities');
            }, 500);
          } else {
            notify.success(data.message);
          }
        } else {
          notify.error(data.message);
        }
      });

  }

  modalskeleton = true;

  renderUploadProductsModal() {
    return (
      <Modal
        open={this.state.showUploadProducts}
        onClose={() => {
          this.state.showUploadProducts = false;
          this.updateState();
        }}
        title="Upload All Products"
      >{(this.modalskeleton) ? <Skeleton case="businesspolicy"/> :
        <Modal.Section>
          <Stack vertical={true}>

            <Banner status="info">
              <Label>You can create an <span style={{color: "#0000FF", cursor: 'pointer'}}
                                             onClick={() => {
                                               this.redirect('/panel/profiles/createprofile');
                                             }}>Custom Profile</span> for products upload. To know more
                about Profile and Default Profile visit our <span style={{color: "#0000FF"}}
                                                                  onClick={() => {
                                                                    this.redirect('/panel/help?faq=profile');
                                                                  }}>Help</span> section.</Label>
            </Banner>
            {
              this.profilesList.length > 0 &&
              <Select
                label="Select Profile"
                options={this.profilesList}
                placeholder="Custom Profile"
                onChange={this.handleProfileSelect.bind(this)}
                value={this.state.uploadProductDetails.selected_profile}
              />
            }
            {
              this.profilesList.length === 0 &&
              <React.Fragment>
                <Banner status="warning">
                  <Label>No profiles
                    for {capitalizeWord(this.state.uploadProductDetails.source)} and {capitalizeWord(this.state.uploadProductDetails.target)} integration</Label>
                </Banner>
                <Stack alignment={"center"} vertical={true}>
                  <Button onClick={() => {
                    this.redirect('/panel/profiling/create');
                  }} primary>
                    Create Profile
                  </Button>
                  <Button onClick={() => {
                    this.state.uploadProductDetails.profile_type = '';
                    this.state.uploadProductDetails.selected_profile = 'default_profile';
                    this.updateState();
                  }} primary>
                    Select Default Profile
                  </Button>
                </Stack>
              </React.Fragment>
            }

            <Stack alignment={"center"} vertical={true}>
              <Button onClick={() => {
                this.uploadProducts();
              }}
                      disabled={!(this.state.uploadProductDetails.source !== '' &&
                        this.state.uploadProductDetails.target !== '' &&
                        this.state.uploadProductDetails.selected_profile !== '')}
                      primary>
                Upload All Products
              </Button>
            </Stack>
          </Stack>
        </Modal.Section>}
      </Modal>
    );
  }

  handleProfileSelect(profile) {

    if (profile === 'default_profile') {
      this.handleUploadChange('selected_profile', profile);
    } else {
      this.state.uploadProductDetails.selected_profile = profile;
      this.updateState();
    }
  }

  handleUploadChange(key, value) {
    switch (key) {
      case 'selected_profile':
        if (value === 'custom_profile') {
          if (this.state.uploadProductDetails.source === '' ||
            this.state.uploadProductDetails.target === '') {
            notify.info('Please choose product import source and product upload target first');
          } else {
            this.getMatchingProfiles();
            this.state.uploadProductDetails.profile_type = 'custom';
            this.state.uploadProductDetails[key] = '';
          }
        } else {
          this.state.uploadProductDetails.profile_type = '';
          this.state.uploadProductDetails[key] = value;
        }
        break;
      case 'source':
        this.state.importerShopLists = [];
        this.state.uploadProductDetails.source = value;
        this.state.uploadProductDetails.profile_type = '';
        this.state.uploadProductDetails.selected_profile = 'default_profile';
        this.state.uploadProductDetails.source_shop = '';
        this.state.uploadProductDetails.source_shop_id = '';
        for (let i = 0; i < this.state.importServicesList.length; i++) {
          if (this.state.importServicesList[i].value === value) {
            for (let j = 0; j < this.state.importServicesList[i].shops.length; j++) {
              this.state.importerShopLists.push({
                label: this.state.importServicesList[i].shops[j].shop_url,
                value: this.state.importServicesList[i].shops[j].shop_url,
                shop_id: this.state.importServicesList[i].shops[j].id
              });
            }
            break;
          }
        }
        if (this.state.importerShopLists.length > 0) {
          this.state.uploadProductDetails.source_shop = this.state.importerShopLists[0].value;
          this.state.uploadProductDetails.source_shop_id = this.state.importerShopLists[0].shop_id;
        }
        break;
      case 'target':
        this.state.uploaderShopLists = [];
        this.state.uploadProductDetails.target = value;
        this.state.uploadProductDetails.profile_type = '';
        this.state.uploadProductDetails.selected_profile = 'default_profile';
        this.state.uploadProductDetails.target_shop = '';
        this.state.uploadProductDetails.target_shop_id = '';
        for (let i = 0; i < this.state.uploadServicesList.length; i++) {
          if (this.state.uploadServicesList[i].value === value) {
            for (let j = 0; j < this.state.uploadServicesList[i].shops.length; j++) {
              this.state.uploaderShopLists.push({
                label: this.state.uploadServicesList[i].shops[j].site_id,
                value: this.state.uploadServicesList[i].shops[j].site_id,
                shop_id: this.state.uploadServicesList[i].shops[j].id
              });
            }
            break;
          }
        }
        if (this.state.uploaderShopLists.length > 0) {
          this.state.uploadProductDetails.target_shop = this.state.uploaderShopLists[0].value;
          this.state.uploadProductDetails.target_shop_id = this.state.uploaderShopLists[0].shop_id;
        }
        break;
      case 'source_shop':
        this.state.uploadProductDetails.profile_type = '';
        this.state.uploadProductDetails.selected_profile = 'default_profile';
        for (let i = 0; i < this.state.importerShopLists.length; i++) {
          if (this.state.importerShopLists[i].value === value) {
            this.state.uploadProductDetails.source_shop_id = this.state.importerShopLists[i].shop_id;
            this.state.uploadProductDetails.source_shop = this.state.importerShopLists[i].value;
            break;
          }
        }
        break;
      case 'target_shop':
        this.state.uploadProductDetails.profile_type = '';
        this.state.uploadProductDetails.selected_profile = 'default_profile';
        for (let i = 0; i < this.state.uploaderShopLists.length; i++) {
          if (this.state.uploaderShopLists[i].value === value) {
            this.state.uploadProductDetails.target_shop_id = this.state.uploaderShopLists[i].shop_id;
            this.state.uploadProductDetails.target_shop = this.state.uploaderShopLists[i].value;
            break;
          }
        }
        break;
    }
    this.updateState();
  }

  getMatchingProfiles() {
    this.modalskeleton = true;
    this.profilesList = [];
    const data = {
      source: this.state.uploadProductDetails.source,
      target: this.state.uploadProductDetails.target
    };
    if (this.state.uploadProductDetails.source_shop !== '' &&
      this.state.uploadProductDetails.source_shop !== null) {
      data['source_shop'] = this.state.uploadProductDetails.source_shop;
    }
    if (this.state.uploadProductDetails.target_shop !== '' &&
      this.state.uploadProductDetails.target_shop !== null) {
      data['target_shop'] = this.state.uploadProductDetails.target_shop;
    }
    requests.getRequest('connector/profile/getMatchingProfiles', data)
      .then(data => {
        if (data.success) {
          this.profilesList.push({
            label: 'Default Profile(Upload products with Default Settings)',
            value: 'default_profile'
          });
          for (let i = 0; i < data.data.length; i++) {
            this.profilesList.push({
              label: data.data[i].name,
              value: (data.data[i].id).toString()
            });
          }
          this.modalskeleton = false;
          this.updateState();
        } else {
          notify.error(data.message);
        }
      });
  }

  uploadProducts() {
    const data = Object.assign({}, this.state.uploadProductDetails);
    data['marketplace'] = data['target'];
    if (this.state.uploadProductDetails.target_shop_id !== '') {
      requests.postRequest('connector/product/upload', data)
        .then(data => {
          this.state.showUploadProducts = false;
          if (data.success) {
            if (data.code === 'product_upload_started') {
              notify.info('Upload process started. Check progress in activities section.');
              setTimeout(() => {
                this.redirect('/panel/activities');
              }, 500);
            } else {
              notify.success(data.message);
            }
          } else {
            notify.error(data.message);
            if (data.code === 'link_your_account') {
              setTimeout(() => {
                this.redirect('/panel/accounts');
              }, 1200);
            }
          }
          this.updateState();
        });
    } else {
      notify.info('Your product upload limit has expired. Upgrade your plan');
    }
  }


  getAllImporterServicesandgetAllUploaderServices() {
    requests.getRequest('connector/get/services', {'filters[type]': 'importer'}, false, true)
      .then(data => {
        if (data.success === true) {
          requests.getRequest('connector/get/services', {'filters[type]': 'uploader'}, false, true)
            .then(data1 => {
              if (data1.success === true) {
                this.setState({
                  target_shop_id: data1['data']['ebay_uploader']['shops'][0]['id'],
                  marketplace: data1['data']['ebay_uploader']['marketplace'],
                  source_shop_id: data['data']['shopify_importer']['shops'][0]['id'],
                  source: data['data']['shopify_importer']['marketplace'],
                  isLoading: ""
                });
              } else {
                notify.error('Your product upload limit has expired. Upgrade your plan');
              }
            })
        } else {
          notify.error('Your product upload limit has expired. Upgrade your plan');
        }
      });
  }

  getInstalledApps() {
    requests.getRequest('connector/get/getInstalledApps', false, false, true)
      .then(data => {
        this.state.installedApps = [
          {
            id: 'all',
            content: 'All',
            accessibilityLabel: 'All',
            panelID: 'all'
          }
        ];
        if (data.success) {
          for (let i = 0; i < data.data.length; i++) {
            this.state.installedApps.push({
              id: data.data[i].code,
              content: data.data[i].title,
              accessibilityLabel: data.data[i].title,
              panelID: data.data[i].code
            });
          }
        } else {
          notify.error(data.message);
        }
        this.state.showLoaderBar = data.success;
        this.updateState();
      });
  }

  //
  // prepareFilterObject() {
  //     this.state.appliedFilters = {};
  //     if (this.filters.marketplace !== 'all') {
  //         this.state.appliedFilters['marketplace'] = this.filters.marketplace;
  //     }
  //     if (this.filters.full_text_search !== '') {
  //         this.state.appliedFilters['search'] = this.filters.full_text_search;
  //     }
  //     for (let i = 0; i < Object.keys(this.filters.column_filters).length; i++) {
  //         const key = Object.keys(this.filters.column_filters)[i];
  //         if (this.filters.column_filters[key].value !== '') {
  //             switch (key) {
  //                 case 'type':
  //                 case 'title':
  //                 case 'long_description':
  //                 case 'source_product_id':
  //                     this.state.appliedFilters['filter[details.' + key + '][' + this.filters.column_filters[key].operator + ']'] = this.filters.column_filters[key].value;
  //                     break;
  //                 case 'sku':
  //                 case 'price':
  //                 case 'weight':
  //                 case 'weight_unit':
  //                 case 'main_image':
  //                 case 'quantity':
  //                     this.state.appliedFilters['filter[variants.' + key + '][' + this.filters.column_filters[key].operator + ']'] = this.filters.column_filters[key].value;
  //                     break;
  //                 case 'ebay_item_id':
  //                     this.state.appliedFilters['filter[listing_id][' + this.filters.column_filters[key].operator + ']'] = this.filters.column_filters[key].value;
  //                     break;
  //                 case 'ebay_profile':
  //                     this.state.appliedFilters['filter[profile_name][' + this.filters.column_filters[key].operator + ']'] = this.filters.column_filters[key].value;
  //                     break;
  //                 case 'product_type':
  //                     this.state.appliedFilters['filter[details.product_type][' + this.filters.column_filters[key].operator + ']'] = this.filters.column_filters[key].value;
  //                     break;
  //             }
  //         }
  //     }
  //     this.updateState();
  // }

  // modifyProductsData(data) {
  //     let products = [];
  //     let source_product_id = [];
  //     for (let i = 0; i < data.length; i++) {
  //         let rowData = {};
  //         rowData['main_image'] = /*<div onClick={(e)=>{
  //             this.operations.bind(this,'button',data);
  //             e.stopPropagation();
  //         }
  //         }>{*/data[i].details['image_main']===""?Notfound:data[i].details['image_main'];/*}</div>*/
  //         rowData['title'] = data[i].details.title/*<ReadMoreReact
  //             text={data[i].details.title}
  //             min={40}
  //             ideal={40}
  //             max={100} />*/;
  //         // if ( source_product_id.indexOf(data[i].product_data['details']['source_product_id']) === -1 ) {
  //         //     rowData['title'] = <ReadMoreReact
  //         //         text={data[i].product_data.details.title}
  //         //         min={40}
  //         //         ideal={40}
  //         //         max={100} />;
  //         //     source_product_id.push(data[i].product_data['details']['source_product_id']);
  //         // } else {
  //         //     rowData['title'] = <div className="w-100 text-center">
  //         //         <Icon source="subtract" />
  //         //     </div>;
  //         // }
  //         rowData['ebay_item_id'] = !isUndefined(data[i].listing_id)?<div style={{color:'#25B6CF',textDecoration:'underline'}}>{data[i].listing_id}</div>:<div className="w-100 text-center"><Icon source="subtract" /></div>;
  //         rowData['listing_id'] = !isUndefined(data[i].listing_id)?data[i].listing_id:"n/a";
  //         rowData['ebay_profile'] = this.getProfileSuggestion(data[i],i);
  //         rowData['product_type'] = !isUndefined(data[i].details.product_type) && data[i].details.product_type!=="" ?data[i].details.product_type:<div className="w-100 text-center"><Icon source="subtract" /></div>;
  //         // rowData['quantity'] = data[i].product_data.variants['quantity'];
  //         // rowData['type'] = data[i].product_data.details.type;
  //         // if ( !isUndefined(data[i]['product_data']['fromItems']) && Object.keys(data[i]['product_data']['fromItems']).length > 0 ) {
  //         //     rowData['upload_status'] = <React.Fragment>
  //         //         <Badge status="success">Uploaded</Badge><br/>
  //         //         <Badge status="attention">Imported</Badge>
  //         //     </React.Fragment>;
  //         // } else {
  //         //     rowData['upload_status'] = <Badge status="attention">Imported</Badge>;
  //         // }
  //         // if (data[i]['product_data']['fromItems'].length>0 && (data[i]['product_data']['variants']['source_variant_id'] in data[i]['product_data']['fromItems'][0]['variants']) && ('marketplace_status' in data[i]['product_data']['fromItems'][0]['variants'][
  //         //         data[i]['product_data']['variants']['source_variant_id']
  //         //         ] ) && !isUndefined(
  //         //     data[i]['product_data']['fromItems'][0]['variants'][
  //         //         data[i]['product_data']['variants']['source_variant_id']
  //         //         ]['marketplace_status']) &&
  //         //     data[i]['product_data']['fromItems'][0]['variants']
  //         //         [data[i]['product_data']['variants']['source_variant_id']]['marketplace_status'].length > 0 ) {
  //         //     rowData['google_status'] = this.getGoogleStatus(data[i]['product_data']['fromItems'][0]['variants'][data[i]['product_data']['variants']['source_variant_id']]['marketplace_status']);
  //         // } else {
  //         //     rowData['google_status'] =
  //         //         <React.Fragment>
  //         //             <Badge status="attention">Unavailable</Badge>
  //         //         </React.Fragment>;
  //         //
  //         // }
  //         rowData['inventory']=this.getInventoryData(data[i]);
  //         rowData['ebay_status']=this.getEbayStatus(data[i]);
  //         rowData['_id'] = data[i]._id;
  //         rowData['source_product_id'] = data[i].details.source_product_id;
  //         rowData['sku'] = !isUndefined(data[i].variants) && !isUndefined(data[i].variants[0]) && !isUndefined(data[i].variants[0].sku)?data[i].variants[0].sku+"...":'...';
  //
  //         // rowData['ebay_status']=this.conditioncheck(data,i);
  //         // rowData['source_variant_id'] = data[i].product_data.variants['source_variant_id'];
  //         // rowData['parent_id'] = data[i].product_data.details['source_product_id'];
  //         // rowData['unpublish'] = JSON.stringify(isUndefined(data[i].product_data)?[]:data[i].product_data);
  //         products.push(rowData);
  //     }
  //     return products;
  // }
  getInventoryData(data) {
    let totalVariants = 0;
    let totalquantity = 0;
    if (!isUndefined(data.variants) ) {
      if(Array.isArray(data.variants)) {
        data.variants.forEach((variants, index) => {
          totalquantity += !isNaN(parseInt(variants.quantity))? parseInt(variants.quantity):0;
        });
      }else{
        Object.keys(data.variants).map((key) => {
          totalquantity +=  !isNaN(parseInt(data.variants.quantity)) ? parseInt(data.variants[key].quantity) : 0;
        });
      }
        totalVariants = data.variants.length;
        let addonVarianttext = totalVariants > 1 ? " variants" : " variant";
        let varianttext = "for " + totalVariants + addonVarianttext;
        if (data.details.type === 'simple') {
          varianttext = '';
        }
        let text = totalquantity + " in stock " + varianttext;
        return text;

    }
    return '';
  }

// <Badge status={`${!haserror?'success':'warning'}`}>{`${!haserror?'Uploaded':'Error'}`}</Badge>

  getEbayStatus(data) {

    let temparr = [];
    let itemEnded = !isUndefined(data.item_ended) ? data.item_ended : false;
    let ebay_status = !isUndefined(data.listing_id) ? data.listing_id : false;
    let haserror = !isUndefined(data.has_error) ? data.has_error : false;
    temparr.push(
      <div className="row" style={{whiteSpace: 'nowrap'}} key={data._id}>
        <div className="col-12 col-md-12">
          <Stack vertical={true} spacing={"tight"}>

            {itemEnded ? <Badge status={"info"}>Listing ended</Badge> : ebay_status ? <Badge
                status={'success'}>{haserror && (['7704', '8553', '18906', '14048', '11977', '9560', '8349', '14950', '14921'].indexOf(this.state.user_id) > -1) ?<Icon source={"alert"} color={"red"}/> : ''}{' Uploaded'}</Badge> :
              <Badge status={`${!haserror ? 'attention' : 'warning'}`}>{!haserror ? 'Not uploaded' :
                <b style={{color: '#0000aa', textDecoration: 'underline'}}>Error</b>}</Badge>}
          </Stack>
        </div>
      </div>
    );
    return temparr;
  }

  getEbayStatusnewConfig(data) {
    let haserror = !isUndefined(data.has_error) ? data.has_error : false;
    // console.log(haserror)
    let temparr = [];
    let type = '';
    let Content = '';
    switch (data['status']) {
      case 'ended':
        type = 'info';
        Content = 'Ended';
        break;
      case 'not_uploaded':
        type = 'attention';
        Content = 'Not uploaded';
        break;
      case 'uploaded':
        type = 'success';
        Content = 'Uploaded';
        break;
      case 'error':
        type = 'warning';
        Content = <b style={{color: '#0000aa', textDecoration: 'underline'}}>Error</b>;
        break;
    }
    temparr.push(
      <div className="row" style={{whiteSpace: 'nowrap'}} key={data._id}>
        <div className="col-12 col-md-12">
          <Stack vertical={true} spacing={"tight"}>
            <Badge status={type}>{Content}{haserror && (['7704', '8553', '18906', '14048', '11977', '9560', '8349', '14950', '14921'].indexOf(this.state.user_id) > -1) ?<Icon source={"alert"} color={"red"}/> : ''}</Badge>
          </Stack>
        </div>
      </div>
    );

    return temparr;
  }

  //
  // conditioncheck(data,i)
  // {
  //
  //     let temparr=[];
  //     let final_arr=[];
  //     let upload=0;
  //     let google_status=0;
  //     if(!isUndefined(data[i]['product_data']['fromItems']) && Object.keys(data[i]['product_data']['fromItems']).length > 0 )
  //     {
  //         upload=1;
  //     }
  //     if(data[i]['product_data']['fromItems'].length>0 && (data[i]['product_data']['variants']['source_variant_id'] in data[i]['product_data']['fromItems'][0]['variants']) && ('marketplace_status' in data[i]['product_data']['fromItems'][0]['variants'][
  //             data[i]['product_data']['variants']['source_variant_id']
  //             ] ) && !isUndefined(
  //             data[i]['product_data']['fromItems'][0]['variants'][
  //                 data[i]['product_data']['variants']['source_variant_id']
  //                 ]['marketplace_status']) &&
  //         data[i]['product_data']['fromItems'][0]['variants']
  //             [data[i]['product_data']['variants']['source_variant_id']]['marketplace_status'].length > 0 ){
  //         google_status=1;
  //     }
  //     temparr.push(
  //         <div className="row" style={{whiteSpace:'nowrap'}}>
  //             <div className="col-12 col-md-12">
  //                 { google_status ?<Badge status="success">Product Uploaded</Badge>:<div className="w-100 text-center">
  //                     {/*<FontAwesomeIcon icon={faMinus} size="2x" color="#cccccc"/>*/}
  //                     <Icon source="subtract" />
  //                 </div> }
  //             </div>
  //         </div>
  //     );
  //     if(upload && google_status){
  //         temparr.push(
  //             this.getGoogleStatus(data[i]['product_data']['fromItems'][0]['variants'][data[i]['product_data']['variants']['source_variant_id']]['marketplace_status'])
  //         );
  //     }
  //     // else {
  //     //     temparr.push(
  //     //         <div className="row">
  //     //             <div className="col-12 col-md-12">
  //     //             <Badge status="attention">Status Unavailable</Badge>
  //     //             </div>
  //     //         </div>
  //     //     );
  //     // }
  //     final_arr.push(
  //         <React.Fragment key={'Status'+i}>
  //             {temparr}
  //         </React.Fragment>
  //     );
  //
  //     return temparr;
  //
  //
  //
  // }
  //
  // getGoogleStatus(marketplacestatus){
  //     let temparr=[];
  //     let status={Shopping:{message:'',type:'attention'},ExpressOnline:{message:'',type:'attention'}};
  //     temparr.push()
  //     for(let i=0;i<marketplacestatus.length;i++) {
  //         switch (marketplacestatus[i]['label']) {
  //             case 'Shopping':
  //                 status.Shopping.message=marketplacestatus[i]['message'];
  //                 if(marketplacestatus[i]['message'] == 'approved'){
  //                     status.Shopping.type='success';
  //                 }
  //
  //                 break;
  //             case 'ExpressOnline':
  //                 status.ExpressOnline.message=marketplacestatus[i]['message'];
  //                 if(marketplacestatus[i]['message'] == 'approved'){
  //                     status.ExpressOnline.type='success';
  //                 }
  //                 break;
  //         }
  //     }
  //     if(status.Shopping.message!=='' || status.ExpressOnline.message!=='') {
  //         temparr.push(
  //             <div className="row" style={{whiteSpace:'nowrap'}}>
  //                 {status.Shopping.message !== '' ?
  //                     <div className="col-12 col-md-12">
  //                         <Badge status= {status.Shopping.type}>{`Shopping ${status.Shopping.message}`}</Badge> </div>: ''}
  //                 <br/>
  //                 {status.ExpressOnline.message !== '' ?
  //                     <div className="col-12 col-md-12">
  //                         <Badge status={status.ExpressOnline.type}>{`Express ${status.ExpressOnline.message}`}</Badge> </div>: ''}
  //             </div>
  //         );
  //     }
  //     else{
  //         temparr.push(
  //
  //             <div className="row" style={{whiteSpace:'nowrap'}}>
  //                 <div className="col-12 col-md-12">
  //                     <Badge status="attention">Status Unavailable</Badge>
  //                 </div>
  //             </div>
  //         );
  //     }
  //     return temparr;
  //
  // }

  updateState() {
    const state = this.state;
    this.setState(state);
  }

  closeDeleteProductModal() {
    this.state.toDeleteRow = {};
    this.state.deleteProductData = false;
    const state = this.state;
    this.setState(state);
  }

  closePublishProductModal() {
    // this.state.topublishRow = {};
    this.state.bulkUnpublish = {
      itemIdpresentCount: 0,
      listOfItemIds: []
    };
    this.state.publishProductData = false;
    const state = this.state;
    this.setState(state);
  }

  closeRelistProductModal() {
    // this.state.topublishRow = {};
    this.state.bulkRelist = {
      itemIdpresentCount: 0,
      listOfItemIds: []
    };
    this.state.relistProductData = false;
    const state = this.state;
    this.setState(state);
  }

  closebulksyncProductModal() {
    this.state.bulkSync = {
      itemIdpresentCount: 0,
      listOfItemIds: []
    };
    this.state.sync_fields = {
      all: false,
      details: [],
      variants: [],
    };
    // this.state.topublishRow = {};
    this.state.syncwithShopify = false;
    const state = this.state;
    this.setState(state);
    this.handleChangeSyncall(false);
  }

  closebulksyncallProductModal() {
    this.state.sync_fields = {
      all: false,
      details: [],
      variants: [],
    };
    // this.state.topublishRow = {};
    this.state.syncAllwithShopify = false;
    const state = this.state;
    this.setState(state);
    this.handleChangeSyncall(false);
  }

  closebulkInventorysyncProductModal() {
    this.state.bulkInventorySync = {
      itemIdpresentCount: 0,
      listOfItemIds: []
    };
    // this.state.topublishRow = {};
    this.state.InventorySyncModal = false;
    const state = this.state;
    this.setState(state);
  }

  closeselectexportProductModal() {
    this.state.selectExportCSV = {
      itemIdpresentCount: 0,
      listOfItemIds: []
    };
    // this.state.topublishRow = {};
    this.state.selectExportModal = false;
    const state = this.state;
    this.setState(state);
  }

  CalculateUnpublishDetails() {

    let temparr = this.state.selectedProductDetails.listing_ids.slice(0);
    // this.state.products.forEach((Obj,index)=>{
    //     if(this.state.selectedIds.indexOf(Obj._id)>-1){
    //         if(Obj.listing_id!=='n/a'){
    //             temparr.push(Obj.listing_id);
    //         }
    //     }
    // });
    this.state.bulkUnpublish.listOfItemIds = temparr.slice(0);
    this.state.bulkUnpublish.itemIdpresentCount = temparr.length;
    this.setState(this.state);

  }

  CalculateRelistDetails() {

    let temparr = this.state.selectedProductDetails.listing_ids.slice(0);
    // this.state.products.forEach((Obj,index)=>{
    //     if(this.state.selectedIds.indexOf(Obj._id)>-1){
    //         if(Obj.listing_id!=='n/a'){
    //             temparr.push(Obj.listing_id);
    //         }
    //     }
    // });
    this.state.bulkRelist.listOfItemIds = temparr.slice(0);
    this.state.bulkRelist.itemIdpresentCount = temparr.length;
    this.setState(this.state);

  }

  CalculateInventorySyncWithDetails() {

    let temparr = this.state.selectedProductDetails.source_product_ids.slice(0);
    // this.state.products.forEach((Obj,index)=>{
    //     if(this.state.selectedIds.indexOf(Obj._id)>-1){
    //         if(!isUndefined(Obj.source_product_id)){
    //             temparr.push(Obj.source_product_id);
    //         }
    //     }
    // });
    this.state.bulkInventorySync.listOfItemIds = temparr.slice(0);
    this.state.bulkInventorySync.itemIdpresentCount = temparr.length;
    this.setState(this.state);

  }

  CalculateexportcsvDetails() {
    let temparr = this.state.selectedProductDetails.source_product_ids.slice(0);
    this.state.selectExportCSV.listOfItemIds = temparr.slice(0);
    this.state.selectExportCSV.itemIdpresentCount = temparr.length;
    this.setState(this.state);

  }

  CalculateUploadable() {

    let temparr = this.state.selectedProductDetails.source_product_ids.slice(0);
    // this.state.products.forEach((Obj,index)=>{
    //     if(this.state.selectedIds.indexOf(Obj._id)>-1){
    //         if(!isUndefined(Obj.source_product_id)){
    //             temparr.push(Obj.source_product_id);
    //         }
    //     }
    // });
    this.state.SelectUpload.listOfItemIds = temparr.slice(0);
    this.state.SelectUpload.itemIdpresentCount = temparr.length;
    this.setState(this.state);

    this.getUploadabledetails()


  }

  formulateUploadabledata(data) {

    let tempObjMatchingProfile = [];
    let { matching_profiles, product_profile_data } = data;
     matching_profiles.forEach(profile => {
      tempObjMatchingProfile.push({label: profile['name'], value: profile['id'].toString()});
    });


    // let tempObjprofileData = {};
    //
    // if (!isUndefined(data['product_profile_data']) && !isUndefined(data['matching_profiles'])) {
    //   tempObjMatchingProfile.push({label: 'Default profile', value: 'default_profile'});
    //   data['matching_profiles'].forEach((profile, pos) => {
    //     tempObjMatchingProfile.push({label: profile['name'], value: profile['id'].toString()});
    //   });
    //   data['product_profile_data'].forEach((profileData, index) => {
    //
    //     if (isUndefined(tempObjprofileData)) {
    //       if (!profileData['profile_id']) {
    //         tempObjprofileData['false'] = {
    //           profile_name: profileData['profile_name'],
    //           source_product_ids: [profileData['container_id']]
    //         }
    //
    //       } else {
    //
    //         tempObjprofileData[profileData['profile_id']] = {
    //           profile_name: profileData['profile_name'],
    //           source_product_ids: [profileData['container_id']]
    //         }
    //       }
    //     } else {
    //
    //       if (!profileData['profile_id']) {
    //         if ('false' in tempObjprofileData) {
    //           tempObjprofileData['false']['source_product_ids'].push(profileData['container_id']);
    //         } else {
    //           tempObjprofileData['false'] = {
    //             profile_name: profileData['profile_name'],
    //             source_product_ids: [profileData['container_id']]
    //           }
    //         }
    //       } else {
    //         if (profileData['profile_id'] in tempObjprofileData) {
    //           tempObjprofileData[profileData['profile_id']]['source_product_ids'].push(profileData['container_id']);
    //         } else {
    //           tempObjprofileData[profileData['profile_id']] = {
    //             profile_name: profileData['profile_name'],
    //             source_product_ids: [profileData['container_id']]
    //           }
    //         }
    //       }
    //     }
    //   });
    // }
    // if (!isUndefined(tempObjprofileData['false']) && !tempObjprofileData['false']['profile_name']) {
    //   tempObjprofileData['false']['profile_name'] = 'default_profile';
    // }

    this.state.SelectUploadProfileData.matchingProfile = tempObjMatchingProfile.slice(0);

    this.state.SelectUploadProfileData.profileData = product_profile_data.slice(0);
    this.state.selectandUpload = true;
    const state = this.state;
    this.setState(state);

  }

  getUploadabledetails() {

    let tempObj = {
      product_ids: this.state.SelectUpload.listOfItemIds,
      source: 'shopify',
      target: 'ebay',
      target_shop: this.state.site_id
    }

    requests.postRequest('ebayV1/upload/getProductProfiles', tempObj).then(data => {
      if (data.success) {
        if (!isUndefined(data.data)) {
          this.formulateUploadabledata(data.data);
        } else {
          notify.error('Upload information missing');
        }
      } else {
        notify.error(data.message);
      }

    })
  }

  CalculateSyncWithDetails() {

    let temparr = this.state.selectedProductDetails.source_product_ids.slice(0);
    ;
    // this.state.products.forEach((Obj,index)=>{
    //     if(this.state.selectedIds.indexOf(Obj._id)>-1){
    //         if(!isUndefined(Obj.source_product_id)){
    //             temparr.push(Obj.source_product_id);
    //         }
    //     }
    // });
    this.state.bulkSync.listOfItemIds = temparr.slice(0);
    this.state.bulkSync.itemIdpresentCount = temparr.length;
    this.setState(this.state);

  }

  setunPublishproduct(event, data) {
    // this.state.topublishRow=data;
    this.CalculateUnpublishDetails();
    this.state.publishProductData = true;
    const state = this.state;
    this.setState(state);
  }

  opensyncImagesofProduct(){
    this.state.syncImagesModal = true;
    const state = this.state;
    this.setState(state);
  }

  closesyncImagesofProduct(){
    this.state.syncImagesModal = false;
    const state = this.state;
    this.setState(state);
  }

  setbulkRelistproduct(event, data) {
    // this.state.topublishRow=data;
    this.CalculateRelistDetails();
    this.state.relistProductData = true;
    const state = this.state;
    this.setState(state);
  }

  setsyncwithShopify(event, data) {
    // this.state.topublishRow=data;
    this.CalculateSyncWithDetails();
    this.state.syncwithShopify = true;
    const state = this.state;
    this.setState(state);
  }

  setInventorysync(event, data) {
    // this.state.topublishRow=data;
    this.CalculateInventorySyncWithDetails();
    this.state.InventorySyncModal = true;
    const state = this.state;
    this.setState(state);
  }

  setexportProducts(event, data) {
    this.CalculateexportcsvDetails();
    this.state.selectExportModal = true;
    const state = this.state;
    this.setState(state);
  }

  setSelectandUpload() {

    this.CalculateUploadable();
    // this.state.selectandUpload=true;
    // const state = this.state;
    // this.setState(state);
  }

  closeSelectandUpload() {
    let tempObj = {
      itemIdpresentCount: 0,
      listOfItemIds: []
    };
    this.state.selectandUpload = false;
    this.state.SelectUpload = Object.assign({}, tempObj);
    this.state.SelectUploadProfileData = {
      matchingProfile: [],
      profileData: [],
      selected_profile:''
    };
    this.state.uploadUsingDiffprofile.id = '';
    this.state.uploadUsingDiffprofile.profile_name = '';
    this.state.uploadUsingDiffprofile.data_selected = false;
    this.state.uploadUsingDiffprofile.data = {};
    const state = this.state;
    this.setState(state);
  }

  operations(data, event) {
    switch (event) {
      case 'status':
        this.handleStatusViewChange(event, JSON.parse(data));
        break;
      case 'unpublish': /*this.setunPublishproduct(event,JSON.parse(data))*/
        ;
        break;
      // case 'grid':
      //     // let parent_props = {
      //     //     gridSettings:this.gridSettings,
      //     //     filters: this.filters,
      //     // };
      //     let tempObj={id:data['_id']}
      //     let message=cryptr.encrypt(JSON.stringify(tempObj));
      //     this.redirect('/panel/products/view?message='+message);break;
      case 'title':
        // let parent_props = {
        //     gridSettings:this.gridSettings,
        //     filters: this.filters,
        // };

        let tempObjtitle = {id: data['source_product_id']}
        let messagetitle = cryptr.encrypt(JSON.stringify(tempObjtitle));
        this.redirect('/panel/products/view?message=' + messagetitle);
        break;

      // case 'main_image':
      // let parent_props = {
      //     gridSettings:this.gridSettings,
      //     filters: this.filters,
      // };

      // let tempObj={id:data['source_product_id']}
      // let message=cryptr.encrypt(JSON.stringify(tempObj));
      // this.redirect('/panel/products/view?message='+message);break;
      case 'ebay_status':
        requests.getRequest('ebayV1/get/failedProducts', {product_id: data._id}).then(data => {
          if (data.success) {
            this.prepareStatusData(data.data);
          }
        });
        break;
      case 'ebay_item_id':

        requests.getRequest('ebayV1/get/ebayProductData', {listing_id: data.ebay_item_id.props.children}).then(data1 => {
          if (data1.success) {
            // window.open(data1.data.ListingDetails.ViewItemURL,'_blank');
            this.state.ListingRedirectId = data.ebay_item_id.props.children;
            this.state.ListingRedirectUrl = data1.data.ListingDetails.ViewItemURL;
            this.state.showListingRedirectModal = true;
            this.setState(this.state);
          }
        })
        break;
      default:
        break;

    }
  }

  prepareStatusData(data) {
    let temparr = [];
    if (!isUndefined(data.full_response) && Object.keys(data.full_response).length > 0) {
      let FullResponse = Object.assign({}, flatten(data.full_response));

      if (FullResponse.hasOwnProperty('Message')) {
        temparr.push(
          <Banner title={'Error'} status="critical" key={'htmlError'}>
            <p dangerouslySetInnerHTML={{__html: FullResponse.Message}}/>
          </Banner>
        );
      }
      temparr = this.prepareStatusResponse(FullResponse, temparr);
    }

    if (temparr.length === 0) {
      if (!isUndefined(data.report) && Object.keys(data.report).length > 0) {
        let reportResponse = Object.assign({}, flatten(data.report));
        temparr = this.prepareStatusResponse(reportResponse, temparr);
      }
    }
    if (!isUndefined(temparr.length) && temparr.length > 0) {
      this.state.statusShowData = temparr;
      this.state.statusModalTitle = !isUndefined(data['title']) ?
        <p>{data['title']} <sub>(eBay response)</sub></p> : 'Product status'
      this.state.statusShowModal = true;
      this.setState(this.state);
    }
  }

  prepareStatusResponse(FullResponse, temparr =[]){
    Object.keys(FullResponse).map(key => {
      if (key.includes('SeverityCode')) {
        let keySplit = key.split('.');
        let indexOfSeverityCode = keySplit.indexOf('SeverityCode');
        let indexOfError = indexOfSeverityCode - 1;
        keySplit[indexOfSeverityCode] = 'LongMessage';
        let LongMessageKey = keySplit.join('.');
        let typeOfError = FullResponse[key];
        let Message = FullResponse[LongMessageKey];

        switch (typeOfError) {
          case 'Error':
            temparr.push(
              <Banner title={'Error'} status="critical" key={indexOfError}>
                {Message}
              </Banner>
            );
            break;
          case 'Warning':
            temparr.push(
              <Banner title={'Warning'} status={"warning"} key={indexOfError}>
                {Message}
              </Banner>
            );
            break;
          default:
            temparr.push(
              <Banner status={"critical"} key={indexOfError}>
                {Message}
              </Banner>
            );
        }
      }
      if(!isNaN(key)){
        temparr.push(
          <Banner status={"critical"} key={'title_error_key'}>
            {FullResponse[key]}
          </Banner>
        );
      }
    });

    return temparr;
  }

  // prepareStatusData(data) {
  //     if (!isUndefined(data.report) && data.report) {
  //         let temparr = [];
  //         if (!isUndefined(data.report) && data.report) {
  //
  //             if (Array.isArray(data.report)) {
  //                 (data.report).forEach((value, index) => {
  //                     if (typeof value === 'string') {
  //                         switch (value.SeverityCode) {
  //                             case 'Error':
  //                                 temparr.push(
  //                                     <Banner title={'Error'} status="critical" key={index}>
  //                                         {value}
  //                                     </Banner>
  //                                 )
  //                                 break;
  //                             case 'Warning':
  //                                 temparr.push(
  //                                     <Banner title={'Warning'} status={"warning"} key={index}>
  //                                         {value}
  //                                     </Banner>
  //                                 )
  //                                 break;
  //                             default:
  //                                 temparr.push(
  //                                     <Banner status={"critical"} key={index}>
  //                                         {value}
  //                                     </Banner>
  //                                 )
  //
  //                         }
  //                     } else if (typeof value === 'object') {
  //                         switch (value.SeverityCode) {
  //                             case 'Error':
  //                                 let error_spec = 0;
  //                                 if (value.ErrorCode === '240') {
  //                                     if (!isUndefined(value.ErrorParameters)) {
  //                                         if (typeof value.ErrorParameters === 'object') {
  //                                             (value.ErrorParameters).forEach((error, pos) => {
  //                                                 if (error.ParamID === '0') {
  //                                                     error_spec = 1;
  //                                                     temparr.push(
  //                                                         <Banner title={'Error'} status="critical" key={index}>
  //                                                             <p dangerouslySetInnerHTML={{__html: error.Value}}/>
  //
  //                                                         </Banner>
  //                                                     );
  //                                                 }
  //                                             })
  //                                         }
  //                                     }
  //                                 }
  //                                 ;
  //
  //                                 if (!isUndefined(data.full_response) && !isUndefined(data.full_response.Message)) {
  //                                     error_spec = 1;
  //                                     temparr.push(
  //                                         <Banner title={'Error'} status="critical" key={index}>
  //                                             <p dangerouslySetInnerHTML={{__html: data.full_response.Message}}/>
  //
  //                                         </Banner>
  //                                     );
  //                                 }
  //
  //                                 if (error_spec === 0) {
  //                                     temparr.push(
  //                                         <Banner title={'Error'} status="critical" key={index}>
  //                                             {value.LongMessage}
  //                                         </Banner>
  //                                     )
  //                                 }
  //                                 break;
  //                             case 'Warning':
  //                                 temparr.push(
  //                                     <Banner title={'Warning'} status="warning" key={index}>
  //                                         {value.LongMessage}
  //                                     </Banner>
  //                                 );
  //                                 break;
  //                             default:
  //                                 temparr.push(
  //                                     <Banner status="critical" key={index}>
  //                                         {value.LongMessage}
  //                                     </Banner>
  //                                 )
  //                         }
  //                     }
  //                 });
  //             } else {
  //                 Object.keys(data.report).map((value, index) => {
  //
  //                     if (typeof data.report[value] === 'string') {
  //
  //                         switch (data.report[value].SeverityCode) {
  //                             case 'Error':
  //                                 temparr.push(
  //                                     <Banner title={'Error'} status="critical" key={index}>
  //                                         {data.report[value]}
  //                                     </Banner>
  //                                 )
  //                                 break;
  //                             case 'Warning':
  //                                 temparr.push(
  //                                     <Banner title={'Warning'} status={"warning"} key={index}>
  //                                         {data.report[value]}
  //                                     </Banner>
  //                                 )
  //                                 break;
  //                             default:
  //                                 temparr.push(
  //                                     <Banner status={"critical"} key={index}>
  //                                         {data.report[value]}
  //                                     </Banner>
  //                                 )
  //
  //                         }
  //                     } else if (typeof data.report[value] === 'object') {
  //                         let value = Object.assign({}, data.report[index]);
  //                         switch (value.SeverityCode) {
  //                             case 'Error':
  //                                 let error_spec = 0;
  //                                 if (value.ErrorCode === '240') {
  //                                     if (!isUndefined(value.ErrorParameters)) {
  //                                         if (typeof value.ErrorParameters === 'object') {
  //                                             (value.ErrorParameters).forEach((error, pos) => {
  //                                                 if (error.ParamID === '0') {
  //                                                     error_spec = 1;
  //                                                     temparr.push(
  //                                                         <Banner title={'Error'} status="critical" key={index}>
  //                                                             <p dangerouslySetInnerHTML={{__html: error.Value}}/>
  //
  //                                                         </Banner>
  //                                                     );
  //                                                 }
  //                                             })
  //                                         }
  //                                     }
  //                                 }
  //                                 ;
  //
  //                                 if (!isUndefined(data.full_response) && !isUndefined(data.full_response.Message)) {
  //                                     error_spec = 1;
  //                                     temparr.push(
  //                                         <Banner title={'Error'} status="critical" key={index}>
  //                                             <p dangerouslySetInnerHTML={{__html: data.full_response.Message}}/>
  //
  //                                         </Banner>
  //                                     );
  //                                 }
  //
  //                                 if (error_spec === 0) {
  //                                     temparr.push(
  //                                         <Banner title={'Error'} status="critical" key={index}>
  //                                             {value.LongMessage}
  //                                         </Banner>
  //                                     )
  //                                 }
  //                                 break;
  //                             case 'Warning':
  //                                 temparr.push(
  //                                     <Banner title={'Warning'} status="warning" key={index}>
  //                                         {value.LongMessage}
  //                                     </Banner>
  //                                 );
  //                                 break;
  //                             default:
  //                                 if (!isUndefined(value.LongMessage)) {
  //                                     temparr.push(
  //                                         <Banner status="critical" key={index}>
  //                                             {value.LongMessage}
  //                                         </Banner>
  //                                     );
  //                                 }
  //                         }
  //                     } else if (typeof data.report[value] === 'string') {
  //                         temparr.push(
  //                             <Banner status="critical" key={index}>
  //                                 {data.report[value]}
  //                             </Banner>);
  //                     }
  //                 });
  //             }
  //         }
  //         if (!isUndefined(temparr.length) && temparr.length > 0) {
  //             this.state.statusShowData = temparr;
  //             this.state.statusModalTitle = !isUndefined(data['title']) ?
  //                 <p>{data['title']} <sub>(eBay response)</sub></p> : 'Product status'
  //             this.state.statusShowModal = true;
  //             this.setState(this.state);
  //         }
  //     }
  // }

  publishProductconfirmed() {
    requests.postRequest('ebayV1/upload/bulkUnpublish', {
      'listing_ids': this.state.bulkUnpublish.listOfItemIds,
      reason_end_listing: this.state.reason_end_listing
    }).then(data => {
      if (data.success) {
        notify.success(data.message)
        if (data.code === "unpublish_process_started") {
          this.redirect('/panel/activities');
        }
      } else {
        notify.error(data.message);
      }
    });

    this.closePublishProductModal();
  }

  relistProductconfirmed() {
    requests.postRequest('ebayV1/upload/massRelistItem', {'listing_ids': this.state.bulkRelist.listOfItemIds}).then(data => {
      if (data.success) {
        notify.success(data.message)
        if (data.code === "product_relisting_started") {
          this.redirect('/panel/activities');
        }
      } else {
        notify.error(data.message);
      }
    });

    this.closeRelistProductModal();
  }

  selectAndUploadConfirm() {
    let tempObj = {};
    let { selected_profile } = this.state.SelectUploadProfileData;

      tempObj = {
        marketplace: 'ebay',
        source: 'shopify',
        source_shop_id: this.state.importServicesList[0].shops[0].id,
        target_shop_id: this.state.uploadServicesList[0].shops[0].id,
        selected_profile: selected_profile,
        product_ids: this.state.SelectUpload.listOfItemIds
      };

    requests.postRequest('ebayV1/upload/selectAndUploadProducts', tempObj).then(data => {
      if (data.success) {
        if (data.code === 'product_upload_started') {
          notify.info(data.message);
          this.redirect('/panel/activities');
        }
      } else {
        notify.error(data.message);
      }
    });
    this.closeSelectandUpload();
  }

  syncProductconfirmed() {

    let tempObj = {
      product_ids: this.state.bulkSync.listOfItemIds,
    }
    if (!this.state.sync_fields.all) {
      tempObj['sync_fields'] = this.state.sync_fields;
    }

    requests.postRequest('ebayV1/upload/syncWithShopify', tempObj).then(data => {
      if (data.success) {
        notify.success(data.message)
        if (data.code === "syncing_process_started") {
          this.redirect('/panel/activities');
        }
      } else {
        notify.error(data.message);
      }
    });

    this.closebulksyncProductModal();
  }

  publishProductModal() {
    return (
      <Modal
        open={this.state.publishProductData}
        onClose={() => {
          this.closePublishProductModal();
        }}
      >
        <Modal.Section>
          <Stack vertical={true} alignment={"center"} spacing={"loose"}>
            <Stack.Item>
              <Stack vertical={true} alignment={"center"} spacing={"loose"}>
                <h2>You have
                  selected {this.state.selectedIds.length} {this.state.selectedIds.length > 1 ? "Products" : "Product"}</h2>
                {this.state.bulkUnpublish.itemIdpresentCount !== this.state.selectedIds.length &&
                <h2>{this.state.bulkUnpublish.itemIdpresentCount === 0 ? "None " : this.state.bulkUnpublish.itemIdpresentCount} of
                  the
                  selected {this.state.selectedIds.length > 1 ? this.state.selectedIds.length : ''} {this.state.selectedIds.length > 1 ? "Products" : "Product"} Contains
                  eBay item id</h2>}
                {this.state.bulkUnpublish.itemIdpresentCount !== 0 ?
                  <h2>Do you want to end them from eBay?</h2> :
                  <h2>Only products with eBay item id can be ended</h2>}
              </Stack>

            </Stack.Item>
            {this.state.bulkUnpublish.itemIdpresentCount !== 0 &&
            <Select
              key={'Endreasonlisting-select'}
              options={reason_end_listing}
              label={'Please provide end reason listing'}
              value={this.state.reason_end_listing}
              onChange={(e) => {
                this.setState({reason_end_listing: e})
              }}/>
            }
            <Stack.Item>

              <Button
                disabled={this.state.bulkUnpublish.itemIdpresentCount === 0}
                onClick={() => {
                  this.publishProductconfirmed()
                }} primary>
                Yes
              </Button>
            </Stack.Item>
          </Stack>

        </Modal.Section>
      </Modal>
    );
  }

  RelistProductModal() {
    return (
      <Modal
        open={this.state.relistProductData}
        onClose={() => {
          this.closeRelistProductModal();
        }}
      >
        <Modal.Section>
          <div className="row p-5">
            <div className="col-12 text-center">

              <h2>You have
                selected {this.state.selectedIds.length} {this.state.selectedIds.length > 1 ? "Products" : "Product"}</h2>
              {this.state.bulkRelist.itemIdpresentCount !== this.state.selectedIds.length &&
              <h2>{this.state.bulkRelist.itemIdpresentCount === 0 ? "None " : this.state.bulkRelist.itemIdpresentCount} of
                the
                selected {this.state.selectedIds.length > 1 ? this.state.selectedIds.length : ''} {this.state.selectedIds.length > 1 ? "Products" : "Product"} Contains
                eBay item id</h2>}
              {this.state.bulkRelist.itemIdpresentCount !== 0 ?
                <h2>Do you want to relist them on eBay?</h2> :
                <h2>Only products with eBay item id can be unpublished</h2>}
            </div>
            <div className="col-12 text-center pt-5">
              <Button
                disabled={this.state.bulkRelist.itemIdpresentCount === 0}
                onClick={() => {
                  this.relistProductconfirmed()
                }} primary>
                Yes
              </Button>
            </div>
          </div>
        </Modal.Section>
      </Modal>
    );
  }

  getProductAdditionalDetails(data) {
    let sourceproductIds = this.state.selectedProductDetails.source_product_ids.slice(0);
    let listingIds = this.state.selectedProductDetails.listing_ids.slice(0);
    if (Array.isArray(data)) {
      data.forEach((row, index) => {
        if (!isUndefined(row.source_product_id)) {
          if (sourceproductIds.indexOf(row.source_product_id) === -1) {
            sourceproductIds.push(row.source_product_id);
          } else {
            sourceproductIds.splice(sourceproductIds.indexOf(row.source_product_id), 1);
          }
        }
        if (!isUndefined(row.listing_id) && row.listing_id !== 'n/a') {
          if (listingIds.indexOf(row.listing_id) === -1) {
            listingIds.push(row.listing_id);
          } else {
            listingIds.splice(listingIds.indexOf(row.listing_id), 1);
          }
        }
      })

    } else {
      if (!isUndefined(data.source_product_id)) {
        if (sourceproductIds.indexOf(data.source_product_id) === -1) {
          sourceproductIds.push(data.source_product_id);
        } else {
          sourceproductIds.splice(sourceproductIds.indexOf(data.source_product_id), 1);
        }
      }
      if (!isUndefined(data.listing_id) && data.listing_id !== 'n/a') {
        if (listingIds.indexOf(data.listing_id) === -1) {
          listingIds.push(data.listing_id);
        } else {
          listingIds.splice(listingIds.indexOf(data.listing_id), 1);
        }
      }
    }
    this.state.selectedProductDetails.source_product_ids = sourceproductIds.slice(0);
    this.state.selectedProductDetails.listing_ids = listingIds.slice(0)
    this.updateState();
    // console.log(data);
    // console.log(this.state.selectedIds);
  }

  InventoryBulkSyncModal() {
    return (
      <Modal
        open={this.state.InventorySyncModal}
        onClose={() => {
          this.closebulkInventorysyncProductModal();
        }}
      >
        <Modal.Section>
          <div className="row p-5">
            <div className="col-12 text-center">

              <h2>You have
                selected {this.state.selectedIds.length} {this.state.selectedIds.length > 1 ? "Products" : "Product"}</h2>
              {this.state.bulkInventorySync.itemIdpresentCount !== this.state.selectedIds.length &&
              <h2>{this.state.bulkInventorySync.itemIdpresentCount === 0 ? "None " : this.state.bulkInventorySync.itemIdpresentCount} of
                the
                selected {this.state.selectedIds.length > 1 ? this.state.selectedIds.length : ''} {this.state.selectedIds.length > 1 ? "Products" : "Product"} Contains
                product ID</h2>}
              {this.state.bulkInventorySync.itemIdpresentCount !== 0 ? <h2>Do you want to
                  sync {this.state.selectedIds.length > 1 ? "their" : "it's"} inventory?</h2> :
                <h2>Inventory of only products with product ID can be synced</h2>}
            </div>
            <div className="col-12 text-center pt-5">
              <Button
                disabled={this.state.bulkInventorySync.itemIdpresentCount === 0}
                onClick={() => {
                  this.inventorySync()
                }} primary>
                Yes
              </Button>
            </div>
          </div>
        </Modal.Section>
      </Modal>
    );
  }

  exportselectedProducts() {
    requests.postRequest('ebayV1/app/selectandExportCSV', {'product_ids': this.state.selectExportCSV.listOfItemIds}).then(data => {
      if (data.success) {
        notify.success(data.message);
        if (data.code === "export_started") {
          this.redirect('/panel/activities');
        }
      } else {
        notify.error(data.message);
      }
      this.closeselectexportProductModal();
    });
  }

  selectAndExportCsvModal() {
    return (
      <Modal
        open={this.state.selectExportModal}
        onClose={() => {
          this.closeselectexportProductModal();
        }}
      >
        <Modal.Section>
          <div className="row p-5">
            <div className="col-12 text-center">

              <h2>You have
                selected {this.state.selectedIds.length} {this.state.selectedIds.length > 1 ? "Products" : "Product"}</h2>
              <h2>Do you want to
                export {this.state.selectedIds.length > 1 ? "their" : "it's"} details?</h2>
            </div>
            <div className="col-12 text-center pt-5">
              <Button
                disabled={this.state.selectExportCSV.itemIdpresentCount === 0}
                onClick={() => {
                  this.exportselectedProducts()
                }} primary>
                Yes
              </Button>
            </div>
          </div>
        </Modal.Section>
      </Modal>
    );
  }

  StatusShowModal() {
    return (
      <Modal
        title={this.state.statusModalTitle}
        open={this.state.statusShowModal}
        onClose={() => {
          this.state.statusShowModal = false;
          this.state.statusModalTitle = "";
          this.setState(this.state);
        }}
      >
        <Modal.Section>
          <Card actions={[{
            content: <React.Fragment>
              <b style={{color: '#0000aa', textDecoration: 'underline'}}>Solution</b>
            </React.Fragment>, onAction: this.redirect.bind(this, '/panel/help')
          }]}>
            <Card.Section>
              {this.state.statusShowData}
            </Card.Section>
          </Card>
        </Modal.Section>
      </Modal>
    );
  }

  ListingIdShowModal() {
    return (
      <Modal
        open={this.state.showListingRedirectModal}
        onClose={() => {
          this.state.showListingRedirectModal = false;
          this.state.ListingRedirectId = '';
          this.state.ListingRedirectUrl = '';
          this.setState(this.state);
        }}
        /*primaryAction={{content:'Redirect', onAction:()=>{
                    window.open(this.state.ListingRedirectUrl,'_blank');
                    }}}*/>
        <Modal.Section>
          <Stack vertical={true} alignment={"center"}>
            <DisplayText element={"p"} size={"small"}>
              View product on eBay?
            </DisplayText>
            <Button primary={true} onClick={() => {
              window.open(this.state.ListingRedirectUrl, '_blank');
              this.state.showListingRedirectModal = false;
              this.state.ListingRedirectId = '';
              this.state.ListingRedirectUrl = '';
              this.setState(this.state);
            }}>Yes</Button>
          </Stack>
        </Modal.Section>
      </Modal>
    );
  }

  syncBulkProductModal() {
    return (
      <Modal
        open={this.state.syncwithShopify}
        onClose={() => {
          this.closebulksyncProductModal();
        }}
      >
        <Modal.Section>
          <div className="row p-5">
            <div className="col-12 text-center p-1">
              <h2>You have
                selected {this.state.bulkSync.listOfItemIds.length} {this.state.bulkSync.listOfItemIds.length > 1 ? "Products" : "Product"}</h2>
              <h2>Do you want to sync them with Shopify?</h2>
            </div>
            <div className="col-12 mt-3">
              {this.getSyncfieldsCompo()}
            </div>
            <div className="col-12 text-center pt-5">
              <Button
                disabled={this.state.sync_fields.variants.length === 0 && this.state.sync_fields.details.length === 0}
                onClick={() => {
                  this.syncProductconfirmed()
                }} primary>
                Yes
              </Button>
            </div>
          </div>
        </Modal.Section>
      </Modal>
    );
  }


  syncAllProductModal() {
    return (
      <Modal
        open={this.state.syncAllwithShopify}
        onClose={() => {
          this.closebulksyncallProductModal();
        }}
      >
        <Modal.Section>
          <div className="row p-5">
            <div className="col-12 text-center p-1">
              <h2 className='font-weight-bold'>You are about to perform bulk sync for all products</h2>
            </div>
            <div className="col-12 mt-3">

              {this.getSyncfieldsCompo()}

            </div>
            <div className="col-12 text-center pt-5">
              <Button
                disabled={this.state.sync_fields.variants.length === 0 && this.state.sync_fields.details.length === 0}
                onClick={() => {
                  this.BulkSyncwithShopify()
                }} primary>
                Yes
              </Button>
            </div>
          </div>
        </Modal.Section>
      </Modal>
    );
  }

  SelectUploadMatchProfile(value) {
    this.state.SelectUploadProfileData.profileData.selected_profile = value;
    this.setState(this.state);
  }

  SelectUploadUsingDiffProfile(value) {
    this.state.SelectUploadProfileData.selected_profile = value;
    this.setState(this.state);
  }

  renderUploadProductDetails() {
    let temparr = [];
    let { matchingProfile, profileData, selected_profile } = this.state.SelectUploadProfileData;

    let profileExistingonProducts = {};

    profileData.forEach((profile) => {
      let { profile_name } = profile;

      if(!profile_name){
        profile_name = 'Default Profile';
      }
      if( profileExistingonProducts.hasOwnProperty(profile_name)){
        profileExistingonProducts[profile_name] +=1;
      }else{
        profileExistingonProducts[profile_name] = 1;
      }
    });

    Object.keys(profileExistingonProducts).map( key => {


      temparr.push(
          <Banner status={'info'}>
            <p><b>{profileExistingonProducts[key]}</b> product(s) belong to profile <b>{key}</b></p>
          </Banner>
      );
      return true;
    });
      temparr.push(
        <Stack.Item key={'notfalsekey'}>
          <FormLayout>
            <Banner status={"info"}>
              <p>If you want to <b>upload</b> the selected product(s) with a <b>different
                profile</b> kindly select one <b>Profile</b> from below and <b>click on Upload</b>,Or to
                continue with the already assigned one just click <b>Upload</b></p>
            </Banner>
            <Select
              label={''}
              options={matchingProfile}
              placeholder={'Please select'}
              value={selected_profile}
              onChange={this.SelectUploadUsingDiffProfile.bind(this)}>
            </Select>
          </FormLayout>
        </Stack.Item>
      );

    return temparr;

  }

  selectAndUploadModal() {
    return (
      <Modal
        open={this.state.selectandUpload}
        onClose={() => {
          this.closeSelectandUpload();
        }}
        primaryAction={{
          content: 'Upload',
          onAction: this.selectAndUploadConfirm.bind(this),
        }}
      >
        <Modal.Section>

          <Stack vertical={true}>
            <DisplayText element={"h2"}><b>Among the selected products</b></DisplayText>
            {
              this.renderUploadProductDetails()
            }
          </Stack>
        </Modal.Section>
      </Modal>
    );
  }

  deleteProductModal() {
    return (
      <Modal
        open={this.state.deleteProductData}
        onClose={() => {
          this.closeDeleteProductModal();
        }}
        title="Delete Product?"
        primaryAction={{
          content: 'Delete',
          onAction: () => {
            notify.success(this.state.toDeleteRow.title + ' deleted  successfully');
            this.closeDeleteProductModal();
          },
        }}
        secondaryActions={[
          {
            content: 'No',
            onAction: () => {
              notify.info('No products deleted');
              this.closeDeleteProductModal();
            }
          },
        ]}
      >
        <Modal.Section>
          <TextContainer>
            <p>
              Are you sure, you want to delete {this.state.toDeleteRow.title}?
            </p>
          </TextContainer>
        </Modal.Section>
      </Modal>
    );
  }

  exportProductModal() {
    return (
      <Modal
        open={this.state.exportProductDataCsv}
        onClose={() => {
          this.state.exportProductDataCsv = false;
          this.updateState();
        }}
        title="Product Export"
        primaryAction={{
          content: 'Yes',
          onAction: () => {
            this.exportCSV();
            this.state.exportProductDataCsv = false;
            this.updateState();
          },
        }}
        secondaryActions={[
          {
            content: 'No',
            onAction: () => {
              this.state.exportProductDataCsv = false;
              this.updateState()
            }
          },
        ]}
      >
        <Modal.Section>
          <TextContainer>
            <div className="row text-center">
              <div className="col-12 col-md-12">
                <p style={{fontSize: "1em"}}>
                  Are you sure, You want to Export product's data to CSV?
                </p>
              </div>
            </div>
          </TextContainer>
        </Modal.Section>
      </Modal>
    );
  }

  syncImagestoebay(){
    let productIds = Object.keys(this.state.checkbox);
    requests.getRequest('ebayV1/upload/syncImageswithShopify', { product_ids : [...productIds]}).then(data => {
      if(data.success){
        notify.success(data.message);
        this.redirect('/panel/activities');
      }else{
        notify.error(data.message);
      }
    });
  }

  syncImagesModalStructure() {
    return (
      <Modal
        open={this.state.syncImagesModal}
        onClose={() => {
          this.closesyncImagesofProduct();
        }}
        title="Sync images to eBay"
        primaryAction={{
          content: 'Yes',
          onAction: () => {
            this.syncImagestoebay();
          },
        }}
      >
        <Modal.Section>
          <TextContainer>
            <div className="row text-center">
              <div className="col-12 col-md-12">
                <p style={{fontSize: "1em"}}>
                  Are you sure, You want to sync Images to eBay ?
                </p>
              </div>
            </div>
          </TextContainer>
        </Modal.Section>
      </Modal>
    );
  }

  exportCSV() {
    requests.postRequest("connector/product/exportProductCSV", {marketplace: 'shopify'}).then(data => {
      if (data.success) {
        this.redirect('/panel/activities');
      } else {
        notify.error(data.message);
      }
    });
  }

  handleTabChange(event) {
    this.state.selectedTab = event;
    this.state.EnableMultiselect = (event === 1 || event === 3);
    this.state.selectedProductDetails = {};
    this.state.checkbox = {};
    switch (event) {
      case 2:
        this.massActions.forEach((value, index) => {
          if (value.label !== 'Relist on eBay' && value.label !== 'End from eBay' /*value.label === 'Upload and revise on eBay' || value.label === 'Update on eBay' || value.label === 'Upload on eBay'*/) {
            this.massActions[index].disabled = false;
          } else {
            this.massActions[index].disabled = true;
          }
        });
        break;
      case 3:
        this.massActions.forEach((value, index) => {
          if ( value.label !== 'End from eBay' /*value.label === 'Relist on eBay'*/ /*|| value.label === 'Upload and revise on eBay' */) {
            this.massActions[index].disabled = false;
          } else {
            this.massActions[index].disabled = true;
          }
        });
        break;
      case 4:
        this.massActions.forEach((value, index) => {
          if (value.label !== 'Relist on eBay' && value.label !== 'End from eBay' /*value.label === 'Upload and revise on eBay' || value.label === 'Sync details' || value.label === 'Sync inventory'*/) {
            this.massActions[index].disabled = false;
          } else {
            this.massActions[index].disabled = true;
          }
        });
        break;
      default:
        this.massActions.forEach((value, index) => {
          if (value.label === 'Relist on eBay') {
            this.massActions[index].disabled = true;
          } else {
            this.massActions[index].disabled = false;
          }
        });

    }
    this.state.selectedIds = [];
    this.state.profile_suggestion_show = {};
    this.state.selectedProductDetails = {
      listing_ids: [],
      source_product_ids: []
    };
    this.state.showLoaderBar = false;
    this.setState(this.state);
    this.getProducts();
  }

  inventorySync() {
    requests.postRequest('ebayV1/upload/inventorySync', {'product_ids': this.state.bulkInventorySync.listOfItemIds}).then(data => {
      if (data.success) {
        notify.success(data.message)
        if (data.code === "syncing_process_started") {
          this.redirect('/panel/activities');
        }
      } else {
        notify.error(data.message);
      }
    });

    this.closebulkInventorysyncProductModal();
  }

  bulkInventorySync() {
    let tempObj = {};
    if (this.state.bulk_action_marketplace !== '') {
      tempObj['sync_to'] = this.state.bulk_action_marketplace;
    }
    requests.getRequest('ebayV1/upload/bulkSyncInventory', tempObj).then(data => {
      if (data.success) {
        if (data.code === 'syncing_process_started') {
          notify.success(data.message);
          this.redirect('/panel/activities');
        }
      } else {
        notify.error(data.message)

      }
      this.setState({bulk_action_marketplace: ''});
    })
  }

  bulkPriceSync() {
    let tempObj = {};
    if (this.state.bulk_action_marketplace !== '') {
      tempObj['sync_to'] = this.state.bulk_action_marketplace;
    }
    requests.getRequest('ebayV1/upload/bulkSyncPrice', tempObj).then(data => {
      if (data.success) {
        notify.success(data.message);
        this.redirect('/panel/activities');
      } else {
        notify.error(data.message);
      }
      this.setState({bulk_action_marketplace: ''});
    })
  }

  InitiateBulkSyncfromeBay() {
    requests.getRequest('ebayV1/import/syncProductFromeBay').then(data => {
      if (data.success) {
        if (data.code === 'ebay_sync_product_started') {
          notify.success(data.message);
          this.redirect('/panel/activities');
        }
      } else {
        notify.error(data.message)
      }
    })
  }

  InitiateimportfromCollection() {

    requests.getRequest('shopify/import/importCollectionsProducts').then(data => {
      if (data.success) {

        notify.success(data.message);
        this.redirect('/panel/activities');

      } else {
        notify.error(data.message)
      }
    })
  }

  BulkSyncwithShopify() {
    let tempObj = {};
    if (!this.state.sync_fields.all) {
      tempObj['sync_fields'] = this.state.sync_fields;
    }
    ;
    if (this.state.bulk_action_marketplace !== '') {
      tempObj['sync_to'] = this.state.bulk_action_marketplace;
    }
    requests.postRequest('ebayV1/upload/bulkSyncWithShopify', tempObj).then(data => {
      if (data.success) {
        if (data.code === 'syncing_process_started') {
          notify.success(data.message);
          this.redirect('/panel/activities');
        }
      } else {
        notify.error(data.message)
      }
      this.setState({bulk_action_marketplace: ''});
    });
    this.closebulksyncallProductModal();
  }

  InitiateBulkSyncwithShopify() {
    this.state.syncAllwithShopify = true;
    this.setState(this.state);
  }

  /*hitpradCreate(){
        requests.getRequest('frontend/test/pradCreate').then(data=>{
            console.log(data);
        })
    }*/


  handleStatusViewChange(status, arg) {
    let data = this.state.statusView;
    data.data = false;
    if (!isUndefined(arg) && Object.keys(arg).length > 0) {
      if (!isUndefined(arg['status']) && arg['status'].length > 0) {
        arg = arg['status'];
        data.data = arg.map((e, index) => {
          if (e.severity === 'critical') {
            return (
              <Banner status="warning" key={index}>
                <h4>{e.label}</h4>
                <h5>{e.message}</h5>
              </Banner>
            );
          } else if (e.severity === 'error') {
            return (
              <Banner status="critical" key={index}>
                <h4>{e.label}</h4>
                <h5>{e.message}</h5>
              </Banner>
            );
          } else {
            return (
              <Banner status="info" key={index}>
                <h4>{e.label}</h4>
                <h5>{e.message}</h5>
              </Banner>
            );
          }
        })
      } else if (!isUndefined(arg['errors']) && arg['errors'].length > 0) {
        arg = arg['errors'];
        data.data = arg.map((e, i) => {
          return (
            <Banner key={i} status={'critical'}>
              <h4>{e}</h4>
            </Banner>
          )
        })
      } else {
        arg = [];
      }
    }
    data.open = !data.open;
    this.setState({
      statusView: data,
    });
  }

  handleMarketplaceChange(event) {
    this.filters.marketplace = this.state.installedApps[event].id;
    this.state.selectedApp = event;
    this.updateState();
    this.getProducts();
  }

  pageSettingsChange(event) {
    this.gridSettings.count = event;
    this.gridSettings.activePage = 1;
    this.getProducts();
  }

  manageStateChange = (old_state) => {
    this.filters = Object.assign({}, old_state['filters']);
    this.gridSettings = Object.assign({}, old_state['gridSettings']);
    this.props.location.state = undefined;
    this.getProducts();
  };

  redirect(url) {

    this.props.history.push(url);

  }

//--grid functions----//

  // modifyProductsData(data) {
  //     let products = [];
  //     let source_product_id = [];
  //     for (let i = 0; i < data.length; i++) {
  //         let rowData = {};
  //         rowData['main_image'] = /*<div onClick={(e)=>{
  //             this.operations.bind(this,'button',data);
  //             e.stopPropagation();
  //         }
  //         }>{*/data[i].details['image_main']===""?Notfound:data[i].details['image_main'];/*}</div>*/
  //         rowData['title'] = data[i].details.title/*<ReadMoreReact
  //             text={data[i].details.title}
  //             min={40}
  //             ideal={40}
  //             max={100} />*/;
  //         // if ( source_product_id.indexOf(data[i].product_data['details']['source_product_id']) === -1 ) {
  //         //     rowData['title'] = <ReadMoreReact
  //         //         text={data[i].product_data.details.title}
  //         //         min={40}
  //         //         ideal={40}
  //         //         max={100} />;
  //         //     source_product_id.push(data[i].product_data['details']['source_product_id']);
  //         // } else {
  //         //     rowData['title'] = <div className="w-100 text-center">
  //         //         <Icon source="subtract" />
  //         //     </div>;
  //         // }
  //         rowData['ebay_item_id'] = !isUndefined(data[i].listing_id)?<div style={{color:'#25B6CF',textDecoration:'underline'}}>{data[i].listing_id}</div>:<div className="w-100 text-center"><Icon source="subtract" /></div>;
  //         rowData['listing_id'] = !isUndefined(data[i].listing_id)?data[i].listing_id:"n/a";
  //         rowData['ebay_profile'] = this.getProfileSuggestion(data[i],i);
  //         rowData['product_type'] = !isUndefined(data[i].details.product_type) && data[i].details.product_type!=="" ?data[i].details.product_type:<div className="w-100 text-center"><Icon source="subtract" /></div>;
  //         // rowData['quantity'] = data[i].product_data.variants['quantity'];
  //         // rowData['type'] = data[i].product_data.details.type;
  //         // if ( !isUndefined(data[i]['product_data']['fromItems']) && Object.keys(data[i]['product_data']['fromItems']).length > 0 ) {
  //         //     rowData['upload_status'] = <React.Fragment>
  //         //         <Badge status="success">Uploaded</Badge><br/>
  //         //         <Badge status="attention">Imported</Badge>
  //         //     </React.Fragment>;
  //         // } else {
  //         //     rowData['upload_status'] = <Badge status="attention">Imported</Badge>;
  //         // }
  //         // if (data[i]['product_data']['fromItems'].length>0 && (data[i]['product_data']['variants']['source_variant_id'] in data[i]['product_data']['fromItems'][0]['variants']) && ('marketplace_status' in data[i]['product_data']['fromItems'][0]['variants'][
  //         //         data[i]['product_data']['variants']['source_variant_id']
  //         //         ] ) && !isUndefined(
  //         //     data[i]['product_data']['fromItems'][0]['variants'][
  //         //         data[i]['product_data']['variants']['source_variant_id']
  //         //         ]['marketplace_status']) &&
  //         //     data[i]['product_data']['fromItems'][0]['variants']
  //         //         [data[i]['product_data']['variants']['source_variant_id']]['marketplace_status'].length > 0 ) {
  //         //     rowData['google_status'] = this.getGoogleStatus(data[i]['product_data']['fromItems'][0]['variants'][data[i]['product_data']['variants']['source_variant_id']]['marketplace_status']);
  //         // } else {
  //         //     rowData['google_status'] =
  //         //         <React.Fragment>
  //         //             <Badge status="attention">Unavailable</Badge>
  //         //         </React.Fragment>;
  //         //
  //         // }
  //         rowData['inventory']=this.getInventoryData(data[i]);
  //         rowData['ebay_status']=this.getEbayStatus(data[i]);
  //         rowData['_id'] = data[i]._id;
  //         rowData['source_product_id'] = data[i].details.source_product_id;
  //         rowData['sku'] = !isUndefined(data[i].variants) && !isUndefined(data[i].variants[0]) && !isUndefined(data[i].variants[0].sku)?data[i].variants[0].sku+"...":'...';
  //         // rowData['ebay_status']=this.conditioncheck(data,i);
  //         // rowData['source_variant_id'] = data[i].product_data.variants['source_variant_idsource_variant_id'];
  //         // rowData['parent_id'] = data[i].product_data.details['source_product_id'];
  //         // rowData['unpublish'] = JSON.stringify(isUndefined(data[i].product_data)?[]:data[i].product_data);
  //         products.push(rowData);
  //     }
  //     return products;
  // }

  getSubRowDetails = expandedRows1 => rowItem => {
    let {expandedRows} = this.state;
    const isExpanded = expandedRows && expandedRows[rowItem.id]
      ? expandedRows[rowItem.id]
      : false;
    return {
      group: rowItem.variants && rowItem.variants.length > 0,
      expanded: isExpanded,
      children: rowItem.variants,
      field: "title",
      treeDepth: rowItem.treeDepth || 0,
      siblingIndex: rowItem.siblingIndex,
      numberSiblings: rowItem.numberSiblings
    };
  };

  dataMapping(data, loading = "false", whichOne) {

    if (whichOne == "Products_grid") {
      let source_product_id = [];
      return data.map((row, index) => {
        // console.log(row,index)
        let data = {};
        data['main_image'] = row["details"]['image_main'] === "" ?
          <div title={"Image"}><Thumbnail size="extralarge" alt="Image" title={"Image"}
                                          source={Notfound}/></div> :
          <div title={"Image"}><Thumbnail size="extralarge" alt="Image" title={"Image"}
                                          source={row["details"]['image_main']}/></div>
        data["check"] = <div title={"checkbox"}><Checkbox
          checked={(this.state.checkbox.hasOwnProperty(row['details']['source_product_id'])) ? true : false}
          label={row['details']['source_product_id']}
          id={row['details']['source_product_id']}
          onChange={this.handleChangeCheck}
          labelHidden={true}/></div>;
        data['_id'] = row['_id'];
        data['sku'] = !isUndefined(row.variants) && !isUndefined(row.variants[0]) && !isUndefined(row.variants[0].sku) ? row.variants[0].sku + "..." : '...';
        data['ebay_item_id'] = !isUndefined(row['listing_id']) ? <div title={row['listing_id']} style={{
            color: '#25B6CF',
            textDecoration: 'underline'
          }}>{row['listing_id']}</div> :
          <div title={'No data'} className="w-100 text-center"><Icon source="subtract"/></div>;
        data['ebay_profile'] = this.getProfileSuggestion(row, index)
        data['product_type'] = !isUndefined(row['details']['product_type']) && row['details']['product_type'] !== "" ? row['details']['product_type'] :
          <div className="w-100 text-center"><Icon source="subtract"/></div>;
        data['quantity'] = this.getInventoryData(row);
        data['ebay_status'] = <div title={'Status'}>{this.getEbayStatus(row)}</div>
        data['title'] = <div
          title={row["details"]['title']}>{(row["details"]['title']).length > 30 ? (row["details"]['title']).slice(0, 20) + "...." : row["details"]['title']}</div>
        data['vendor'] = row['details']['vendor'];
        return data;
      });
    }

  }


  dataMappingNewConfig(data, loading = "false", whichOne) {

    if (whichOne == "Products_grid") {
      let source_product_id = [];
      return data.map((row, index) => {
        // console.log(row,index)
        let data = {};
        data['main_image'] = row["details"]['image_main'] === "" ?
          <div title={"Image"}><Thumbnail size="extralarge" alt="Image" title={"Image"}
                                          source={Notfound}/></div> :
          <div title={"Image"}><Thumbnail size="extralarge" alt="Image" title={"Image"}
                                          source={row["details"]['image_main']}/></div>
        data["check"] = <div title={"checkbox"}><Checkbox
          checked={(this.state.checkbox.hasOwnProperty(row['details']['source_product_id'])) ? true : false}
          label={row['details']['source_product_id']}
          id={row['details']['source_product_id']}
          onChange={this.handleChangeCheck}
          labelHidden={true}/></div>;
        data['_id'] = row['_id'];
        data['sku'] = !isUndefined(row.variants) && !isUndefined(row.variants[0]) && !isUndefined(row.variants[0].sku) ? row.variants[0].sku + "..." : '...';
        data['ebay_item_id'] = !isUndefined(row['listing_id']) ? <div title={row['listing_id']} style={{
            color: '#25B6CF',
            textDecoration: 'underline'
          }}>{row['listing_id']}</div> :
          <div title={'No data'} className="w-100 text-center"><Icon source="subtract"/></div>;
        data['ebay_profile'] = !isUndefined(row['profile_name']) ? row['profile_name'] : '';
        data['product_type'] = !isUndefined(row['details']['product_type']) && row['details']['product_type'] !== "" ? row['details']['product_type'] :
          <div className="w-100 text-center"><Icon source="subtract"/></div>;
        data['quantity'] = this.getInventoryData(row);
        data['ebay_status'] = <div title={'Status'}>{this.getEbayStatusnewConfig(row)}</div>
        data['title'] = <div
          title={row["details"]['title']}>{(row["details"]['title']).length > 30 ? (row["details"]['title']).slice(0, 20) + "...." : row["details"]['title']}</div>
        data['vendor'] = row['details']['vendor'];
        data['tags'] = !isUndefined(row['details']['tags'])?row['details']['tags'].substring(0, 6)+'...':<div title={'No data'} className="w-100 text-center"><Icon source="subtract"/></div>;
        return data;
      });
    }

  }


  handleChangeCheck = (value, e) => {
    if (value) {
      this.state.checkbox[e] = value;
      let temp = 0;
      this.state.rawData.map((value) => {
        if ((value.details.source_product_id in this.state.checkbox)) {
          this.state.checkbox[e] = value.listing_id;
          temp += 1;
        }
      });
      if (temp == Object.keys(this.state.rawData).length && Object.keys(this.state.rawData).length != 0) {
        this.state.All_Selected = true;
      }
    } else {
      delete this.state.checkbox[e];
      this.state.All_Selected = false
    }
    this.updateState();
    this.all_Selected();
    if (true || this.state.user_id == '1217' || this.state.user_id == '620') {
      this.setState({rows: this.dataMappingNewConfig(this.state.rawData, false, "Products_grid")});
    } else {
      this.setState({rows: this.dataMapping(this.state.rawData, false, "Products_grid")});
    }
    // this.setState({
    //   rows:this.dataMapping(this.state.rawData,false,"Products_grid")
    // });

  };

  allSelector(field, value) {
    if (value) {
      this.state.columns[0]['name'] = (<Checkbox id={"all"}
                                                 checked={true}
                                                 onChange={this.allSelector.bind(this, 'all_selector')}

      />)
      this.state.rawData.map((e) => {
        this.state.checkbox[e['details']['source_product_id']] = e['listing_id'];
      })
      this.updateState();
      if (true || this.state.user_id == '1217' || this.state.user_id == '620') {
        this.setState({rows: this.dataMappingNewConfig(this.state.rawData, false, "Products_grid")});
      } else {
        this.setState({rows: this.dataMapping(this.state.rawData, false, "Products_grid")});
      }
      // this.setState({rows:this.dataMapping(this.state.rawData,false,"Products_grid")});
    } else {
      this.state.columns[0]['name'] = (<Checkbox id={"all"}
                                                 checked={false}
                                                 onChange={this.allSelector.bind(this, 'all_selector')}/>)
      this.state.rawData.map((e) => {
        if (e.details.source_product_id in this.state.checkbox) {
          delete this.state.checkbox[e.details.source_product_id];
        }

      })

      this.updateState();
      if (true || this.state.user_id == '1217' || this.state.user_id == '620') {
        this.setState({rows: this.dataMappingNewConfig(this.state.rawData, false, "Products_grid")});
      } else {
        this.setState({rows: this.dataMapping(this.state.rawData, false, "Products_grid")});
      }
      // if(Object.values(this.state.checkbox).length == 0){
      //     this.massActions = [];
      // }
    }

  }

  all_Selected() {
    if (this.state.All_Selected) {
      this.state.columns[0]['name'] = (<Checkbox id={"all"}
                                                 checked={true}
                                                 onChange={this.allSelector.bind(this, 'all_selector')}/>)
    } else {
      this.state.columns[0]['name'] = (<Checkbox id={"all"}
                                                 checked={false}
                                                 onChange={this.allSelector.bind(this, 'all_selector')}/>)
    }
    this.updateState();
  }

  prepareFilterObject(coloumn, index) {
    let filterObtained = '';
    if (coloumn !== '') {
      switch (coloumn) {
        case 'type':
        case 'title':
        case 'long_description':
        case 'vendor':
        case 'tags':
        case 'source_product_id':
          filterObtained = (index === undefined) ? 'filter[details.' + coloumn + ']' : 'filter[details.' + coloumn + '][' + index + ']';
          break;
        case 'sku':
        case 'price':
        case 'weight':
        case 'weight_unit':
        case 'main_image':
        case 'quantity':
          filterObtained = (index === undefined) ? 'filter[variants.' + coloumn + ']' : 'filter[variants.' + coloumn + '][' + index + ']';
          break;
        case 'ebay_item_id':
          filterObtained = (index === undefined) ? 'filter[listing_id]' : 'filter[listing_id][' + index + ']';
          break;
        case 'ebay_profile':
          filterObtained = (index === undefined) ? 'filter[profile_name]' : 'filter[profile_name][' + index + ']';
          break;
        case 'product_type':
          filterObtained = (index === undefined) ? 'filter[details.' + coloumn + ']' : 'filter[details.' + coloumn + '][' + index + ']';
          break;
      }
    }
    return filterObtained;
  }

  // filter Change

  handleFilterChange = filter => {
    console.log(filter);
    let {appliedFilters, preparedFilter} = this.state;
    preparedFilter[filter["key"]] = [this.prepareFilterObject(filter["key"], filter["operator"]), filter["rawValue"]];
    if (filter["rawValue"] === "") {
      delete preparedFilter[filter["key"]];
    }
    appliedFilters = {};
    this.setState({preparedFilter, appliedFilters}, () => {
      for (let i in this.state.preparedFilter) {
        if (this.state.preparedFilter.hasOwnProperty(i)) {
          appliedFilters[this.state.preparedFilter[i][0]] = this.state.preparedFilter[i][1];
        }
      }
      this.props.filterUpdated({...appliedFilters});
      this.setState({appliedFilters}, () => {
        this.getProducts();
      });
    });

  };

  getCellClick = (e) => {
    if (e.idx > 0) {
//            console.log(this.state.rawData[e.rowIdx]);
      let parent_props = {
        source_product_id: this.state.rawData[e.rowIdx].details.source_product_id
      };
      switch (e.idx) {
        case 7:// for ebay item id (at index 5)
          requests.getRequest('ebayV1/get/ebayProductData', {listing_id: this.state.rawData[e.rowIdx].listing_id}).then(data1 => {
            if (data1.success) {
              // window.open(data1.data.ListingDetails.ViewItemURL,'_blank');
              this.state.ListingRedirectId = this.state.rawData[e.rowIdx].listing_id;
              this.state.ListingRedirectUrl = data1.data.ListingDetails.ViewItemURL;
              this.state.showListingRedirectModal = true;
              this.setState(this.state);
            }
          })
          break;
        case 5:// for error product status
          requests.getRequest('ebayV1/get/failedProducts', {product_id: this.state.rawData[e.rowIdx]._id}).then(data => {
            if (data.success) {
              this.prepareStatusData(data.data);
            }
          });
          break;
        case 8 :
          // for suggestion
          break;
        default:
          let tempObjtitle = {id: this.state.rawData[e.rowIdx].details.source_product_id}
          let messagetitle = cryptr.encrypt(JSON.stringify(tempObjtitle));
          this.redirect('/panel/products/view?message=' + messagetitle);
      }
    }
  }

  // on Grid Update

  onGridRowsUpdated = (fieldName, fromRow, toRow, updated) => {
    this.setState(state => {
      const rows = state.rows.slice();
      for (let i = fromRow; i <= toRow; i++) {
        rows[i] = {...rows[i], ...updated};
      }
      return {rows};
    });
  };

  onHeaderDrop = (source, target) => {
    const stateCopy = Object.assign({}, this.state);
    const columnSourceIndex = this.state.columns.findIndex(
      i => i.key === source
    );
    const columnTargetIndex = this.state.columns.findIndex(
      i => i.key === target
    );

    stateCopy.columns.splice(
      columnTargetIndex,
      0,
      stateCopy.columns.splice(columnSourceIndex, 1)[0]
    );

    const emptyColumns = Object.assign({}, this.state, {columns: []});
    this.setState(emptyColumns);

    const reorderedColumns = Object.assign({}, this.state, {
      columns: stateCopy.columns
    });
    this.setState(reorderedColumns);
  };

  // set the Drop down Filter Value here

  getValidFilterValues = (rows, columnId) => {
    let val = rows
      .map(r => r[columnId])
      .filter((item, i, a) => {
        return i === a.indexOf(item);
      });
    return val;
  };

  sortRows = (sortColumn, sortDirection) => {

  };

  onCheckCellIsEditable = (event) => {
    // return false;
    let flag = true;
    if (event.row.variants && event.column.key !== 'title')
      flag = false;
    if (event.row.type === 'child' && event.column.key === 'title')
      flag = false;
    return flag;
  };

  onRowsSelected = rows => {
    this.setState({
      selectedIndexes: this.state.selectedIndexes.concat(
        rows.map(r => r.rowIdx)
      ),
      selectedIds: this.state.selectedIds.concat(
        rows.map(r => r["row"]["source_product_id"])
      )
    });
  };

  onRowsDeselected = rows => {

    let rowIndexes = rows.map(r => r.rowIdx);
    let Ids = rows.map(r => r["row"]["source_product_id"]);
    this.setState({
      selectedIndexes: this.state.selectedIndexes.filter(
        i => rowIndexes.indexOf(i) === -1
      ),
      selectedIds: this.state.selectedIds.filter(
        i => Ids.indexOf(i) === -1
      )

    }, () => {

    });
  };

  handlePagination = (pageProps) => {
    this.setState({pagination: pageProps}, () => {
      this.getProducts();
    });
  };

  handleColumn = (columnProps) => {

    this.setState({visibleColumns: columnProps}, () => {
      this.setVisibleColumns();
    })

  }

  setVisibleColumns() {
    let check = [];
    for (let key in this.column) {
      if (this.column[key]["key"] in this.state.visibleColumns) {
        check.push({...defaultData, ...this.column[key]})
      }
    }
    console.log(check);
    this.setState({columns: check}, () => {

    })
  }

  getSubRowDetails = expandedRows1 => rowItem => {
    let {expandedRows} = this.state;
    const isExpanded = expandedRows && expandedRows[rowItem.id]
      ? expandedRows[rowItem.id]
      : false;
    return {
      group: rowItem.variants && rowItem.variants.length > 0,
      expanded: isExpanded,
      children: rowItem.variants,
      field: "title",
      treeDepth: rowItem.treeDepth || 0,
      siblingIndex: rowItem.siblingIndex,
      numberSiblings: rowItem.numberSiblings
    };
  };

  updateSubRowDetails(subRows, parentTreeDepth) {
    const treeDepth = parentTreeDepth || 0;
    subRows.forEach((sr, i) => {
      sr.treeDepth = treeDepth + 1;
      sr.siblingIndex = i;
      sr.numberSiblings = subRows.length;
    });
  }

  onCellExpand = args => {
    let {rows, expandedRows} = this.state;
    const rowKey = args.rowData.id;
    const rowIndex = rows.indexOf(args.rowData);
    const subRows = args.expandArgs.children;
    if (expandedRows && !expandedRows[rowKey]) {
      expandedRows[rowKey] = true;
      this.updateSubRowDetails(subRows, args.rowData.treeDepth);
      rows.splice(rowIndex + 1, 0, ...subRows);
    } else if (expandedRows[rowKey]) {
      expandedRows[rowKey] = false;
      rows.splice(rowIndex + 1, subRows.length);
    }
    this.setState({expandedRows: expandedRows, rows: rows});
    return {expandedRows, rows};
  }

  getProducts() {
    this.grid_loader = true;
    this.setState({rows: createDemoRows("", true, "Products_grid"), All_Selected: false})
    window.showGridLoader = true;
    // this.prepareFilterObject();
    let {pagination} = this.state;
    let final_request;
    const pageSettings = Object.assign({}, {count: pagination.pageSize, activePage: pagination.page});
    switch (this.state.selectedTab) {
      case 0:
        final_request = requests.getRequest('ebayV1/get/products', Object.assign(pageSettings, this.state.appliedFilters, {
          sort: this.state.sortby !== '' ? this.state.sortby : false,
          order: this.state.high_low_sort !== '' ? this.state.high_low_sort : false
        }), false, true)
        break;
      case 1:
        final_request = requests.getRequest('ebayV1/get/products', Object.assign(pageSettings, this.state.appliedFilters, {
          'filter[uploaded][1]': 'yes',
          sort: this.state.sortby !== '' ? this.state.sortby : false,
          order: this.state.high_low_sort !== '' ? this.state.high_low_sort : false
        }), false, false)
        break;
      case 2:
        final_request = requests.getRequest('ebayV1/get/products', Object.assign(pageSettings, this.state.appliedFilters, {
          'filter[uploaded][1]': 'no',
          sort: this.state.sortby !== '' ? this.state.sortby : false,
          order: this.state.high_low_sort !== '' ? this.state.high_low_sort : false
        }), false, false)
        break;
      case 3:
        final_request = requests.getRequest('ebayV1/get/products', Object.assign(pageSettings, this.state.appliedFilters, {
          'filter[ended][1]': 'yes',
          sort: this.state.sortby !== '' ? this.state.sortby : false,
          order: this.state.high_low_sort !== '' ? this.state.high_low_sort : false
        }), false, false)
        break;
      case 4:
        final_request = requests.getRequest('ebayV1/get/products', Object.assign(pageSettings, this.state.appliedFilters, {
          'filter[hasError][1]': 'yes',
          sort: this.state.sortby !== '' ? this.state.sortby : false,
          order: this.state.high_low_sort !== '' ? this.state.high_low_sort : false
        }), false, false)
        break;
    }
    final_request.then(data => {
      if (data.success) {
        window.showGridLoader = false;
        this.setState({totalPage: parseInt(data.data.count)});
        // this.state['products'] = this.modifyProductsData(data.data.rows);
        this.setState({user_id: data.user_id})
        this.state.rawData = data.data.rows;
        if (true || this.state.user_id == '1217' || this.state.user_id == '620') {
          this.state.rows = this.dataMappingNewConfig(data.data.rows, false, "Products_grid");
        } else {
          this.state.rows = this.dataMapping(data.data.rows, false, "Products_grid");
        }
        this.state.showLoaderBar = data.success;
        this.state.hideLoader = !data.success;
        this.state.pagination.totalNumberOfItems = data.data.count;
        this.state.pagination.totalNumberOfPages = Math.ceil(data.data.count / this.state.pagination.pageSize);
        let temp = 0;
        data.data.rows.map((e) => {
          if ((e.details.source_product_id in this.state.checkbox)) {
            temp += 1;
          }
        });
        if (temp == Object.keys(data.data.rows).length && Object.keys(data.data.rows).length != 0) {
          this.setState({All_Selected: true});
        } else {
          this.setState({All_Selected: false});
        }
        this.all_Selected();
        this.grid_loader = false;
        this.updateState();
        if (!isUndefined(this.props.location.state) && Object.keys(this.props.location.state).length > 0) {
          this.manageStateChange(this.props.location.state['parent_props']);
        }
      } else {
        this.setState({
          showLoaderBar: false,
          hideLoader: true,
          pagination_show: paginationShow(0, 0, 0, false),
        });
        window.showGridLoader = false;
        setTimeout(() => {
          window.handleOutOfControlLoader = true;
        }, 3000);
        notify.info('No products found');
        this.grid_loader = false;
        this.updateState();
      }

    });

  }

  performMassAction = (action) => {
    let tmpSourceIds = [];
    let tempListingIds = [];
    for (var key in this.state.checkbox) {
      tmpSourceIds.push(key)
      this.state.selectedProductDetails.source_product_ids = tmpSourceIds;
      this.updateState();
    }
    Object.values(this.state.checkbox).map(e => {
      if (e != undefined) {
        tempListingIds.push(e)
        this.state.selectedProductDetails.listing_ids = tempListingIds;
        this.updateState();
      }
    })
    this.setState({selectedIds: tmpSourceIds}, () => {
      if (this.state.selectedIds.length > 0) {
        switch (action) {
          case 'syncimages' :
            this.opensyncImagesofProduct();
              break;
          case 'unpublish':
            this.setunPublishproduct();
            break;
          case 'relist':
            this.setbulkRelistproduct();
            break;
          case 'syncshopify':
            this.setsyncwithShopify();
            break;
          case 'Inventorysync':
            this.setInventorysync();
            break;
          case 'upload':
            this.setSelectandUpload();
            break;
          case 'exportcsv':
            this.setexportProducts()
            // this.getAllImporterServicesandgetAllUploaderServices();
            break
          case 'only_update':
            this.differentiateProducts('update');
            break;
          case 'only_upload':
            this.differentiateProducts('upload');
            break;
          default://console.log(action,this.state.selectedIds);
                break;
        }
      } else {
        notify.info("No product is selected");
      }
    });
  };


  async differentiateProducts(action='update'){
    let { selectedProductDetails, uploadandUpdateData } = this.state;
    let data = { product_ids : [...selectedProductDetails.source_product_ids], action }
    let { success, data: infoRecieved } = await requests.postRequest('ebayV1/upload/getProductProfileDetails', data);
    if(success) {
      let { eligible_for_action, message, matching_profiles, all_profiles } = infoRecieved;
      if(!eligible_for_action) notify.info(message);
      else{
          let allprofiles = [];
          all_profiles.forEach(profile => {
            allprofiles = [ ...allprofiles, { label : profile.name, value: (profile.profile_id).toString()}]
          });
          if(allprofiles.length === 0){
            allprofiles = [{ label: 'Default Profile', value: 'default_profile'}];
          }
        let matchingprofiles = {};
        matching_profiles.forEach(profile => {
          if(profile.profile_name === ""){
            profile.profile_name = 'Default Profile';
            profile.profile_id = 'default_profile';
          }
          if (matchingprofiles.hasOwnProperty(profile.profile_name) && (matchingprofiles[profile.profile_name]).indexOf(profile.source_product_id) === -1 ) {
              matchingprofiles[profile.profile_name] = [...matchingprofiles[profile.profile_name], profile.source_product_id];
          } else matchingprofiles[profile.profile_name] = [profile.source_product_id];
        });
        let uploadUpdateData = { ...uploadandUpdateData, matching_profiles : {...matchingprofiles}, all_profiles: [...allprofiles], type : action, message };
        this.setState({ uploadandUpdateData : uploadUpdateData }, ()=>{
          this.modalhandler(true, { title : action === 'update' ? 'Update product(s)': 'Upload product(s)', })
        });
      }
    }
  }

  EmptyRowsView = () => {
    return (
      <EmptyState heading="No data found"
                  action={{
                    content: 'Refresh filter', onAction: () => {
                      this.setState({appliedFilters: {}}, () => {
                        this.getProducts();
                      });
                    }
                  }}
                  image="https://cdn.shopify.com/s/assets/admin/empty-states-fresh/emptystate-abandoncheckout-de95c7af243bfbc1a127a7bd1a6a9b7a5769ddc295a303268fdf26913f16801c.svg">
      </EmptyState>
    );
  };

  initiatefetchVendorProductType(){
    requests.getRequest('shopify/product/initiateVendorProductTypeFetch').then(data=>{
      if(data.success) {}
    })
  }

  hitpradCreate() {
     // this.initiatefetchVendorProductType();
    // requests.getRequest('ebayV1/app/createsqswebhook').then(data=>{
    // this.initiatefetchVendorProductType();

    //
    requests.getRequest('frontend/test/pradEdit').then(data => {

    });
    // let tempOBj = {
    //
    //     selling_on_ebay:'no',
    //     account_type:'business',
    //     matching_identifier : {
    //         Title:'details.title',
    //         SKU:'variants.sku',
    //     }
    // };
    // requests.postRequest('ebayV1/upload/syncProducts',tempOBj).then(data => {
    //     if (data.success) {
    //     console.log(data);
    //      }
    // });
  }

  hitPradEdit() {
    requests.getRequest('shopify/product/getVendorProductTypeProducts').then(data => {
      console.log(data);
    })
    // requests.getRequest('shopify/product/initiateVendorProductTypeFetch').then(data=>{
    //   console.log(data);
    // })
  }

  getVendorProducttype() {
    requests.getRequest('shopify/product/getVendorProductTypeProducts').then(data => {
      if (data.success) {

        this.setState({
          product_type_options: this.prepareOptions(data.data.product_type),
          vendor_options: this.prepareOptions(data.data.vendor)
        });

      }
    })
  }

  prepareOptions(data) {
    let tempOptions = [];
    data.forEach((value, index) => {
      tempOptions.push(
        {label: value, value: value}
      )
    });
    return tempOptions;
  }

  initiatefetchVendorProductType() {
    requests.getRequest('shopify/product/initiateVendorProductTypeFetch').then(data => {
      if (data.success) {
        notify.success('Vendor and product type fetch has been initiated');
        notify.info('Please wait for 5 minutes for options to prepare then refresh the page');
      } else {
        notify.error(data.message);
      }

    })
  }



  InitiateBulkaction(type) {
    let action_type = '';
    let text = '';
    switch (type) {
      case 'bulk_inventory':
        action_type = type;
        text = 'Sync inventory';
        break;
      case 'bulk_price':
        action_type = type;
        text = 'Sync Price';
        break;
      case 'bulk_sync_details':
        action_type = type;
        text = 'Sync details';
        break;
      case 'import_match_ebay':
        action_type = type;
        text = 'Import and match products from eBay';
        break;
      case 'import_collection':
        action_type = type;
        text = 'Import collection from Shopify';
        break;
      case 'import_meta':
        action_type = type;
        text = 'Import meta fields from Shopify';
        break;
      case 'only_upload':
        action_type = type;
        text = 'This action will only upload product(s) that already have profile assigned to them, Do you want to proceed ?';
        break;
    }
    this.state.bulkAction.text = text;
    this.state.bulkAction.type = action_type;
    this.state.bulkAction.modal = true;
    this.setState(this.state);
  }

  confirmBulkAction() {
    let type = this.state.bulkAction.type;
    switch (type) {
      case 'bulk_inventory':
        this.bulkInventorySync();
        break;
      case 'bulk_price':
        this.bulkPriceSync();
        break;
      case 'bulk_sync_details':
        this.InitiateBulkSyncwithShopify();
        break;
      case 'import_match_ebay':
        this.InitiateBulkSyncfromeBay();
        break;
      case 'import_collection':
        this.InitiateimportfromCollection();
        break;
      case 'import_meta':
        this.Initiatemetaimport();
        break;
      case 'only_upload':
        this.intitateOnlyUpload();
        break;
    }
    this.state.bulkAction.modal = false;
    this.state.bulkAction.text = '';
    this.state.bulkAction.type = '';
    this.setState(this.state);

  }

  Initiatemetaimport(){
    requests.getRequest('shopify/import/importMetafieldsAllProductsAll').then(data => {
      if (data.success) {

        notify.success(data.message);
        this.redirect('/panel/activities');

      } else {
        notify.error(data.message)
      }
    })
  }

  async getProductsCount(){
    let { success, data} = await requests.getRequest('ebayV1/get/getTotalProductsCount');
    if(success) {
      let {count} = data;
      this.setState({total_product_count : count});
    }
  }

  async intitateOnlyUpload(){
    let { success, message } = await requests.getRequest('ebayV1/upload/onlyMassUploadProducts');
    if(success) notify.success(message);
    else notify.error(message);
  }

  async handleUploadUpdateAction( action, data ){
    let { selectedProductDetails } =this.state;
    let { choose_another_profile, type, selected_profile } = data;
    let reqData = {};
    let apiPoint = '';
    switch(action){
      case 'update':
        reqData = {product_ids : selectedProductDetails.source_product_ids, choose_another_profile, action: type, selected_profile };
        apiPoint = 'selectUpdateProducts';
        break;
      case 'upload':
        apiPoint = 'selectUploadProducts';
        reqData = {product_ids : selectedProductDetails.source_product_ids, choose_another_profile, action: type, selected_profile };
        break;
      default: break;
    }
    if(apiPoint !== ''){
      // let { success, message }
      let res = await requests.postRequest(`ebayV1/upload/${apiPoint}`, reqData);
      console.log(res);
    }
    this.modalhandler(false, {});
  }

  render() {
    let { uploadandUpdateData, modalInfo } = this.state;
    let structure = uploadandUpdateData.type !== '' ? getStructureofModal(uploadandUpdateData.type, uploadandUpdateData, this.handleTwoLevelChange.bind(this)) : [];
    let modalAction = uploadandUpdateData.type !== '' ? { content: "Submit", onAction: this.handleUploadUpdateAction.bind(this, uploadandUpdateData.type, uploadandUpdateData) } : false;
    return (
      <Page
        fullWidth={true}
        title="Products"
        titleMetadata=/*{<p style={{cursor:'pointer'}} onClick={()=>{
          window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=prodt','_blank')
        }}><Badge status={"info"}><b style={{color:'#0000aa', textDecoration:'underline'}}>Need help?</b></Badge></p>}*/
          {<Stack vertical={false}><p style={{cursor: 'pointer'}} onClick={() => {
            window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=prodt', '_blank')
          }}><Badge status={"info"}><b style={{color: '#0000aa', textDecoration: 'underline'}}>Need help?</b></Badge>
          </p>
            <p style={{color: '#3B7DC4', textDecoration: 'underline', cursor: 'pointer'}}
               onClick={this.openvideoModal.bind(this, 'vrtrw_fgrYo')}><Badge status={"info"}><b
              style={{color: '#0000aa', textDecoration: 'underline'}}>Help Video?</b></Badge></p>
          </Stack>}

        // primaryAction= {{content: 'test', onAction: this.hitpradCreate.bind(this)}}
        secondaryActions={this.state.user_id ==  3429 || this.state.user_id == 7704 ? [{content: 'Taxes',icon:TaxMajorMonotone,onAction:()=>{
           this.redirect('/panel/products/taxtables');
          }}] : []}
        /*primaryAction={{content:'Upload', onAction:()=>{
                    this.state.uploadProductDetails.source = '';
                    this.state.uploadProductDetails.target = '';
                    this.state.uploadProductDetails.selected_profile = 'default_profile';
                    this.state.uploadProductDetails.profile_type = '';
                    this.state.showUploadProducts = true;
                    this.handleUploadChange('source', 'shopify');
                    this.handleUploadChange('target', 'ebay');
                    this.handleUploadChange('selected_profile', 'default_profile');
                    this.getMatchingProfiles();
                    this.updateState();
                }}} /* secondaryActions={[{content: 'Failed products',icon:'risk',onAction:()=>{
               this.redirect('/panel/products/failed')
            }}]}*/

        // secondaryActions={[{content: 'Export',icon:'export',onAction:()=>{
        //         this.state.exportProductDataCsv=true;
        //         this.updateState();
        //     }},
        //     {
        //         content:'Bulk update' , onAction:()=>{
        //             this.redirect('/panel/products/bulkupdate')
        //         }}
        //
        // ]}
        actionGroups={
          this.state.total_product_count < 11000 || this.state.user_id === '3383' || this.state.user_id === '8554'  ?
          [
          {
            title: 'CSV actions',
            actions: [
              {
                content: 'Export', icon: 'export',
                onAction: () => {
                  this.state.exportProductDataCsv = true;
                  this.updateState();
                }
              },
              {
                content: 'Bulk update', icon: 'import', onAction: () => {
                  this.redirect('/panel/products/bulkupdate')
                }
              },
            ],
          },
          {
            title: 'Shopify actions',
            actions: [
              {
                content: 'Import products', icon: 'import', onAction: () => {
                  this.state.importProductsDetails.source = '';
                  this.state.importProductsDetails.shop = '';
                  this.state.importProductsDetails.shop_id = '';
                  this.handleImportChange('source', 'shopify');
                  this.state.showImportProducts = true;
                  this.getVendorProducttype();
                  this.updateState();
                }
              },
              {
                content: 'Sync inventory', icon: 'refresh', onAction: () => {
                  this.setState({bulk_action_marketplace: 'shopify'}, () => {
                    this.InitiateBulkaction('bulk_inventory');
                  });

                }
              },

              {
                content: 'Sync details', icon: 'refresh', onAction: () => {
                  this.setState({bulk_action_marketplace: 'shopify'}, () => {
                    this.InitiateBulkaction('bulk_sync_details')
                  });
                }
              }
              ,
              {
                content: 'Import collection products', icon: 'import', onAction: () => {
                  this.setState({bulk_action_marketplace: 'shopify'}, () => {
                    this.InitiateBulkaction('import_collection')
                  });
                }
              },

              {
                content: 'Import metafields of products', icon: 'import', onAction: () => {
                  this.setState({bulk_action_marketplace: 'shopify'}, () => {
                    this.InitiateBulkaction('import_meta')
                  });
                }
              },

            ],
          },
          {
            title: 'eBay actions',
            actions: this.state.user_id == '2735' ?[
              {
                content: 'Sync inventory', icon: 'refresh', onAction: () => {
                  this.setState({bulk_action_marketplace: 'ebay'}, () => {
                    this.InitiateBulkaction('bulk_inventory')
                  });

                }
              },
              {
                content: 'Match from eBay',
                icon: 'import',
                onAction: this.InitiateBulkaction.bind(this, 'import_match_ebay')
              }

            ]:[
              {
                content: 'Upload and revise(All products)', icon: 'export', onAction: () => {
                  this.state.uploadProductDetails.source = '';
                  this.state.uploadProductDetails.target = '';
                  this.state.uploadProductDetails.selected_profile = 'default_profile';
                  this.state.uploadProductDetails.profile_type = '';
                  this.state.showUploadProducts = true;
                  this.handleUploadChange('source', 'shopify');
                  this.handleUploadChange('target', 'ebay');
                  this.handleUploadChange('selected_profile', 'default_profile');
                  this.getMatchingProfiles();
                  this.updateState();
                }
              },
              {
                content: 'Sync inventory', icon: 'refresh', onAction: () => {
                  this.setState({bulk_action_marketplace: 'ebay'}, () => {
                    this.InitiateBulkaction('bulk_inventory')
                  });

                }
              },
              {
                content: 'Sync price', icon: 'refresh', onAction: () => {
                  this.setState({bulk_action_marketplace: 'ebay'}, () => {
                    this.InitiateBulkaction('bulk_price')
                  });

                }
              },

              {
                content: 'Sync details', icon: 'refresh', onAction: () => {
                  this.setState({bulk_action_marketplace: 'ebay'}, () => {
                    this.InitiateBulkaction('bulk_sync_details')
                  });
                }
              },
              {
                content: 'Match from eBay',
                icon: 'import',
                onAction: this.InitiateBulkaction.bind(this, 'import_match_ebay')
              },
              {
                content: 'Upload product(s)',
                icon: 'export',
                onAction: () => {
                  this.setState({bulk_action_marketplace: 'ebay'}, () => {
                    this.InitiateBulkaction('only_upload');
                  });

                }
              }

            ],
          },

        ]:[]
        }
      >
        {/*<Banner*/}
        {/*  status={"critical"}*/}
        {/*  title={`Our Server are going through maintainence currently , So we request you to not use any bulk or mass actions unnecessarily`}>*/}
        {/*</Banner>*/}
        <Banner
          title={`${this.state.credits_info.products.available} / ${this.state.credits_info.products.total} product credits available`}>
        </Banner>
        <ProgressBar progress={this.state.credits_info.products.percent} size="small"/>
        <React.Fragment>
          <Stack vertical={true}>
            {this.state.user_id !== '620' &&
            <Stack spacing={"loose"}>
              <Stack.Item>
                <div style={{paddingTop: '1.5rem'}}>
                  <Select label={''} options={sortingOptions} value={this.state.sortby}
                          helpText={'Use this option for sorting'} onChange={(e) => {
                    this.state.sortby = e;
                    this.setState({sortby: e}, () => {
                      this.getProducts();
                    });
                  }}/>
                </div>
              </Stack.Item>
              {this.state.sortby !== '' &&
              <Stack.Item>
                <div style={{paddingTop: '1.5rem'}}>
                  <Select label={''} options={sortingOptionsHighLow} value={this.state.high_low_sort}
                          helpText={'Set your preferred order'} onChange={(e) => {
                    this.state.high_low_sort = e;
                    this.setState({high_low_sort: e}, () => {
                      this.getProducts();
                    });
                  }}/>
                </div>
              </Stack.Item>
              }
              <Stack.Item fill></Stack.Item>
            </Stack>
            }
              {/*{*/}
              {/*    Object.keys(this.state.appliedFilters).length &&*/}
              {/*    <Banner>{<p><b>Filters are applied </b>For removing filters click on Reset button on grid.</p>}</Banner>*/}
              {/*}*/}
            <Tabs tabs={this.orderListTabs} selected={this.state.selectedTab}
                  onSelect={this.handleTabChange.bind(this)}/>
            {/*<div className="col-12 text-right">*/}
            {/*    <h5 className="mr-5">{this.state.pagination_show} Product(s)</h5>*/}
            {/*    <hr/>*/}
            {/*</div>*/}
            <LoadingOverlay
              active={this.grid_loader}
              spinner
              text='Loading please wait...'
            >
              <DraggableContainer onHeaderDrop={this.onHeaderDrop}>
                <Grid
                  suffix={this.state.toolbar_suffix}
                  rowGetter={i => this.state.rows[i]}
                  rowsCount={this.state.rows.length}
                  massAction={this.massActions}
                  onGridRowsUpdated={this.onGridRowsUpdated}
                  hideLoader={this.state.hideLoader}
                  onRowClick={this.getRowData}
                  columns={this.state.columns}
                  onAddFilter={filter => this.handleFilterChange(filter)}
                  onClearFilters={(e) => {
                    this.props.filterUpdated({});
                    this.setState({appliedFilters: {}}, () => {
                      this.getProducts()
                    })
                  }}
                  onCheckCellIsEditable={(e) => {
                    return this.onCheckCellIsEditable(e)
                  }}
                  onGridSort={(sortColumn, sortDirection) => this.sortRows(sortColumn, sortDirection)}
                  getValidFilterValues={columnKey => this.getValidFilterValues(this.state.rows, columnKey)}
                  getSubRowDetails={this.getSubRowDetails(this.state.expandedRows)}
                  visibleColumns={this.state.visibleColumns}
                  // onCellExpand={args => this.onCellExpand(args)}
                  getCellClick={this.getCellClick}
                  filtercolumnSize={defaultParams}
                  paginationProps={this.state.pagination}
                  handlePagination={this.handlePagination}
                  handleColumn={this.handleColumn}
                  performMassAction={this.performMassAction}
                  selected_count={Object.values(this.state.checkbox).length}
                  rowSelection={{
                    showCheckbox: false,
                    enableShiftSelect: true,
                    onRowsSelected: this.onRowsSelected,
                    onRowsDeselected: this.onRowsDeselected,
                    selectBy: {
                      indexes: this.state.selectedIndexes
                    }
                  }}
                  emptyRowsView={this.EmptyRowsView}
                />
              </DraggableContainer>
            </LoadingOverlay>
          </Stack>
        </React.Fragment>
        {this.state.publishProductData && this.publishProductModal()}
        {this.state.syncwithShopify && this.syncBulkProductModal()}
        {this.state.syncAllwithShopify && this.syncAllProductModal()}
        {this.state.deleteProductData && this.deleteProductModal()}
        {this.state.selectandUpload && this.selectAndUploadModal()}
        {this.state.exportProductDataCsv && this.exportProductModal()}
        {this.state.syncImagesModal && this.syncImagesModalStructure()}
        {this.StatusShowModal()}
        {this.ListingIdShowModal()}
        {this.InventoryBulkSyncModal()}
        {this.selectAndExportCsvModal()}
        {this.RelistProductModal()}
        {
          modalPolaris( modalInfo.title, modalInfo.open, this.modalhandler.bind(this, false, {}), modalAction, structure)
        }

        <Modal title="Product Status" open={this.state.statusView.open}
               onClose={this.handleStatusViewChange.bind(this, false)}>
          <Modal.Section>
            {this.state.statusView.data &&
            this.state.statusView.data}
            {!this.state.statusView.data &&
            <div className="w-100 pt-5 pb-5 text-center">
              <h2>Status of this product not available yet.</h2>
              <Label><i className="text-info">(It may take upto <b>48 Hrs</b> for any new product to
                get <b>listed on Merchant Center</b>. If <b>product not uploaded</b> please upload this
                product first.)</i></Label>
            </div>
            }
          </Modal.Section>
        </Modal>
        <Modal title="Bulk action" open={this.state.bulkAction.modal} onClose={() => {
          this.state.bulkAction.modal = false;
          this.state.bulkAction.type = '';
          this.state.bulkAction.text = '';
          this.setState(this.state);
        }}
               primaryAction={{
                 content: 'Yes',
                 onAction: this.confirmBulkAction.bind(this),
               }}
        >
          <Modal.Section>
            {this.state.bulkAction.type === 'only_upload' && this.state.bulkAction.text}
            {this.state.bulkAction.type !== 'only_upload' &&
              <p>Are you sure you want to initiate {this.state.bulkAction.text} bulk action</p>}
          </Modal.Section>
        </Modal>
        {this.renderImportProductsModal()}
        {this.renderUploadProductsModal()}
        <ModalVideo channel='youtube' isOpen={this.video.Modal} videoId={this.video.id}  onClose={this.closevideoModal.bind(this)} />
      </Page>
    );
  }

  openvideoModal(id) {
    this.video.Modal = true;
    this.video.id = id;
    this.setState(this.state);
  }

  closevideoModal() {
    this.video.Modal = false;
    this.video.id = '';
    this.setState(this.state);
  }
}

const mapStateToProps = state => {
  let { ebay } = state;
  let { products } = ebay;
  let { filters } = products;
  return ({
    filters
  });
}

const mapDispatchToProps = dispatch => {
  return ({
    filterUpdated : (filters = []) => dispatch(filterUpdated(filters))
  })
}

export default  connect(mapStateToProps, mapDispatchToProps)(Products);
