import React, {Component} from 'react';
import {Banner, Button, Card, Label, Modal, Page, Checkbox, TextContainer,Spinner} from "@shopify/polaris";
import {isUndefined} from "util";
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import DropZoneimport from "../../shared/Dropzone/dropzone";
import {ImportMinor} from '@shopify/polaris-icons';

class bulkUpdate extends Component {


    options_main_feild = [
        {label: 'Handle', value: 'Handle'},
        {label: 'Variant SKU', value: 'Variant SKU'},
        {label: 'Title', value: 'Title'},

    ];
    constructor(props){
        super(props);

        this.state={
            exportProductDataCsv:false,
            removefile:false,
            selected_main_feild:'Handle',
            file_handle: {
                isfileUploaded: false,
                isFileuploading: false,
                showDetails:false,
                fileuploaded_data: {}
            },
            predefined_selected_feild:['Title','Variant SKU','Variant Price','Variant Inventory Qty','Body (HTML)'],
            selected_feild:['Title','Variant SKU','Variant Price','Variant Inventory Qty','Body (HTML)']
        }
        this.myRef = React.createRef();
        this.triggerChildMethod = this.triggerChildMethod.bind(this);
    }

    handleChangecheckbox(label){
        let itemIndex=this.state.selected_feild.indexOf(label);
        let temparr= this.state.selected_feild;
        if(itemIndex!==-1){
            temparr.splice(itemIndex,1);
        }
        else{
            temparr.push(label)
        }
        this.state.selected_feild=temparr;
        this.setState(this.state);
    }

    handleChange_dropdown(value){
      this.state.selected_main_feild=value;
      this.setState(this.state);
    }

    getList(){
        let temp_arr=[];
        for(let i=0;i<this.state.predefined_selected_feild.length;i++){
            temp_arr.push(
                <li key={"feild" + i} className="d-block d-md-inline m-1 m-md-5">
                    <Checkbox
                        checked={this.state.selected_feild.indexOf(this.state.predefined_selected_feild[i])!==-1?true:false}
                        label={this.state.predefined_selected_feild[i]}
                        onChange={this.handleChangecheckbox.bind(this, this.state.predefined_selected_feild[i])}
                    />
                </li>
            );
        }

        return temp_arr;
    }

    exportProductModal() {
        return (
            <Modal
                open={this.state.exportProductDataCsv}
                onClose={() => {
                    this.state.exportProductDataCsv=false;
                    this.updateState();
                }}
                title="Product Export"
                primaryAction={{
                    content: 'Yes',
                    onAction: () => {
                        this.exportCSV();
                        this.state.exportProductDataCsv=false;
                        this.updateState();
                    },
                }}
                secondaryActions={[
                    {
                        content: 'No',
                        onAction: () => {
                            this.state.exportProductDataCsv=false;
                            this.updateState()
                        }
                    },
                ]}
            >
                <Modal.Section>
                    <TextContainer>
                        <div className="row text-center">
                            <div className="col-12 col-md-12">
                                <p style={{fontSize:"1em"}}>
                                    Are you sure, You want to Export product's data to CSV ?
                                </p>
                            </div>
                        </div>
                    </TextContainer>
                </Modal.Section>
            </Modal>
        );
    }

    renderCheckbox(){
        let temparr=[];
        temparr.push(
            <div className="row" key="CSV identify fields">
                <div className="col-12 col-md-12" key="Update fields">
                    <Card title="Please select fields you want update from below list" >
                        <Card.Section>
                            <div className="row">
                                <div className="col-12 col-md-12">
                                    <div className="card">
                                        <div className="card-body">
                                            <ul>
                                                {
                                                    this.getList()
                                                }
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Card.Section>
                    </Card>

                </div>
                <div className="col-12 col-md-12 mt-3" key="Mainfeild">
                    <Card /*title="Please Choose a feild to identify every Unique Product"*/ >
                        <Card.Section>
                            <div className="row">
                                <div className="col-12 col-md-12 mt-md-4 mt-2">
                                    <Banner status="info">
                                        <Label>We are Considering <b>Handle</b> as a Unique Field for identification of a product in the CSV, Please make sure each entry in CSV has a handle associated with it</Label>
                                    </Banner>
                                </div>
                                {/*<div className="col-12 col-md-4">*/}
                                    {/*<Select*/}
                                        {/*label="Select a Unique feild"*/}
                                        {/*options={this.options_main_feild}*/}
                                        {/*onChange={this.handleChange_dropdown.bind(this)}*/}
                                        {/*value={this.state.selected_main_feild}*/}
                                        {/*disabled={true}*/}
                                    {/*/>*/}
                                {/*</div>*/}
                                {/*<div className="col-12 col-md-8 mt-md-4 mt-2">*/}
                                    {/*<Banner status="info">*/}
                                        {/*<Label>Each product will be Identified by Feild <span className="font-weight-bold">{this.state.selected_main_feild}</span> of CSV</Label>*/}
                                    {/*</Banner>*/}
                                {/*</div>*/}
                            </div>
                        </Card.Section>
                    </Card>
                </div>
            </div>
        );
        return temparr;
    }

    triggerChildMethod(){
        this.myRef.current.removefiles();
    }

    exportCSV(){

        requests.postRequest("connector/product/exportProductCSV", {marketplace:'shopify'}).then(data=>{
            if(data.success){
                this.redirect('/panel/activities');
            }
            else {
                notify.error(data.message);
            }
        });
    }
    bulk_update(){
        if(this.state.selected_feild.length>0) {
            this.importProductsformCsv('update');
        }
        else{
            notify.warn('No feilds Selected for updating,Kindly Select atleast one to proceed');
        }
    }
    render() {
        return (
            <Page
                fullWidth={true}
                title="Bulk Update"
                breadcrumbs={[{content: 'Products', onAction:this.redirect.bind(this,'/panel/products')}]}
                secondaryActions={[{content: 'Export CSV',icon: ImportMinor,onAction:()=>{
                    this.state.exportProductDataCsv=true;
                    this.updateState();
                }}]}>

                <div className="row">
                    <div className="col-12 pt-1 pb-1">
                        <Banner status="info">
                            <Label><span className="font-weight-bold">Important points for Bulk Update procedure :</span></Label>
                            <Label>1.First <span className="font-weight-bold">Export CSV</span> then <span className="font-weight-bold">update the fields</span> according to your need.</Label>
                            <Label>2.For smooth functioning of bulk update <span className="font-weight-bold">kindly only upload the CSV exported from the app.</span></Label>
                            <Label>3.We take <span className="font-weight-bold">Handle</span> field as a unique so kindly <span className="font-weight-bold">do not make any changes to handle.</span></Label>
                            <Label><span className="font-weight-bold"># CSV file with size upto 25 Mb are acceptable for bulk update.</span></Label>
                        </Banner>
                    </div>
                    {/*<div className="col-12 pt-1 pb-1">*/}
                        {/*<Banner status="info">*/}
                            {/*<Label><span className="font-weight-bold">Please Note :</span> File uploaded must be of <span className="font-weight-bold">.csv extension</span> and for Update procedure required format of CSV must be according to Exported format of App</Label>*/}
                        {/*</Banner>*/}
                    {/*</div>*/}
                    <div className="col-12 pt-1 pb-1">
                        <Card title="Upload CSV file">
                            <Card.Section>
                                <div className="row">
                                    {this.state.file_handle.isFileuploading &&
                                        <div className="col-12 col-md-12 text-center font-weight-bold">
                                            Uploading file ...<Spinner size="small" color="teal"/>
                                        </div>
                                    }
                                    {!this.state.file_handle.isFileuploading &&
                                        <div className="col-12 col-md-12 pt-1 pb-1">
                                            {
                                                !this.state.file_handle.isfileUploaded &&
                                                <DropZoneimport ref={this.myRef} getFile={this.getFile.bind(this)}/>
                                            }
                                        </div>
                                    }
                                    { this.state.file_handle.showDetails &&
                                    this.renderCSVInfoBanner()
                                    }
                                </div>
                            </Card.Section>
                        </Card>
                    </div>
                    {
                        this.state.file_handle.showDetails &&
                        <div className="col-12 pt-1 pb-1">
                            {
                                this.renderCheckbox()
                            }
                        </div>
                    }
                    <div className="col-12 pt-1 pb-1 text-center">
                        <Button
                            disabled={!this.state.file_handle.showDetails}
                            onClick={() => {
                                this.bulk_update()

                            }}
                            primary>
                            Update Via CSV
                        </Button>

                    </div>
                </div>
                {this.state.exportProductDataCsv && this.exportProductModal()}
            </Page>
        );
    }

    redirect(url, data) {

            this.props.history.push(url);

    }

    renderCSVInfoBanner(){
        return (
            <div className="col-12 pt-1 pb-1">
                <div className="row">
                    <div className="col-12 col-md-12 mb-2">
                        <Banner status="success">
                            <Label>The CSV selected Contains {this.state.file_handle.fileuploaded_data.handle_count} Main Products , {this.state.file_handle.fileuploaded_data.sku_count} Variant SKU's and {this.state.file_handle.fileuploaded_data.image_count} Images</Label>
                        </Banner>
                    </div>
                    <div className="col-12 col-md-12 mt-2">
                        <Banner status="info">
                            <Label>If you want to proceed with Bulk Update procedure Kindly choose feilds you want to Update using CSV from below Or if you want to Upload some other CSV kindly choose Cancel option from Below </Label>
                        </Banner>
                    </div>
                    <div className="col-12 col-md-12 text-right mt-2">
                        <Button onClick={() => {
                            this.importProductsformCsv('cancel');
                            this.state.importtype='api';
                            this.state.showImportProducts = false;
                            this.state.file_handle.isfileUploaded= false;
                            this.state.file_handle.showDetails=false;
                            this.state.file_handle.fileuploaded_data={};
                            this.updateState();
                        }}
                                primary>
                            Cancel
                        </Button>
                    </div>
                </div>

            </div>
        );
    }

    getFile(file,rejectedFiles){
        this.state.file_handle.isFileuploading =true ;
        this.updateState();
        let filedata;
       if(!isUndefined(file) && file.length>0) {
           if (file[0].size < 25000000) {
               this.getBase64(file[0], rejectedFiles).then(data => {
                   if (data) {
                       let tempdata = {marketplace: 'shopify', 'filedata': data}
                       requests.postRequest('connector/product/importCSV', tempdata).then(data => {
                           if (data.success) {
                               if (data.data.info !== '' && data.data.info !== false) {
                                   this.state.file_handle.isfileUploaded = true;
                                   this.state.file_handle.fileuploaded_data = data.data.info;
                                   this.state.file_handle.showDetails = true;
                                   this.state.file_handle.isFileuploading =false ;
                                   this.updateState();
                               }
                               else {
                                   notify.error('Error is CSV data extraction');
                                   this.state.file_handle.isFileuploading =false ;
                                   this.updateState();
                               }
                           }
                           else {

                               notify.warn(data.message);
                               this.state.file_handle.isFileuploading =false ;
                               this.updateState();
                               this.triggerChildMethod();
                           }

                       });
                   }

               });
           } else {
               this.triggerChildMethod();
               notify.info('CSV file of Size less than 25 Mb is only allowed')
           }
       }else{
           this.state.file_handle.isFileuploading =false ;
           this.updateState();
       }
    }

    getBase64(file,rejectedFile) {
        if(!isUndefined(file) && rejectedFile.length===0) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = () => resolve(reader.result);
                reader.onerror = error => reject(error);
            });
        }
        else {
            return new Promise((resolve, reject) => {
                resolve=false;
            });
        }
    }

    importProductsformCsv(action){
        if(this.state.file_handle.fileuploaded_data.path!==''){
            requests.postRequest('connector/product/importCSV',
                {
                    path:this.state.file_handle.fileuploaded_data.path,
                    marketplace:'shopify',
                    action:action,
                    feild:this.state.selected_feild,
                    unique_feild:this.state.selected_main_feild
                }).then(data=>{
                    if(data.success){
                        if(data.code!=='CSV_IMPORT_CANCELLED') {
                            this.redirect("/panel/activities")
                        }
                    }
                    else{
                        notify.error(data.message);
                    }
            });
        }
        else {
            notify.info('File Upload error: Path missing');
        }

    }
    updateState() {
        const state = this.state;
        this.setState(state);
    }
}

export default bulkUpdate;
