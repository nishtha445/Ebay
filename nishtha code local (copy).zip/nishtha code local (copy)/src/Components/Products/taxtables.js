import React, {Component} from 'react';
import {Page} from "@shopify/polaris";
import {isUndefined} from "util";
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import {Card, DataTable,EmptyState} from "@shopify/polaris";

class Taxtables extends Component {

  constructor(props){
    super(props);
    this.state = {
      taxes: [],
      rows:[],
      loader_button : false,
    };

  }

  refetchTaxes(){
    requests.getRequest('ebayV1/get/getTaxTablesShopify').then(data=>{
      if(data.success){
        notify.success(data.message);
      }else{
        notify.error(data.message);
      }
      this.fetchtaxes();
    })
  }

  fetchtaxes(){
    requests.getRequest('ebayV1/get/fetchTaxTables').then(data=>{
      if(data.success){
        this.setState({taxes: data.data , rows:  this.modifyData(data.data)});
      }else{
        notify.error(data.message);
      }
    })
  }

  componentDidMount() {
    this.fetchtaxes();
  }

  modifyData(data){
    let taxes =[];
    if(Array.isArray(data)){
      data.forEach(key => {
        taxes.push(
          [
            key.id,
             key.name,
             key.tax,
             key.code,
             key.tax_name,
          ]
        );
      });

    }
    return taxes;
  }

  render() {
    let { rows, taxes ,loader_button} = this.state;
    return (
      <Page title={'Tax tables'} fullWidth={true}
            breadcrumbs={[{content: 'Products', onAction:this.redirect.bind(this,'/panel/newproducts')}]}
            primaryAction={{content:'Update taxes', onAction:this.refetchTaxes.bind(this), loading: loader_button}}
      >
        <Card>
          { rows.length > 0 &&
            <DataTable
              columnContentTypes={[
                'text',
                'text',
                'text',
                'text',
                'text',
              ]}
              headings={[
                'ID',
                'Country',
                'Tax rate(%)',
                'Country code',
                'Tax type',
              ]}
              rows={rows}
              defaultSortDirection={"ascending"}
            />
          }
          { rows.length == 0 &&
          <EmptyState
              heading="Tax tables not found"
              image="https://cdn.shopify.com/s/files/1/0757/9955/files/empty-state.svg"
              action={{content: 'Fetch taxes', onAction : this.refetchTaxes.bind(this)}}
            >
              <p>To Fetch/Update tax rates of Shopify on app click on Fetch taxes</p>
            </EmptyState>
          }
        </Card>
      </Page>
    );
  }

  redirect(url) {
    if ( !isUndefined(this.props.location.state) && Object.keys(this.props.location.state).length > 0 ) {
      this.props.history.push(url, JSON.parse(JSON.stringify(this.props.location.state)))
    } else {
      this.props.history.push(url);
    }
  }
}

export default Taxtables;
