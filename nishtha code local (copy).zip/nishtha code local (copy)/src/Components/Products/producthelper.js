import React from "react";
import { Modal, Banner, Card, Checkbox, Stack, Select, Thumbnail, Icon, Badge, Tooltip, TextStyle } from "@shopify/polaris";
import Notfound from "../../assets/img/notfound.png"
import {
    MinusMinor, AlertMinor, ViewMajorMonotone
} from '@shopify/polaris-icons';
import { isUndefined } from "util";
import { prepareChoiceoption } from "../../Subcomponents/Aggrid/gridHelper";
import { getprofiles } from "../../APIrequests/profilesAPI";
import { getVendorProductTypeProducts } from "../../APIrequests/productsAPI";

export function modalPolaris(title = '', open, handleChange, action = { content: "Submit", onAction: () => { } }, structure = []) {
    return <Modal
        open={open}
        onClose={handleChange}
        title={title}
        primaryAction={action}
    >
        <Modal.Section>
            {structure}
        </Modal.Section>
    </Modal>
}

export function getStructureofModal(action, data, onChange) {
    let { matching_profiles, choose_another_profile, selected_profile, all_profiles } = data;
    let matchedInfo = [];
    Object.keys(matching_profiles).map(profileName => {
        matchedInfo = [...matchedInfo, <Banner status={"info"} title={`${(matching_profiles[profileName]).length} product(s) belong to ${profileName}.`} />]
        return true;
    });
    switch (action) {
        case 'update':
            return <Card>
                <Card.Section title={'Product Information'}>{matchedInfo}</Card.Section>
                <Card.Section>
                    <Stack vertical={true} spacing={"loose"}>
                        <Checkbox label={'Choose a different profile for updating'}
                            checked={choose_another_profile}
                            onChange={onChange.bind(this, 'uploadandUpdateData', 'choose_another_profile')}
                        />
                        {choose_another_profile &&
                            <Select options={all_profiles} label={'Select profile'} value={selected_profile} onChange={onChange.bind(this, 'uploadandUpdateData', 'selected_profile')} placeholder={'Please select...'} />
                        }
                    </Stack>
                </Card.Section>
            </Card>;
        case 'upload':
            return <Card>
                <Card.Section title={'Product Information'}>{matchedInfo}</Card.Section>
                <Card.Section><Banner status={"info"}>To upload product(s) using different profile select from options below.</Banner></Card.Section>
                <Card.Section>
                    <Stack vertical={true} spacing={"loose"}>
                        <Checkbox label={'Choose a different profile for updating'}
                            checked={choose_another_profile}
                            onChange={onChange.bind(this, 'uploadandUpdateData', 'choose_another_profile')}
                        />
                        {choose_another_profile &&
                            <Select options={all_profiles} label={'Select profile'} value={selected_profile} onChange={onChange.bind(this, 'uploadandUpdateData', 'selected_profile')} placeholder={'Please select...'} />
                        }
                    </Stack>
                </Card.Section>
            </Card>;
        default: break;
    }
    return [];
}


export const productlistTabs = [
    {
        id: 'All',
        content: 'All',
        title: 'All',
        accessibilityLabel: 'All',
        panelID: 'all-products-content',
        type: 'all',
        index: 0,
    },
    {
        id: 'Uploaded',
        content: 'Uploaded',
        title: 'Uploaded',
        panelID: 'uploaded-products-content',
        type: 'uploaded',
        index: 1,
    },
    {
        id: 'Not Uploaded',
        content: 'Not Uploaded',
        title: 'Not Uploaded',
        panelID: 'notuploaded-products-content',
        type: 'notuploaded',
        index: 2,
    },
    {
        id: 'Ended',
        content: 'Ended',
        title: 'Ended',
        panelID: 'Ended',
        type: 'ended',
        index: 3,
    },
    {
        id: 'Error',
        content: 'Error',
        title: 'Error',
        panelID: 'Error',
        type: 'error',
        index: 4,
    }
];

export function changeProductListTabs(selectedTab, tabs, totalRecords) {
    console.log('selectedTab', selectedTab)
    let key = 'count';
    let value = totalRecords;
    tabs = tabs.map(tab => {
        if(tab.index === selectedTab) {
            tab[key] = value;
            tab['content'] = <span>{tab['content']}<Badge status={"info"}>{totalRecords}</Badge></span>
            return tab;
        } 
        else {
            delete tab['count'];
            tab['content'] = <p>{tab['content']}</p>
            return tab;
        }
    })
    console.log('tabs', tabs)
    return tabs;
}

export function getTabSelectedFilter(type) {
    switch (type) {
        case 'uploaded': return { 'filter[uploaded][1]': 'yes' };
        case 'notuploaded': return { 'filter[uploaded][1]': 'no' };
        case 'ended': return { 'filter[ended][1]': 'yes' };
        case 'error': return { 'filter[hasError][1]': 'yes' };
        default: return {};
    }
}

function imageDetails(incellElement, params) {
    let { main_image } = params.data;
    return (
        // <div 
        //     // className={"row w-100"} 
        // // style={{lineHeight: 1.8}}
        // >
        //     {
        main_image === "" ?
            // <div title={"Image"}>
            <Thumbnail size="small" alt="Image" title={"Image"} source={Notfound} />
            // </div> 
            :
            // <div title={"Image"}>
            <Thumbnail size="small" alt="Image" title={"Image"} source={main_image} />
            // <h1>dfhbgf</h1>
        // </div>
        //     }
        // </div>
    );

}

function titleDetails(incellElement, params) {
    let { title } = params.data;
    return (<><div title={title}>{title.length > 30 ? title.slice(0, 20) + "...." : title}</div>

        {/* <p onClick={(e) => {
            // incellElement('view_product', params.data);
            e.preventDefault();
        }}><Tooltip content="View product"><Icon source={ViewMajorMonotone} /></Tooltip></p> */}
    </>
    )
}
function loopAttributes(attributes) {
    let attrbute_structure = attributes.map(attribute => attribute.replace( /(<([^>]+)>)/ig, ''));
    return attrbute_structure;
}
function renderVariantAttributes(row) {
    let lastindexVariantAttribute = -1;
    if (row.hasOwnProperty('variant_attribute')) {
        if (row['variant_attribute'].length > 0) {
            return (
            // <Tooltip content={row.variant_attribute.map((attribute, index) => {
            //     if(row.variant_attribute[index] === row.variant_attribute.at(lastindexVariantAttribute)) 
            //         return attribute
            //     else return attribute + ','
            // })}>
                <div 
            // className={"col-12"}
            >
                {/* {`Variant Attribute(s) -:  ${loopAttributes(row['variant_attribute'])}`} */}
                {`${loopAttributes(row['variant_attribute'])}`}
            </div>
            // </Tooltip>
            )
        } else if ((row['variant_attribute'].length === 0)) {
            return <div>N/A</div>
        }
    }
}
function metaDetails(incellElement, params) {
    let { row } = params.value;
    // console.log('row', row)
    let { image_main, title, product_type, vendor } = row.details;
    return (
        <div 
        // className={"row w-100"} 
        style={{ lineHeight: 1.5, display: 'flex', flexDirection: 'column' }}
        >
            {
                // <div className={"col-12"}>Profile -:  {renderProfiles(incellElement, row) ? renderProfiles(incellElement, row) : '...'}</div>
                renderProfiles(incellElement, row)
            }
            {/* {product_type &&
                <div className={"col-12"} >Product type -: {product_type}</div>
                // : <div className={"col-12"} >Product type -: ...</div>
            }
            {vendor &&
                <div className={"col-12"}>Vendor -:  {vendor}</div>
            } */}
            {/* {
                <div className={"col-12"}>{renderPrice(row)}</div>
            } */}
            {/* {
                <div className={"col-12"} style={{ color: "dimgrey" }}>SKU -:  {renderSKU(row)}</div>
            } */}
            {/* {
                !isUndefined(row['details']['tags']) ? <div className={"col-12"}>Tags -:  {row['details']['tags'].substring(0, 6) + '...'}</div> : <div className={"col-12"} title={'No data'} >Tags -:  <Icon source="subtract" /></div>
            } */}
            <div 
            style={{ display: 'inline-block', overflow: 'hidden', whiteSpace: 'nowrap', clear: "both" }}
            >{renderVariantAttributes(row)}</div>
            {/* {
                <div className={"col-12"} style={{ color: "dimgrey" }}>Inventory -:  {inventoryDetails(row)}</div>
            } */}
        </div>
    )
}
function getTypeOfProduct(row) {
    let { variant_attribute } = row
    let totalVariants = 0;
    if (!isUndefined(row.variants)) {
        totalVariants = row.variants.length;
    }
    if (variant_attribute && Array.isArray(variant_attribute) && variant_attribute.length > 0) {
        return `Variant (${totalVariants} Products)`;
    }
    return `Simple Product`;
}
function marketplaceData(incellElement, params) {
    let data = params.data.ebay_status.row;
    let user_id = params.data.ebay_status.user_id;
    return (
        <React.Fragment>
            <div 
            // className={"row w-100"} 
            style={{lineHeight: 1.5}}
            >
                <Stack vertical spacing="extraTight">
                {getEbayStatusnewConfig(incellElement, data, user_id)}
                {ebayItemID(incellElement, params)}
                </Stack>
            </div>
        </React.Fragment>
    )
}
function productTypeVendor(incellElement, params) {
    let { row } = params.value;
    let { vendor, product_type } = row.details;
    return (
        <div 
        // className={"row w-100"} 
        style={{ lineHeight: 1.5, display: 'flex', flexDirection: 'column' }}
        >
            {vendor ?
                <div
                style={{ display: 'inline-block', overflow: 'hidden', whiteSpace: 'nowrap', clear: "both" }}
                ><Tooltip content={vendor}><div>  {vendor}</div></Tooltip></div> : <div>N/A</div>
            }
            { product_type ? 
                <div
                style={{ display: 'inline-block', overflow: 'hidden', whiteSpace: 'nowrap', clear: "both" }}
                ><Tooltip content={product_type}><div>{product_type}</div></Tooltip></div> : <div>N/A</div>
            }
        </div>
    )
}
function basicDetails(incellElement, params) {
    // console.log('params', params);
    let { row } = params.value;
    let { image_main, title, product_type, vendor } = row.details;
    return (
        <div 
        // className={"row w-100"} 
        style={{ lineHeight: 1.5, display: 'flex', flexDirection: 'column' }}
        >
            <div style={{ cursor: 'pointer', display: 'inline-block', overflow: 'hidden', whiteSpace: 'nowrap', clear: "both" }} ><TextStyle variation="strong"><Tooltip content={title}>
                <span onClick={(e) => {
                    incellElement('edit', params.data);
                    e.preventDefault();
                }} onMouseOver={e => {
                    e.target.style.textDecoration = 'underline';
                }} onMouseOut={e => {
                    e.target.style.textDecoration = 'none';
                }}>
                    {/* {title.length > 30 ? title.slice(0, 30) + "...." : title} */}
                    {title}
                    </span>
            </Tooltip></TextStyle></div>
            <Tooltip content={renderSKU(row)}><p style={{ display: 'inline-block', overflow: 'hidden', whiteSpace: 'nowrap', clear: "both" }}>{renderSKU(row)}</p></Tooltip>
        </div>
    )
}
function otherDetails(incellElement, params) {
    // console.log('params', params);
    let { row } = params.value;
    let { image_main, title, product_type, vendor } = row.details;
    return (
        <div 
        // className={"row w-100"} 
        style={{ lineHeight: 1.5 }}
        >

{
                <div 
                // className={"col-12"}
                >
                    {/* Inventory -:   */}
                {inventoryDetails(row)}</div>
            }
            {
                <div 
                // className={"col-12"}
                >{renderPrice(row)}</div>
            }
        </div>
    )
}

function productTypeDetails(incellElement, params) {
    let { product_type } = params.data;
    return product_type !== "" ? product_type : <div className="w-100 text-center"><Icon source={MinusMinor} /></div>
}

function inventoryDetails(params) {
    let data = params;
    let totalVariants = 0;
    let totalquantity = 0;
    if (!isUndefined(data.variants)) {
        if (Array.isArray(data.variants)) {
            data.variants.forEach((variants, index) => {
                totalquantity += !isNaN(parseInt(variants.quantity)) ? parseInt(variants.quantity) : 0;
            });
        } else {
            Object.keys(data.variants).map((key) => {
                totalquantity += !isNaN(parseInt(data.variants.quantity)) ? parseInt(data.variants[key].quantity) : 0;
            });
        }
        totalVariants = data.variants.length;
        let addonVarianttext = totalVariants > 1 ? " variants" : " variant";
        let varianttext = "for " + totalVariants + addonVarianttext;
        if (data.details.type === 'simple') {
            varianttext = '';
        }
        let text = totalquantity + " in stock " + varianttext;
        // let text = totalquantity;
        return text;

    }
    return '';
}

function getEbayStatusnewConfig(incellElement, data, user_id = '') {
    let haserror = !isUndefined(data.has_error) ? data.has_error : false;
    let temparr = [];
    let type = '';
    let Content = '';
    switch (data['status']) {
        case 'ended':
            type = 'info';
            Content = 'Ended';
            break;
        case 'not_uploaded':
            type = 'attention';
            Content = 'Not uploaded';
            break;
        case 'uploaded':
            type = 'success';
            Content = 'Uploaded';
            break;
        case 'error':
            type = 'warning';
            Content = <b style={{ color: '#0000aa', textDecoration: 'underline' }}>Error</b>;
            break;
    }
    temparr.push(
        // <div className="row" style={{ whiteSpace: 'nowrap' }} key={data._id}>
            // {/* <div className="col-12 col-md-12"> */}
                <Stack vertical={true} spacing={"tight"}>
                    <div onClick={(e) => {
                        incellElement('ebay_status', data);
                        e.preventDefault();
                    }}>
                        <Badge status={type}>{Content}
                        {haserror 
                        // && (['7704', '8553', '18906', '14048', '11977', '9560', '8349', '14950', '14921', '15547', '694'].indexOf(user_id) > -1) 
                        ? <Icon source={AlertMinor} color={"critical"} /> : ''}
                        </Badge>
                    </div>
                </Stack>
            // {/* </div> */}
        // </div>
    );
    return temparr;
}

// function ebayStatusDetails(incellElement, params) {
//     let data = params.data.ebay_status.row;
//     let user_id = params.data.ebay_status.user_id;
//     return getEbayStatusnewConfig(data, user_id);
// }

function ebayItemID(incellElement, params) {
    let row = params.data.listing_id.row;
    return !isUndefined(row['listing_id']) && row['listing_id'] && <div title={row['listing_id']} style={{
        color: '#25B6CF',
        textDecoration: 'underline'
    }} onClick={(e) => {
        incellElement('ebay_item_id', params.data);
        e.preventDefault();
    }}>{`${row['listing_id']}`}</div>
    // return !isUndefined(row['listing_id']) ? <div title={row['listing_id']} style={{
    //     color: '#25B6CF',
    //     textDecoration: 'underline'
    // }} onClick={(e) => {
    //     incellElement('ebay_item_id', params.data);
    //     e.preventDefault();
    // }}>{row['listing_id'] && `Ebay Item ID -: ${row['listing_id']}`  }</div> :
    //     <div title={'No data'} className="w-100 text-center"><Icon source="subtract" /></div>
}

export function gridPropColumns(incellElement = () => { }, innerWidth) {
    // console.log('width', innerWidth)
    let deductedWidth = innerWidth;
    let imageWidth = 120;
    let basicDetailsWidth = deductedWidth/1;
    let otherDetailsWidth = deductedWidth/1.5;
    let metaDetailsWidth = deductedWidth/1.2;
    let marketplaceDataWidth = deductedWidth/2;
    let metaDataWidth = deductedWidth/1.2;
    if(innerWidth >= 425) {
        deductedWidth = innerWidth - (innerWidth*15/100);
        imageWidth = 120;
        basicDetailsWidth = deductedWidth/1.2;
        otherDetailsWidth = deductedWidth/1.5;
        metaDetailsWidth = deductedWidth/1.2;
        marketplaceDataWidth = deductedWidth/2;
        metaDataWidth = deductedWidth/1.2;
    }
    if(innerWidth >= 768) {
        deductedWidth = innerWidth - (innerWidth*15/100);
        imageWidth = 120;
        basicDetailsWidth = deductedWidth/2.2;
        otherDetailsWidth = deductedWidth/3;
        metaDetailsWidth = deductedWidth/3;
        marketplaceDataWidth = deductedWidth/3.5;
        metaDataWidth = deductedWidth/3;
    } 
    if(innerWidth >= 1366) {
        deductedWidth = innerWidth - (innerWidth*15/100);
        imageWidth = 120;
        basicDetailsWidth = deductedWidth/4;
        otherDetailsWidth = deductedWidth/5;
        metaDetailsWidth = deductedWidth/5;
        marketplaceDataWidth = deductedWidth/5;
        metaDataWidth = deductedWidth/4;
    }
    // console.log('deductedWidth', deductedWidth)
    // console.log('basicDetailsWidth', basicDetailsWidth, 'metaDetailsWidth', metaDetailsWidth, 'marketplaceDataWidth', marketplaceDataWidth)
    return [
        {
            headerName: "Image", field: "main_image", cellRendererFramework: imageDetails.bind(this, incellElement.bind(this)),
            pinned: 'left', resizable: true, cellStyle: { 'white-space': 'normal' }, headerCheckboxSelection: true, checkboxSelection: true, autoHeight: true,
            // width: 150,
            width: imageWidth,
        },
        {
            // headerName: 'Basic Details', 
            headerName: 'Title/ SKU', 
            field: 'basicDetails', cellRendererFramework: basicDetails.bind(this, incellElement.bind(this)), 
            resizable: true, 
            cellStyle: { 'white-space': 'normal', 'border': 'none' }, autoHeight: true,
            // width: 350,
            // width: 500,
            width: basicDetailsWidth
        },
        {
            // headerName: 'Other Details', 
            headerName: 'Inventory/ Price', 
            field: 'otherDetails', cellRendererFramework: otherDetails.bind(this, incellElement.bind(this)), 
            resizable: true, 
            cellStyle: { 'white-space': 'normal', 'border': 'none' }, autoHeight: true,
            // width: 350,
            // width: 500,
            width: otherDetailsWidth
        },
        {
            // headerName: "Additional Details", 
            headerName: "Profile/ Variant Attributes", 
            field: "metaDetails", cellRendererFramework: metaDetails.bind(this, incellElement.bind(this)), 
            resizable: true, 
            cellStyle: { 'white-space': 'normal', 'border': 'none' }, autoHeight: true,
            // width: 345,
            // width: 500,
            width: metaDetailsWidth
        },
        {
            headerName: 'eBay Status/eBay Item ID', 
            // headerName: 'eBay Status/ Item ID', 
            field: 'marketplaceData', cellRendererFramework: marketplaceData.bind(this, incellElement.bind(this)), 
            resizable: true, 
            autoHeight: true, cellStyle: { 'white-space': 'normal', 'border': 'none' },
            // width: 300,
            width: marketplaceDataWidth
            //  maxWidth: 200, minWidth: 100
        },
        {
            headerName: 'Vendor/ Product Type', 
            // headerName: 'eBay Status/ Item ID', 
            field: 'productTypeVendor', cellRendererFramework: productTypeVendor.bind(this, incellElement.bind(this)), 
            resizable: true, 
            autoHeight: true, cellStyle: { 'white-space': 'normal', 'border': 'none' },
            // width: 300,
            width: metaDataWidth
            //  maxWidth: 200, minWidth: 100
        },
    ]
};


export const pageSizeOptionProducts = [50, 100, 150, 200];

export const filterCondition = [
    { label: 'equals', value: "1" },
    { label: 'not equals', value: "2" },
    {
        label: 'contains', value: "3", disable_for: ['variants.quantity', 'listing_id', 'variants.price']
    },
    {
        label: 'does not contains', value: "4", disable_for: ['variants.quantity', 'listing_id', 'variants.price']
    },
    {
        label: 'starts with', value: "5", disable_for: ['variants.quantity', 'listing_id', 'variants.price']
    },
    {
        label: 'ends with', value: "6", disable_for: ['variants.quantity', 'listing_id', 'variants.price']
    },
    {
        label: 'greater than or equal to', value: "7", disable_for: ['details.title', 'details.product_type', 'variants.sku', 'details.tags', 'profile_name', 'details.vendor', 'variant_attribute', 'listing_id']
    },
    {
        label: 'less than or equal to', value: "8", disable_for: ['details.title', 'details.product_type', 'variants.sku', 'details.tags', 'profile_name', 'details.vendor', 'variant_attribute', 'listing_id']
    }
];

export function getFilterforRequest(filters = []) {
    // console.log('filters', filters)
    let tempObj = {};
    filters.forEach(filter => {
        // console.log('filter', filter)
        if(filter.attribute === "variants.price" || filter.attribute === "variants.quantity") {
            if(filter.condition === "7") {
                tempObj[`filter[${filter['attribute']}][${filter['condition']}][from]`] = filter['value'];
            } else if(filter.condition === "8") {
                tempObj[`filter[${filter['attribute']}][7][to]`] = filter['value'];
            } else {
                tempObj[`filter[${filter['attribute']}][${filter['condition']}]`] = filter['value'];
            }
        } else {
            tempObj[`filter[${filter['attribute']}][${filter['condition']}]`] = filter['value'];
        }
    });
    // console.log('tempObj', tempObj)
    return tempObj;
}

export function getpaginationInfo(totalrecords, pageSize) {
    let pages = Math.ceil(parseInt(totalrecords) / parseInt(pageSize));
    return { pages, totalrecords };
}

function tagsDetails(incellElement, params) {
    let row = params.data.tags.row;
    return !isUndefined(row['details']['tags']) ? row['details']['tags'].substring(0, 6) + '...' : <div title={'No data'} className="w-100 text-center"><Icon source="subtract" /></div>
}

// function renderProfiles(incellElement, row) {
//     return !isUndefined(row['profile_name']) && row['profile_name'] ? <div className={"col-12"} style={{ cursor: 'pointer' }} onClick={(e) => {
//         incellElement('view_profile', row);
//         e.preventDefault();
//     }} onMouseOver={e => {
//         e.target.style.textDecoration = 'underline';
//     }} onMouseOut={e => {
//         e.target.style.textDecoration = 'none';
//     }}><Tooltip content={"View Profile"}><TextStyle variation="strong">Profile -: {row['profile_name']}</TextStyle></Tooltip></div> : <div className={"col-12"}><TextStyle variation="strong">Profile -: N/A</TextStyle></div>
// }
function renderProfiles(incellElement, row) {
    return !isUndefined(row['profile_name']) ? <div 
    // className={"col-12"}
    style={{ display: 'inline-block', overflow: 'hidden', whiteSpace: 'nowrap', clear: "both" }}
    ><TextStyle variation="strong">{row['profile_name'] ? <Tooltip content={row['profile_name']}><span style={{ cursor: 'pointer' }} onClick={(e) => {
        incellElement('view_profile', row);
        e.preventDefault();
    }} onMouseOver={e => {
        e.target.style.textDecoration = 'underline';
    }} onMouseOut={e => {
        e.target.style.textDecoration = 'none';
    }}>
        {/* Profile -:  */}
    {row['profile_name']}
    {/* {row['profile_name'].length > 25 ? row['profile_name'].slice(0, 25) + "...." : row['profile_name']} */}
    </span></Tooltip> : 
    // 'Profile -: N/A'
    'N/A'
    }</TextStyle></div> : ''
}

function renderSKU(row) {
    return !isUndefined(row.variants) && !isUndefined(row.variants[0]) && !isUndefined(row.variants[0].sku) ? row.variants[0].sku : '...';
    // return !isUndefined(row.variants) && !isUndefined(row.variants[0]) && !isUndefined(row.variants[0].sku) ? row.variants[0].sku.length > 30 ? row.variants[0].sku.slice(0, 30) + "...." : row.variants[0].sku: '...';
}

function renderPrice(row) {
    let min_price = '';
    let max_price = '';
    let variant_price_array =[];
    let priceRender = '';
    !isUndefined(row.variants) && row.variants.forEach(variant => {
        !isUndefined(variant) && !isUndefined(variant.price) && variant_price_array.push(variant.price);
    })
    max_price = Math.max.apply(Math, variant_price_array);
    min_price = Math.min.apply(Math, variant_price_array);
    if(max_price !== min_price) {
        // priceRender = `Price -: ${min_price} - ${max_price}`;
        priceRender = `${min_price} - ${max_price}`;
    } else {
        // priceRender = `Price -: ${min_price}`;
        priceRender = `${min_price}`;
    }
    // return !isUndefined(row.variants) && !isUndefined(row.variants[0]) && !isUndefined(row.variants[0].price) ? `Price -: ${row.variants[0].price}` : '...';
    return priceRender;
}

export function extractValuesfromRequest(rows = [], user_id = '') {
    // console.log(rows)
    let modifiedRows = [];
    let index=-1; // nishtha
    rows.forEach(row => {
        let { image_main, title, product_type, vendor } = row.details
        // nishtha
        index=image_main.lastIndexOf(".")
        if(index!==-1){
        image_main=image_main.slice(0,index)+"_small"+image_main.slice(index);
        }

        let { listing_id } = row
        modifiedRows.push({
            main_image: image_main,
            title,
            product_type,
            basicDetails: { 'row': row, 'user_id': user_id },
            otherDetails: { 'row': row, 'user_id': user_id },
            metaDetails: { 'row': row, 'user_id': user_id },
            marketplaceData: { 'row': row, 'user_id': user_id },
            productTypeVendor: { 'row': row, 'user_id': user_id },
            quantity: inventoryDetails(row),
            ebay_status: { 'row': row, 'user_id': user_id },
            sku: renderSKU(row),
            listing_id: { 'row': row },
            tags: { 'row': row },
            vendor: vendor,
            // profile: renderProfiles(row)
        })
    });
    return modifiedRows;
}

export async function templateId(grid_type) {
    // console.log('object')
    // let profilesRequest = await getprofiles({ count: 25, activePage: 1, getAllProfiles: true });
    // console.log('check')
    // console.log('profilesRequest', profilesRequest)
    // let { success: profilesRequestSuccess, data: profilesRequestData } = profilesRequest;
    let vendorProductTypeProductsRequest = await getVendorProductTypeProducts();
    let { success: vendorProductTypeProductsRequestSuccess, data: vendorProductTypeProductsRequestRequestData } = vendorProductTypeProductsRequest;
    // console.log('filterOptions', filterOptions)
    let attributeOptions = [...prepareChoiceoption(filterOptions, 'headerName', "field")];
    // console.log('profilesRequestSuccess', profilesRequestSuccess)
    // console.log('vendorProductTypeProductsRequestSuccess', vendorProductTypeProductsRequestSuccess)
    // if (profilesRequestSuccess) {
    //     let templateArray = [];
    //     let { rows } = profilesRequestData;
    //     Object.entries(rows).map(([key, value]) => {
    //         let { name, profile_id } = value;
    //         templateArray.push({ 'label': name, 'value': name });
    //     });
    //     attributeOptions.forEach((attrib, index) => {
    //         if (attrib.value === 'profile_name') {
    //             attributeOptions[index]['choices'] = [...templateArray];
    //         }
    //     })
    // }
    if (vendorProductTypeProductsRequestSuccess) {
        let productTypeArray = [];
        let vendorArray = [];
        let { product_type: product_type_rows, vendor: vendorRows } = vendorProductTypeProductsRequestRequestData;
        Object.entries(product_type_rows).map(([key, value]) => {
            if(value !== '') {
                productTypeArray.push({ 'label': value, 'value': value });
            }
        });
        Object.entries(vendorRows).map(([key, value]) => {
            vendorArray.push({ 'label': value, 'value': value });
        });
        attributeOptions.forEach((attrib, index) => {
            if (attrib.value === 'details.product_type') {
                attributeOptions[index]['choices'] = [...productTypeArray];
            }
        })
        attributeOptions.forEach((attrib, index) => {
            if (attrib.value === 'details.vendor') {
                attributeOptions[index]['choices'] = [...vendorArray];
            }
        })
    }
    return [...attributeOptions];
}

export const filterOptions = [
    {
        headerName: "Title", field: "details.title"
    },
    {
        headerName: "Product Type", field: "details.product_type", choices: [], default_condition: 'equals'
    },
    {
        headerName: "Price", field: "variants.price",
    },
    {
        headerName: "Inventory", field: "variants.quantity",
    },
    {
        headerName: "SKU", field: "variants.sku"
    },
    {
        headerName: "eBay Item Id", field: "listing_id",
    },
    {
        headerName: "Tags", field: "details.tags"
    },
    {
        headerName: "Profile", field: "profile_name", choices: [], default_condition: 'equals'
    },
    {
        headerName: 'Vendor', field: 'details.vendor', choices: [], default_condition: 'equals'
    },
    {
        headerName: 'Variant Attribute', field: 'variant_attribute'
    }
];

export const selectedProductActions = [
    {
        label: 'Upload and revise on eBay', value: 'upload',
        // modaltext:'Do you want to proceed with uploading product(s) ?'
    },
    {
        label: 'Sync inventory', value: 'Inventorysync',
        modaltext: 'Do you want to sync their inventory?'
    },
    { label: 'Sync details', value: 'syncshopify' },
    { label: 'Sync Images', value: 'syncimages' },
    { label: 'End from eBay', value: 'unpublish' },
    { label: 'Export details csv', value: 'exportcsv' },
    { label: 'Relist on eBay', value: 'relist', disabled: true },
];

export const sortingOptions = [
    { label: 'SKU', value: 'variants.0.sku' },
    { label: 'Title', value: 'details.title' },
    { label: 'Sort disabled', value: '' }
];

export const sortingOptionsHighLow = [
    { label: 'High to low', value: 'DEC' },
    { label: 'Low to High', value: 'INC' },
    { label: 'Preference disabled', value: '' }
];


export const productViewtabs = [
    {
        id: 'details-product',
        content: 'Basic Details',
        title: 'Details',
        accessibilityLabel: 'Details',
        panelID: 'details-content',
        type: 'details',
    },
    {
        id: 'description-product',
        content: 'Description',
        title: 'Description',
        panelID: 'description-content',
        type: 'description'
    },
    {
        id: 'specifications-product',
        content: 'Specifications',
        title: 'Specifications',
        panelID: 'specifications-product-content',
        type: 'specifications'
    },
    {
        id: 'variant-images-product',
        content: 'Images',
        title: 'Variant Images',
        panelID: 'variant-images-content',
        type: 'variantimages'
    },
    {
        id: 'ebay-data-product',
        content: 'Product Data',
        title: 'Ebay product',
        panelID: 'ebay-product-content',
        type: 'ebayproductdata'
    }
];


export function getProductViewTabsStructure(tab, productData, changeProductViewDetails) {
    let tabType = productViewtabs.filter((tabData, index) => index === tab);
    if (tabType.length) {
        tabType = tabType[0]['type'];
        switch (tabType) {
            case 'details':
                // let  { title, vendor, product_type, tags, variant_attributes } = productData.details;
                return <Stack vertical={true}>
                    {/* {
                        textField("Title", title, changeProductViewDetails.bind(this, 'details', 'title', false))
                    }
                    <Stack vertical={false} distribution={"fillEvenly"}>
                    {
                        textField("Vendor", vendor, changeProductViewDetails.bind(this, 'details', 'vendor', false))
                    }
                    {
                        textField("Product type", product_type, changeProductViewDetails.bind(this, 'details', 'product_type', false))
                    }
                    </Stack>
                    {
                        textField("Tags", tags, changeProductViewDetails.bind(this, 'details', 'tags', false))
                    }
                    { variant_attributes.length !==0  &&
                        textField("Variant attributes", variant_attributes.join(','), ()=>{}, "","", false, 'text', "","", false, true)
                    } */}
                </Stack>

            // case 'specifications' :
            //     let  { variants, variant_attributes: attributes } =  productData.details;
            //     let barcodeAttribute = [];
            //     if( variants && variants.length && variants[0].hasOwnProperty('barcode')) barcodeAttribute = ['Barcode'];
            //     let headings = _.concat(['Product', 'Price', 'SKU Number', 'Net quantity'],barcodeAttribute, attributes);
            //     let columnTypes = headings.map( heading => 'text');
            //     let rows = variants.map( (variantObj, index) => {
            //         let { main_image, source_variant_id, price, quantity, sku, barcode  } = variantObj;
            //          main_image = main_image ? main_image: Noimage;
            //          let singlerow = [
            //            thumbnail(main_image, `${source_variant_id}`),
            //              textField("", price, changeProductViewDetails.bind(this, "variants", "price", index ), "", "", false, "number", "$" ),
            //              textField("", sku, changeProductViewDetails.bind(this, "variants", "sku", index ) ),
            //              textField("", quantity, changeProductViewDetails.bind(this, "variants", "quantity", index ), "", "", false, "number" )
            //          ];
            //          if(barcode) singlerow.push( textField("", barcode, changeProductViewDetails.bind(this, "variants", "barcode", index ) ))
            //          attributes.forEach(attri => {
            //             singlerow.push( textField("", variantObj[attri], changeProductViewDetails.bind(this, "variants", attri, index ) ) );
            //          });
            //          return singlerow;
            //     });
            //     return <DataTable
            //             columnContentTypes={columnTypes}
            //             headings={ headings }
            //             rows={ rows }
            //         />

            // case 'description':
            //     let { long_description } = productData.details;
            //     return ckeditor(long_description, changeProductViewDetails.bind(this, 'details','long_description',false));

            // case 'variantimages':
            //     let { image_array } = productData.details;
            //     return <Stack vertical={true} alignment={"center"}><div style={{paddingLeft : 150, paddingRight: 150}}>{crouselStructureFunction(image_array)}</div></Stack>

            // case 'ebayproductdata' :
            //     let { ebay_product_json } = productData;
            //     if(ebay_product_json && Object.keys(ebay_product_json).length) return ReactJsonStructure(ebay_product_json);
            //     else return bannerPolaris("eBay Product data",<p>Not available</p>, "info" )
            default: break;
        }
    }
}

export function attachCountTabTitle(tabs, type, rows) {
    let count = 0;
    if (type !== 'all') {
        rows.forEach(row => {
            if (row.type === type) count++;
        })
    }
    else count = rows.length;
    tabs.forEach((tab, index) => {
        if (tab.type === type) tabs[index].content = <p>{tabs[index].title} <Badge status={"info"}>{`${count}`}</Badge></p>
    })
    return tabs;
}
