import React, {Component} from 'react';
import {Badge, Banner, Card, Modal, Page, Pagination, Select, Tabs,ResourceList,Avatar,TextStyle} from "@shopify/polaris";
import {isUndefined} from "util";
import SmartDataTable from "../../shared/smartTable";
import {requests} from "../../services/request";
import {paginationShow} from "../../shared/static-functions";



class newProducts extends Component {

    filters = {
        full_text_search: '',
        marketplace: 'all',
        column_filters: {}
    };
    gridSettings = {
        count: 50,
        activePage: 1
    };
    pageLimits = [
        {label: 25, value: '25'},
        {label: 50, value: '50'},
        {label: 100, value: '100'},
        {label: 200, value: '200'},
    ];
    visibleColumns = ['title','profile_name','status'];

    hideFilters = ['_id','title','profile_name','status'];
    columnTitles = {
        _id:{
            title:'Id',
            label:'_id',
            id:'_id',
            sortable:false,
        },
        title: {
            title: 'Title',
            sortable: true,
            type:'react'
        },
        profile_name: {
            title: 'Profile name',
            sortable: false,
            type:'react'
        },
        status: {
            title: 'Status',
            sortable: false,
            type:'react'
        },
    };
    constructor(props){
        super(props);
        this.state={
            products:[],
            Resource_data:[],
            pagination_show:'',
            totalPage:0,
            statusShowModal:false,
            statusShowData:[],

        }
        this.operations = this.operations.bind(this);
    }
    operations(data, event) {
        switch (event) {
            default:
                requests.getRequest('ebayV1/get/failedProducts',{product_id:data._id}).then(data=>{
                    if(data.success){
                        this.prepareStatusData(data.data);
                    }
                });
                break;
        }
    }
    prepareStatusData(data){
        let temparr=[];
        if(!isUndefined(data.report)){
            (data.report).forEach((value,index)=>{
                if(typeof value === 'string'){
                    temparr.push(
                        <Banner status="critical" key={index}>
                            {value}
                        </Banner>
                    )
                }else if(typeof value === 'object'){
                    temparr.push(
                        <Banner status="critical" key={index}>
                            {value.LongMessage}
                        </Banner>
                    )
                }
            });

        }
        this.state.statusShowData=temparr;
        this.state.statusShowModal=true;
        this.setState(this.state);
    }
    componentDidMount(){
        this.getProducts()
    }
    getProducts(){
        requests.getRequest('ebayV1/get/newProducts',this.gridSettings).then(data=>{
            if(data.success){
                this.setState({totalPage:parseInt(data.data.count)});
                this.state.pagination_show = paginationShow(this.gridSettings.activePage,this.gridSettings.count,data.data.count,true);
                // this.state.products=this.modifyData(data.data.rows);
                this.state.Resource_data=this.modifyData1(data.data.rows);
                this.setState(this.state);
            }
        })
    }
    modifyData(rows){
        let temparr=[];
        rows.forEach((row,index)=>{
            let tempObj={};
            tempObj['_id']=row._id;
            tempObj['profile_name']=row.profile_name;
            tempObj['title']=row.title;
            tempObj['status']=<Badge status={'warning'}>{row.uploaded?'Uploaded':'Not uploaded'}</Badge>;
            temparr.push(Object.assign({},tempObj));
        });
        return temparr;
    }
    modifyData1(rows){
        let temparr=[];
        temparr=rows.slice(0);
        return temparr;
    }

    render() {
        return (
            <Page
                fullWidth={true}
                breadcrumbs={[{content: 'Products', onAction:this.redirect.bind(this,'/panel/products')}]}
                title={'New products'}
            >
                <Card>
                    <div className="p-5">
                        <div className="row">
                            <div className="col-12 text-right">
                                <h5 className="mr-5">{this.state.pagination_show} New products</h5>
                                <hr/>
                            </div>
                            <div className="col-12">
                                <ResourceList items={this.state.Resource_data}
                                              renderItem={(item) => {
                                                  const {title, variants_count} = item;

                                                  return (
                                                      <ResourceList.Item

                                                          accessibilityLabel={`View details for ${title}`}
                                                      >
                                                          <h3>
                                                              <TextStyle variation="strong">{title}</TextStyle>
                                                          </h3>
                                                          <div>{variants_count} {variants_count===1?"variant":"variants"}</div>
                                                      </ResourceList.Item>
                                                  );
                                              }}
                                />
                            </div>
                            {/*<div className="col-12">*/}
                            {/*<SmartDataTable*/}
                            {/*data={this.state.products}*/}
                            {/*uniqueKey="_id"*/}
                            {/*columnFiltersValue={this.filters.column_filters}*/}
                            {/*columnTitles={this.columnTitles}*/}
                            {/*hideLoader={this.state.hideLoader}*/}
                            {/*showLoaderBar={this.state.showLoaderBar}*/}
                            {/*hideFilters={this.hideFilters}*/}
                            {/*actions={this.massActions}*/}
                            {/*count={this.gridSettings.count}*/}
                            {/*activePage={this.gridSettings.activePage}*/}
                            {/*operations={this.operations}*/}
                            {/*multiSelect={false}*/}
                            {/*selected={this.state.selectedProducts}*/}
                            {/*className='ui compact selectable table'*/}
                            {/*withLinks={true}*/}
                            {/*visibleColumns={this.visibleColumns}*/}
                            {/*ViewColumnsHide={true}*/}
                            {/*showColumnFilters={false}*/}
                            {/*rowActions={{*/}
                            {/*edit: false,*/}
                            {/*delete: false*/}
                            {/*}}*/}
                            {/*massAction={(event) => {*/}
                            {/*switch (event) {*/}
                            {/*default:console.log(event,this.state.selectedProducts);*/}
                            {/*}*/}
                            {/*}}*/}
                            {/*editRow={(row) => {*/}
                            {/*this.redirect("/panel/products/edit/" + row.id);*/}
                            {/*}}*/}
                            {/*getVisibleColumns={(event) => {*/}
                            {/*this.visibleColumns = event;*/}
                            {/*}}*/}
                            {/*deleteRow={(row) => {*/}
                            {/*this.state.toDeleteRow = row;*/}
                            {/*this.state.deleteProductData = true;*/}
                            {/*const state = this.state;*/}
                            {/*this.setState(state);*/}
                            {/*}}*/}
                            {/*columnFilters={(filters) => {*/}
                            {/*this.filters.column_filters = filters;*/}
                            {/*this.getProducts();*/}
                            {/*}}*/}
                            {/*userRowSelect={(event) => {*/}
                            {/*const itemIndex = this.state.selectedProducts.indexOf(event.data._id);*/}
                            {/*if (event.isSelected) {*/}
                            {/*if (itemIndex === -1) {*/}
                            {/*this.state.selectedProducts.push(event.data._id);*/}
                            {/*}*/}
                            {/*} else {*/}
                            {/*if (itemIndex !== -1) {*/}
                            {/*this.state.selectedProducts.splice(itemIndex, 1);*/}
                            {/*}*/}
                            {/*}*/}
                            {/*const state = this.state;*/}
                            {/*this.setState(state);*/}
                            {/*}}*/}
                            {/*allRowSelected={(event, rows) => {*/}
                            {/*let data = this.state.selectedProducts.slice(0);*/}
                            {/*if (event) {*/}
                            {/*for (let i = 0; i < rows.length; i++) {*/}
                            {/*const itemIndex = this.state.selectedProducts.indexOf(rows[i]._id);*/}
                            {/*if ( itemIndex === -1 ) {*/}
                            {/*data.push(rows[i].source_variant_id);*/}
                            {/*}*/}
                            {/*}*/}
                            {/*} else {*/}
                            {/*for (let i = 0; i < rows.length; i++) {*/}
                            {/*if ( data.indexOf(rows[i]._id) !== -1 ) {*/}
                            {/*data.splice(data.indexOf(rows[i]._id), 1)*/}
                            {/*}*/}
                            {/*}*/}
                            {/*}*/}
                            {/*this.state.selectedProducts=data.slice(0);*/}
                            {/*this.setState(this.state);*/}
                            {/*}}*/}
                            {/*sortable*/}
                            {/*/>*/}
                            {/*</div>*/}
                        </div>
                        <div className="row mt-3">
                            <div className="col-6 text-right">
                                <Pagination
                                    hasPrevious={1 < this.gridSettings.activePage}
                                    onPrevious={() => {
                                        this.gridSettings.activePage--;
                                        this.getProducts();
                                    }}
                                    hasNext={this.state.totalPage/this.gridSettings.count > this.gridSettings.activePage}
                                    onNext={() => {
                                        this.gridSettings.activePage++;
                                        this.getProducts();
                                    }}
                                />
                            </div>
                            <div className="col-md-2 col-sm-2 col-6 d-none">
                                <Select
                                    options={this.pageLimits}
                                    value={this.gridSettings.count}
                                    onChange={this.pageSettingsChange.bind(this)}>
                                </Select>
                            </div>
                        </div>
                    </div>
                </Card>
                {this.StatusShowModal()}
            </Page>
        );
    }

    StatusShowModal() {
        return (
            <Modal
                title={'Product status'}
                open={this.state.statusShowModal}
                onClose={() => {
                    this.state.statusShowModal=false;
                    this.setState(this.state);
                }}
            >
                <Modal.Section>
                    {this.state.statusShowData}
                </Modal.Section>
            </Modal>
        );
    }

    pageSettingsChange(event) {
        this.gridSettings.count = event;
        this.gridSettings.activePage = 1;
        this.getProducts();
    }

    redirect(url) {
        if ( !isUndefined(this.props.location.state) && Object.keys(this.props.location.state).length > 0 ) {
            this.props.history.push(url, JSON.parse(JSON.stringify(this.props.location.state)))
        } else {
            this.props.history.push(url);
        }
    }
}

export default newProducts;
