import React, {Component} from 'react';
import {
  Page,
  Label,
  Card,
  TextContainer,
  Collapsible,
  Banner,
  Select,
  Button,
  TextField,
  ButtonGroup,
  DataTable,
  Thumbnail,
  Stack,
  Heading,
  Modal,
  ChoiceList,
  Checkbox,
  FormLayout,
  DisplayText, Badge, Icon
} from "@shopify/polaris";
import { isUndefined } from 'util';
import Notfound from "../../assets/img/notfound.png"
// import './analytics.css';
import { EditorState, convertToRaw, ContentState } from 'draft-js';
import { Editor } from 'react-draft-wysiwyg';
import draftToHtml from 'draftjs-to-html';
import htmlToDraft from 'html-to-draftjs';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import * as queryString from "query-string";
import ReactJson from 'react-json-view';


let Syncfieldsdetails = [
  {label:'Title' , value : 'title'},
  {label:'Description' , value : 'long_description'},
  {label:'Product type' , value : 'product_type'},
  {label:'Vendor' , value : 'vendor'},
  {label:'Tags' , value : 'tags'},
];
let Syncfieldsvariants =[
  {label:'SKU' , value : 'sku'},
  {label:'Quantity' , value : 'quantity'},
  {label:'Price' , value : 'price'},
  {label:'Weight' , value : 'weight'},
  {label:'Weight unit' , value : 'weight_unit'},
]
const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');
class ViewProducts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      id:'',
      complete_data:{},
      ebay_product_data:false,
      open: 1,
      img:[],
      sync_fields :{
        all:false,
        details: [],
        variants : [],
      },

      variants_details_grid:{
        columns_type:['text','text','text','text','text','text','text','text'],
        columns:[
          'Image',
          'SKU',
          'Price',
          'Quantity',
          'Barcode',
          'Excluded',
          'Weight',
          'unit',
        ],
      },
      synconewithShopify:false,
      buttonDisable: {
        save:true,
        save_upload:false,
        discard:false,
        sync:false,
      },
      editorState: EditorState.createEmpty(),
      imagePosition:0,
      products_top: {
        title:'',
        description: EditorState.createEmpty(),
      },
      product_data:{
        details:{
          product_dimensions:{
            length:'',
            width:'',
            height:'',
            unit:'in'
          },
        },

        variants:[],
        created_at:'',
        updated_at:'',
        variants_attributes:[],
      },
      SelectUploadProfileData:{
        matchingProfile:[],
        profileData:{},
      },
      selectandUpload:false,
      uploadUsingDiffprofile:{
        profile_name:'',
        profile_id:'',
        data:{},
        data_selected:false
      },
      edited_fields:{},
      variants:[],
      rows:[],
      ProductStatus:{
        data:[],
        exists:false,
        activeStatus:false,
        openModal:false,
      }
    };

  }

  componentDidMount(){
    this.getQueryPrams();
  }

  getQueryPrams() {
    if (this.props.location.search !== "") {
      const queryParams = queryString.parse(this.props.location.search);
      if (!isUndefined(queryParams['message'])) {
        let data_recieved = JSON.parse(cryptr.decrypt(decodeURI(queryParams['message'])))
        if (!isUndefined(data_recieved['id'])) {
          this.state.id = data_recieved['id'];
          this.setState(this.state);
          this.getSingleProductData();
        }
      }
    }
  }

  handleToggleClick(key){
    let tempObj = Object.assign({},this.state);
    tempObj[key]=!tempObj[key];
    this.setState(tempObj);
  }

  getUploadabledetails(){

    let tempObj={product_ids: [this.state.id], source: 'shopify', target: 'ebay'}

    requests.postRequest('ebayV1/upload/getProductProfiles',tempObj).then(data=>{
      if(data.success){
        if(!isUndefined(data.data)) {
          this.formulateUploadabledata(data.data);
        }
        else{
          notify.error('Upload information missing');
        }
      }else{
        notify.error(data.message);
      }

    })
  }

  formulateUploadabledata(data){
    let tempObjMatchingProfile=[];

    let tempObjprofileData={};

    if(!isUndefined(data['product_profile_data']) && !isUndefined(data['matching_profiles'])){
      tempObjMatchingProfile.push({label:'Default profile',value:'default_profile'})
      data['matching_profiles'].forEach((profile,pos)=>{
        tempObjMatchingProfile.push({label:profile['name'],value:profile['id'].toString()});
      });
      data['product_profile_data'].forEach((profileData,index)=> {

        if (isUndefined(tempObjprofileData)) {
          if(!profileData['profile_id']){
            tempObjprofileData['false'] = {
              profile_name: profileData['profile_name'],
              source_product_ids: [profileData['container_id']]
            }

          }
          else {

            tempObjprofileData[profileData['profile_id']] = {
              profile_name: profileData['profile_name'],
              source_product_ids: [profileData['container_id']]
            }
          }
        } else {

          if(!profileData['profile_id']){
            if ('false' in tempObjprofileData) {
              tempObjprofileData['false']['source_product_ids'].push(profileData['container_id']);
            } else {
              tempObjprofileData['false'] = {
                profile_name: profileData['profile_name'],
                source_product_ids: [profileData['container_id']]
              }
            }
          }
          else {
            if (profileData['profile_id'] in tempObjprofileData) {
              tempObjprofileData[profileData['profile_id']]['source_product_ids'].push(profileData['container_id']);
            } else {
              tempObjprofileData[profileData['profile_id']] = {
                profile_name: profileData['profile_name'],
                source_product_ids: [profileData['container_id']]
              }
            }
          }
        }
      });
    }
    if(!isUndefined(tempObjprofileData['false']) && !tempObjprofileData['false']['profile_name']){
      tempObjprofileData['false']['profile_name']='default_profile';
    }
    this.state.SelectUploadProfileData.matchingProfile=tempObjMatchingProfile.slice(0);
    this.state.SelectUploadProfileData.profileData=Object.assign({},tempObjprofileData);
    this.state.selectandUpload=true;
    const state = this.state;
    this.setState(state);

  }

  closeSaveandUpload(){
    this.state.selectandUpload=false;
    this.state.SelectUploadProfileData={
      matchingProfile:[],
      profileData:{},
    };
    this.state.uploadUsingDiffprofile.id = '';
    this.state.uploadUsingDiffprofile.profile_name = '';
    this.state.uploadUsingDiffprofile.data_selected = false;
    this.state.uploadUsingDiffprofile.data ={};
    const state = this.state;
    this.setState(state);
  }

  SelectUploadMatchProfile(value)
  {
    this.state.SelectUploadProfileData.profileData['false']['profile_name']=value;
    this.setState(this.state);
  }
  renderProductProfilesDetails(){
    let temparr=[];

    Object.keys(this.state.SelectUploadProfileData.profileData).map(key=>{
      if(key!=='false'){
        temparr.push(
          <p>This {this.state.SelectUploadProfileData.profileData[key].source_product_ids.length===1?" product":" products"} belong to profile <b>{this.state.SelectUploadProfileData.profileData[key].profile_name}</b></p>
        )
      }
    });
    if('false' in this.state.SelectUploadProfileData.profileData){
      temparr.push(
        <Stack.Item key={'falsekey'}>
          <FormLayout>
            <Select
              label={ <React.Fragment>This {this.state.SelectUploadProfileData.profileData['false'].source_product_ids.length===1?" product":" products"} does not belong to any profile kindly specify one by selecting below</React.Fragment>}
              options={this.state.SelectUploadProfileData.matchingProfile}
              placeholder={'Please select'}
              value={this.state.SelectUploadProfileData.profileData['false'].profile_name?this.state.SelectUploadProfileData.profileData['false'].profile_name:''}
              onChange={this.SelectUploadMatchProfile.bind(this)}>
            </Select>
          </FormLayout>
        </Stack.Item>
      )
    }
    else{
      temparr.push(
        <Stack.Item key={'notfalsekey'}>
          <FormLayout>
            <Banner status={"info"}>
              <p>If you want to <b>upload</b> the selected product(s) with a <b>different profile</b> kindly select one <b>Profile</b> from below and <b>click on Upload</b>,Or to continue with the already assigned one just click <b>Upload</b></p>
            </Banner>
            <Select
              label={''}
              options={this.state.SelectUploadProfileData.matchingProfile}
              placeholder={'Please select'}
              value={this.state.uploadUsingDiffprofile.id}
              onChange={this.SelectUploadUsingDiffProfile.bind(this)}>
            </Select>
          </FormLayout>
        </Stack.Item>
      )
    }

    return temparr;

  }

  SelectUploadUsingDiffProfile(value)
  {
    let selectedProfile ={};
    let tempObj = Object.assign({},Object.values(this.state.SelectUploadProfileData.profileData));
    this.state.SelectUploadProfileData.matchingProfile.forEach((profile,index)=>{
      if(profile.value === value){
        this.state.uploadUsingDiffprofile.profile_name = profile.label ;
        selectedProfile[value] = {};
        selectedProfile[value]['profile_name'] = profile.label;
        selectedProfile[value]['source_product_ids'] = tempObj['0'].source_product_ids;
      }

    });
    this.state.uploadUsingDiffprofile.id = value;
    this.state.uploadUsingDiffprofile.data=Object.assign({},selectedProfile);
    this.state.uploadUsingDiffprofile.data_selected = true;
    this.setState(this.state);
  }

  updateAndUploadModal() {
    return (
      <Modal
        open={this.state.selectandUpload}
        onClose={() => {
          this.closeSaveandUpload();
        }}
        title={'Save & Upload Product'}
        primaryAction={{content:'Upload',onAction:this.saveAndUploadConfirm.bind(this), disabled:'false' in this.state.SelectUploadProfileData.profileData && this.state.SelectUploadProfileData.profileData['false']['profile_name']===false }}
      >
        <Modal.Section>

          <Stack vertical={true}>
            {
              this.renderProductProfilesDetails()
            }
          </Stack>
        </Modal.Section>
      </Modal>
    );
  }


  handleChangeSyncfields(key,data){
    switch(key){
      case 'details':
        this.state.sync_fields.details=data.slice(0);
        break;
      case 'variants':
        this.state.sync_fields.variants=data.slice(0);
        break;
    }
    if((this.state.sync_fields.details.length === Syncfieldsdetails.length) && (this.state.sync_fields.variants.length === Syncfieldsvariants.length)) {
      this.state.sync_fields.all = true
    } else {
      this.state.sync_fields.all = false
    }
    this.setState(this.state);
  }

  saveAndUploadConfirm(){
    let tempObj ={};
    let product_data = Object.assign({},this.state.product_data);
    product_data['_id']= this.state.complete_data.product._id;
    if(this.state.uploadUsingDiffprofile.data_selected){
      tempObj={
        marketplace:'ebay',
        product_data: product_data,
        edited_fields: this.state.edited_fields,
        upload_product: true,
        upload_product_profile:this.state.uploadUsingDiffprofile.id,
      };
    }else{
      tempObj={
        marketplace:'ebay',
        product_data: product_data,
        edited_fields: this.state.edited_fields,
        upload_product: true,
        upload_product_profile:!isUndefined(this.state.SelectUploadProfileData.profileData['false'])?this.state.SelectUploadProfileData.profileData['false']['profile_name']:false,
      };
    }
    
    let buttonDisable = this.state.buttonDisable;
    buttonDisable.save = true;
    this.setState({buttonDisable:buttonDisable});
    if(this.state.uploadUsingDiffprofile.profile_name == ""){
      if(this.state.SelectUploadProfileData.hasOwnProperty('profileData') && Object.keys(this.state.SelectUploadProfileData.profileData).length>0){
        tempObj['upload_product_profile'] = Object.keys(this.state.SelectUploadProfileData.profileData)[0];
      }
    }
    if(tempObj.upload_product_profile === '' && (this.state.uploadUsingDiffprofile.id === undefined || this.state.uploadUsingDiffprofile.id === "")) {
      notify.warn("Please choose any profile")
      return
    } 
    requests.postRequest('connector/product/updateProduct',tempObj).then(e => {
      if ( e.success ) {
        notify.success(e.message);
      } else {
        notify.error(e.message);
      }
      this.getSingleProductData();
    });

    this.closeSaveandUpload();
  
  }
  

  handleChangeSyncall(key){
    let tempDetails=[];
    let tempvariants=[];
    let selectedvariantsSync =[];
    let selecteddetailsSync =[];

    if(key){
      Syncfieldsvariants.forEach((variantoption,index)=>{
        selectedvariantsSync.push(variantoption.value);
        variantoption.disabled = true
        tempvariants.push(
          variantoption
        )
      });
      Syncfieldsdetails.forEach((detailsoption,index)=>{
        selecteddetailsSync.push(detailsoption.value);
        detailsoption.disabled = true
        tempDetails.push(
          detailsoption
        )
      });

    }else{
      Syncfieldsvariants.forEach((variantoption,index)=>{
        variantoption.disabled = false
        tempvariants.push(
          variantoption
        )
      });

      Syncfieldsdetails.forEach((detailsoption,index)=>{
        detailsoption.disabled = false
        tempDetails.push(
          detailsoption
        )
      });
    }
    Syncfieldsdetails = tempDetails.slice(0);
    Syncfieldsvariants = tempvariants.slice(0);
    this.state.sync_fields.details = selecteddetailsSync.slice(0);
    this.state.sync_fields.variants = selectedvariantsSync.slice(0);
    this.state.sync_fields.all=key;
    this.setState(this.state);
  }

  getSyncfieldsCompo(){
    let temparr=[];
    temparr.push(
      <ChoiceList
        key={'details-syncfields'}
        allowMultiple
        title={''}
        choices={Syncfieldsdetails}
        selected={this.state.sync_fields.details}
        onChange={this.handleChangeSyncfields.bind(this,'details')}
      />
    );
    temparr.push(
      <ChoiceList
        key={'variants-syncfields'}
        allowMultiple
        title={''}
        choices={Syncfieldsvariants}
        selected={this.state.sync_fields.variants}
        onChange={this.handleChangeSyncfields.bind(this,'variants')}
      />
    )
    return <Card title={'Kindly select the fields you want to sync'}>
      <Card.Section>
        <FormLayout>
          <Checkbox
            checked={this.state.sync_fields.all}
            label="Sync all fields"
            onChange={this.handleChangeSyncall.bind(this)}
          />
          <FormLayout.Group condensed>{temparr}</FormLayout.Group>
        </FormLayout>
      </Card.Section>
    </Card>;
  }

  syncSingleProductModal() {
    return (
      <Modal
        open={this.state.synconewithShopify}
        onClose={() => {
          this.closebulksyncOneProductModal();
        }}
      >
        <Modal.Section>
          <div className="row p-5">
            <div className="col-12 text-center p-1">
              <h2 className='font-weight-bold'>You are about to perform sync for this product</h2>
            </div>
            <div className="col-12 mt-3">

              {this.getSyncfieldsCompo()}

            </div>
            <div className="col-12 text-center pt-5">
              <Button
                disabled={this.state.sync_fields.variants.length === 0 && this.state.sync_fields.details.length === 0 }
                onClick={()=>{this.handleSyncAction()}} primary>
                Yes
              </Button>
            </div>
          </div>
        </Modal.Section>
      </Modal>
    );
  }

  getSingleProductData = () => {
    requests.postRequest('ebayV1/get/productById',{'product_id': this.state.id})
      .then(data => {
        if (data.success) {
          this.state.complete_data=Object.assign({},data.data);
          this.setState(this.state);
          let temp = this.state;
          temp.edited_fields = {};
          temp['product_data'] = {
            details:Object.assign({}, {...this.state.product_data.details,...data.data.product.details}),
            variants:JSON.parse(JSON.stringify(data.data.product.variants)),
            created_at: data.data.product['created_at'],
            updated_at: data.data.product['updated_at'],
          };
          if ( !isUndefined(data.data.product['variant_attribute']) ) {
            temp['product_data']['variant_attribute'] = JSON.parse(JSON.stringify(data.data.product['variant_attribute']))
          } else if ( !isUndefined(data.data.product['variant_attributes']) ) {
            temp['product_data']['variant_attribute'] = JSON.parse(JSON.stringify(data.data.product['variant_attributes']))
          }else {
            temp['product_data']['variant_attribute'] = [];
          }
          let excludeData = {};
          if(data.data.ebay_product_container_data) {
            excludeData = {...data.data.ebay_product_container_data};
          }

          let draft = htmlToDraft('<React.Fragment><div>' + data.data.product.details['short_description'] + '</div></React.Fragment>');
          const { contentBlocks, entityMap } = draft;
          const contentState = ContentState.createFromBlockArray(contentBlocks, entityMap);
          const editorState = EditorState.createWithContent(contentState);
          temp.editorState = editorState;
          temp.products_top = {
            title:data.data.product.details.title,
            description: data.data.product.details['short_description'],
            vendor: !isUndefined(data.data.product.details['vendor']) && data.data.product.details['vendor'] !==''?data.data.product.details['vendor']:'',
            product_type: !isUndefined(data.data.product.details['product_type']) && data.data.product.details['product_type'] !==''?data.data.product.details['product_type']:'',
            tags: !isUndefined(data.data.product.details['tags']) && data.data.product.details['tags'] !==''?data.data.product.details['tags']:''
          };
          if ( !isUndefined(data.data.product['variants']) && typeof data.data.product['variants'] === 'object') {
            let variant = data.data.product['variants'];
            temp.variants = [];
            Object.keys(variant).forEach((e) => {
              if ( !isUndefined(variant[e]) ) {
                // console.log(variant[e]['main_image']);
                let excluded_confirm = 'no';
                if(excludeData.variants) {
                 excludeData.variants.map( variant_data => {
                    if(variant_data.source_variant_id === variant[e]['source_variant_id']){
                      if(!isUndefined(variant_data['excluded'])){
                        excluded_confirm =  variant_data['excluded'];
                      }
                    }
                  } );
                }
                if(!isUndefined(temp['product_data']['variant_attribute']) && temp['product_data']['variant_attribute'].length > 0 ) {

                  let tempAttrib = {};

                  temp['product_data']['variant_attribute'].forEach((variant_attr) => {
                    if(temp.variants_details_grid.columns.indexOf(variant_attr)=== -1) {
                      temp.variants_details_grid.columns_type.push('text');
                      temp.variants_details_grid.columns.push(variant_attr);
                    }

                    tempAttrib[variant_attr.toLowerCase()] =  variant[e][variant_attr.toLowerCase()]
                  })
                  temp.variants.push({...
                      {
                        main_image: !isUndefined(variant[e]['main_image']) ? variant[e]['main_image'] : Notfound,
                        sku: variant[e]['sku'],
                        source_variant_id: variant[e]['source_variant_id'],
                        price: variant[e]['price'],
                        quantity: variant[e]['quantity'],
                        barcode: variant[e]['barcode'] !== null ? variant[e]['barcode']:'Not available',
                        excluded: excluded_confirm,
                        weight: variant[e]['weight'],
                        weight_unit: variant[e]['weight_unit'],
                        // barcode:variant[e]['barcode']
                      },...tempAttrib}
                  );
                }else{
                  temp.variants.push(
                    {
                      main_image: !isUndefined(variant[e]['main_image']) ? variant[e]['main_image'] : Notfound,
                      sku: variant[e]['sku'],
                      source_variant_id: variant[e]['source_variant_id'],
                      price: variant[e]['price'],
                      quantity: variant[e]['quantity'],
                      barcode: variant[e]['barcode'] !== null ? variant[e]['barcode']:'Not available',
                      excluded: excluded_confirm,
                      weight: variant[e]['weight'],
                      weight_unit: variant[e]['weight_unit'],
                      // barcode:variant[e]['barcode']
                    }
                  );
                }
              }
            });
            temp.rows = this.handleTableChange(temp.variants, temp['product_data']['variant_attribute'] );
          }
          temp.img = [];
          if('image_array' in data.data.product.details) {
            Object.keys(data.data.product.details['image_array']).forEach(e => {
              if (!isUndefined(data.data.product.details['image_array'][e]['src'])) {
                temp.img.push(data.data.product.details['image_array'][e]['src']);
              }
            });
          }
          // console.clear();

          this.setState(temp,()=>{
            // console.log(this.state);
          });
        } else {
          notify.error(data.message);
        }
        this.getStatusOfproduct();
      })
  };

  getStatusOfproduct(){
    this.state.ProductStatus.activeStatus = false;
    this.setState(this.state);
    let allData = Object.assign({},this.state.complete_data);
    let status = {
      notuploaded:false,
      uploaded:false,
      ended:false,
      errors:false,
    };
    if(allData.product && !allData.marketplace_table_data && !allData.end_item_status && !allData.ebay_product_data && !allData.ebay_item_status ){
      status.notuploaded = true;
    }
    if(allData.marketplace_table_data && !allData.end_item_status && allData.ebay_product_data && allData.ebay_item_status){
      status.uploaded =true;
    }
    if(!allData.marketplace_table_data && allData.end_item_status && !allData.ebay_product_data && !allData.ebay_item_status){
      status.ended =true;
    }
    status ={};
    switch(allData.ebay_product_container_data.status){
      case 'error':
        status['error'] = true;
        break;
      case 'not_uploaded':
        status['notuploaded'] = true;
        break;
      case 'uploaded':
        status['uploaded'] = true;
        break;
      case 'ended':
        status['ended'] = true;
        break;
    }
    this.prepareStatusData(allData.ebay_item_status,status);
  }
  prepareStatusData(data,stats = {}){
    let error_exists =false;
    if(!isUndefined(data.report) && data.report) {
      let temparr = [];
      if (!isUndefined(data.report) && data.report) {
        (data.report).forEach((value, index) => {
          if (typeof value === 'string') {
            switch(value.SeverityCode){
              case 'Error':
                temparr.push(
                  <Banner title={'Error'} status="critical" key={index}>
                    {value}
                  </Banner>
                );
                error_exists =true;
                break;
              case 'Warning':
                temparr.push(
                  <Banner title={'Warning'} status={"warning"} key={index}>
                    {value}
                  </Banner>
                )
                break;
              default:
                temparr.push(
                  <Banner status={"critical"} key={index}>
                    {value}
                  </Banner>
                )

            }
          } else if (typeof value === 'object') {
            switch(value.SeverityCode){
              case 'Error':
                let error_spec = 0;
                if(value.ErrorCode === '240'){
                  if(!isUndefined(value.ErrorParameters)){
                    if(typeof value.ErrorParameters === 'object'){
                      (value.ErrorParameters).forEach((error,pos)=>{
                        if(error.ParamID === '0'){
                          error_spec = 1;
                          temparr.push(
                            <Banner title={'Error'} status="critical" key={index}>
                              <p dangerouslySetInnerHTML={{__html: error.Value}} />

                            </Banner>
                          );
                        }
                      })
                    }
                  }
                };
                if(temparr.length === 0){
                  if(!isUndefined(data.full_response) && !isUndefined(data.full_response.Message)){
                    error_spec = 1;
                    temparr.push(
                      <Banner title={'Error'} status="critical" key={index}>
                        <p dangerouslySetInnerHTML={{__html:data.full_response.Message}} />

                      </Banner>
                    );
                  }
                }
                if(error_spec === 0) {
                  temparr.push(
                    <Banner title={'Error'} status="critical" key={index}>
                      {value.LongMessage}
                    </Banner>
                  )
                }
                error_exists = true;
                break;
              case 'Warning':
                temparr.push(
                  <Banner title={'Warning'} status="warning" key={index}>
                    {value.LongMessage}
                  </Banner>
                );
                break;
              default:
                temparr.push(
                  <Banner status="critical" key={index}>
                    {value.LongMessage}
                  </Banner>
                )
            }
          }
        });

      }
      if(!isUndefined(temparr.length) && temparr.length>0) {
        stats.errors = error_exists;
        this.state.ProductStatus.data = temparr;
        this.state.ProductStatus.exists = true;
      }
    }
    let activeStatus=[];
    if(stats.uploaded){
      activeStatus.push(
        <Badge status={"success"}>Uploaded {stats.errors?<Icon source={"alert"}/>:''}</Badge>
      );
    }
    if(stats.error){
      activeStatus.push(
        <Badge status={"warning"}>Error</Badge>
      );
    }
    if(stats.notuploaded){
      activeStatus.push(
        <Badge status={"attention"}>Not uploaded</Badge>
      );
    }
    if(stats.ended){
      activeStatus.push(
        <Badge status={"info"}>Ended</Badge>
      );
    }
    this.state.ProductStatus.activeStatus = activeStatus;
    this.setState(this.state);
  }



  handleTableChange = (variant,variants_attributes = false) => {
    let rows = [];
    Object.keys(variant).forEach(e => {

      let temparr=[
        <div style={{
          width: '200px'
        }}>
          <Thumbnail source={variant[e]['main_image']} size={"small"} alt={''}/></div>,
        <div style={{
          width: '200px'
        }}>
          <TextField
            label={'sku'}
            labelHidden={true}
            value={this.state.variants[e].sku}
            onChange={this.handleVariantsChange.bind(this,'sku',e)}
          /></div>,
        <div style={{
          width: '200px'
        }}>
          <TextField
            label={'price'}
            labelHidden={true}
            value={this.state.variants[e].price}
            type={"number"}
            onChange={this.handleVariantsChange.bind(this,'price',e)}
          /></div>,
        <div style={{
          width: '200px'
        }}>
          <TextField
            label={'quantity'}
            labelHidden={true}
            value={this.state.variants[e].quantity}
            type={"number"}
            onChange={this.handleVariantsChange.bind(this,'quantity',e)}
          />
        </div>,
        <div style={{
          width: '200px'
        }}>
          <TextField
            label={'barcode'}
            labelHidden={true}
            value={this.state.variants[e].barcode}
            onChange={this.handleVariantsChange.bind(this,'barcode',e)}
          />
        </div>
        ,
        this.state.variants[e].excluded == 'yes'?<Badge status={"warning"}>Excluded</Badge>:<Badge status={"success"}>Included</Badge>
        ,
        <div style={{
          width: '200px'
        }}>
          <TextField
            label={'Weight'}
            readOnly={false}
            labelHidden={true}
            value={this.state.variants[e].weight}
            type="number" min="0"
            onChange={this.handleVariantsChange.bind(this,'weight',e)}/>
        </div>
        ,
        <div style={{minWidth:'80px'}}>
          <Select
            label={"Unit"}
            labelHidden={true}
            options={[
              {label:'g', value:'g'},
              {label:'lb', value:'lb'},
              {label:'kg', value:'kg'},
              {label:'oz', value:'oz'}]}
            /*   disabled={true}  */
            value={this.state.variants[e].weight_unit}
            onChange={this.handleVariantsChange.bind(this,'weight_unit',e)}/>
        </div>,


      ];
      if(variants_attributes) {
        variants_attributes.forEach(uniqueattrib => {
          temparr.push(
            <div style={{
              width: '200px'
            }}>
              <TextField
                label={uniqueattrib.toUpperCase()}
                labelHidden={true}
                value={this.state.variants[e][uniqueattrib.toLowerCase()]}
                onChange={this.handleVariantsChange.bind(this, uniqueattrib.toLowerCase(), e)}/>
            </div>)

        })
      }
      rows.push(temparr.slice(0));
    });
    return rows;
  };
  operations(data, event) {
    // switch (event) {
    // case 'status': this.handleStatusViewChange(event, JSON.parse(data));break;
    // case 'unpublish': this.setunPublishproduct(event,JSON.parse(data));break;
    // case 'grid':
    //     let parent_props = {
    //         gridSettings:this.gridSettings,
    //         filters: this.filters,
    //     };
    //     this.redirect('/panel/products/view/' + data['parent_id'], {parent_props:parent_props});break;
    //     default:
    //         console.log(event, data);
    // }
  }

  closebulksyncOneProductModal() {
    this.state.sync_fields ={
      all:false,
      details: [],
      variants : [],
    };
    // this.state.topublishRow = {};
    this.state.synconewithShopify = false;
    const state = this.state;
    this.setState(state);
    this.handleChangeSyncall(false);
  }
  render() {
    return (
      <Page
        fullWidth={true}
        title={<React.Fragment>View Products {this.state.ProductStatus.activeStatus?this.state.ProductStatus.activeStatus:<Button loading={true} plain={true}/>}</React.Fragment>}  breadcrumbs={[{content: 'Products', onAction:this.redirect.bind(this,'/panel/products')}]}
      >
        <Card>
          <div className="p-5 row">
            <div className="col-12 mb-5 d-flex justify-content-end">
              <ButtonGroup>
                {!this.state.complete_data.end_item_status && this.state.complete_data.marketplace_table_data &&
                <Button onClick={this.handleunpblishAction.bind(this,'unpublish',this.state.complete_data.marketplace_table_data)} destructive > End from eBay</Button>}
                <Button onClick={()=>{
                  this.state.synconewithShopify=true;
                  this.setState(this.state);
                }} icon={"refresh"}> Sync With Shopify</Button>
                { this.state.complete_data.end_item_status && <Button onClick={this.handleRelistAction} icon={"notes"}>Relist on eBay</Button>}
              </ButtonGroup>
            </div>
            <div className="col-12 mb-5 d-flex justify-content-end">
              <ButtonGroup>
                <Button onClick={this.handleSaveAction} primary disabled={this.state.buttonDisable.save}> Save </Button>
                <Button onClick={this.handleSaveUploadAction} > Save & Upload </Button>
                <Button onClick={this.handleDiscardAction} destructive disabled={this.state.buttonDisable.save}> Discard </Button>
              </ButtonGroup>
            </div>

            <div className="col-12 mb-5">
              <Card>

                <Card.Section title={'Product details'}>
                  <FormLayout>
                    <TextField
                      label={'Title'}
                      value={this.state.products_top.title}
                      onChange={this.handleDetailChange.bind(this,'title')}
                    />

                    <FormLayout.Group condensed>
                      <TextField
                        label={'Vendor'}
                        value={this.state.products_top.vendor}
                        onChange={this.handleDetailChange.bind(this,'vendor')}
                      />
                      <TextField
                        label={'Product type'}
                        value={this.state.products_top.product_type}
                        onChange={this.handleDetailChange.bind(this,'product_type')}
                      />
                    </FormLayout.Group>
                    <TextField
                      label={'Tags'}
                      value={this.state.products_top.tags}
                      onChange={this.handleDetailChange.bind(this,'tags')}
                    />
                  </FormLayout>
                </Card.Section>
                <Card.Section title={'Description'}>
                  <div className="react_quill_app_class">
                    <div id="editor">
                      <Editor
                        editorState={this.state.editorState}
                        wrapperClassName="demo-wrapper"
                        editorClassName="demo-editor"
                        /* readOnly */
                        toolbar={{
                          options: /*[]*/['inline', 'blockType', 'fontSize', 'fontFamily', 'history', 'textAlign','list'],
                          inline: {
                            options: ['bold', 'italic', 'underline', 'strikethrough', 'monospace'],
                            bold: { className: 'bordered-option-classname' },
                            italic: { className: 'bordered-option-classname' },
                            underline: { className: 'bordered-option-classname' },
                            strikethrough: { className: 'bordered-option-classname' },
                            code: { className: 'bordered-option-classname' },
                          },
                          blockType: {
                            className: 'bordered-option-classname',
                          },
                          fontSize: {
                            className: 'bordered-option-classname',
                          },
                          fontFamily: {
                            className: 'bordered-option-classname',
                          },
                        }}
                        onEditorStateChange={this.handleDraftJS}
                      />
                      {/*<Editor*/}
                      {/*editorState={this.state.products_top.description}*/}
                      {/*toolbarClassName="toolbarClassName"*/}
                      {/*wrapperClassName="wrapperClassName"*/}
                      {/*editorClassName="editorClassName"*/}
                      {/*onEditorStateChange={this.handleDetailChange.bind(this,'description')}*/}
                      {/*/>*/}
                    </div>
                  </div>
                </Card.Section>
                <Card.Section title={'Product dimensions'}>
                  <FormLayout>
                    <Banner status={"info"}>Choose only if you have selected <b>Calculated Shipping</b></Banner>
                    <FormLayout.Group condensed>
                      <TextField
                        key={'LengthProduct'}
                        placeholder={''}
                        label={'Length'}
                        suffix={this.state.product_data.details.product_dimensions.unit}
                        value={this.state.product_data.details.product_dimensions.length}
                        onChange={(e)=>{
                          let buttonDisable = this.state.buttonDisable;
                          buttonDisable.save = false;
                          this.setState({buttonDisable:buttonDisable});
                          this.handleProductDataChange('product_dimensions', 'length', 0, e);
                          this.handleEditedFieldChange('product_dimensions', 'length', 0, e);
                          this.setState(this.state);
                        }}/>
                      <TextField
                        key={'BreadthProduct'}
                        placeholder={''}
                        label={'Width'}
                        suffix={this.state.product_data.details.product_dimensions.unit}
                        value={this.state.product_data.details.product_dimensions.width}
                        onChange={(e)=>{
                          let buttonDisable = this.state.buttonDisable;
                          buttonDisable.save = false;
                          this.setState({buttonDisable:buttonDisable});
                          this.handleProductDataChange('product_dimensions', 'width', 0, e);
                          this.handleEditedFieldChange('product_dimensions', 'width', 0, e);
                          this.setState(this.state);
                        }}/>
                      <TextField
                        key={'HeightProduct'}
                        placeholder={''}
                        label={'Height'}
                        suffix={this.state.product_data.details.product_dimensions.unit}
                        value={this.state.product_data.details.product_dimensions.height}
                        onChange={(e)=>{
                          let buttonDisable = this.state.buttonDisable;
                          buttonDisable.save = false;
                          this.setState({buttonDisable:buttonDisable});
                          this.handleProductDataChange('product_dimensions', 'height', 0, e);
                          this.handleEditedFieldChange('product_dimensions', 'height', 0, e);
                          this.setState(this.state);
                        }}/>
                    </FormLayout.Group>
                    {/*<Select*/}
                    {/*key={'UnitMeasurement'}*/}
                    {/*placeholder={'Please select...'}*/}
                    {/*options={[{label:'Inch',value:'in'},{label:'Centimeters',value:'cm'},{label:'Meters',value:'m'},{label:'Foot',value:'ft'}]}*/}
                    {/*label={'Select unit for above dimensions'}*/}
                    {/*value={this.state.product_data.product_dimensions.unit}*/}
                    {/*onChange={(e)=>{*/}
                    {/*this.state.product_data.product_dimensions.unit=e;*/}
                    {/*this.setState(this.state);*/}
                    {/*}}/>*/}
                  </FormLayout>
                </Card.Section>
              </Card>
            </div>
            {this.state.img.length === 0 &&
            <div className="col-12 mb-5">
                            <span>
                                <div className="row p-5 d-flex justify-content-center">
                                    <div className="col-12 col-sm-5">
                                        <div className="pb-5 pr-5 text-center">
                                            <Thumbnail source={Notfound} alt={''}
                                                       size={"extralarge"}/>
                                            <h2 className="font-weight-bold mt-2 mt-md-2" style={{color:'grey'}}>No Images Found</h2>
                                          {/*<img src={Notfound} alt="Product Image" className="img-show"/>*/}
                                        </div>
                                    </div>
                                </div>
                            </span>
            </div>
            }
            {this.state.img.length>0 &&
            <div className="col-12 mb-5">
                            <span>
                                <div className="row p-5 d-flex justify-content-center">
                                    <div className="col-12 col-sm-5">
                                        <div className="pb-5 pr-5">
                                            <Thumbnail source={this.state.img[this.state.imagePosition]} alt={''}
                                                       size={"extralarge"}/>
                                          {/*<img src={this.state.img[this.state.imagePosition]} alt="Product Image" className="img-show"/>*/}
                                        </div>
                                    </div>
                                    <div className={"col-12"}>
                                        <div className="row d-flex justify-content-center">
                                            {this.state.img.map((e, i) => {
                                              return <div key={i} className="col-3 col-sm-1 mb-1"
                                                          onPointerOver={this.handleImageChange.bind(this, i)}>
                                                    <span
                                                      className={`pr-4 ${this.state.imagePosition === i ? 'bg-info' : ''}`}>
                                                        <Thumbnail source={e} alt={''}/>
                                                    </span>
                                              </div>
                                            })}
                                        </div>
                                    </div>
                                </div>
                            </span>
            </div>
            }
            <div className="col-12 mb-5">
              <Card>
                {!isUndefined(this.state.complete_data.ebay_product_data) && this.state.complete_data.ebay_product_data &&
                <Card.Section>
                  <div  ariaExpanded={this.state.ebay_product_data}>
                    <Card>
                      <Card.Section>
                        <div style={{cursor:'pointer'}} onClick={this.handleToggleClick.bind(this, 'ebay_product_data')}>
                          <Stack distribution={"equalSpacing"}>
                            <b>eBay product data</b>
                            <Button plain icon={this.state.ebay_product_data?"chevronDown":"chevronRight"}/>
                          </Stack>
                        </div>
                      </Card.Section>
                      <Collapsible open={this.state.ebay_product_data} id={'ebayProductdata'}>
                        <Card>
                          <Card.Section>
                            <ReactJson  style={{maxHeight:200,overflowY:'scroll'}} src={!isUndefined(this.state.complete_data.ebay_product_data) && this.state.complete_data.ebay_product_data?this.state.complete_data.ebay_product_data:{}} />
                          </Card.Section>
                        </Card>
                      </Collapsible>
                    </Card>
                  </div>
                </Card.Section>
                }
                {this.state.ProductStatus.exists &&
                <Card.Section>
                  <div  ariaExpanded={this.state.ProductStatus.openModal}>
                    <Card>
                      <Card.Section>
                        <div style={{cursor:'pointer'}} onClick={()=>{
                          this.state.ProductStatus.openModal = !this.state.ProductStatus.openModal;
                          this.setState(this.state);
                        }}>
                          <Stack distribution={"equalSpacing"}>
                            <b>Warning(s) & Error(s)</b>
                            <Button plain icon={this.state.ProductStatus.openModal?"chevronDown":"chevronRight"}/>
                          </Stack>
                        </div>
                      </Card.Section>
                      <Collapsible open={this.state.ProductStatus.openModal} id={'ebayProductdataWarning'}>
                        <Card>
                          <Card.Section>
                            {this.state.ProductStatus.data}
                          </Card.Section>
                        </Card>
                      </Collapsible>
                    </Card>
                  </div>
                </Card.Section>
                }
                <Card.Section title={'Variants'}>

                  <DataTable
                    columnContentTypes={this.state.variants_details_grid.columns_type}
                    headings={this.state.variants_details_grid.columns}
                    rows={this.state.rows}
                    truncate={true}
                  />

                </Card.Section>
              </Card>
            </div>
            <div className="col-12 d-flex justify-content-end">
              <ButtonGroup>
                <Button onClick={this.handleSaveAction} primary disabled={this.state.buttonDisable.save}> Save </Button>
                <Button onClick={this.handleSaveUploadAction} > Save & Upload </Button>
                <Button onClick={this.handleDiscardAction} destructive disabled={this.state.buttonDisable.save}> Discard </Button>
              </ButtonGroup>
            </div>

          </div>
        </Card>
        {this.state.synconewithShopify && this.syncSingleProductModal()}
        {this.state.selectandUpload && this.updateAndUploadModal()}
      </Page>
    );
  }

  handleImageChange = (index) => {
    this.setState({imagePosition:index});
  };

  handleDraftJS = (value) => {
    let html = draftToHtml(convertToRaw(value.getCurrentContent()));
    let products_top = this.state.products_top;
    products_top.description = html;
    this.setState({products_top:products_top});
    this.setState({editorState:value});
    if ( this.state.open === 1 ) {
      this.setState({open:2});
    } else {
      this.setState({open:3});
      let buttonDisable = this.state.buttonDisable;
      buttonDisable.save = false;
      this.setState({buttonDisable:buttonDisable});
      this.handleProductDataChange('details', 'description', 0, html);
      this.handleEditedFieldChange('details', 'description', 0, html);
    }
  };

  handleDetailChange = (field, value) => {
    let buttonDisable = this.state.buttonDisable;
    buttonDisable.save = false;
    this.setState({buttonDisable:buttonDisable});
    this.handleProductDataChange('details', field, 0, value);
    this.handleEditedFieldChange('details', field, 0, value);
    let products_top = this.state.products_top;
    products_top[field] = value;
    this.setState({products_top:products_top});
  };

  handleVariantsChange = (field, index, value) => {
    if(field === 'weight' && value < 0) {
      notify.error("Negative values are not allowed")
      return
    } 
    this.handleProductDataChange('variants', field, index, value);
    this.handleEditedFieldChange('variants', field, index, value);
    this.setState({open:3});
    let buttonDisable = this.state.buttonDisable;
    buttonDisable.save = false;
    let variants = this.state.variants;
    variants[index][field] = value;
    let rows = this.handleTableChange(variants,this.state.product_data.variant_attribute);
    this.setState({variants:variants,rows:rows});
  };

  handleProductDataChange = (main_field,field,index, value) => {
    if(field === 'quantity' || field === 'price' || field === 'length' || field === 'width' || field === 'height'){
      value = Number(value);
    }
    let product_data = this.state.product_data;
    if ( main_field === 'details' || main_field === 'product_dimensions' ) {
      if(main_field === 'details') {
        product_data[main_field][field] = value;
      }else{
        product_data.details[main_field][field] = value;
      }
    } else {
      product_data[main_field][index][field] = value;
    }
    this.setState({product_data:product_data});
  };

  handleEditedFieldChange = (main_field, field, index, value) => {
    let edited_fields = this.state.edited_fields;
    let product_data = this.state.product_data;
    if(field === 'quantity' || field === 'price' || field === 'length' || field === 'width' || field === 'height'){
      value = Number(value);
    }
    if ( main_field === 'details' || main_field === 'product_dimensions') {
      if(main_field === 'details') {
        if (isUndefined(edited_fields[main_field]))
          edited_fields[main_field] = {};
        edited_fields[main_field][field] = value;
      }else{
        if (isUndefined(edited_fields['details'])) {
          edited_fields['details'] = {};
        }
        if(isUndefined(edited_fields['details'][main_field])){
          edited_fields['details'][main_field] = {};
        }
        edited_fields['details'][main_field][field] = value;
      }
    } else {
      if ( isUndefined(edited_fields[main_field]) )
        edited_fields[main_field] = {};
      if ( isUndefined(edited_fields[main_field][index]) )
        edited_fields[main_field][index] = {};
      edited_fields[main_field][index]['source_variant_id'] = product_data[main_field][index]['source_variant_id'];
      edited_fields[main_field][index][field] = value;
    }
    this.setState({edited_fields:edited_fields});
  };

  handleSaveAction = () => {
    let buttonDisable = this.state.buttonDisable;
    buttonDisable.save = true;
    this.setState({buttonDisable:buttonDisable});
    let data = {
      marketplace: 'ebay',
      product_data: this.state.product_data,
      edited_fields: this.state.edited_fields,
      upload_product: false
    };
    requests.postRequest('connector/product/updateProduct',data).then(e => {
      if ( e.success ) {
        notify.success(e.message);
      } else {
        notify.error(e.message);
      }
      this.getSingleProductData();
    });
  };



  handleSaveUploadAction = () => {
    let buttonDisable = this.state.buttonDisable;
    buttonDisable.save = true;
    this.setState({buttonDisable:buttonDisable});
    let data = {
      marketplace: 'ebay',
      product_data: this.state.product_data,
      edited_fields: this.state.edited_fields,
      upload_product: true
    };

    this.getUploadabledetails();

    // requests.postRequest('connector/product/updateProduct',data).then(e => {
    //     if ( e.success ) {
    //         notify.success(e.message);
    //     } else {
    //         notify.error(e.message);
    //     }
    //     this.getSingleProductData();
    // });
  };

  handleSyncAction = () => {

    let data = {
      product_id: this.state.product_data['details']['source_product_id'],
    };
    if(!this.state.sync_fields.all){
      data['sync_fields'] = this.state.sync_fields
    }
    this.state.synconewithShopify =false ;
    this.state.sync_fields ={
      all:false,
      details: [],
      variants : [],
    };
    this.setState(this.state);
    requests.postRequest('ebayV1/upload/syncWithShopify',data).then(e => {
      if ( e.success ) {
        notify.success(e.message);
      } else {
        notify.error(e.message);
      }
      this.getSingleProductData();
    });
  };

  handleRelistAction = () => {
    let listing_id = false;
    if(!isUndefined(this.state.complete_data.marketplace_table_data) && !isUndefined(this.state.complete_data.marketplace_table_data.listing_id)){
      listing_id = this.state.complete_data.marketplace_table_data.listing_id;
    }

    if(!listing_id && !isUndefined(this.state.complete_data.end_item_status) && !isUndefined(this.state.complete_data.end_item_status.listing_id)){
      listing_id = this.state.complete_data.end_item_status.listing_id;
    }
    if(listing_id) {

      let data = {
        listing_id: listing_id
      };

      requests.postRequest('ebayV1/upload/relistItem',data).then(e => {
        if ( e.success ) {
          notify.success(e.message);
        } else {
          notify.error(e.message);
        }
        this.getSingleProductData();
      });
    }else{
      notify.info("It seems Listing ID is missing");
    }
  };

  handleunpblishAction =(action,data)=>{
    if(action==='unpublish') {
      requests.postRequest('ebayV1/upload/unpublish',{'listing_id':data.listing_id}).then(data=>{
        if(data.success){
          this.getSingleProductData();
        }
        else {
          notify.error(data.message);
        }
      });
    }

  };

  handleDiscardAction = () => {
    let buttonDisable = this.state.buttonDisable;
    buttonDisable.save = true;
    this.setState({buttonDisable:buttonDisable});
    this.getSingleProductData();
  };

  redirect = url => {
    if ( !isUndefined(this.props.location.state) && Object.keys(this.props.location.state).length > 0 ) {
      this.props.history.push(url, JSON.parse(JSON.stringify(this.props.location.state)))
    } else {
      this.props.history.push(url);
    }
  }
}

export default ViewProducts;
