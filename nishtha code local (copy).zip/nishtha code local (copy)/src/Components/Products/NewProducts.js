import { Badge, Banner, Button, Card, Checkbox, ChoiceList, DisplayText, EmptyState, FormLayout, Icon, Label, Modal, Page, ProgressBar, Select, Stack, TextContainer, Thumbnail, TextField, Tooltip,FooterHelp,Link } from '@shopify/polaris'
import React, { Component } from 'react'
import { isUndefined } from 'util';
import { notify } from '../../services/notify';
import { requests } from '../../services/request';
import { capitalizeWord, paginationShow } from '../../shared/static-functions';
import Grid from '../../Subcomponents/Aggrid/grid'
import Notfound from "../../assets/img/notfound.png"
import { changeProductListTabs, extractValuesfromRequest, filterCondition, filterOptions, getFilterforRequest, getpaginationInfo, getTabSelectedFilter, gridPropColumns, pageSizeOptionProducts, productlistTabs, selectedProductActions, sortingOptions, sortingOptionsHighLow, templateId } from './producthelper';
import { getproducts } from '../../APIrequests/productsAPI';
import { prepareChoiceoption } from '../../Subcomponents/Aggrid/gridHelper';
import {
    ExportMinor, ImportMinor, QuestionMarkMinor, RefreshMinor, TaxMajorMonotone
} from '@shopify/polaris-icons';
import Skeleton from '../../shared/skeleton';
import LoadingOverlay from 'react-loading-overlay';
import ModalVideo from "react-modal-video";
import { filterUpdated } from "../../store/reducers/ebay/products/filters";
import { activityAdd } from "../../store/reducers/activity/modifyactivityslice";
import { connect } from 'react-redux';
import CustomNoRowsOverlay from '../../Subcomponents/Aggrid/CustomNoRowsOverlay';
import { getprofiles } from '../../APIrequests/profilesAPI';
import './NewProducts.css'

var flatten = require('flat');

let gridApi = '';

let Syncfieldsdetails = [
    { label: 'Title', value: 'title' },
    { label: 'Description', value: 'long_description' },
    { label: 'Product type', value: 'product_type' },
    { label: 'Vendor', value: 'vendor' },
    { label: 'Tags', value: 'tags' },
];

let Syncfieldsvariants = [
    { label: 'SKU', value: 'sku' },
    { label: 'Quantity', value: 'quantity' },
    { label: 'Price', value: 'price' },
    { label: 'Weight', value: 'weight' },
    { label: 'Weight unit', value: 'weight_unit' },
]

const reason_end_listing = [
    { label: 'Incorrect', value: 'Incorrect' },
    { label: 'Lost or broken', value: 'LostOrBroken' },
    { label: 'Not available', value: 'NotAvailable' },
    { label: 'Other listing error', value: 'OtherListingError' },
    { label: 'Sell to high bidder', value: 'SellToHighBidder' },
    { label: 'Sold', value: 'Sold' },
];

const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');
const defaultData = {
    width: 100,
    filterable: true,
    editable: false,
    sortable: false,
    resizable: false,
    draggable: false,
};

class NewProducts extends Component {

    grid_loader = false;

    massActions = [
        { label: 'Upload and revise on eBay', value: 'upload' },
        { label: 'Sync inventory', value: 'Inventorysync' },
        { label: 'Sync details', value: 'syncshopify' },
        { label: 'Sync Images', value: 'syncimages' },
        { label: 'End from eBay', value: 'unpublish' },
        { label: 'Export details csv', value: 'exportcsv' },
        { label: 'Relist on eBay', value: 'relist', disabled: true },
        // {label: 'Upload on eBay', value: 'only_upload'},
        // {label: 'Update on eBay', value: 'only_update'},
    ];
    video = { Modal: false, id: '' };
    column = [
        {
            key: "check",
            // name: <Checkbox id={"all"}
            //     checked={false}
            //     onChange={this.allSelector.bind(this, 'all_selector')} />,
            frozen: true,
            editable: false,
            width: 50,
            sortable: false,
            draggable: false,
            filterable: false,
        },
        {
            key: "main_image",
            name: "Image",
            frozen: true,
            editable: false,
            width: 80,
            sortable: false,
            draggable: false,
            filterable: false,
        },
        {
            key: "title",
            frozen: false,
            width: 100,
            // filterRenderer: Filter,
            name: "Title",
        },
        {
            key: "product_type",
            sortable: true,
            name: "Product type",
            width: 100,
            // filterRenderer: Filter,
        },
        {
            frozen: false,
            key: "quantity",
            sortable: false,
            name: "Inventory",
            width: 100,
            // filterRenderer: NumericFilter,

        },
        {
            key: "ebay_status",
            sortable: false,
            name: "eBay Status",
            width: 100,
            filterable: false,

        },
        {
            key: "sku",
            sortable: false,
            name: "SKU",
            width: 100,
            // filterRenderer: Filter,
        },
        {
            key: "ebay_item_id",
            sortable: false,
            name: "eBay Item ID",
            width: 100,
            // filterRenderer: NumericFilter
        },
        {
            key: "tags",
            sortable: false,
            name: "Tags",
            width: 100,
            // filterRenderer: Filter,
        },
        {
            key: "ebay_profile",
            width: 100,
            // filterRenderer: Filter,
            name: "Profile",
        },
        {
            key: "vendor",
            sortable: true,
            name: "Vendor",
            width: 100,
            // filterRenderer: Filter,
        },

    ];
    profilesList = [];

    constructor(props) {
        super(props);
        this.state = {
            toolbar_suffix: "Product(s)",
            site_id: '',
            user_id: '',
            syncImagesModal: false,
            bulk_action_marketplace: '',
            sync_fields: {
                all: false,
                details: [],
                variants: []
            },
            product_status: ['published'],
            optional_filter: false,
            use_product_type_filter: false,
            use_vendor_filter: false,
            vendor: '',
            product_type: '',
            import_and_replace: 'no',
            vendor_options: false,
            product_type_options: false,
            sortby: '',
            high_low_sort: '',
            reason_end_listing: 'Incorrect',

            bulkAction: {
                modal: false,
                type: '',
                text: ''
            },
            relistProductData: false,
            showListingRedirectModal: false,
            selectExportCSV: {
                itemIdpresentCount: 0,
                listOfItemIds: []
            },
            selectExportModal: false,
            uploadUsingDiffprofile: {
                profile_name: '',
                profile_id: '',
                data: {},
                data_selected: false
            },
            ListingRedirectUrl: '',
            ListingRedirectId: '',
            selectedProductDetails: {
                listing_ids: [],
                source_product_ids: []
            },
            bulkUnpublish: {
                itemIdpresentCount: 0,
                listOfItemIds: []
            },
            bulkInventorySync: {
                itemIdpresentCount: 0,
                listOfItemIds: []
            },
            bulkSync: {
                itemIdpresentCount: 0,
                listOfItemIds: []
            },
            SelectUpload: {
                itemIdpresentCount: 0,
                listOfItemIds: []
            },
            bulkRelist: {
                itemIdpresentCount: 0,
                listOfItemIds: []
            },
            SelectUploadProfileData: {
                matchingProfile: [],
                profileData: [],
                selected_profile: ''
            },
            modalInfo: {
                open: false,

                title: ''
            },
            uploadandUpdateData: {
                all_profiles: [],
                matching_profiles: {},
                choose_another_profile: false,
                selected_profile: '',
                type: '',
                message: '',
            },
            credits_info: {
                products: {
                    available: 0,
                    total: 0,
                    percent: 0
                }
            },
            statusShowModal: false,
            statusModalTitle: '',
            statusShowData: [],
            products: [],
            rows: [],
            appliedFilters: this.props.filters,
            installedApps: [],
            selectedApp: 0,
            searchValue: '',
            selectedTab: 0,
            selectedIds: [],
            profile_suggestion_show: {},
            deleteProductData: false,
            exportProductDataCsv: false,
            toDeleteRow: {},
            publishProductData: false,
            syncwithShopify: false,
            syncAllwithShopify: false,
            InventorySyncModal: false,
            topublishRow: {},
            totalPage: 0,
            statusView: { open: false, data: <h1>Hello</h1> },
            showLoaderBar: true,
            hideLoader: false,
            selectandUpload: false,
            source_shop_id: 0,
            target_shop_id: 0,
            source: '',
            marketplace: '',
            isLoading: "loading",
            importServicesList: [],
            importerShopLists: [],
            uploadServicesList: [],
            uploaderShopLists: [],
            EnableMultiselect: false,
            showImportProducts: false,
            showUploadProducts: false,
            uploadProductDetails: {
                source: '',
                source_shop: '',
                source_shop_id: '',
                target: '',
                target_shop: '',
                target_shop_id: '',
                selected_profile: '',
                profile_type: ''
            },
            importProductsDetails: {
                source: '',
                shop: '',
                shop_id: ''
            },
            // columns: this.column.map(c => ({ ...defaultData, ...c })),
            // columnsAG: gridPropColumns(this.incellElement.bind(this)),

            // utkarsh
            user_idAG: '',
            tabs: productlistTabs,
            columnsAG: gridPropColumns(this.incellElement.bind(this), window.innerWidth),
            rowsAG: [],
            paginationProps: {
                pageSizeOptions: pageSizeOptionProducts,
                activePage: 1,
                pageSize: pageSizeOptionProducts[0],
                pages: 0, totalrecords: 0
            },
            tabfilters: {},
            filtersProps: { attributeoptions: [], filters: this.props.filters, filterCondition: filterCondition },
            selectedRows: [],
            // selectedActions: selectedProductActions,
            selectedActions: [
                {
                    label: 'Upload and revise on eBay', value: 'upload',
                    // modaltext:'Do you want to proceed with uploading product(s) ?'
                },
                {
                    label: 'Sync inventory', value: 'Inventorysync',
                    // modaltext: 'Do you want to sync their inventory?'
                },
                { label: 'Sync details', value: 'syncshopify' },
                { label: 'Sync Images', value: 'syncimages' },
                { label: 'End from eBay', value: 'unpublish' },
                { label: 'Export details csv', value: 'exportcsv' },
                { label: 'Relist on eBay', value: 'relist', disabled: true },
            ],
            frameworkComponents: {
                customNoRowsOverlay: CustomNoRowsOverlay,
            },
            noRowsOverlayComponent: 'customNoRowsOverlay',
            noRowsOverlayComponentParams: {
                // noRowsMessageFunc: () => 'No Products Found',
                noRowsMessageFunc: () => <EmptyState heading="No Products Found"
                // image="https://cdn.shopify.com/s/assets/admin/empty-states-fresh/emptystate-abandoncheckout-de95c7af243bfbc1a127a7bd1a6a9b7a5769ddc295a303268fdf26913f16801c.svg"
                >
                </EmptyState>
            },

            // previous
            visibleColumns: {
                'check': 1,
                'main_image': 1,
                'title': 1,
                'product_type': 1,
                'sku': 1,
                'tags': 1,
                "ebay_item_id": 1,
                "ebay_profile": 1,
                "inventory": 1,
                "quantity": 1,
                "ebay_status": 1,
                "vendor": 1
            },
            pagination: {
                page: 1,
                totalNumberOfPages: 0,
                totalNumberOfProducts: 0,
                totalNumberOfItems: 0,
                pageSize: '50',
            },
            pagination_show: "",
            preparedFilter: {},
            expandedRows: {},
            checkbox: {},
            All_Selected: false,
            toolbar_suffix: "Product(s)",
            selected_count: 0,
            total_product_count: 999999
        };
        // this.getProducts();
        this.getProductsNew();
        this.getInstalledApps();
        this.handleStatusViewChange = this.handleStatusViewChange.bind(this);
        this.getAllImporterServices();
        this.getAllUploaderServices();
        // console.log(this.state.columns)
    }

    getAllUploaderServices() {
        requests.getRequest('connector/get/services', { 'filters[type]': 'uploader' })
            .then(data => {
                if (data.success === true) {
                    this.state.uploadServicesList = [];
                    for (let i = 0; i < Object.keys(data.data).length; i++) {
                        let key = Object.keys(data.data)[i];
                        if (!isUndefined(key) && key === 'ebay_uploader') {
                            this.state.uploadServicesList.push({
                                label: data.data[key].title,
                                value: data.data[key].marketplace,
                                shops: data.data[key].shops
                            });
                        }
                    }
                    this.updateState();
                    if (this.state.uploadServicesList.length === 0) {
                        notify.info('Your product upload limit has expired. Upgrade your plan');
                    }
                } else {
                    notify.error('Your product upload limit has expired. Upgrade your plan');
                }
            });
    }

    getAllImporterServices() {
        requests.getRequest('connector/get/services', { 'filters[type]': 'importer' })
            .then(data => {
                if (data.success === true) {
                    this.state.importServicesList = [];
                    for (let i = 0; i < Object.keys(data.data).length; i++) {
                        let key = Object.keys(data.data)[i];
                        if (!isUndefined(key) && key === 'shopify_importer') {
                            this.state.importServicesList.push({
                                label: data.data[key].title,
                                value: data.data[key].marketplace,
                                shops: data.data[key].shops
                            });
                        }
                    }
                    this.updateState();
                } else {
                    notify.error('Your product upload limit has expired. Upgrade your plan');
                }
            });
    }
    handleStatusViewChange(status, arg) {
        let data = this.state.statusView;
        data.data = false;
        if (!isUndefined(arg) && Object.keys(arg).length > 0) {
            if (!isUndefined(arg['status']) && arg['status'].length > 0) {
                arg = arg['status'];
                data.data = arg.map((e, index) => {
                    if (e.severity === 'critical') {
                        return (
                            <Banner status="warning" key={index}>
                                <h4>{e.label}</h4>
                                <h5>{e.message}</h5>
                            </Banner>
                        );
                    } else if (e.severity === 'error') {
                        return (
                            <Banner status="critical" key={index}>
                                <h4>{e.label}</h4>
                                <h5>{e.message}</h5>
                            </Banner>
                        );
                    } else {
                        return (
                            <Banner status="info" key={index}>
                                <h4>{e.label}</h4>
                                <h5>{e.message}</h5>
                            </Banner>
                        );
                    }
                })
            } else if (!isUndefined(arg['errors']) && arg['errors'].length > 0) {
                arg = arg['errors'];
                data.data = arg.map((e, i) => {
                    return (
                        <Banner key={i} status={'critical'}>
                            <h4>{e}</h4>
                        </Banner>
                    )
                })
            } else {
                arg = [];
            }
        }
        data.open = !data.open;
        this.setState({
            statusView: data,
        });
    }

    getInstalledApps() {
        requests.getRequest('connector/get/getInstalledApps', false, false, true)
            .then(data => {
                this.state.installedApps = [
                    {
                        id: 'all',
                        content: 'All',
                        accessibilityLabel: 'All',
                        panelID: 'all'
                    }
                ];
                if (data.success) {
                    for (let i = 0; i < data.data.length; i++) {
                        this.state.installedApps.push({
                            id: data.data[i].code,
                            content: data.data[i].title,
                            accessibilityLabel: data.data[i].title,
                            panelID: data.data[i].code
                        });
                    }
                } else {
                    notify.error(data.message);
                }
                this.state.showLoaderBar = data.success;
                this.updateState();
            });
    }

    async prepareFilters() {
        // console.log('attributeoptions', this.state.filtersProps)
        // let { filtersProps } = this.state;
        // filtersProps['attributeoptions'] = [...prepareChoiceoption(filterOptions, 'headerName', "field")];
        // this.setState({ filtersProps });

        let { filtersProps } = this.state;
        filtersProps['attributeoptions'] = await templateId();
        this.setState({ filtersProps }, () => {
            // console.log('attributeoptions', this.state.filtersProps)
        });
    }

    toggleOverLay(showhide) {
        console.log('gridApi', gridApi)
        console.log('showhide', showhide)
        if (gridApi !== '') {
            // console.log('object')
            if (showhide) gridApi.showLoadingOverlay();
            else gridApi.hideOverlay();
        }
    }

    async getProductsNew() {
        // this.toggleOverLay(true);
        this.grid_loader = true;
        this.updateState();
        let { paginationProps, tabfilters, filtersProps, user_idAG, tabs, selectedTab } = this.state;
        let { filters } = filtersProps;
        let { pageSize: count, activePage, } = paginationProps;
        let sortingOrdering = {
            sort: this.state.sortby !== '' ? this.state.sortby : false,
            order: this.state.high_low_sort !== '' ? this.state.high_low_sort : false
        }
        // console.log('tabfilters', getFilterforRequest(filters))
        let productsRequest = await getproducts({ count, activePage, ...tabfilters, ...getFilterforRequest(filters), ...sortingOrdering });
        let { success, data, user_id } = productsRequest;
        if (success) {
            user_idAG = user_id;
            let { rows, count: totalRecords } = data;
            // console.log('rows', rows);
            let paginationInformation = getpaginationInfo(totalRecords, count);
            paginationProps = { ...paginationProps, ...paginationInformation };
            let extractRowData = extractValuesfromRequest(rows, user_id);
            // tabs = changeProductListTabs(selectedTab, tabs, totalRecords)
            this.state.rawData = rows;
            // console.log('extractRowData', extractRowData)
            this.setState({ rowsAG: [...extractRowData], paginationProps, user_idAG, tabs });
            this.grid_loader = false;
            this.updateState();
        }
        // this.toggleOverLay(false);
    }

    onPaginationChange(paginationProps) {
        this.setState({ paginationProps }, () => { this.getProductsNew(); });
    }

    getSelectedRows(selectedRows) {
        this.setState({ selectedRows }, () => {
            // console.log(this.state.selectedRows);
        });
    }

    all_Selected() {
        if (this.state.All_Selected) {
            this.state.columns[0]['name'] = (<Checkbox id={"all"}
                checked={true}
                onChange={this.allSelector.bind(this, 'all_selector')} />)
        } else {
            this.state.columns[0]['name'] = (<Checkbox id={"all"}
                checked={false}
                onChange={this.allSelector.bind(this, 'all_selector')} />)
        }
        this.updateState();
    }
    updateState() {
        const state = this.state;
        this.setState(state);
    }
    allSelector(field, value) {
        if (value) {
            this.state.columns[0]['name'] = (<Checkbox id={"all"}
                checked={true}
                onChange={this.allSelector.bind(this, 'all_selector')}

            />)
            this.state.rawData.map((e) => {
                this.state.checkbox[e['details']['source_product_id']] = e['listing_id'];
            })
            this.updateState();
            if (true || this.state.user_id == '1217' || this.state.user_id == '620') {
                this.setState({ rows: this.dataMappingNewConfig(this.state.rawData, false, "Products_grid") });
            } else {
                this.setState({ rows: this.dataMapping(this.state.rawData, false, "Products_grid") });
            }
            // this.setState({rows:this.dataMapping(this.state.rawData,false,"Products_grid")});
        } else {
            this.state.columns[0]['name'] = (<Checkbox id={"all"}
                checked={false}
                onChange={this.allSelector.bind(this, 'all_selector')} />)
            this.state.rawData.map((e) => {
                if (e.details.source_product_id in this.state.checkbox) {
                    delete this.state.checkbox[e.details.source_product_id];
                }

            })

            this.updateState();
            if (true || this.state.user_id == '1217' || this.state.user_id == '620') {
                this.setState({ rows: this.dataMappingNewConfig(this.state.rawData, false, "Products_grid") });
            } else {
                this.setState({ rows: this.dataMapping(this.state.rawData, false, "Products_grid") });
            }
            // if(Object.values(this.state.checkbox).length == 0){
            //     this.massActions = [];
            // }
        }

    }
    dataMappingNewConfig(data, loading = "false", whichOne) {

        if (whichOne == "Products_grid") {
            let source_product_id = [];
            return data.map((row, index) => {
                // console.log(row,index)
                let data = {};
                data['main_image'] = row["details"]['image_main'] === "" ?
                    <div title={"Image"}><Thumbnail size="extralarge" alt="Image" title={"Image"}
                        source={Notfound} /></div> :
                    <div title={"Image"}><Thumbnail size="extralarge" alt="Image" title={"Image"}
                        source={row["details"]['image_main']} /></div>
                data["check"] = <div title={"checkbox"}><Checkbox
                    checked={(this.state.checkbox.hasOwnProperty(row['details']['source_product_id'])) ? true : false}
                    label={row['details']['source_product_id']}
                    id={row['details']['source_product_id']}
                    onChange={this.handleChangeCheck}
                    labelHidden={true} /></div>;
                data['_id'] = row['_id'];
                data['sku'] = !isUndefined(row.variants) && !isUndefined(row.variants[0]) && !isUndefined(row.variants[0].sku) ? row.variants[0].sku + "..." : '...';
                data['ebay_item_id'] = !isUndefined(row['listing_id']) ? <div title={row['listing_id']} style={{
                    color: '#25B6CF',
                    textDecoration: 'underline'
                }}>{row['listing_id']}</div> :
                    <div title={'No data'} className="w-100 text-center"><Icon source="subtract" /></div>;
                data['ebay_profile'] = !isUndefined(row['profile_name']) ? row['profile_name'] : '';
                data['product_type'] = !isUndefined(row['details']['product_type']) && row['details']['product_type'] !== "" ? row['details']['product_type'] :
                    <div className="w-100 text-center"><Icon source="subtract" /></div>;
                data['quantity'] = this.getInventoryData(row);
                data['ebay_status'] = <div title={'Status'}>{this.getEbayStatusnewConfig(row)}</div>
                data['title'] = <div
                    title={row["details"]['title']}>{(row["details"]['title']).length > 30 ? (row["details"]['title']).slice(0, 20) + "...." : row["details"]['title']}</div>
                data['vendor'] = row['details']['vendor'];
                data['tags'] = !isUndefined(row['details']['tags']) ? row['details']['tags'].substring(0, 6) + '...' : <div title={'No data'} className="w-100 text-center"><Icon source="subtract" /></div>;
                return data;
            });
        }

    }
    getEbayStatusnewConfig(data) {
        let haserror = !isUndefined(data.has_error) ? data.has_error : false;
        // console.log(haserror)
        let temparr = [];
        let type = '';
        let Content = '';
        switch (data['status']) {
            case 'ended':
                type = 'info';
                Content = 'Ended';
                break;
            case 'not_uploaded':
                type = 'attention';
                Content = 'Not uploaded';
                break;
            case 'uploaded':
                type = 'success';
                Content = 'Uploaded';
                break;
            case 'error':
                type = 'warning';
                Content = <b style={{ color: '#0000aa', textDecoration: 'underline' }}>Error</b>;
                break;
        }
        temparr.push(
            <div className="row" style={{ whiteSpace: 'nowrap' }} key={data._id}>
                <div className="col-12 col-md-12">
                    <Stack vertical={true} spacing={"tight"}>
                        <Badge status={type}>{Content}{haserror && (['7704', '8553', '18906', '14048', '11977', '9560', '8349', '14950', '14921', '694'].indexOf(this.state.user_id) > -1) ? <Icon source={"alert"} color={"red"} /> : ''}</Badge>
                    </Stack>
                </div>
            </div>
        );

        return temparr;
    }

    getInventoryData(data) {
        let totalVariants = 0;
        let totalquantity = 0;
        if (!isUndefined(data.variants)) {
            if (Array.isArray(data.variants)) {
                data.variants.forEach((variants, index) => {
                    totalquantity += !isNaN(parseInt(variants.quantity)) ? parseInt(variants.quantity) : 0;
                });
            } else {
                Object.keys(data.variants).map((key) => {
                    totalquantity += !isNaN(parseInt(data.variants.quantity)) ? parseInt(data.variants[key].quantity) : 0;
                });
            }
            totalVariants = data.variants.length;
            let addonVarianttext = totalVariants > 1 ? " variants" : " variant";
            let varianttext = "for " + totalVariants + addonVarianttext;
            if (data.details.type === 'simple') {
                varianttext = '';
            }
            let text = totalquantity + " in stock " + varianttext;
            return text;

        }
        return '';
    }

    componentDidMount() {
        this.tabSelected(0);
        this.prepareFilters();

        this.getServiceCredits();
        this.getSideID();
        this.getProductsCount();
        this.getVendorProducttype();
        this.getCollections();

        document.title = 'Manage Shopify products on eBay Marketplace Integration App';
        document.description = 'Minimize your efforts to sell Shopify products on eBay with eBay Marketplace Integration App, which helps to easily list, sync & manage your products on eBay.';
        if (!document.title.includes(localStorage.getItem('shop_url'))) {
            document.title += !isUndefined(localStorage.getItem('shop_url')) ? " " + localStorage.getItem('shop_url') : "";
        }
        // this.getProfiles();
    }

    getProfiles = async () => {
        let profilesRequest = await getprofiles({ count: 25, activePage: 1, getAllProfiles: true })
        console.log('profilesRequest', profilesRequest)
    }

    tabSelected(tabs) {
        let tabfilters = {};
        let { paginationProps } = this.state;
        paginationProps['pageSizeOptions'] = pageSizeOptionProducts;
        paginationProps['activePage'] = 1;
        paginationProps['pageSize'] = pageSizeOptionProducts[0];
        paginationProps['pages'] = 0;
        paginationProps['totalrecords'] = 0;
        let tabselected = productlistTabs.filter((tabOrder, tabIndex) => tabIndex === tabs);
        if (tabselected.length) {
            tabselected = tabselected[0]['type'];
            tabfilters = { ...getTabSelectedFilter(tabselected) };
        }
        this.setState({ selectedTab: tabs, tabfilters, selectedRows: [], paginationProps }, () => {
            // console.log('selectedTab', this.state.selectedTab, this.state.selectedRows)
            // this.getProducts();
            let { selectedTab } = this.state;
            switch (selectedTab) {
                case 2:
                    this.massActions.forEach((value, index) => {
                        if (value.label !== 'Relist on eBay' && value.label !== 'End from eBay' /*value.label === 'Upload and revise on eBay' || value.label === 'Update on eBay' || value.label === 'Upload on eBay'*/) {
                            this.massActions[index].disabled = false;
                        } else {
                            this.massActions[index].disabled = true;
                        }
                    });
                    break;
                case 3:
                    this.massActions.forEach((value, index) => {
                        if (value.label !== 'End from eBay' /*value.label === 'Relist on eBay'*/ /*|| value.label === 'Upload and revise on eBay' */) {
                            this.massActions[index].disabled = false;
                        } else {
                            this.massActions[index].disabled = true;
                        }
                    });
                    break;
                case 4:
                    this.massActions.forEach((value, index) => {
                        if (value.label !== 'Relist on eBay' && value.label !== 'End from eBay' /*value.label === 'Upload and revise on eBay' || value.label === 'Sync details' || value.label === 'Sync inventory'*/) {
                            this.massActions[index].disabled = false;
                        } else {
                            this.massActions[index].disabled = true;
                        }
                    });
                    break;
                default:
                    this.massActions.forEach((value, index) => {
                        if (value.label === 'Relist on eBay') {
                            this.massActions[index].disabled = true;
                        } else {
                            this.massActions[index].disabled = false;
                        }
                    });

            }
            this.getProductsNew();
        });
    }

    getSideID() {
        requests.getRequest('ebayV1/get/siteId').then(data => {
            if (data.success) {
                this.state.site_id = !isUndefined(data.data.site_id) ? data.data.site_id : '';
                // this.state.site_id ='MOTORS';
            }
            this.setState(this.state, () => {
                // console.log(this.state.site_id)
            });
        });

    }

    getServiceCredits() {
        requests.getRequest('frontend/app/getServiceCredits', { service_code: 'ebay_uploader' }, false, true)
            .then(response => {
                if (response.success) {

                    let productObj = {
                        available: response.data.available_credits,
                        total: response.data.available_credits + response.data.total_used_credits,
                        percent: ((response.data.available_credits) / (response.data.available_credits + response.data.total_used_credits)) * 100
                    };
                    this.state.credits_info.products = Object.assign({}, productObj);
                }
                this.setState(this.state, () => {
                    // console.log(this.state.credits_info)
                });
            });
    }

    async getProductsCount() {
        let { success, data } = await requests.getRequest('ebayV1/get/getTotalProductsCount');
        if (success) {
            let { count } = data;
            this.setState({ total_product_count: count }, () => {
                // console.log(this.state.total_product_count)
            });
        }
    }


    getVendorProducttype() {
        requests.getRequest('shopify/product/getVendorProductTypeProducts').then(data => {
            if (data.success) {

                this.setState({
                    product_type_options: this.prepareOptions(data.data.product_type),
                    vendor_options: this.prepareOptions(data.data.vendor)
                }, () => {
                    // console.log(this.state.product_type_options)
                });

            }
        })
    }

    prepareOptions(data) {
        let tempOptions = [];
        data.forEach((value, index) => {
            if (value !== '') {
                tempOptions.push(
                    { label: value, value: value }
                )
            }
        });
        return tempOptions;
    }


    getCollections() {
        requests
            .getRequest("ebayV1/get/getSourceAttributes", {
                marketplace: 'shopify'
            })
            .then(data => {
                if (data.success) {
                    data.data.forEach(option => {
                        if (option.code === 'collections') {
                            let dictioned_options = this.dictionedData(option.options);
                            this.setState({ collection_options: dictioned_options }, () => {
                                // console.log(this.state.collection_options)
                            });
                        }
                    })
                }
            });
    }

    dictionedData(data) {
        let Obj = {};
        data.forEach((option, index) => {
            Obj[option.label] = index;
        });
        let Ordered_Array = [];
        Object.keys(Obj).sort().forEach(key => {
            data[Obj[key]]['label'] = data[Obj[key]]['label'] + "-" + data[Obj[key]]['value']
            Ordered_Array.push(data[Obj[key]]);
        });
        return Ordered_Array;
    }

    prepareFilterObject(coloumn, index) {
        let filterObtained = '';
        switch (coloumn) {
            case 'type':
            case 'title':
            case 'long_description':
            case 'vendor':
            case 'tags':
            case 'source_product_id':
                filterObtained =
                    (index === undefined) ?
                        'filter[details.' + coloumn + ']'
                        : 'filter[details.' + coloumn + '][' + index + ']';
                break;
            case 'sku':
            case 'price':
            case 'weight':
            case 'weight_unit':
            case 'main_image':
            case 'quantity':
                filterObtained =
                    (index === undefined) ?
                        'filter[variants.' + coloumn + ']'
                        : 'filter[variants.' + coloumn + '][' + index + ']';
                break;
            case 'ebay_item_id':
                filterObtained = (index === undefined) ? 'filter[listing_id]' : 'filter[listing_id][' + index + ']';
                break;
            case 'ebay_profile':
                filterObtained = (index === undefined) ? 'filter[profile_name]' : 'filter[profile_name][' + index + ']';
                break;
            case 'product_type':
                filterObtained = (index === undefined) ? 'filter[details.' + coloumn + ']' : 'filter[details.' + coloumn + '][' + index + ']';
                break;
        }
        console.log('filterObtained', filterObtained);
        return filterObtained;
    }

    filterData(componentFilters) {
        // console.log('object', componentFilters)
        let { filtersProps } = this.state;
        filtersProps['filters'] = [...componentFilters];
        this.props.filterUpdated([...componentFilters]);
        this.setState({ filtersProps }, () => {
            this.getProductsNew();
        });
    }

    ListingIdShowModal() {
        return (
            <Modal
                open={this.state.showListingRedirectModal}
                onClose={() => {
                    this.state.showListingRedirectModal = false;
                    this.state.ListingRedirectId = '';
                    this.state.ListingRedirectUrl = '';
                    this.setState(this.state);
                }}
        /*primaryAction={{content:'Redirect', onAction:()=>{
                    window.open(this.state.ListingRedirectUrl,'_blank');
                    }}}*/>
                <Modal.Section>
                    <Stack vertical={true} alignment={"center"}>
                        <DisplayText element={"p"} size={"small"}>
                            View product on eBay?
                        </DisplayText>
                        <Button primary={true} onClick={() => {
                            window.open(this.state.ListingRedirectUrl, '_blank');
                            this.state.showListingRedirectModal = false;
                            this.state.ListingRedirectId = '';
                            this.state.ListingRedirectUrl = '';
                            this.setState(this.state);
                        }}>Yes</Button>
                    </Stack>
                </Modal.Section>
            </Modal>
        );
    }


    prepareStatusResponse(FullResponse, temparr = []) {
        Object.keys(FullResponse).map(key => {
            if (key.includes('SeverityCode')) {
                let keySplit = key.split('.');
                let indexOfSeverityCode = keySplit.indexOf('SeverityCode');
                let indexOfError = indexOfSeverityCode - 1;
                keySplit[indexOfSeverityCode] = 'LongMessage';
                let LongMessageKey = keySplit.join('.');
                let typeOfError = FullResponse[key];
                let Message = FullResponse[LongMessageKey];

                switch (typeOfError) {
                    case 'Error':
                        temparr.push(
                            <Banner title={'Error'} status="critical" key={indexOfError}>
                                {Message}
                            </Banner>
                        );
                        break;
                    case 'Warning':
                        temparr.push(
                            <Banner title={'Warning'} status={"warning"} key={indexOfError}>
                                {Message}
                            </Banner>
                        );
                        break;
                    default:
                        temparr.push(
                            <Banner status={"critical"} key={indexOfError}>
                                {Message}
                            </Banner>
                        );
                }
            }
            if (!isNaN(key)) {
                console.log('FullResponse[key]', FullResponse[key]);
                temparr.push(
                    <Banner status={"critical"} key={'title_error_key'}>
                        {FullResponse[key]}
                    </Banner>
                );
            }
        });

        return temparr;
    }

    prepareStatusData(data) {
        let temparr = [];
        if (!isUndefined(data.full_response) && Object.keys(data.full_response).length > 0) {
            let FullResponse = Object.assign({}, flatten(data.full_response));
        
            if (FullResponse.hasOwnProperty('Message')) {
                temparr.push(
                    <Banner title={'Error'} status="critical" key={'htmlError'}>
                        <p dangerouslySetInnerHTML={{ __html: FullResponse.Message }} />
                    </Banner>
                );
            }
            temparr = this.prepareStatusResponse(FullResponse, temparr);
        }

        if (temparr.length === 0) {
            if (!isUndefined(data.report) && Object.keys(data.report).length > 0) {
                let reportResponse = Object.assign({}, flatten(data.report));
                temparr = this.prepareStatusResponse(reportResponse, temparr);
            }
        }
        if (!isUndefined(temparr.length) && temparr.length > 0) {
            this.state.statusShowData = temparr;
            this.state.statusModalTitle = !isUndefined(data['title']) ?
                <p>{data['title']} <sub>(eBay response)</sub></p> : 'Product status'
            this.state.statusShowModal = true;
            this.setState(this.state);
        }
    }

    StatusShowModal() {
        return (
            <Modal
                title={this.state.statusModalTitle}
                open={this.state.statusShowModal}
                onClose={() => {
                    this.state.statusShowModal = false;
                    this.state.statusModalTitle = "";
                    this.setState(this.state);
                }}
            >
                <Modal.Section>
                    <Card actions={[{
                        content: <React.Fragment>
                            <b style={{ color: '#0000aa', textDecoration: 'underline' }}>Solution</b>
                        </React.Fragment>, onAction: this.redirect.bind(this, '/panel/help')
                    }]}>
                        <Card.Section>
                            {this.state.statusShowData}
                        </Card.Section>
                    </Card>
                </Modal.Section>
            </Modal>
        );
    }

    cellClickedEvent(colDef, data, rowIdx) {
        // console.log('colDef', colDef, 'data', data, 'rowIdx', rowIdx);
        let { field } = colDef;
        switch (field) {
            // case "listing_id":// for ebay item id (at index 5)
            //     requests.getRequest('ebayV1/get/ebayProductData', { listing_id: this.state.rawData[rowIdx].listing_id }).then(data1 => {
            //         if (data1.success) {
            //             // window.open(data1.data.ListingDetails.ViewItemURL,'_blank');
            //             this.state.ListingRedirectId = this.state.rawData[rowIdx].listing_id;
            //             this.state.ListingRedirectUrl = data1.data.ListingDetails.ViewItemURL;
            //             this.state.showListingRedirectModal = true;
            //             this.setState(this.state);
            //         }
            //     })
            //     break;
            case 'ebay_status':
            // requests.getRequest('ebayV1/get/failedProducts', { product_id: this.state.rawData[rowIdx]._id }).then(data => {
            //     if (data.success) {
            //         this.prepareStatusData(data.data);
            //     }
            // });
            // break;
            default:
                // let tempObjtitle = { id: this.state.rawData[rowIdx].details.source_product_id }
                // let messagetitle = cryptr.encrypt(JSON.stringify(tempObjtitle));
                // this.redirect('/panel/products/view?message=' + messagetitle);
                break;
        }
        // console.log('Cell Clicked', field);
        // console.log('Cell Clicked', data);
    }

    async onSelectedAction(action) {
        console.log(action);
    }

    getGridApi(api) {
        gridApi = api;
    }


    InitiateBulkaction(type) {
        let action_type = '';
        let text = '';
        switch (type) {
            case 'bulk_inventory':
                action_type = type;
                text = 'Sync inventory';
                break;
            case 'bulk_price':
                action_type = type;
                text = 'Sync Price';
                break;
            case 'bulk_sync_details':
                action_type = type;
                text = 'Sync details';
                break;
            case 'import_match_ebay':
                action_type = type;
                text = 'Import and match products from eBay';
                break;
            case 'import_collection':
                action_type = type;
                text = 'Import collection from Shopify';
                break;
            case 'import_meta':
                action_type = type;
                text = 'Import meta fields from Shopify';
                break;
            case 'only_upload':
                action_type = type;
                text = 'This action will only upload product(s) that already have profile assigned to them, Do you want to proceed ?';
                break;
        }
        this.state.bulkAction.text = text;
        this.state.bulkAction.type = action_type;
        this.state.bulkAction.modal = true;
        this.setState(this.state);
    }


    bulkInventorySync() {
        let tempObj = {};
        if (this.state.bulk_action_marketplace !== '') {
            tempObj['sync_to'] = this.state.bulk_action_marketplace;
        }
        requests.getRequest('ebayV1/upload/bulkSyncInventory', tempObj).then(data => {
            if (data.success) {
                if (data.code === 'syncing_process_started') {
                    notify.success(data.message);
                    this.redirect('/panel/activities');
                }
            } else {
                notify.error(data.message)

            }
            this.setState({ bulk_action_marketplace: '' });
        })
    }

    bulkPriceSync() {
        let tempObj = {};
        if (this.state.bulk_action_marketplace !== '') {
            tempObj['sync_to'] = this.state.bulk_action_marketplace;
        }
        requests.getRequest('ebayV1/upload/bulkSyncPrice', tempObj).then(data => {
            if (data.success) {
                notify.success(data.message);
                this.redirect('/panel/activities');
            } else {
                notify.error(data.message);
            }
            this.setState({ bulk_action_marketplace: '' });
        })
    }

    InitiateBulkSyncfromeBay() {
        requests.getRequest('ebayV1/import/syncProductFromeBay').then(data => {
            if (data.success) {
                if (data.code === 'ebay_sync_product_started') {
                    notify.success(data.message);
                    this.redirect('/panel/activities');
                }
            } else {
                notify.error(data.message)
            }
        })
    }

    InitiateimportfromCollection() {

        requests.getRequest('shopify/import/importCollectionsProducts').then(data => {
            if (data.success) {

                notify.success(data.message);
                this.redirect('/panel/activities');

            } else {
                notify.error(data.message)
            }
        })
    }

    InitiateBulkSyncwithShopify() {
        this.state.syncAllwithShopify = true;
        this.setState(this.state);
    }

    Initiatemetaimport() {
        requests.getRequest('shopify/import/importMetafieldsAllProductsAll').then(data => {
            if (data.success) {

                notify.success(data.message);
                this.redirect('/panel/activities');

            } else {
                notify.error(data.message)
            }
        })
    }

    async intitateOnlyUpload() {
        let { success, message } = await requests.getRequest('ebayV1/upload/onlyMassUploadProducts');
        if (success) notify.success(message);
        else notify.error(message);
    }

    confirmBulkAction() {
        let type = this.state.bulkAction.type;
        switch (type) {
            case 'bulk_inventory':
                this.bulkInventorySync();
                break;
            case 'bulk_price':
                this.bulkPriceSync();
                break;
            case 'bulk_sync_details':
                this.InitiateBulkSyncwithShopify();
                break;
            case 'import_match_ebay':
                this.InitiateBulkSyncfromeBay();
                break;
            case 'import_collection':
                this.InitiateimportfromCollection();
                break;
            case 'import_meta':
                this.Initiatemetaimport();
                break;
            case 'only_upload':
                this.intitateOnlyUpload();
                break;
        }
        this.state.bulkAction.modal = false;
        this.state.bulkAction.text = '';
        this.state.bulkAction.type = '';
        this.setState(this.state);

    }

    handleImportChange(key, value) {
        this.state.importProductsDetails[key] = value;
        if (key === 'source') {
            this.state.importerShopLists = [];
            this.state.importProductsDetails.shop = '';
            this.state.importProductsDetails.shop_id = '';
            for (let i = 0; i < this.state.importServicesList.length; i++) {
                if (this.state.importServicesList[i].value === value) {
                    for (let j = 0; j < this.state.importServicesList[i].shops.length; j++) {
                        this.state.importerShopLists.push({
                            label: this.state.importServicesList[i].shops[j].shop_url,
                            value: this.state.importServicesList[i].shops[j].shop_url,
                            shop_id: this.state.importServicesList[i].shops[j].id
                        });
                    }
                    break;
                }
            }
            if (this.state.importerShopLists.length > 0) {
                this.state.importProductsDetails.shop = this.state.importerShopLists[0].value;
                this.state.importProductsDetails.shop_id = this.state.importerShopLists[0].shop_id;
            }
        } else if (key === 'shop') {
            for (let i = 0; i < this.state.importerShopLists.length; i++) {
                if (this.state.importerShopLists[i].value === value) {
                    this.state.importProductsDetails.shop_id = this.state.importerShopLists[i].shop_id;
                    break;
                }
            }
        }
        this.updateState();
    }

    openvideoModal(id) {
        this.video.Modal = true;
        this.video.id = id;
        this.setState(this.state);
    }

    exportCSV() {
        requests.postRequest("connector/product/exportProductCSV", { marketplace: 'shopify' }).then(data => {
            if (data.success) {
                this.redirect('/panel/activities');
            } else {
                notify.error(data.message);
            }
        });
    }

    exportProductModal() {
        return (
            <Modal
                open={this.state.exportProductDataCsv}
                onClose={() => {
                    this.state.exportProductDataCsv = false;
                    this.updateState();
                }}
                title="Product Export"
                primaryAction={{
                    content: 'Yes',
                    onAction: () => {
                        this.exportCSV();
                        this.state.exportProductDataCsv = false;
                        this.updateState();
                    },
                }}
                secondaryActions={[
                    {
                        content: 'No',
                        onAction: () => {
                            this.state.exportProductDataCsv = false;
                            this.updateState()
                        }
                    },
                ]}
            >
                <Modal.Section>
                    <TextContainer>
                        <div className="row text-center">
                            <div className="col-12 col-md-12">
                                <p style={{ fontSize: "1em" }}>
                                    Are you sure, You want to Export product's data to CSV?
                                </p>
                            </div>
                        </div>
                    </TextContainer>
                </Modal.Section>
            </Modal>
        );
    }

    redirect(url) {
        this.props.history.push(url);
    }

    importProducts() {

        // let filter = this.getFilters();
        requests.postRequest('connector/product/import',
            {
                marketplace: this.state.importProductsDetails.source,
                shop: this.state.importProductsDetails.shop,
                shop_id: this.state.importProductsDetails.shop_id,
                product_status: this.state.product_status[0],
                // filter: filter,
                import_and_replace: this.state.import_and_replace,
            })
            .then(data => {
                this.state.showImportProducts = false;
                this.updateState();
                if (data.success === true) {
                    if (data.code === 'product_import_started') {
                        notify.info('Import process started. Check progress in activities section.');
                        setTimeout(() => {
                            this.redirect('/panel/activities');
                        }, 500);
                    } else {
                        notify.success(data.message);
                    }
                } else {
                    notify.error(data.message);
                }
            });

    }

    renderImportProductsModal() {
        return (
            <div>
                <Modal
                    open={this.state.showImportProducts}
                    onClose={() => {
                        this.state.showImportProducts = false;
                        this.state.product_status = ['published']
                        this.updateState();
                    }}
                    title="Import Products"
                /* primaryAction={{disabled:this.state.importProductsDetails.source === '',content:'Import Products',
                               onAction: this.importProducts.bind(this)
      
                           }}*/
                >
                    <Modal.Section>
                        <Stack vertical={true} distribution={"fill"}>
                            <Banner status={"info"}
                                title=" You are about to import product's from Shopify, Are you sure ?" />
                            <Button disabled={this.state.importProductsDetails.source === ''}
                                onClick={this.importProducts.bind(this)} primary>
                                Yes
                            </Button>
                        </Stack>
                    </Modal.Section>
                </Modal>
            </div>
        );
    }

    handleChangeSyncfields(key, data) {
        switch (key) {
            case 'details':
                this.state.sync_fields.details = data.slice(0);
                break;
            case 'variants':
                this.state.sync_fields.variants = data.slice(0);
                break;
        }
        this.setState(this.state);
    }

    handleChangeSyncall(key) {
        let tempDetails = [];
        let tempvariants = [];
        let selectedvariantsSync = [];
        let selecteddetailsSync = [];

        if (key) {
            Syncfieldsvariants.forEach((variantoption, index) => {
                selectedvariantsSync.push(variantoption.value);
                variantoption.disabled = true
                tempvariants.push(
                    variantoption
                )
            });
            Syncfieldsdetails.forEach((detailsoption, index) => {
                selecteddetailsSync.push(detailsoption.value);
                detailsoption.disabled = true
                tempDetails.push(
                    detailsoption
                )
            });

        } else {
            Syncfieldsvariants.forEach((variantoption, index) => {
                variantoption.disabled = false
                tempvariants.push(
                    variantoption
                )
            });

            Syncfieldsdetails.forEach((detailsoption, index) => {
                detailsoption.disabled = false
                tempDetails.push(
                    detailsoption
                )
            });
        }
        Syncfieldsdetails = tempDetails.slice(0);
        Syncfieldsvariants = tempvariants.slice(0);
        this.state.sync_fields.details = selecteddetailsSync.slice(0);
        this.state.sync_fields.variants = selectedvariantsSync.slice(0);
        this.state.sync_fields.all = key;
        this.setState(this.state);
    }

    getSyncfieldsCompo() {
        let temparr = [];
        temparr.push(
            <ChoiceList
                key={'details-syncfields'}
                allowMultiple
                title={''}
                choices={Syncfieldsdetails}
                selected={this.state.sync_fields.details}
                onChange={this.handleChangeSyncfields.bind(this, 'details')}
            />
        );
        temparr.push(
            <ChoiceList
                key={'variants-syncfields'}
                allowMultiple
                title={''}
                choices={Syncfieldsvariants}
                selected={this.state.sync_fields.variants}
                onChange={this.handleChangeSyncfields.bind(this, 'variants')}
            />
        );
        return <Card title={'Kindly select the fields you want to sync'}>
            <Card.Section>
                <FormLayout>
                    <Checkbox
                        checked={this.state.sync_fields.all}
                        label="Sync all fields"
                        onChange={this.handleChangeSyncall.bind(this)}
                    />
                    <FormLayout.Group condensed>{temparr}</FormLayout.Group>
                </FormLayout>
            </Card.Section>
        </Card>;
    }

    closebulksyncallProductModal() {
        this.state.sync_fields = {
            all: false,
            details: [],
            variants: [],
        };
        // this.state.topublishRow = {};
        this.state.syncAllwithShopify = false;
        const state = this.state;
        this.setState(state);
        this.handleChangeSyncall(false);
    }

    BulkSyncwithShopify() {
        let tempObj = {};
        if (!this.state.sync_fields.all) {
            tempObj['sync_fields'] = this.state.sync_fields;
        }
        ;
        if (this.state.bulk_action_marketplace !== '') {
            tempObj['sync_to'] = this.state.bulk_action_marketplace;
        }
        requests.postRequest('ebayV1/upload/bulkSyncWithShopify', tempObj).then(data => {
            if (data.success) {
                if (data.code === 'syncing_process_started') {
                    notify.success(data.message);
                    this.redirect('/panel/activities');
                }
            } else {
                notify.error(data.message)
            }
            this.setState({ bulk_action_marketplace: '' });
        });
        this.closebulksyncallProductModal();
    }

    syncAllProductModal() {
        return (
            <Modal
                open={this.state.syncAllwithShopify}
                onClose={() => {
                    this.closebulksyncallProductModal();
                }}
            >
                <Modal.Section>
                    <div className="row p-5">
                        <div className="col-12 text-center p-1">
                            <h2 className='font-weight-bold'>You are about to perform bulk sync for all products</h2>
                        </div>
                        <div className="col-12 mt-3">

                            {this.getSyncfieldsCompo()}

                        </div>
                        <div className="col-12 text-center pt-5">
                            <Button
                                disabled={this.state.sync_fields.variants.length === 0 && this.state.sync_fields.details.length === 0}
                                onClick={() => {
                                    this.BulkSyncwithShopify()
                                }} primary>
                                Yes
                            </Button>
                        </div>
                    </div>
                </Modal.Section>
            </Modal>
        );
    }


    handleUploadChange(key, value) {
        switch (key) {
            case 'selected_profile':
                if (value === 'custom_profile') {
                    if (this.state.uploadProductDetails.source === '' ||
                        this.state.uploadProductDetails.target === '') {
                        notify.info('Please choose product import source and product upload target first');
                    } else {
                        this.getMatchingProfiles();
                        this.state.uploadProductDetails.profile_type = 'custom';
                        this.state.uploadProductDetails[key] = '';
                    }
                } else {
                    this.state.uploadProductDetails.profile_type = '';
                    this.state.uploadProductDetails[key] = value;
                }
                break;
            case 'source':
                this.state.importerShopLists = [];
                this.state.uploadProductDetails.source = value;
                this.state.uploadProductDetails.profile_type = '';
                this.state.uploadProductDetails.selected_profile = 'default_profile';
                this.state.uploadProductDetails.source_shop = '';
                this.state.uploadProductDetails.source_shop_id = '';
                for (let i = 0; i < this.state.importServicesList.length; i++) {
                    if (this.state.importServicesList[i].value === value) {
                        for (let j = 0; j < this.state.importServicesList[i].shops.length; j++) {
                            this.state.importerShopLists.push({
                                label: this.state.importServicesList[i].shops[j].shop_url,
                                value: this.state.importServicesList[i].shops[j].shop_url,
                                shop_id: this.state.importServicesList[i].shops[j].id
                            });
                        }
                        break;
                    }
                }
                if (this.state.importerShopLists.length > 0) {
                    this.state.uploadProductDetails.source_shop = this.state.importerShopLists[0].value;
                    this.state.uploadProductDetails.source_shop_id = this.state.importerShopLists[0].shop_id;
                }
                break;
            case 'target':
                this.state.uploaderShopLists = [];
                this.state.uploadProductDetails.target = value;
                this.state.uploadProductDetails.profile_type = '';
                this.state.uploadProductDetails.selected_profile = 'default_profile';
                this.state.uploadProductDetails.target_shop = '';
                this.state.uploadProductDetails.target_shop_id = '';
                for (let i = 0; i < this.state.uploadServicesList.length; i++) {
                    if (this.state.uploadServicesList[i].value === value) {
                        for (let j = 0; j < this.state.uploadServicesList[i].shops.length; j++) {
                            this.state.uploaderShopLists.push({
                                label: this.state.uploadServicesList[i].shops[j].site_id,
                                value: this.state.uploadServicesList[i].shops[j].site_id,
                                shop_id: this.state.uploadServicesList[i].shops[j].id
                            });
                        }
                        break;
                    }
                }
                if (this.state.uploaderShopLists.length > 0) {
                    this.state.uploadProductDetails.target_shop = this.state.uploaderShopLists[0].value;
                    this.state.uploadProductDetails.target_shop_id = this.state.uploaderShopLists[0].shop_id;
                }
                break;
            case 'source_shop':
                this.state.uploadProductDetails.profile_type = '';
                this.state.uploadProductDetails.selected_profile = 'default_profile';
                for (let i = 0; i < this.state.importerShopLists.length; i++) {
                    if (this.state.importerShopLists[i].value === value) {
                        this.state.uploadProductDetails.source_shop_id = this.state.importerShopLists[i].shop_id;
                        this.state.uploadProductDetails.source_shop = this.state.importerShopLists[i].value;
                        break;
                    }
                }
                break;
            case 'target_shop':
                this.state.uploadProductDetails.profile_type = '';
                this.state.uploadProductDetails.selected_profile = 'default_profile';
                for (let i = 0; i < this.state.uploaderShopLists.length; i++) {
                    if (this.state.uploaderShopLists[i].value === value) {
                        this.state.uploadProductDetails.target_shop_id = this.state.uploaderShopLists[i].shop_id;
                        this.state.uploadProductDetails.target_shop = this.state.uploaderShopLists[i].value;
                        break;
                    }
                }
                break;
        }
        this.updateState();
    }


    getMatchingProfiles() {
        this.modalskeleton = true;
        this.profilesList = [];
        const data = {
            source: this.state.uploadProductDetails.source,
            target: this.state.uploadProductDetails.target
        };
        if (this.state.uploadProductDetails.source_shop !== '' &&
            this.state.uploadProductDetails.source_shop !== null) {
            data['source_shop'] = this.state.uploadProductDetails.source_shop;
        }
        if (this.state.uploadProductDetails.target_shop !== '' &&
            this.state.uploadProductDetails.target_shop !== null) {
            data['target_shop'] = this.state.uploadProductDetails.target_shop;
        }
        requests.getRequest('connector/profile/getMatchingProfiles', data)
            .then(data => {
                if (data.success) {
                    this.profilesList.push({
                        label: 'Default Profile(Upload products with Default Settings)',
                        value: 'default_profile'
                    });
                    for (let i = 0; i < data.data.length; i++) {
                        this.profilesList.push({
                            label: data.data[i].name,
                            value: (data.data[i].id).toString()
                        });
                    }
                    this.modalskeleton = false;
                    this.updateState();
                } else {
                    notify.error(data.message);
                }
            });
    }

    handleProfileSelect(profile) {

        if (profile === 'default_profile') {
            this.handleUploadChange('selected_profile', profile);
        } else {
            this.state.uploadProductDetails.selected_profile = profile;
            this.updateState();
        }
    }

    renderUploadProductsModal() {
        return (
            <Modal
                open={this.state.showUploadProducts}
                onClose={() => {
                    this.state.showUploadProducts = false;
                    this.updateState();
                }}
                title="Upload All Products"
            >{(this.modalskeleton) ? <Skeleton case="businesspolicy" /> :
                <Modal.Section>
                    <Stack vertical={true}>

                        <Banner status="info">
                            <Label>You can create an <span style={{ color: "#0000FF", cursor: 'pointer' }}
                                onClick={() => {
                                    this.redirect('/panel/profiles/createprofile');
                                }}>Custom Profile</span> for products upload.
                                To know more
                                about Profile and Default Profile visit our <span style={{ color: "#0000FF" }}
                                    onClick={() => {
                                        this.redirect('/panel/help?faq=profile');
                                    }}>Help</span> section.
                            </Label>
                        </Banner>
                        {
                            this.profilesList.length > 0 &&
                            <Select
                                label="Select Profile"
                                options={this.profilesList}
                                placeholder="Custom Profile"
                                onChange={this.handleProfileSelect.bind(this)}
                                value={this.state.uploadProductDetails.selected_profile}
                            />
                        }
                        {
                            this.profilesList.length === 0 &&
                            <React.Fragment>
                                <Banner status="warning">
                                    <Label>No profiles
                                        for {capitalizeWord(this.state.uploadProductDetails.source)} and {capitalizeWord(this.state.uploadProductDetails.target)} integration</Label>
                                </Banner>
                                <Stack alignment={"center"} vertical={true}>
                                    <Button onClick={() => {
                                        this.redirect('/panel/profiling/create');
                                    }} primary>
                                        Create Profile
                                    </Button>
                                    <Button onClick={() => {
                                        this.state.uploadProductDetails.profile_type = '';
                                        this.state.uploadProductDetails.selected_profile = 'default_profile';
                                        this.updateState();
                                    }} primary>
                                        Select Default Profile
                                    </Button>
                                </Stack>
                            </React.Fragment>
                        }
                        <Stack alignment={"center"} vertical={true}>
                            <Button onClick={() => {
                                this.uploadProducts();
                            }}
                                disabled={!(this.state.uploadProductDetails.source !== '' &&
                                    this.state.uploadProductDetails.target !== '' &&
                                    this.state.uploadProductDetails.selected_profile !== '')}
                                primary>
                                Upload All Products
                            </Button>
                        </Stack>
                    </Stack>
                </Modal.Section>}
            </Modal>
        );
    }

    uploadProducts() {
        const data = Object.assign({}, this.state.uploadProductDetails);
        data['marketplace'] = data['target'];
        if (this.state.uploadProductDetails.target_shop_id !== '') {
            requests.postRequest('connector/product/upload', data)
                .then(data => {
                    this.state.showUploadProducts = false;
                    if (data.success) {
                        if (data.code === 'product_upload_started') {
                            notify.info('Upload process started. Check progress in activities section.');
                            setTimeout(() => {
                                this.redirect('/panel/activities');
                            }, 500);
                        } else {
                            notify.success(data.message);
                        }
                    } else {
                        notify.error(data.message);
                        if (data.code === 'link_your_account') {
                            setTimeout(() => {
                                this.redirect('/panel/accounts');
                            }, 1200);
                        }
                    }
                    this.updateState();
                });
        } else {
            notify.info('Your product upload limit has expired. Upgrade your plan');
        }
    }

    // utkarsh

    syncImagestoebay() {
        let { selectedIds } = this.state;
        console.log('selectedIds', selectedIds)
        let productIds = Object.keys(this.state.checkbox);
        requests.getRequest('ebayV1/upload/syncImageswithShopify', { product_ids: selectedIds }).then(data => {
            if (data.success) {
                notify.success(data.message);
                this.redirect('/panel/activities');
            } else {
                notify.error(data.message);
            }
        });
    }

    closesyncImagesofProduct() {
        this.state.syncImagesModal = false;
        const state = this.state;
        this.setState(state);
    }

    syncImagesModalStructure() {
        return (
            <Modal
                open={this.state.syncImagesModal}
                onClose={() => {
                    this.closesyncImagesofProduct();
                }}
                title="Sync images to eBay"
                primaryAction={{
                    content: 'Yes',
                    onAction: () => {
                        this.syncImagestoebay();
                    },
                }}
            >
                <Modal.Section>
                    <TextContainer>
                        <div className="row text-center">
                            <div className="col-12 col-md-12">
                                <p style={{ fontSize: "1em" }}>
                                    Are you sure, You want to sync Images to eBay ?
                                </p>
                            </div>
                        </div>
                    </TextContainer>
                </Modal.Section>
            </Modal>
        );
    }

    async incellElement(field, data) {
        var { basicDetails, profile_id } = data;
        switch (field) {
            case 'edit':
                let tempObjtitle = { id: basicDetails['row']['details']['source_product_id'] };
                let messagetitle = cryptr.encrypt(JSON.stringify(tempObjtitle));
                this.redirect('/panel/products/view?message=' + messagetitle);
                break;
            case 'ebay_item_id':
                requests.getRequest('ebayV1/get/ebayProductData', { listing_id: basicDetails['row'].listing_id }).then(data1 => {
                    if (data1.success) {
                        this.state.ListingRedirectId = basicDetails['row'].listing_id;
                        this.state.ListingRedirectUrl = data1.data.ListingDetails.ViewItemURL;
                        this.state.showListingRedirectModal = true;
                        this.setState(this.state);
                    }
                })
                break;
            case "ebay_status":
                requests.getRequest('ebayV1/get/failedProducts', { product_id: data._id }).then(data => {
                    if (data.success) {
                        this.prepareStatusData(data.data);
                    }
                });
                break;
            case "view_profile":
                if (profile_id === 'default_profile') {
                    this.redirect('/panel/config');
                } else if (profile_id !== '') {
                    let tempObj = { id: profile_id }
                    let message = cryptr.encrypt(JSON.stringify(tempObj));
                    this.redirect('/panel/profiles/viewprofile?message=' + message);
                }
                break;
            default: break;
        }
    }

    SelectUploadUsingDiffProfile(value) {
        this.state.SelectUploadProfileData.selected_profile = value;
        this.setState(this.state);
    }

    renderUploadProductDetails() {
        let temparr = [];
        let { matchingProfile, profileData, selected_profile } = this.state.SelectUploadProfileData;

        let profileExistingonProducts = {};

        profileData.forEach((profile) => {
            let { profile_name } = profile;

            if (!profile_name) {
                profile_name = 'Default Profile';
            }
            if (profileExistingonProducts.hasOwnProperty(profile_name)) {
                profileExistingonProducts[profile_name] += 1;
            } else {
                profileExistingonProducts[profile_name] = 1;
            }
        });

        Object.keys(profileExistingonProducts).map(key => {


            temparr.push(
                <Banner status={'info'}>
                    <p><b>{profileExistingonProducts[key]}</b> product(s) belong to profile <b>{key}</b></p>
                </Banner>
            );
            return true;
        });
        temparr.push(
            <Stack.Item key={'notfalsekey'}>
                <FormLayout>
                    <Banner status={"info"}>
                        <p>If you want to <b>upload</b> the selected product(s) with a <b>different
                            profile</b> kindly select one <b>Profile</b> from below and <b>click on Upload</b>,Or to
                            continue with the already assigned one just click <b>Upload</b></p>
                    </Banner>
                    <Select
                        label={''}
                        options={matchingProfile}
                        placeholder={'Please select'}
                        value={selected_profile}
                        onChange={this.SelectUploadUsingDiffProfile.bind(this)}>
                    </Select>
                </FormLayout>
            </Stack.Item>
        );

        return temparr;

    }

    closeSelectandUpload() {
        let tempObj = {
            itemIdpresentCount: 0,
            listOfItemIds: []
        };
        this.state.selectandUpload = false;
        this.state.SelectUpload = Object.assign({}, tempObj);
        this.state.SelectUploadProfileData = {
            matchingProfile: [],
            profileData: [],
            selected_profile: ''
        };
        this.state.uploadUsingDiffprofile.id = '';
        this.state.uploadUsingDiffprofile.profile_name = '';
        this.state.uploadUsingDiffprofile.data_selected = false;
        this.state.uploadUsingDiffprofile.data = {};
        const state = this.state;
        this.setState(state);
    }

    selectAndUploadConfirm() {
        let tempObj = {};
        let { selected_profile } = this.state.SelectUploadProfileData;

        tempObj = {
            marketplace: 'ebay',
            source: 'shopify',
            source_shop_id: this.state.importServicesList[0].shops[0].id,
            target_shop_id: this.state.uploadServicesList[0].shops[0].id,
            selected_profile: selected_profile,
            product_ids: this.state.SelectUpload.listOfItemIds
        };

        requests.postRequest('ebayV1/upload/selectAndUploadProducts', tempObj).then(data => {
            if (data.success) {
                if (data.code === 'product_upload_started') {
                    notify.info(data.message);
                    this.redirect('/panel/activities');
                }
            } else {
                notify.error(data.message);
            }
        });
        this.closeSelectandUpload();
    }

    selectAndUploadModal() {
        return (
            <Modal
                open={this.state.selectandUpload}
                onClose={() => {
                    this.closeSelectandUpload();
                }}
                primaryAction={{
                    content: 'Upload',
                    onAction: this.selectAndUploadConfirm.bind(this),
                }}
            >
                <Modal.Section>

                    <Stack vertical={true}>
                        <DisplayText element={"h2"}><b>Among the selected products</b></DisplayText>
                        {
                            this.renderUploadProductDetails()
                        }
                    </Stack>
                </Modal.Section>
            </Modal>
        );
    }

    formulateUploadabledata(data) {

        let tempObjMatchingProfile = [];
        let { matching_profiles, product_profile_data } = data;
        matching_profiles.forEach(profile => {
            tempObjMatchingProfile.push({ label: profile['name'], value: profile['id'].toString() });
        });

        this.state.SelectUploadProfileData.matchingProfile = tempObjMatchingProfile.slice(0);

        this.state.SelectUploadProfileData.profileData = product_profile_data.slice(0);
        this.state.selectandUpload = true;
        const state = this.state;
        this.setState(state);

    }

    getUploadabledetails() {

        let tempObj = {
            product_ids: this.state.SelectUpload.listOfItemIds,
            source: 'shopify',
            target: 'ebay',
            target_shop: this.state.site_id
        }

        requests.postRequest('ebayV1/upload/getProductProfiles', tempObj).then(data => {
            if (data.success) {
                if (!isUndefined(data.data)) {
                    this.formulateUploadabledata(data.data);
                } else {
                    notify.error('Upload information missing');
                }
            } else {
                notify.error(data.message);
            }

        })
    }

    CalculateUploadable() {

        let temparr = this.state.selectedProductDetails.source_product_ids.slice(0);
        // this.state.products.forEach((Obj,index)=>{
        //     if(this.state.selectedIds.indexOf(Obj._id)>-1){
        //         if(!isUndefined(Obj.source_product_id)){
        //             temparr.push(Obj.source_product_id);
        //         }
        //     }
        // });
        this.state.SelectUpload.listOfItemIds = temparr.slice(0);
        this.state.SelectUpload.itemIdpresentCount = temparr.length;
        this.setState(this.state);

        this.getUploadabledetails()


    }

    setSelectandUpload() {

        this.CalculateUploadable();
        // this.state.selectandUpload=true;
        // const state = this.state;
        // this.setState(state);
    }

    opensyncImagesofProduct() {
        this.state.syncImagesModal = true;
        const state = this.state;
        this.setState(state);
    }

    CalculateUnpublishDetails() {

        let temparr = this.state.selectedProductDetails.listing_ids.slice(0);
        // this.state.products.forEach((Obj,index)=>{
        //     if(this.state.selectedIds.indexOf(Obj._id)>-1){
        //         if(Obj.listing_id!=='n/a'){
        //             temparr.push(Obj.listing_id);
        //         }
        //     }
        // });
        this.state.bulkUnpublish.listOfItemIds = temparr.slice(0);
        this.state.bulkUnpublish.itemIdpresentCount = temparr.length;
        this.setState(this.state);

    }

    setunPublishproduct(event, data) {
        // this.state.topublishRow=data;
        this.CalculateUnpublishDetails();
        this.state.publishProductData = true;
        const state = this.state;
        this.setState(state);
    }

    CalculateexportcsvDetails() {
        let temparr = this.state.selectedProductDetails.source_product_ids.slice(0);
        this.state.selectExportCSV.listOfItemIds = temparr.slice(0);
        this.state.selectExportCSV.itemIdpresentCount = temparr.length;
        this.setState(this.state);

    }

    setexportProducts(event, data) {
        this.CalculateexportcsvDetails();
        this.state.selectExportModal = true;
        const state = this.state;
        this.setState(state);
    }

    CalculateRelistDetails() {
        let temparr = this.state.selectedProductDetails.listing_ids.slice(0);
        // this.state.products.forEach((Obj,index)=>{
        //     if(this.state.selectedIds.indexOf(Obj._id)>-1){
        //         if(Obj.listing_id!=='n/a'){
        //             temparr.push(Obj.listing_id);
        //         }
        //     }
        // });
        this.state.bulkRelist.listOfItemIds = temparr.slice(0);
        this.state.bulkRelist.itemIdpresentCount = temparr.length;
        this.setState(this.state);
    }

    setbulkRelistproduct(event, data) {
        // this.state.topublishRow=data;
        this.CalculateRelistDetails();
        this.state.relistProductData = true;
        const state = this.state;
        this.setState(state);
    }

    closeRelistProductModal() {
        // this.state.topublishRow = {};
        this.state.bulkRelist = {
        itemIdpresentCount: 0,
        listOfItemIds: []
        };
        this.state.relistProductData = false;
        const state = this.state;
        this.setState(state);
    }

    relistProductconfirmed() {
        requests.postRequest('ebayV1/upload/massRelistItem', {'listing_ids': this.state.bulkRelist.listOfItemIds}).then(data => {
        if (data.success) {
            notify.success(data.message)
            if (data.code === "product_relisting_started") {
            this.redirect('/panel/activities');
            }
        } else {
            notify.error(data.message);
        }
        });

        this.closeRelistProductModal();
    }

    RelistProductModal() {
        return (
        <Modal
            open={this.state.relistProductData}
            onClose={() => {
            this.closeRelistProductModal();
            }}
        >
            <Modal.Section>
            <div className="row p-5">
                <div className="col-12 text-center">

                <h2>You have
                    selected {this.state.selectedIds.length} {this.state.selectedIds.length > 1 ? "Products" : "Product"}</h2>
                {this.state.bulkRelist.itemIdpresentCount !== this.state.selectedIds.length &&
                <h2>{this.state.bulkRelist.itemIdpresentCount === 0 ? "None " : this.state.bulkRelist.itemIdpresentCount} of
                    the
                    selected {this.state.selectedIds.length > 1 ? this.state.selectedIds.length : ''} {this.state.selectedIds.length > 1 ? "Products" : "Product"} Contains
                    eBay item id</h2>}
                {this.state.bulkRelist.itemIdpresentCount !== 0 ?
                    <h2>Do you want to relist them on eBay?</h2> :
                    <h2>Only products with eBay item id can be unpublished</h2>}
                </div>
                <div className="col-12 text-center pt-5">
                <Button
                    disabled={this.state.bulkRelist.itemIdpresentCount === 0}
                    onClick={() => {
                    this.relistProductconfirmed()
                    }} primary>
                    Yes
                </Button>
                </div>
            </div>
            </Modal.Section>
        </Modal>
        );
    }

    performMassAction = (action) => {
        // console.log('action', action);
        // console.log(this.state.selectedRows);
        let tmpSourceIds = [];
        let tempListingIds = [];
        let { selectedRows } = this.state;
        // for (var key in this.state.checkbox) {
        //     tmpSourceIds.push(key)
        //     this.state.selectedProductDetails.source_product_ids = tmpSourceIds;
        //     console.log('this.state.selectedProductDetails.source_product_ids ', this.state.selectedProductDetails.source_product_ids);
        //     this.updateState();
        // }
        selectedRows.forEach(row => {
            // console.log('row', row)
            let { listing_id, details } = row.basicDetails.row;
            let { source_product_id } = details;
            tmpSourceIds.push(source_product_id);
            tempListingIds.push(listing_id);
            this.state.selectedProductDetails.source_product_ids = tmpSourceIds;
            this.state.selectedProductDetails.listing_ids = tempListingIds;
            this.updateState();
        })
        // Object.values(this.state.checkbox).map(e => {
        //     if (e != undefined) {
        //         tempListingIds.push(e)
        //         this.state.selectedProductDetails.listing_ids = tempListingIds;
        //         console.log('this.state.selectedProductDetails.listing_ids ', this.state.selectedProductDetails.listing_ids);
        //         this.updateState();
        //     }
        // })

        this.setState({ selectedIds: tmpSourceIds }, () => {
            // console.log('selectedIds', this.state.selectedProductDetails)
            console.log('selectedIds', this.state.selectedIds)
            if (this.state.selectedIds.length > 0) {
                switch (action) {
                    case 'syncimages':
                        this.opensyncImagesofProduct();
                        break;
                    case 'unpublish':
                        this.setunPublishproduct();
                        break;
                    case 'relist':
                        this.setbulkRelistproduct();
                        break;
                    case 'syncshopify':
                        this.setsyncwithShopify();
                        break;
                    case 'Inventorysync':
                        this.setInventorysync();
                        break;
                    case 'upload':
                        this.setSelectandUpload();
                        break;
                    case 'exportcsv':
                        this.setexportProducts()
                        // this.getAllImporterServicesandgetAllUploaderServices();
                        break
                    // case 'only_update':
                    //     this.differentiateProducts('update');
                    //     break;
                    // case 'only_upload':
                    //     this.differentiateProducts('upload');
                    //     break;
                    default://console.log(action,this.state.selectedIds);
                        break;
                }
            } else {
                notify.info("No product is selected");
            }
        });
    };


    closebulkInventorysyncProductModal() {
        this.state.bulkInventorySync = {
            itemIdpresentCount: 0,
            listOfItemIds: []
        };
        // this.state.topublishRow = {};
        this.state.InventorySyncModal = false;
        const state = this.state;
        this.setState(state);
    }

    InventoryBulkSyncModal() {
        return (
            <Modal
                open={this.state.InventorySyncModal}
                onClose={() => {
                    this.closebulkInventorysyncProductModal();
                }}
                title="Sync Inventory"
                primaryAction={{
                    content: 'Yes',
                    onAction: () => {
                        this.inventorySync()
                    },
                }}
            >

                <Modal.Section>
                    <TextContainer>
                        {/* <div className="row p-5">
                            <div className="col-12 text-center"> */}
                        <div className="row text-center">
                            <div className="col-12 col-md-12">

                                <h2>You have
                                    selected {this.state.selectedIds.length} {this.state.selectedIds.length > 1 ? "Products" : "Product"}</h2>
                                {this.state.bulkInventorySync.itemIdpresentCount !== this.state.selectedIds.length &&
                                    <h2>{this.state.bulkInventorySync.itemIdpresentCount === 0 ? "None " : this.state.bulkInventorySync.itemIdpresentCount} of
                                        the
                                        selected {this.state.selectedIds.length > 1 ? this.state.selectedIds.length : ''} {this.state.selectedIds.length > 1 ? "Products" : "Product"} Contains
                                        product ID</h2>}
                                {this.state.bulkInventorySync.itemIdpresentCount !== 0 ? <h2>Do you want to
                                    sync {this.state.selectedIds.length > 1 ? "their" : "it's"} inventory?</h2> :
                                    <h2>Inventory of only products with product ID can be synced</h2>}
                            </div>
                        </div>
                        {/* <div className="col-12 text-center pt-5">
                                <Button
                                    disabled={this.state.bulkInventorySync.itemIdpresentCount === 0}
                                    onClick={() => {
                                        this.inventorySync()
                                    }} primary>
                                    Yes
                                </Button>
                            </div> */}
                        {/* </div> */}
                    </TextContainer>
                </Modal.Section>
            </Modal>
        );
    }

    inventorySync() {
        requests.postRequest('ebayV1/upload/inventorySync', { 'product_ids': this.state.bulkInventorySync.listOfItemIds }).then(data => {
            if (data.success) {
                notify.success(data.message)
                if (data.code === "syncing_process_started") {
                    this.redirect('/panel/activities');
                }
            } else {
                notify.error(data.message);
            }
        });

        this.closebulkInventorysyncProductModal();
    }

    CalculateInventorySyncWithDetails() {

        let temparr = this.state.selectedProductDetails.source_product_ids.slice(0);
        // this.state.products.forEach((Obj,index)=>{
        //     if(this.state.selectedIds.indexOf(Obj._id)>-1){
        //         if(!isUndefined(Obj.source_product_id)){
        //             temparr.push(Obj.source_product_id);
        //         }
        //     }
        // });
        this.state.bulkInventorySync.listOfItemIds = temparr.slice(0);
        this.state.bulkInventorySync.itemIdpresentCount = temparr.length;
        this.setState(this.state);

    }

    setInventorysync(event, data) {
        // this.state.topublishRow=data;
        this.CalculateInventorySyncWithDetails();
        this.state.InventorySyncModal = true;
        const state = this.state;
        this.setState(state);
    }

    setsyncwithShopify(event, data) {
        // this.state.topublishRow=data;
        this.CalculateSyncWithDetails();
        this.state.syncwithShopify = true;
        const state = this.state;
        this.setState(state);
    }

    CalculateSyncWithDetails() {

        let temparr = this.state.selectedProductDetails.source_product_ids.slice(0);
        ;
        // this.state.products.forEach((Obj,index)=>{
        //     if(this.state.selectedIds.indexOf(Obj._id)>-1){
        //         if(!isUndefined(Obj.source_product_id)){
        //             temparr.push(Obj.source_product_id);
        //         }
        //     }
        // });
        this.state.bulkSync.listOfItemIds = temparr.slice(0);
        this.state.bulkSync.itemIdpresentCount = temparr.length;
        this.setState(this.state);
    }

    syncBulkProductModal() {
        return (
            <Modal
                open={this.state.syncwithShopify}
                onClose={() => {
                    this.closebulksyncProductModal();
                }}
                title="Sync Details"
            // primaryAction={{
            //     content: 'Yes',
            //     onAction: () => {
            //         this.syncProductconfirmed()
            //     },
            // }}
            >
                <Modal.Section>
                    {/* <div className="row p-5">
                        <div className="col-12 text-center p-1"> */}

                    <div className="row text-center">
                        <div className="col-12 col-md-12">
                            <h2>You have
                                selected {this.state.bulkSync.listOfItemIds.length} {this.state.bulkSync.listOfItemIds.length > 1 ? "Products" : "Product"}</h2>
                            <h2>Do you want to sync them with Shopify?</h2>
                        </div>
                    </div>
                    <div className="col-12 mt-3">
                        {this.getSyncfieldsCompo()}
                    </div>
                    <div className="col-12 text-center pt-5">
                        <Button
                            // disabled={this.state.sync_fields.variants.length === 0 && this.state.sync_fields.details.length === 0}
                            onClick={() => {
                                this.syncProductconfirmed()
                            }} primary>
                            Yes
                        </Button>
                    </div>
                    {/* </div> */}
                </Modal.Section>
            </Modal>
        );
    }

    closebulksyncProductModal() {
        this.state.bulkSync = {
            itemIdpresentCount: 0,
            listOfItemIds: []
        };
        this.state.sync_fields = {
            all: false,
            details: [],
            variants: [],
        };
        // this.state.topublishRow = {};
        this.state.syncwithShopify = false;
        const state = this.state;
        this.setState(state);
        this.handleChangeSyncall(false);
    }

    getSyncfieldsCompo() {
        let temparr = [];
        temparr.push(
            <ChoiceList
                key={'details-syncfields'}
                allowMultiple
                title={''}
                choices={Syncfieldsdetails}
                selected={this.state.sync_fields.details}
                onChange={this.handleChangeSyncfields.bind(this, 'details')}
            />
        );
        temparr.push(
            <ChoiceList
                key={'variants-syncfields'}
                allowMultiple
                title={''}
                choices={Syncfieldsvariants}
                selected={this.state.sync_fields.variants}
                onChange={this.handleChangeSyncfields.bind(this, 'variants')}
            />
        );
        return <Card title={'Kindly select the fields you want to sync'}>
            <Card.Section>
                <FormLayout>
                    <Checkbox
                        checked={this.state.sync_fields.all}
                        label="Sync all fields"
                        onChange={this.handleChangeSyncall.bind(this)}
                    />
                    <FormLayout.Group condensed>{temparr}</FormLayout.Group>
                </FormLayout>
            </Card.Section>
        </Card>;
    }

    BulkSyncwithShopify() {
        let tempObj = {};
        if (!this.state.sync_fields.all) {
            tempObj['sync_fields'] = this.state.sync_fields;
        }
        ;
        if (this.state.bulk_action_marketplace !== '') {
            tempObj['sync_to'] = this.state.bulk_action_marketplace;
        }
        requests.postRequest('ebayV1/upload/bulkSyncWithShopify', tempObj).then(data => {
            if (data.success) {
                if (data.code === 'syncing_process_started') {
                    notify.success(data.message);
                    this.redirect('/panel/activities');
                }
            } else {
                notify.error(data.message)
            }
            this.setState({ bulk_action_marketplace: '' });
        });
        this.closebulksyncallProductModal();
    }

    closebulksyncallProductModal() {
        this.state.sync_fields = {
            all: false,
            details: [],
            variants: [],
        };
        // this.state.topublishRow = {};
        this.state.syncAllwithShopify = false;
        const state = this.state;
        this.setState(state);
        this.handleChangeSyncall(false);
    }

    syncProductconfirmed() {

        let tempObj = {
            product_ids: this.state.bulkSync.listOfItemIds,
        }
        // if (!this.state.sync_fields.all) {
        //     tempObj['sync_fields'] = this.state.sync_fields;
        // }

        requests.postRequest('ebayV1/upload/syncWithShopify', tempObj).then(data => {
            if (data.success) {
                notify.success(data.message)
                if (data.code === "syncing_process_started") {
                    this.redirect('/panel/activities');
                }
            } else {
                notify.error(data.message);
            }
        });

        this.closebulksyncProductModal();
    }

    closePublishProductModal() {
        // this.state.topublishRow = {};
        this.state.bulkUnpublish = {
            itemIdpresentCount: 0,
            listOfItemIds: []
        };
        this.state.publishProductData = false;
        const state = this.state;
        this.setState(state);
    }

    publishProductconfirmed() {
        requests.postRequest('ebayV1/upload/bulkUnpublish', {
            'listing_ids': this.state.bulkUnpublish.listOfItemIds,
            reason_end_listing: this.state.reason_end_listing
        }).then(data => {
            if (data.success) {
                notify.success(data.message)
                if (data.code === "unpublish_process_started") {
                    this.redirect('/panel/activities');
                }
            } else {
                notify.error(data.message);
            }
        });

        this.closePublishProductModal();
    }

    publishProductModal() {
        return (
            <Modal
                open={this.state.publishProductData}
                onClose={() => {
                    this.closePublishProductModal();
                }}
                title="End from eBay"
                primaryAction={{
                    content: 'Yes',
                    onAction: () => {
                        this.publishProductconfirmed()
                    },
                }}
            >
                <Modal.Section>
                    <Stack vertical={true} alignment={"center"} spacing={"loose"}>
                        <Stack.Item>
                            <Stack vertical={true} alignment={"center"} spacing={"loose"}>
                                <h2>You have
                                    selected {this.state.selectedIds.length} {this.state.selectedIds.length > 1 ? "Products" : "Product"}</h2>
                                {this.state.bulkUnpublish.itemIdpresentCount !== this.state.selectedIds.length &&
                                    <h2>{this.state.bulkUnpublish.itemIdpresentCount === 0 ? "None " : this.state.bulkUnpublish.itemIdpresentCount} of
                                        the
                                        selected {this.state.selectedIds.length > 1 ? this.state.selectedIds.length : ''} {this.state.selectedIds.length > 1 ? "Products" : "Product"} Contains
                                        eBay item id</h2>}
                                {this.state.bulkUnpublish.itemIdpresentCount !== 0 ?
                                    <h2>Do you want to end them from eBay?</h2> :
                                    <h2>Only products with eBay item id can be ended</h2>}
                            </Stack>

                        </Stack.Item>
                        {this.state.bulkUnpublish.itemIdpresentCount !== 0 &&
                            <Select
                                key={'Endreasonlisting-select'}
                                options={reason_end_listing}
                                label={'Please provide end reason listing'}
                                value={this.state.reason_end_listing}
                                onChange={(e) => {
                                    this.setState({ reason_end_listing: e })
                                }} />
                        }
                        {/* <Stack.Item>

                            <Button
                                disabled={this.state.bulkUnpublish.itemIdpresentCount === 0}
                                onClick={() => {
                                    this.publishProductconfirmed()
                                }} primary>
                                Yes
                            </Button>
                        </Stack.Item> */}
                    </Stack>

                </Modal.Section>
            </Modal>
        );
    }

    closeselectexportProductModal() {
        this.state.selectExportCSV = {
            itemIdpresentCount: 0,
            listOfItemIds: []
        };
        // this.state.topublishRow = {};
        this.state.selectExportModal = false;
        const state = this.state;
        this.setState(state);
    }

    exportselectedProducts() {
        requests.postRequest('ebayV1/app/selectandExportCSV', { 'product_ids': this.state.selectExportCSV.listOfItemIds }).then(data => {
            if (data.success) {
                notify.success(data.message);
                if (data.code === "export_started") {
                    this.redirect('/panel/activities');
                }
            } else {
                notify.error(data.message);
            }
            this.closeselectexportProductModal();
        });
    }

    selectAndExportCsvModal() {
        return (
            <Modal
                open={this.state.selectExportModal}
                onClose={() => {
                    this.closeselectexportProductModal();
                }}
                title="Export Details CSV"
                primaryAction={{
                    content: 'Yes',
                    onAction: () => {
                        this.exportselectedProducts()
                    },
                }}
            >
                <Modal.Section>
                    {/* <div className="row p-5">
                        <div className="col-12 text-center"> */}

                    <div className="row text-center">
                        <div className="col-12 col-md-12">
                            <h2>You have
                                selected {this.state.selectedIds.length} {this.state.selectedIds.length > 1 ? "Products" : "Product"}</h2>
                            <h2>Do you want to
                                export {this.state.selectedIds.length > 1 ? "their" : "it's"} details?</h2>
                        </div>
                    </div>
                    {/* <div className="col-12 text-center pt-5">
                            <Button
                                disabled={this.state.selectExportCSV.itemIdpresentCount === 0}
                                onClick={() => {
                                    this.exportselectedProducts()
                                }} primary>
                                Yes
                            </Button>
                        </div> */}
                    {/* </div> */}
                </Modal.Section>
            </Modal >
        );
    }

    render() {
        let { tabs, selectedTab,
            columnsAG, rowsAG, filtersProps, paginationProps, selectedRows, selectedActions, user_idAG
        } = this.state;
        // console.log('filtersProps', filtersProps)
        return (
            <Page title={'Products'}
                fullWidth={true}

                titleMetadata={<Stack vertical={false}><p style={{ cursor: 'pointer' }} onClick={() => {
                    window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=prodt', '_blank')
                }}><Badge status={"info"}><b style={{ color: '#0000aa', textDecoration: 'underline' }}>Need help?</b></Badge>
                </p>
                <p style={{ color: '#3B7DC4', textDecoration: 'underline', cursor: 'pointer' }}
                        onClick={this.openvideoModal.bind(this, '2pos_rypAVY')}><Badge status={"info"}><b
                            style={{ color: '#0000aa', textDecoration: 'underline' }}>Help Video?</b></Badge></p>
                <Badge status={"new"}>
                    {`${this.state.credits_info.products.available} / ${this.state.credits_info.products.total} product credits available`}
                    <Tooltip content="1 Product Credit means 1 product can be listed on eBay through the app">
                        <Icon source={QuestionMarkMinor} />
                    </Tooltip>
                </Badge>
                    {/* <p style={{ color: '#3B7DC4', textDecoration: 'underline', cursor: 'pointer' }}
                        onClick={this.openvideoModal.bind(this, 'vrtrw_fgrYo')}><Badge status={"info"}><b
                            style={{ color: '#0000aa', textDecoration: 'underline' }}>Help Video?</b></Badge></p> */}
                </Stack>}

                secondaryActions={user_idAG == 3429 || user_idAG == 7704 ? [{
                    content: 'Taxes', icon: TaxMajorMonotone, onAction: () => {
                        this.redirect('/panel/products/taxtables');
                    }
                }] : []}

                actionGroups={
                    this.state.total_product_count < 11000 ||
                        user_idAG == '3383' || user_idAG == '8554' ?
                        [
                            {
                                title: 'CSV actions',
                                actions: [
                                    {
                                        content: 'Export', icon: ExportMinor,
                                        onAction: () => {
                                            this.state.exportProductDataCsv = true;
                                            this.updateState();
                                        }
                                    },
                                    {
                                        content: 'Bulk update', icon: ImportMinor, onAction: () => {
                                            this.redirect('/panel/products/bulkupdate')
                                        }
                                    },
                                ],
                            },
                            {
                                title: 'Shopify actions',
                                actions: [
                                    {
                                        content: 'Import products', icon: ImportMinor, onAction: () => {
                                            this.state.importProductsDetails.source = '';
                                            this.state.importProductsDetails.shop = '';
                                            this.state.importProductsDetails.shop_id = '';
                                            this.handleImportChange('source', 'shopify');
                                            this.state.showImportProducts = true;
                                            this.getVendorProducttype();
                                            this.updateState();
                                        }
                                    },
                                    {
                                        content: 'Sync inventory', icon: RefreshMinor, onAction: () => {
                                            this.setState({ bulk_action_marketplace: 'shopify' }, () => {
                                                this.InitiateBulkaction('bulk_inventory');
                                            });

                                        }
                                    },

                                    {
                                        content: 'Sync details', icon: RefreshMinor, onAction: () => {
                                            this.setState({ bulk_action_marketplace: 'shopify' }, () => {
                                                this.InitiateBulkaction('bulk_sync_details')
                                            });
                                        }
                                    }
                                    ,
                                    {
                                        content: 'Import collection products', icon: ImportMinor, onAction: () => {
                                            this.setState({ bulk_action_marketplace: 'shopify' }, () => {
                                                this.InitiateBulkaction('import_collection')
                                            });
                                        }
                                    },

                                    {
                                        content: 'Import metafields of products', icon: ImportMinor, onAction: () => {
                                            this.setState({ bulk_action_marketplace: 'shopify' }, () => {
                                                this.InitiateBulkaction('import_meta')
                                            });
                                        }
                                    },

                                ],
                            },
                            {
                                title: 'eBay actions',
                                actions: user_idAG == '15553' ? [
                                    // {
                                    //     content: 'Sync inventory', icon: RefreshMinor, onAction: () => {
                                    //         this.setState({ bulk_action_marketplace: 'ebay' }, () => {
                                    //             this.InitiateBulkaction('bulk_inventory')
                                    //         });

                                    //     }
                                    // },
                                    // {
                                    //     content: 'Match from eBay',
                                    //     icon: ImportMinor,
                                    //     onAction: this.InitiateBulkaction.bind(this, 'import_match_ebay')
                                    // }

                                    {
                                        content: 'Upload and revise(All products)', icon: ExportMinor, onAction: () => {
                                            this.state.uploadProductDetails.source = '';
                                            this.state.uploadProductDetails.target = '';
                                            this.state.uploadProductDetails.selected_profile = 'default_profile';
                                            this.state.uploadProductDetails.profile_type = '';
                                            this.state.showUploadProducts = true;
                                            this.handleUploadChange('source', 'shopify');
                                            this.handleUploadChange('target', 'ebay');
                                            this.handleUploadChange('selected_profile', 'default_profile');
                                            this.getMatchingProfiles();
                                            this.updateState();
                                        }
                                    },
                                    {
                                        content: 'Sync inventory', icon: RefreshMinor, onAction: () => {
                                            this.setState({ bulk_action_marketplace: 'ebay' }, () => {
                                                this.InitiateBulkaction('bulk_inventory')
                                            });

                                        }
                                    },
                                    {
                                        content: 'Sync price', icon: RefreshMinor, onAction: () => {
                                            this.setState({ bulk_action_marketplace: 'ebay' }, () => {
                                                this.InitiateBulkaction('bulk_price')
                                            });

                                        }
                                    },

                                    // {
                                    //     content: 'Sync details', icon: RefreshMinor, onAction: () => {
                                    //         this.setState({ bulk_action_marketplace: 'ebay' }, () => {
                                    //             this.InitiateBulkaction('bulk_sync_details')
                                    //         });
                                    //     }
                                    // },
                                    {
                                        content: 'Match from eBay',
                                        icon: ImportMinor,
                                        onAction: this.InitiateBulkaction.bind(this, 'import_match_ebay')
                                    },
                                    {
                                        content: 'Upload product(s)',
                                        icon: ExportMinor,
                                        onAction: () => {
                                            this.setState({ bulk_action_marketplace: 'ebay' }, () => {
                                                this.InitiateBulkaction('only_upload');
                                            });

                                        }
                                    }

                                ] : [
                                    {
                                        content: 'Upload and revise(All products)', icon: ExportMinor, onAction: () => {
                                            this.state.uploadProductDetails.source = '';
                                            this.state.uploadProductDetails.target = '';
                                            this.state.uploadProductDetails.selected_profile = 'default_profile';
                                            this.state.uploadProductDetails.profile_type = '';
                                            this.state.showUploadProducts = true;
                                            this.handleUploadChange('source', 'shopify');
                                            this.handleUploadChange('target', 'ebay');
                                            this.handleUploadChange('selected_profile', 'default_profile');
                                            this.getMatchingProfiles();
                                            this.updateState();
                                        }
                                    },
                                    {
                                        content: 'Sync inventory', icon: RefreshMinor, onAction: () => {
                                            this.setState({ bulk_action_marketplace: 'ebay' }, () => {
                                                this.InitiateBulkaction('bulk_inventory')
                                            });

                                        }
                                    },
                                    {
                                        content: 'Sync price', icon: RefreshMinor, onAction: () => {
                                            this.setState({ bulk_action_marketplace: 'ebay' }, () => {
                                                this.InitiateBulkaction('bulk_price')
                                            });

                                        }
                                    },

                                    // {
                                    //     content: 'Sync details', icon: RefreshMinor, onAction: () => {
                                    //         this.setState({ bulk_action_marketplace: 'ebay' }, () => {
                                    //             this.InitiateBulkaction('bulk_sync_details')
                                    //         });
                                    //     }
                                    // },
                                    // {
                                    //     content: 'Match from eBay',
                                    //     icon: ImportMinor,
                                    //     onAction: this.InitiateBulkaction.bind(this, 'import_match_ebay')
                                    // },
                                    {
                                        content: 'Upload product(s)',
                                        icon: ExportMinor,
                                        onAction: () => {
                                            this.setState({ bulk_action_marketplace: 'ebay' }, () => {
                                                this.InitiateBulkaction('only_upload');
                                            });

                                        }
                                    }

                                ],
                            },

                        ] : []
                }

            >
                {/* <TextField onChange={(e)=>{console.log(e)}} />
                <input type='text' onChange={(e)=>{console.log(e)}} /> */}
                {/* <Banner
                    title={`${this.state.credits_info.products.available} / ${this.state.credits_info.products.total} product credits available`}>
                </Banner> */}
                {/* <ProgressBar progress={this.state.credits_info.products.percent} size="small" /> */}
                {/* {this.state.user_id != '620' &&
                    <Stack spacing={"loose"}>
                        <Stack.Item>
                            <div style={{ paddingTop: '1.5rem' }}>
                                <Select label={''} options={sortingOptions} value={this.state.sortby}
                                    helpText={'Use this option for sorting'} onChange={(e) => {
                                        this.state.sortby = e;
                                        this.setState({ sortby: e }, () => {
                                            // this.getProducts();
                                            this.getProductsNew()
                                        });
                                    }} />
                            </div>
                        </Stack.Item>
                        {this.state.sortby !== '' &&
                            <Stack.Item>
                                <div style={{ paddingTop: '1.5rem' }}>
                                    <Select label={''} options={sortingOptionsHighLow} value={this.state.high_low_sort}
                                        helpText={'Set your preferred order'} onChange={(e) => {
                                            this.state.high_low_sort = e;
                                            this.setState({ high_low_sort: e }, () => {
                                                // this.getProducts();
                                                this.getProductsNew()
                                            });
                                        }} />
                                </div>
                            </Stack.Item>
                        }
                        <Stack.Item fill></Stack.Item>
                    </Stack>
                } */}

                <LoadingOverlay
                    active={this.grid_loader}
                    spinner
                    text='Loading please wait...'
                >
                    <Grid
                        tag={'Product(s)'}
                        showTabs={true}
                        tabs={tabs}
                        selectedTab={selectedTab}
                        tabSelected={this.tabSelected.bind(this)}
                        columns={columnsAG}
                        rows={rowsAG}
                        showFilters
                        // customRowHeight={100}
                        customRowHeight={60}
                        filterData={this.filterData.bind(this)}
                        filtersProps={filtersProps}
                        massAction={this.massActions}
                        suffix={this.state.toolbar_suffix}
                        performMassAction={this.performMassAction}

                        // selectedActions={selectedActions}
                        // onSelectAction={this.onSelectedAction.bind(this)}
                        getGridApi={this.getGridApi.bind(this)}
                        paginationProps={paginationProps}
                        onpaginationChange={this.onPaginationChange.bind(this)}
                        // suppressSizeToFit={true}
                        suppressMovableColumns={true}
                        suppressRowClickSelection={true}
                        enableCellTextSelection={true}
                        rowSelection={"multiple"}
                        selectedRows={selectedRows}
                        cellClickedEvent={this.cellClickedEvent.bind(this)}
                        rowSelected={this.getSelectedRows.bind(this)}
                        frameworkComponents={this.state.frameworkComponents}
                        noRowsOverlayComponent={this.state.noRowsOverlayComponent}
                        noRowsOverlayComponentParams={
                            this.state.noRowsOverlayComponentParams
                        }
                    />
                </LoadingOverlay>
                {/* { modal_type === 'fetch_orders' &&
               modalPolaris(title, open, this.modalHandler.bind(this, false, modal_type), { content: 'Fetch order(s)', onAction: this.fetchOrders.bind(this), disabled : fetch_orders.shop_id === ''}, structure)
               } */}
                {this.state.exportProductDataCsv && this.exportProductModal()}
                {this.renderImportProductsModal()}
                {this.renderUploadProductsModal()}
                {this.state.syncAllwithShopify && this.syncAllProductModal()}
                {this.ListingIdShowModal()}
                {this.StatusShowModal()}
                {this.InventoryBulkSyncModal()}
                {this.state.selectandUpload && this.selectAndUploadModal()}
                {this.state.syncwithShopify && this.syncBulkProductModal()}
                {this.state.syncImagesModal && this.syncImagesModalStructure()}
                {this.state.publishProductData && this.publishProductModal()}
                {this.selectAndExportCsvModal()}
                {this.RelistProductModal()}

                <Modal title="Bulk action" open={this.state.bulkAction.modal} onClose={() => {
                    this.state.bulkAction.modal = false;
                    this.state.bulkAction.type = '';
                    this.state.bulkAction.text = '';
                    this.setState(this.state);
                }}
                    primaryAction={{
                        content: 'Yes',
                        onAction: this.confirmBulkAction.bind(this),
                    }}
                >
                    <Modal.Section>
                        {this.state.bulkAction.type === 'only_upload' && this.state.bulkAction.text}
                        {this.state.bulkAction.type !== 'only_upload' &&
                            <p>Are you sure you want to initiate {this.state.bulkAction.text} bulk action</p>}
                    </Modal.Section>
                </Modal>
                <ModalVideo channel='youtube' isOpen={this.video.Modal} videoId={this.video.id} onClose={this.closevideoModal.bind(this)} />

                <FooterHelp>
    Learn more about{' '}
    <Link external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=prodt">
    Products
    </Link>
  </FooterHelp>
            </Page>
        )
    }

    closevideoModal() {
        this.video.Modal = false;
        this.video.id = '';
        this.setState(this.state);
    }
}

// export default NewProducts

const mapStateToProps = state => {
    // console.log('state', state)
    let { ebay } = state;
    let { products } = ebay;
    let { filters } = products;
    // console.log('filters', filters)
    return ({
        filters
    });
}

const mapDispatchToProps = dispatch => {
    // console.log('dispatch', dispatch)
    return ({
        filterUpdated: (filters = []) => dispatch(filterUpdated(filters)),
        // activityAdd : () => dispatch(activityAdd())
    })
}

export default connect(mapStateToProps, mapDispatchToProps)(NewProducts);