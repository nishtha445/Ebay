import React, { Component } from 'react';
import {
    SearchMajorMonotone, ChevronRightMinor, ChevronDownMinor,
} from '@shopify/polaris-icons';
import DashboardThumbnail from  "../../assets/img/dashboard.jpg";
import AccountThumbnail from  "../../assets/img/accounts.jpg";
import BusinessPolicyThumbnail from  "../../assets/img/businesspolicy.jpg";
import ProfileThumbnail from "../../assets/img/profiles.jpg";
import RegistrationThumbnail1 from "../../assets/img/registration1.jpg";
import RegistrationThumbnail2 from "../../assets/img/registration2.jpg";
import RegistrationThumbnail3 from "../../assets/img/registration3.jpg";
import RegistrationThumbnail4 from "../../assets/img/registration4.jpg";
import AppsThumbnail from "../../assets/img/apps.jpg";
import CategoryTemplateThumbnail from "../../assets/img/categorytemplate.jpg";
import InventoryTemplateThumbnail from "../../assets/img/inventorytemplate.jpg";
import PricingTemplateThumbnail from "../../assets/img/pricingtemplate.jpg";
import ModalVideo from "react-modal-video";
import {
    Button,
    MediaCard,VideoThumbnail,
    Tabs,
    Card,
    Collapsible,
    Modal,
    Page,
    ResourceList,
    Stack,
    TextContainer,
    Icon,
    Heading,
    FooterHelp,
    Link,
    Badge,
    Filters, TextField
} from "@shopify/polaris";
import { NavLink } from "react-router-dom";
import { isUndefined } from "util";
import {
    PageDownMajorMonotone
} from '@shopify/polaris-icons';

import * as queryString from "query-string";

class Help extends Component {
    handleTabChange=(e)=>{
        this.setState({selected:e})
      }
    constructor(props) {
        super(props);
        this.modalOpen = this.modalOpen.bind(this); // modal function
        this.state = {
            selected:0,
            modal: false, // modal show/hide
            search: '',// search
            noSearchFound: [1],
            open: false,
            faq: [
                {
                    id: 18,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'The package weight is not valid or is missing. Provide a valid number for the weight',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">This issue occurs only when a merchant has opted for calculated service type in the shipping policy.</li>
                                <li className="mb-2">The calculated service type requires weight for the products therefore you need to provide the weight for the products from your shopify store or in the app as well.
                                </li>
                                <li>If you  don't provide the weight to all the products you can simply change the calculated service type to the flat service type (if it doesn't require weight for the products).</li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 19,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'The item specific Size Type is missing. Add Size Type to this listing, enter a valid value, and then try again',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">The size is not provided in the products(this error arise in clothing products).
                                    You can do this from your shopify store,
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 20,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'You are not opted into Business Policies',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">You can opt out any time by selecting the Opt out link on the Manage
                                    business policies page. Your active listings won't be affected, but if you want to make
                                    changes to payment, shipping and returns terms, you’ll need to do that individually
                                    on each listing in the future. You can also opt back in to Business policies at any time.
                                    The policies you’ve already created will still be there, ready for you to use again
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 21,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'A mixture of Self Hosted and EPS pictures are not allowed',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">The "self hosted" photos eBay is referring to your photos hosted at SSB.
                                    Anytime an image is sent by a third party service such as SSB, it's considered "self-hosted.
                                    eBay requires that eBay Picture Services (EPS) images be hosted on THEIR server.
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 22,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Before you can list this item we need some additional information to create a seller account',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">This response comes when a seller starts selling on eBay,
                                    so you need to select an automatic payment method for your selling fees
                                    and eBay is requiring the credit card information. Please log into your eBay account
                                    and add an automatic payment method for your eBay selling fees.
                                </li>
                                <li className={"mb-2"}>
                                    <a href={'https://cedcommerce.com/blog/how-to-add-payment-methods-on-ebay/'}
                                        target={'_blank'}>For additional help click here</a>
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 23,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Variation Specifics provided does not match with the variation specifics of the variations on the item',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">An originally single variant product now being sent as a multi-variant product - eBay will not allow this so the product needs to be completely ended, deleted and re-listed.
                                </li>
                                <li>The variation data for the product from the eCommerce store is not particularly good e.g. different attribute names in different variants.</li>
                                <li>So, it would have originally listed fine but now is not getting updated due to failing the validation rules.
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 24,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'The shipping service is not available for this item location. Select a different service',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">This error means that the selected  shipping service is not available for the item location that you have provided for the products.
                                </li>
                                <li className="mb-2">The wrong item location provided for the products, provide the correct country & Item location within the Configuration section.
                                    Go to: Configuration section -> Global configuration -> ZIP Code.</li>
                                <li>The wrong Shipping Service provided for the products, select the different Shipping Service within the Shipping Policy.
                                    Go to : Business Policy -> Shipping Policy.
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 25,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Brand should contain only one value. Remove the extra values and try again',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">This error is because of wrong mapping in the category template.</li>
                                <li className="mb-2">You have maped Brand with Additional Images. Kindly map Brand with Vendor.</li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 26,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'The tags Custom Bundle is/are disabled as Variant? || Custom Bundle is not allowed as a variation specific',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">This error is because of the wrong mapping in the category template.
                                </li>
                                <li className="mb-2">Correct mapping for Custom Bundle is size.
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 27,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Your item-location was not filled in. The location field helps buyers determine the shipping cost(s) for the item, and should always be included',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">Zip code or postal code is not filled.Please enter a valid ZIP code.
                                </li>
                                <li className="mb-2">Go To: Configuration -> Global Policy.
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 28,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Listing titles are limited to 80 characters',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">An eBay title has been entered that is greater than 80 characters.</li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 29,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Price should be greater than 0.99',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">Increase the price of your products.
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 30,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Duplicate custom variation label',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">When the SKU’s are of same in the product variants.Kindly provide different SKU’s.
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 31,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'You will be unable to complete this request until payment is made or a credit card is put on file for automatic monthly billing',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">If you are a new seller, you may encounter this error message when trying to create your first listing. eBay requires sellers to set up a payment method to pay final value fees and listing fees.
                                </li>
                                <li className="mb-2"><a href={'https://www.ebay.com/help/selling/fees-credits-invoices/setting-changing-payment-method?id=4124'}
                                    target={'_blank'}>Set up automatic payments on eBay</a>.
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 32,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'The email address you entered is not linked to a PayPal account.',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">This means the email address you have entered is not verified by eBay, therefore, you need to make sure the email address in your listing is the exact same email address you have attached to your PayPal account.
                                </li>
                                <li className="mb-2"><a href={'https://www.ebay.com/help/buying/paying-items/paying-paypal?id=4033'}
                                    target={'_blank'}>Paying with PayPal</a>.
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 33,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'eBay account not connected',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">Connection breaks with your eBay seller account. Please reconnect with your eBay account.
                                </li>
                                <li className="mb-2">Go To: Top-Right Thumbnail -> Account
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 34,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Return Policy Attribute returnDescription Not Valid On This Site',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">You have to update the return policy from eBay seller panel and then sync with app and then again try to upload. </li>
                                <li className="mb-2">Return description is allowed only on following eBay sites
                                    Germany:(DE),
                                    Austria:(AT),
                                    France:(FR),
                                    Italy:(IT),
                                    Spain:(ES),
                                    Motors
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 35,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Unable to send listing confirmation notice',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2"> When eBay don’t send listing confirmation mail to the sellers.It is just a acknowledgement message from eBay.
                                </li>
                            </ul>
                        </React.Fragment>
                },


                {
                    id: 36,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Please select an international ship to location.||An error number "Shipto.CustomLocation.Required" occurred while processing your request.',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2"> You have not chosen your international shipping destinations in the international shipping policy.</li>
                                <li>Choose shipping destinations.</li>
                                <li>From Business Policy>> Shipping policy >> underInternational Shipping Services</li>
                            </ul>
                        </React.Fragment>
                },

                {
                    id: 37,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Invalid property type provided for PaymentProfileID. Expected integer but got NULL || Invalid property type provided for ReturnProfileID. Expected integer but got NULL || Invalid property type provided for ShippingProfileID. Expected integer but got NULL',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">Please make sure that the Default profile not empty and Business policy should be available on app.,
                                </li>
                            </ul>
                        </React.Fragment>
                }, {
                    id: 38,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Invalid <ShippingPackage>',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">No need to fill Package type value in Configuration -> App Settings -> Package Type. In case you have saved it then just unselect the value from first value of the dropdown,
                                </li>
                            </ul>
                        </React.Fragment>
                }, {
                    id: 39,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Invalid Multi-SKU item id supplied with variations.',
                    ans:
                        <React.Fragment>
                            <ul>
                            <li>
                                You are getting this error because the original item was not a Multi-SKU item and you are trying to relist it as a Multi-SKU item.

                                If the original item was not listed as a Multi-SKU item, you cannot change it to be a Multi-SKU item during relist (or revise). You will need to create a new listing as a Multi-SKU item.
                            </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 1,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'How to connect my eBay seller account with app',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">You need to authenticate your seller account with our app at second
                                    step of registration,
                                </li>
                                <li className="mb-2">If you need to reconnect with different details you can do so from
                                    the Accounts section of the app.
                                </li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 2,
                    show: false,
                    search: true,
                    ques: 'How to import already selling products and sync with Shopify ',
                    ans:
                        <ul>
                            <li className="mb-2">At Step 4 of registration you need to map eBay attributes with Shopify
                                attributes and proceed.
                            </li>
                            <li className="mb-2">This will automatically initiate Product Import and syncing process.
                            </li>
                        </ul>
                },
                {
                    id: 3,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Will my products get duplicated if i already sell on eBay and use this App',
                    ans: <ul>
                        <li className="mb-2">No, Our app handles duplicate listing issue.</li>

                    </ul>
                },

                {
                    id: 4,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'How to register for eBay seller account ',
                    ans: <ul>
                        <li className="mb-2">Registration for an eBay seller account can be done using your email
                            address,for more information kindly visit <a
                                href={'https://www.eBay/help/account/signing-ebay-account/signing-ebay-account?id=4191'}
                                target={'_blank'}>eBay help section</a>.
                        </li>
                    </ul>
                },
                {
                    id: 5,
                    show: false,
                    search: true,
                    ques: 'What are the terms and conditions to apply for eBay seller account',
                    ans: <p>Though there are no prescribed terms and conditions, it is recommended that you go
                        through <a href={'https://pages.ebay.in/terms-and-conditions/'} target={'_blank'}>terms and
                            conditions </a>, put forth by eBay. </p>

                },
                {
                    id: 6,
                    show: false,
                    search: true,
                    ques: 'What is profiling and what is Default Profile',
                    ans: <React.Fragment>
                        <p className="text-justify"><b>Profiling</b> is a feature using which you can upload products
                            with particular specifications by making your own customised profile (for example- all
                            products with price 10$) from App to eBay marketplace.</p>

                        <p className="text-justify">So whenever you want to upload bulk products you can simply make
                            your customised profile with specifications of your choice and upload all products in one
                            go.</p>

                        {/*<p>In default Profile We Have Some Fixed Format. For Example Click <a href="javascript:void(0)" onClick={this.modalOpen}>Here</a></p>*/}
                    </React.Fragment>
                },
                {
                    id: 7,
                    show: false,
                    search: true,
                    ques: 'What do templates in the app stand for? Are they required',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">A listing template contains information that is required to create
                                    a product listing: title, description, images, and other information that you
                                    indicate on eBay’s Sell Your Item form. Multiple listing templates for each product
                                    can be assigned, which allows you to list products in multiple ways.
                                </li>
                                <li className="mb-2">Only <b>category template</b> is a required template.</li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 8,
                    show: false,
                    search: true,
                    ques: 'How to create a template',
                    ans: <React.Fragment>
                        <p className='mb-2'>You can create template by following steps </p>
                        <ul>
                            <li className='mb-2'>
                                Visit <a style={{ color: 'blue' }}
                                    onClick={this.redirect.bind(this, '/panel/template/list')}><b>Templates</b></a> section
                                of the app .
                            </li>
                            <li className='mb-2'>Select a template type you want to create.</li>
                            <li className='mb-2'>Click on create new.</li>
                        </ul>
                    </React.Fragment>
                },
                {
                    id: 9,
                    show: false,
                    search: true,
                    ques: 'What is the difference between Personal eBay account and Business eBay account',
                    ans: <React.Fragment>
                        <ul>
                            <li>
                                Personal eBay accounts can be created if, someone wants to sell casually. For example,
                                if a seller wants to end a particular stock of products, he can create <b>Personal eBay
                                    account</b>.
                            </li>
                            <li>
                                If you are selling or planning to sell large quantites then you need to register for
                                a <b>Business eBay account</b>.
                            </li>
                        </ul>
                        <p>For more information regarding the same you can refer to <a
                            href={'https://docs.cedcommerce.com/shopify/ebay-marketplace-integration'}
                            target={'_blank'}>eBay help documentation.</a></p>
                    </React.Fragment>
                },
                {
                    id: 10,
                    show: false,
                    search: true,
                    ques: 'What is Business policy',
                    ans: <React.Fragment>

                        <p className={'mb-2'}>For creating a listing you`ll need to choose a set of business policies of
                            buyers ie. </p>
                        <ul>
                            <li className={'mb-2'}>Payment policy</li>
                            <li className={'mb-2'}>Shipping policy</li>
                            <li className={'mb-2'}>Return policy</li>
                        </ul>

                        <p>but you can streamline the process by creating business policies templates which can be used
                            to define these set of policies on each listing without re-defining them again-again</p>
                    </React.Fragment>
                },
                {
                    id: 11,
                    show: false,
                    search: true,
                    ques: 'Is order management section based on profiling, templating and business policy',
                    ans:
                        <React.Fragment>
                            <p>
                                <b>No</b>, If you are only on our app for order management then there is no need to
                                create business policies and templates , Your orders will be managed using default
                                settings.
                            </p>
                        </React.Fragment>
                },
                {
                    id: 12,
                    show: false,
                    search: true,
                    ques: 'Does the app support for eBay Motors site',
                    ans: <React.Fragment>
                        <p><b>Yes</b>, Our app does support eBay Motors site</p>
                    </React.Fragment>
                },
                {
                    id: 13,
                    show: false,
                    search: true,
                    ques: 'What is the difference between Auction and Fixed price item',
                    ans: <React.Fragment>
                        <ul>
                            <li>
                                <p><b>Auction price item : </b> Buyers can purchase your item immediately or place a
                                    bid.</p>
                            </li>
                            <li>
                                <p><b>Fixed price item : </b> Buyers can purchase your item immediately at the price you
                                    set, but cannot bid on your item.</p>
                            </li>
                        </ul>
                    </React.Fragment>
                },
                {
                    id: 14,
                    show: false,
                    search: true,
                    ques: 'Does the app support secondary category setting ',
                    ans: <React.Fragment>
                        <p>
                            <b>Yes,</b> app does support secondary category, you can set the same during creation of
                            category template by selecting <b>Enable secondary category.</b>
                        </p>
                    </React.Fragment>
                },
                {
                    id: 15,
                    show: false,
                    search: true,
                    ques: 'Does the app support international shipping and global shipping program ',
                    ans: <React.Fragment>
                        <p>
                            <b>Yes,</b> app supports global shipping program and international shipping ,given global
                            shipping is enabled from eBay seller panel.
                        </p>
                    </React.Fragment>
                },
                {
                    id: 16,
                    show: false,
                    search: true,
                    ques: 'Does the app support for all eBay Countries ',
                    ans: <React.Fragment>
                        <p>
                            <b>Yes,</b> our app does support all eBay countries.
                        </p>
                    </React.Fragment>
                },

                {
                    id: 17,
                    show: false,
                    search: true,
                    ques: 'Can we manage multiple eBay stores from one app ',
                    ans: <React.Fragment>
                        <p>
                            <b>No,</b> as of now multiple eBay stores can`t be managed from the app.
                        </p>
                    </React.Fragment>
                },
                {
                    id: 18,
                    show: false,
                    search: true,
                    ques: 'Your listing cannot contain javascript (".cookie", "cookie(", "replace(", IFRAME, META, or includes), cookies or base href.',
                    ans: <React.Fragment>
                        <p>eBay doesn't allow to list products with these javascripts words.You need to remove the script tags, videos and above words from description/title of the products.
                        </p>
                    </React.Fragment>
                },
                {
                    id: 19,
                    show: false,
                    search: true,
                    ques: 'How does app credits work?',
                    ans: <React.Fragment>
                        <p>As our app plans are based on credits, here is the brief explanation over the app Credits.</p>
                        <p>1 Product Credit means 1 product can be listed on eBay through the app. The product can be a simple or variant product. Therefore, if you have 1000 product credits you can list 1000 products on eBay through the app.</p>
                        <br />
                        <p>About Product Credits</p>
                        <ul>
                            <li>
                                1 Product Credit => 1 product can be listed on eBay through the app.
                            </li>
                            <li>
                                1000 Product Credits=> 1000 products can be listed on eBay through the app.
                            </li>
                        </ul>
                        <br />
                        <p>1 Order credit means 1 eBay Order can be managed from Shopify through the app. Therefore, if you have 500 order credits then you can manage 500 orders through the app.</p>
                        <br />
                        <p>About Order Credits</p>
                        <ul>
                            <li>
                                1 Order credit=> 1 eBay Order can be managed from Shopify through the app.
                            </li>
                            <li>
                                500 Order credits=> 500 eBay Order can be managed from Shopify through the app.
                            </li>
                        </ul>
                    </React.Fragment>
                },
                {
                    id: 20,
                    show: false,
                    search: true,
                    ques: 'Email contains an invalid domain name ?',
                    ans: <React.Fragment>
                        <p>
                            This response means that the email id provided by the buyer does not have a valid domain. If you want this order to be created in Shopify, kindly provide us with the default email Id that we can use for making this order in Shopify.
                            You will receive an update on it in 24 hours. As the creation of the order requires the involvement of the tech team.
                        </p>
                    </React.Fragment>
                },
                {
                    id: 21,
                    show: false,
                    search: true,
                    ques: 'Unable to reserve inventory ?',
                    ans: <React.Fragment>
                        <p>
                            This response means that the ordered product doesn't contain stock/ inventory.

                          <ul>
                                <li>
                                    Kindly provide stock for the product for both the ordered products
                                </li>
                                <li>
                                    Then delete the order from the app, and in a few minutes, both the orders will get synced.
                                </li>
                                </ul>
                        </p>
                    </React.Fragment>
                },
                {
                    id: 22,
                    show: false,
                    search: true,
                    ques: 'Product is either not uploaded from app or title and sku did not match else does not exists ?',
                    ans: <React.Fragment>
                        <p>

                            This response means that the ordered product is not available in your Shopify store.
                            <br />
                            If the product is available in your Shopify store, you need to provide the same title or SKU on both the platforms. As the app map eBay and Shopify attributes (title or SKU) of already existing eBay products.
                            <br />
                            Then delete the order from the app, and in a few minutes, the order will get synced.

                        </p>
                    </React.Fragment>
                }
            ],
            searchValue: [],
            matched_faq: [],
            isSearched: false
        };
        this.getQueryparams();
    }
    video={Modal:false,id:''};
    openvideoModal(id){
        this.video.Modal=true;
        this.video.id=id;
        this.setState(this.state);
      }
    
      closevideoModal(){
        this.video.Modal=false;
        this.video.id='';
        this.setState(this.state);
      }
    getQueryparams() {
        if (!isUndefined(this.props.location.search)) {
            const queryParams = queryString.parse(this.props.location.search);
            if ('faq' in queryParams) {
                this.state.search = queryParams['faq'];
                this.setState(this.state);
                this.handleSearch();
            }
        }
    }

    handleSearch() {
        try {
            let value = this.state.faq;
            let flag = 0;
            if (this.state.search.length >= 2) {
                value.forEach(data => {
                    const text = data.ques.toLowerCase();
                    if (text.search(this.state.search) === -1) {
                        data.search = false;
                    } else {
                        data.search = true;
                        flag = 1;
                    }
                });
            } else {
                value.forEach(data => {
                    data.search = true;
                    flag = 1;
                });
            }
            if (flag === 0) {
                this.setState({ noSearchFound: [] });
            } else {
                this.setState({ noSearchFound: [1] });
            }
            this.setState({ faq: value });
        } catch (e) {
            console.log(e);
        }
    }
   
    findMatch(valuetobematched) {
        let { faq } = this.state;
        let temparr = [];
        faq.forEach(ele => {
            if (ele['ques'].toLowerCase().indexOf(valuetobematched.toLowerCase()) >= 0) {
            
                temparr.push(ele)
            }
        })
        this.setState({ matched_faq: temparr, isSearched: true })
    }

    onSearch = (value) => {
        this.handleSearch()
        this.setState({ searchValue: value }, () => {
            this.findMatch(value)
        })
    }

    render() {
        const tabs = [
            {
              id: 'faq',
              content: (
              
                  <Stack spacing="extraTight">
                 <p>FAQ(s)</p><Icon
               
                color="base" />
                </Stack>
               
              ),

              accessibilityLabel: 'faq',
              panelID: 'faq',
            },
          
         
            {
              id: 'help',
              content:  (
              
                <Stack spacing="extraTight">
               <p>Help Videos</p><Icon
               
                color="base" />
                </Stack>
             
            ),
              panelID: 'help',
            },
          ];
        let { searchValue } = this.state;
        return (
            <Page title="Help" fullWidth={true}
                titleMetadata={<Stack vertical={false}><p style={{ cursor: 'pointer' }} onClick={() => {
                    window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=help-10', '_blank')
                }}><Badge status={"info"}><b style={{ color: '#0000aa', textDecoration: 'underline' }}>Documentation</b></Badge>
                </p>
                <p style={{ cursor: 'pointer' }} onClick={()=>window.open('https://www.ebay.com/help/policies/member-behaviour-policies/user-agreement?id=4259', '_blank')}
                    
                ><Badge status={"info"}><b style={{ color: '#0000aa', textDecoration: 'underline' }}>eBay User Policy</b></Badge>
                </p>
                 </Stack> }
            /* primaryAction={{
                 content: 'Contact us', onAction:
                     this.redirect.bind(this, '/panel/help/report')
             }}*/
            >
                <Stack alignment="fill" distribution="fill" spacing="tight">
          <Stack.Item>
          <Tabs tabs={tabs} selected={this.state.selected} onSelect={this.handleTabChange}>
          
                 {this.state.selected===0?
                  
                    <Card sectioned>
                      <Stack vertical>
                        
                     
                    <TextField value={searchValue} onChange={(value) => { this.onSearch(value) }} placeholder='Search..' prefix={<Icon
                        source={SearchMajorMonotone}
                        color="base" />} />
                    {/* <ResourceList
                        resourceName={{singular: 'Question', plural: 'Questions'}}
                        items={this.state.noSearchFound}
                        renderItem={item => {
                        }}
                        filterControl={
                            // <ResourceList.FilterControl
                            //     searchValue={this.state.search}
                            //     onSearchChange={(searchValue) => {
                            //         this.setState({search: searchValue.toLowerCase()},()=>{
                            //           this.handleSearch();
                            //         });
                            //     }}
                            // />

                            <Filters
                            queryValue={this.state.search}
                            filters={this.state.faq}
                            // appliedFilters={appliedFilters}
                            onQueryChange={setQueryValue}
                            onQueryClear={handleQueryValueRemove}
                            onClearAll={handleClearAll}
                            / >
                        }
                    /> */}

              

                {
                    this.state.isSearched ?
                        this.state.matched_faq.map(data => {
                            return (
                                data.search ?
                                    <div style={{ marginTop: '1rem', marginBottom: '1rem' }}>
                                        <React.Fragment key={data.id}>
                                            <div style={{ cursor: 'pointer' }} onClick={this.handleToggleClick.bind(this, data)}
                                                ariaExpanded={this.state.open}>
                                                <Card>
                                                    <Card.Section>
                                                        <Stack distribution={"equalSpacing"}>
                                                            <b>{data.ques}</b>
                                                            <Button plain icon={data.show ? <Icon source={ChevronDownMinor} /> : <Icon source={ChevronRightMinor} />}/>
                                                        </Stack>
                                                    </Card.Section>
                                                    <Collapsible transition={{duration: '500ms', timingFunction: 'ease-in-out'}} open={data.show} id={data.id}>
                                                        <Card>
                                                            <Card.Section>
                                                                <h5 className="pl-3"><br />{data.ans}</h5>
                                                            </Card.Section>
                                                        </Card>
                                                    </Collapsible>
                                                </Card>
                                            </div>
                                        </React.Fragment>
                                    </div>
                                    : '')
                        }
                        ) :
                        this.state.faq.map(data => {
                            return (
                                data.search ?
                                    <div style={{ marginTop: '1rem', marginBottom: '1rem' }}>
                                        <React.Fragment key={data.id}>
                                            <div style={{ cursor: 'pointer' }} onClick={this.handleToggleClick.bind(this, data)}
                                                ariaExpanded={this.state.open}>
                                                <Card>
                                                   
                                                    <Card.Section>
                                                       <Stack spacing="extraTight" distribution="equalSpacing" wrap={true}>
                                                      <b>{data.ques}</b>
                                                           
                                                       <Button plain icon={data.show ? <Icon source={ChevronDownMinor} /> : <Icon source={ChevronRightMinor} />} />
                                                        </Stack>
                                                    </Card.Section>
                                                    
                                                    <Collapsible transition={{duration: '500ms', timingFunction: 'ease-in-out'}} open={data.show} id={data.id}>
                                                        <Card>
                                                            <Card.Section>
                                                                <h5 className="pl-3"><br />{data.ans}</h5>
                                                            </Card.Section>
                                                        </Card>
                                                    </Collapsible>
                                                </Card>
                                            </div>
                                        </React.Fragment>
                                    </div>
                                    : '')
                        }
                        )
                }

                <Modal
                    open={this.state.modal}
                    title="Default Profile Example"
                    onClose={this.modalOpen}
                >
                    <Modal.Section>
                        <TextContainer>
                            <h2>eBay Attribute Mapping Are Something Like this: </h2>
                            <h4>
                                <ul>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'title'</p><Icon
                                        source={"arrowLeft"} /><Icon source={"horizontalDots"} /><Icon
                                            source={"arrowRight"} /><p>'title</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'description'</p><Icon
                                        source={"arrowLeft"} /><Icon source={"horizontalDots"} /><Icon
                                            source={"arrowRight"} /><p>'long_description'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'price'</p><Icon
                                        source={"arrowLeft"} /><Icon source={"horizontalDots"} /><Icon
                                            source={"arrowRight"} /><p>'price'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'link'</p><Icon
                                        source={"arrowLeft"} /><Icon source={"horizontalDots"} /><Icon
                                            source={"arrowRight"} /><p>'Your Product Link'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'brand'</p><Icon
                                        source={"arrowLeft"} /><Icon source={"horizontalDots"} /><Icon
                                            source={"arrowRight"} /><p>'vendor'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'image_link'</p><Icon
                                        source={"arrowLeft"} /><Icon source={"horizontalDots"} /><Icon
                                            source={"arrowRight"} /><p>'main_image'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'main_image'</p><Icon
                                        source={"arrowLeft"} /><Icon source={"horizontalDots"} /><Icon
                                            source={"arrowRight"} /><p>'container_id'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'gtin'</p><Icon
                                        source={"arrowLeft"} /><Icon source={"horizontalDots"} /><Icon
                                            source={"arrowRight"} /><p>'bar_code'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'mpn'</p><Icon
                                        source={"arrowLeft"} /><Icon source={"horizontalDots"} /><Icon
                                            source={"arrowRight"} /><p>'sku'</p></Stack></li>
                                </ul>
                            </h4>
                        </TextContainer>
                    </Modal.Section>
                </Modal>
                      </Stack>
                      </Card>:
                       this.state.selected===1?
                       <Card sectioned>
                       <Stack alignment="baseline" distribution="fillEvenly">
                         
                      
                          <Card title="How to upload products to eBay using the Integration for eBay app?">
                              <Card.Section>
                            
                    <MediaCard
  title=" Learn the step-by-step process to list products on eBay"
  primaryAction={{
    content: <Link monochrome external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=prodt">Learn more
    </Link>
  }}
  description={`Learn the step-by-step process to list products on eBay with the help of the Integration for eBay app. The product upload video is highly recommended for merchants who have already set up their accounts and have an eBay account in good standing.`}
  
>
<VideoThumbnail onClick={this.openvideoModal.bind(this,'2pos_rypAVY')}
    videoLength={183}
    thumbnailUrl={DashboardThumbnail}
  />

    </MediaCard>
   
                              </Card.Section>
                          </Card>
                          
                          <Card title="How to Reconnect your eBay account with the app?">
                              <Card.Section>
                            
                    <MediaCard
  title="Learn the step-by-step process to Reconnect your eBay account with the app"
  primaryAction={{
    content:  <Link monochrome external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=top-right-thumbnail">Learn more
    </Link>
    
  }}
  description={`This video solely intends to depict the process of Reconnecting your eBay account to the app for a smooth listing of products and management of the same.`}
  
>


<VideoThumbnail onClick={this.openvideoModal.bind(this, 'ZRChv29iC04')}
    videoLength={87}
    thumbnailUrl={AccountThumbnail}
  />
</MediaCard>                              
                </Card.Section>
            </Card>
            <Card title="How to create business policies in eBay Marketplace Integration app - Cedcommerce?">
                              <Card.Section>
                            
                    <MediaCard
  title="Learn the step-by-step process to create business policies"
  primaryAction={{
    content:  <Link monochrome external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=bsns-policies">Learn more
    </Link>
    
  }}
  description={`The business policy includes Payment Policy, Return Policy, Shipping Policy of the product.`}
  
>
<VideoThumbnail onClick={this.openvideoModal.bind(this, 'cw2MiFRBAqY')}
    videoLength={134}
    thumbnailUrl={BusinessPolicyThumbnail}
  />
    </MediaCard>                              
                </Card.Section>
            </Card>
            <Card title="How to create profiles in eBay Marketplace Integration app- CedCommerce?">
                              <Card.Section>
                            
                    <MediaCard
  title="Learn the step-by-step process to create profiles"
  primaryAction={{
    content:  <Link monochrome external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=profil">Learn more
    </Link>
    
  }}
  description={`This video describes the way to create PROFILES in eBay Marketplace Integration platform. Profile section helps to assign different business policies & templates to a group of products created, based on different product properties.`}
  
>

<VideoThumbnail onClick={this.openvideoModal.bind(this, 'ptGo3ktQJ30')}
    videoLength={150}
    thumbnailUrl={ProfileThumbnail}
  />

    </MediaCard>                              
                </Card.Section>
            </Card>

            <Card title="How to register to sell efficiently on eBay- CedCommerce?">
                              <Card.Section>
                            
                    <MediaCard
  title="Learn the step-by-step process to register"
  primaryAction={{
    content:  <Link monochrome external url=" https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=regstn">Learn more
    </Link>
   
    
  }}
  description={`This is the initial step of the #onboarding process, wherein you have to fill in the necessary details. This step calls for accepting the terms and policies of our application so that one can easily list #Shopify products on #eBay.
  This video is an apt representation of how to complete the registration process.`}
  
>


<VideoThumbnail onClick={this.openvideoModal.bind(this, 'jr84JmKFPH4')}
    videoLength={55}
    thumbnailUrl={RegistrationThumbnail1}
  />

    </MediaCard>                              
                </Card.Section>
            </Card>
            <Card title="How to map eBay and Shopify attributes - CedCommerce?">
                              <Card.Section>
                            
                    <MediaCard
  title="Learn the step-by-step process to map eBay and Shopify attributes"
  primaryAction={{
    content:  <Link monochrome external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=map-ebay-shopify-fields">Learn more
    </Link>
    
  }}
  description={`This functionality of the app ensures that you effortlessly map eBay and Shopify attributes of already existing eBay products. This process is to help you avoid duplicate product upload of #Shopify products on #eBay. You can map Shopify attributes with eBay Title or SKU.
  This video ensures that you,  easily carry out the process of mapping eBay and Shopify fields to effectively #import your Shopify products on the app and list them on Shopify.`}
  
>


<VideoThumbnail onClick={this.openvideoModal.bind(this, '2lFk4LFxl0c')}
    videoLength={43}
    thumbnailUrl={RegistrationThumbnail2}
  />

    </MediaCard>                              
                </Card.Section>
            </Card>
            <Card title="How to set your eBay business policies - CedCommerce?">
                              <Card.Section>
                            
                    <MediaCard
  title="Learn the step-by-step process to set your eBay business policies"
  primaryAction={{
    content:  <Link monochrome external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=set-your-business-policies">Learn more
    </Link>
    
  }}
  description={` It is very important to have appropriate #business policies ( #Payment, Shipping, Return) before you start to sell on #eBay. In this step, you need to either choose an existing business policy or create a new one, which will be used as a default business policy for your products.
  This section has been created with a point of view to help existing eBay sellers choose business policies that can be used as the default ones.
  
  Watch the video to explore how to set the business policies and use them to their full potential.`}
  
>

<VideoThumbnail onClick={this.openvideoModal.bind(this, 'Py3zDdTxSfI')}
    videoLength={187}
    thumbnailUrl={RegistrationThumbnail3}
  />

    </MediaCard>                              
                </Card.Section>
            </Card>
            <Card title="How to set a default category template - CedCommerce?">
                              <Card.Section>
                            
                    <MediaCard
  title="Learn the step-by-step process to set a default category template"
  primaryAction={{
    content: <Link monochrome external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=execute-category-mapping">Learn more
    </Link>
  }}
  
  description={` We have listed all the available #eBay categories for you to assign to your products. Also, you can search for the desired category using the “Category Search” Bar.

  You can assign categories up to 6 levels to be very specific about your product category.
  
  If a category, assigned by you to any product has attributes, you can map them to Shopify attributes through our app.
  
  You can choose the categories suitable for your #Shopify products from the recommendations(as available on eBay) as well.`}
  
>

<VideoThumbnail onClick={this.openvideoModal.bind(this, 'qit-0hRCbzQ')}
    videoLength={100}
    thumbnailUrl={RegistrationThumbnail4}
  />

    </MediaCard>                              
                </Card.Section>
            </Card>
            <Card title="How to connect your eBay store - CedCommerce?">
                              <Card.Section>
                            
                    <MediaCard
  title="Learn the step-by-step process to connect your eBay store"
  primaryAction={{
  content:  <Link monochrome external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=link-your-ebay-account">Learn more
    </Link>
    
  }}
  description={`eBay, a global Marketplace, started in 1995 with a view to help online sellers from all over the world to ensure a seamless selling experience.

  The #eBay Channel-Integration app has been designed to bring about a seamless connection between #Shopify & eBay
  
  This video solely intends to depict the process of connecting your eBay store to the app for a smooth listing of products and management of the same.`}
>
<VideoThumbnail onClick={this.openvideoModal.bind(this, 'g6afmrLeVzo')}
    videoLength={83}
    thumbnailUrl={AppsThumbnail}
  />
</MediaCard>                              
                </Card.Section>
            </Card>
            <Card title="How to create category template in eBay Marketplace Integration app - CedCommerce?">
                              <Card.Section>
                            
                    <MediaCard
  title="Learn the step-by-step process to create category template"
  primaryAction={{
    content:  <Link monochrome external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=category-templates">Learn more
    </Link>
    
  }}
  description={`Category template can be used for assigning a category along with the required and optional attributes which you commonly use for listing on eBay.`}
>

<VideoThumbnail onClick={this.openvideoModal.bind(this, 'gVB4UW1R4Gk')}
    videoLength={116}
    thumbnailUrl={CategoryTemplateThumbnail}
  />
    </MediaCard>                              
                </Card.Section>
            </Card>
            <Card title="How to create inventory template in eBay Marketplace Integration app - CedCommerce?">
                              <Card.Section>
                            
                    <MediaCard
  title="Learn the step-by-step process to create inventory template"
  primaryAction={{
    content:  <Link monochrome external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=in-templ">Learn more
    </Link>
    
  }}
  description={`This functionality of the app ensures that you can effortlessly assign properties like how much should be the fixed inventory, what is its threshold limit, restriction per buyer and whether to delete products when they are out of stock. So by simply using the template all of these conditions can be applied while listing on eBay.`}
>

<VideoThumbnail onClick={this.openvideoModal.bind(this, 'IcBzcUXy1TE')}
    videoLength={88}
    thumbnailUrl={InventoryTemplateThumbnail}
  />
    </MediaCard>                              
                </Card.Section>
            </Card>
            <Card title="How to create pricing template in eBay Marketplace Integration app - CedCommerce?">
                              <Card.Section>
                            
                    <MediaCard
  title="Learn the step-by-step process to create pricing template"
  primaryAction={{
    content:  <Link monochrome external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=pricing-templates">Learn more
    </Link>
    
    
  }}
  description={`This functionality of the app ensures that you can effortlessly assign custom pricing while creating or updating a listing on eBay. Simply using the Pricing template you can either list “Fixed Price” or “Auction-Style” for your products.`}
>

<VideoThumbnail onClick={this.openvideoModal.bind(this, '9aMh0zYClEg')}
    videoLength={240}
    thumbnailUrl={PricingTemplateThumbnail}
  />

    </MediaCard>                              
                </Card.Section>
            </Card>
       
            <Card title="How to create title template in eBay Marketplace Integration app - CedCommerce?">
                              <Card.Section>
                            
                    <MediaCard
  title="Learn the step-by-step process to create title template"
  primaryAction={{
    content:  <Link monochrome external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=title-templates">Learn more
    </Link>
    
  }}
  description={`This functionality of the app ensures that you can effortlessly map the desired Shopify attributes to Title, subtitle & description attributes of eBay. So by simply using the title template all of these conditions can be applied while listing on eBay.`}
>

<VideoThumbnail onClick={this.openvideoModal.bind(this, 'WeuuIT-vlC0')}
    videoLength={177}
    thumbnailUrl={PricingTemplateThumbnail}
  />

    </MediaCard>                              
                </Card.Section>
            </Card>
       
            
            
 
                           </Stack>
                           </Card>
                           
    :<h1>Error</h1>}
              </Tabs>
              </Stack.Item>
</Stack>
<ModalVideo channel='youtube' isOpen={this.video.Modal} videoId={this.video.id}  onClose={this.closevideoModal.bind(this)} />
                {/* <FooterHelp>
    Learn more about{' '}
    <Link external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=help-10">
    Integration for eBay
    </Link>
  </FooterHelp> */}
            </Page>
        );
    }

    handleToggleClick = (event) => {
        let data = this.state.faq;
        data.forEach(key => {
            if (key.id === event.id) {
                key.show = !key.show;
            }
        });
        this.setState({
            faq: data,
        });
    };

    modalOpen() {
        this.setState({
            modal: !this.state.modal
        });
    }

    redirect(url) {
        this.props.history.push(url);
    }
}

export default Help;
