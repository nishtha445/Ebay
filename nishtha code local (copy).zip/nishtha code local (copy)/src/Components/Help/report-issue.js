import React, {Component} from 'react';
import Skype from  "../../assets/img/skype.png";
import './report-issue.css'
import Mail from  "../../assets/img/mail.png";
import Whatsapp from  "../../assets/img/whatsapp.png";
import {
    Page,
    Card,
    TextField,
    Form,
    Select,
    Button,
    Layout,
    Stack,
    Badge,
    FooterHelp,
    Link,
    Subheading,
    Thumbnail,

    Heading,
    DisplayText,
    Icon,
    TextStyle,
    Tooltip, FormLayout
} from "@shopify/polaris";
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
const currentTime = new Date();
const year = currentTime.getFullYear();
const month = (currentTime.getMonth() + 1) < 10 ? '0' + (currentTime.getMonth() + 1) : currentTime.getMonth() + 1;
const date = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();

const currentDateInString = year + '-' + month + '-' + date;

let preferredMeeting = [
    { label : 'Skype', value : 'skype'},
    { label : 'Google meet', value : 'gmeet'},
    { label : 'Zoom meet', value : 'zoom'},
];

let timezone = [
    { label : 'GMT', value : 'GMT'},
    { label : 'UTC', value : 'UTC'},
    { label : 'ECT', value : 'GMT+1:00'},
    { label : 'EET', value : 'GMT+2:00'},
    { label : 'ART', value : 'GMT+2:00'},
    { label : 'EAT', value : 'GMT+3:00'},
    { label : 'MET', value : 'GMT+3:30'},
    { label : 'NET', value : 'GMT+4:00'},
    { label : 'PLT', value : 'GMT+5:00'},
    { label : 'IST', value : 'GMT+5:30'},
    { label : 'BST', value : 'GMT+6:00'},
    { label : 'VST', value : 'GMT+7:00'},
    { label : 'CTT', value : 'GMT+8:00'},
    { label : 'JST', value : 'GMT+9:00'},
    { label : 'ACT', value : 'GMT+9:30'},
    { label : 'AET', value : 'GMT+10:00'},
    { label : 'SST', value : 'GMT+11:00'},
    { label : 'NST', value : 'GMT+12:00'},
    { label : 'MIT', value : 'GMT-11:00'},
    { label : 'HST', value : 'GMT-10:00'},
    { label : 'AST', value : 'GMT-9:00'},
    { label : 'AST', value : 'GMT-8:00'},
    { label : 'PST', value : 'GMT-8:00'},
    { label : 'PNT', value : 'GMT-7:00'},
    { label : 'MST', value : 'GMT-7:00'},
    { label : 'CST', value : 'GMT-6:00'},
    { label : 'EST', value : 'GMT-5:00'},
    { label : 'IET', value : 'GMT-5:00'},
    { label : 'PRT', value : 'GMT-4:00'},
    { label : 'CNT', value : 'GMT-3:30'},
    { label : 'AGT', value : 'GMT-3:00'},
    { label : 'BET', value : 'GMT-3:00'},
    { label : 'CAT', value : 'GMT-1:00'},
];

class ReportAnIssue extends Component {
    constructor(props) {
        super(props);
        this.state = {
            subject: '',
            body: '',
            option:'',
            meeting : {
                preferred_meeting : '',
                email : '',
                preferred_time : '',
                additional_note : '',
                time_zone : '',
                date:'',
            },
            issueSubmitLoader: false,
            scheduleDemoLoader: false,
        };
        this.handleSelectChange = this.handleSelectChange.bind(this);
    }
    handleTextChange(key, event) {
        
        this.setState({
            [key]: event
        });
    }

    handleallTextChange(key, subkey, event){
        switch (key){
            case 'meeting' :
                let { meeting } = this.state;
                meeting[subkey] = event;
                this.setState({ meeting });
                break;
            default: break;
        }
    }

    handleSelectChange(event) {
        this.setState({
            option:event
        });
    }
    submit() {
        let {issueSubmitLoader} = this.state;
        issueSubmitLoader = true;
        this.setState({issueSubmitLoader});
        let data = {
            body:'',
            subject:''
        };
        if ( this.state.body !== '' && this.state.option !== '') {
            if ( this.state.option !== 'other' ) {
                data.body = this.state.body;
                data.subject = 'We have Received Your Query Related to ' + this.state.option;
            } else {
                data.body = this.state.body;
                data.subject = 'We have Received Your Issue ';
            }
            requests.postRequest('frontend/app/submitReport',data).then(e => {
                if (e.success) {
                    notify.success(e.message);
                } else {
                    notify.error(e.message);
                }
                issueSubmitLoader = false;
                this.setState({issueSubmitLoader});
            });
        } else {
           
            notify.info('Empty field(s)');
            issueSubmitLoader = false;
            this.setState({issueSubmitLoader});
            
        }
       
    }
    getPrefferedTimeOptions(){
        let options =[];
        let i = 0;
        while( i<= 21){
            options = [ ...options, { label : `${i}:00 - ${i+3}:00`, value: `${i}:00 - ${i+3}:00`}]
            i+=3;
        }
        return options;
    }

    async submitMeetingSchedule(){
       
        let {meeting, scheduleDemoLoader} = this.state;
        scheduleDemoLoader = true;
        this.setState({scheduleDemoLoader})   
        if(meeting.email!=='' && meeting.time_zone!=='' && meeting.preferred_meeting!=='' && meeting.preferred_time!=='' && meeting.date!=='')
        {            
            let { success, message}  = await requests.postRequest('frontend/app/schedulemeeting', {...meeting});
            if(success) notify.success(message);
            else notify.error(message);
            scheduleDemoLoader = false;
            this.setState({scheduleDemoLoader})
            
        }
        else{
            notify.info('Empty field(s)');
            scheduleDemoLoader = false;
            this.setState({scheduleDemoLoader})      
        }     
}

    render() {
        let preferredTime = this.getPrefferedTimeOptions()
        const options = [
            {label:'Products',value:'products'},
            {label:'Orders',value:'orders'},
            {label:'Profiles',value:'profiles'},
            {label:'Templates',value:'templates'},
            {label:'Business policy',value:'Business policy'},
            {label:'Configuration',value:'Configuration'},
            {label:'Others',value:'others'},
        ];
        let {issueSubmitLoader, scheduleDemoLoader} = this.state;
        return (
            <Page
                /* breadcrumbs={[{content: 'Help',onAction: this.redirect.bind(this,'/panel/help')}]}*/
                fullWidth={true} 
                title="Contact Us"
            //     primaryAction={
            //     // <Card sectioned>
            //         <Stack vertical={false} sectioned={false}>
            //     <p style={{cursor:'pointer'}} onClick={(e)=>{
            //                             window.open('https://chat.whatsapp.com/I3qcRQ3yZcR8X1B2khmoDj', '_blank');
            //                             e.preventDefault();
            //                         }}><Thumbnail source={Whatsapp} size="small"/>
                                   
            //     </p>
            //     <p style={{cursor:'pointer'}} onClick={(e)=>{
            //                             window.open('https://join.skype.com/GbdPBTuVsNgN', '_blank')
            //                             e.preventDefault();
            //                         }}><Thumbnail source={Skype} size="small"/>
            //     </p>
            //     <p style={{cursor:'pointer'}}><a style={{color:'black'}} href={
            //     'mailto:divyamishra@cedcommerce.com&cc=srajanshukla@cedcommerce.com'
            // }><Tooltip content="ebay_support@cedcommerce.com"><TextStyle><Thumbnail source={Mail} size="small"/></TextStyle></Tooltip></a>
            //     </p>
            //   </Stack>
            // //   </Card>
            // }
            >

 <Layout>
                      <Layout.Section oneHalf>
                          <Stack vertical spacing="tight"> 
                          <Card sectioned>
                            <Stack alignment="center"  distribution="equalSpacing" >
                                <Heading>Feel free to reach out to us</Heading>
                                <Stack spacing="loose">
                                <Tooltip content="Whatsapp"><p style={{cursor:'pointer'}} onClick={(e)=>{
                                    window.open('https://chat.whatsapp.com/I3qcRQ3yZcR8X1B2khmoDj', '_blank');
                                    e.preventDefault();
                                }}><Thumbnail source={Whatsapp} size="medium"/></p></Tooltip>
                                <Tooltip content="Skype">
                                    <p style={{cursor:'pointer'}} onClick={(e)=>{
                                                            window.open('https://join.skype.com/GbdPBTuVsNgN', '_blank')
                                                            e.preventDefault();
                                                        }}><Thumbnail source={Skype} size="medium"/>
                                    </p></Tooltip>
                                    <p style={{cursor:'pointer'}}><a style={{color:'black'}} href={
                                    'mailto:ebay_support@cedcommerce.com'
                                }><Tooltip content="ebay_support@cedcommerce.com"><TextStyle><Thumbnail source={Mail} size="medium"/></TextStyle></Tooltip></a>
                                    </p>
                                </Stack>
                            </Stack> 
                        </Card>
{/*                                    
                            <Card.Section>
                         <p style={{fontWeight:'bold',color:'grey'}}>You can always reach out to us via the following platforms</p> */}
                               
{/*                                 
                                    <Layout.Section oneThird>
                              
                                <Card sectioned>     
                                        <Stack distribution="equalSpacing" alignment="center" spacing="extraTight">  
                                            <Thumbnail source={Whatsapp} size="medium"/>
                                            <Button size="slim"  onClick={(e)=>{
                                        window.open('https://chat.whatsapp.com/I3qcRQ3yZcR8X1B2khmoDj', '_blank');
                                        e.preventDefault();
                                    }}>Start Chat</Button>    
                                        </Stack>
                                    </Card>
                                    </Layout.Section>
                                
                               <Layout.Section oneThird>
                                <Card sectioned>    
                                        <Stack distribution="equalSpacing" alignment="center" spacing="extraTight">    
                                            <Thumbnail source={Skype} size="medium"/>
                                               <Button size="slim" onClick={(e)=>{
                                        window.open('https://join.skype.com/GbdPBTuVsNgN', '_blank')
                                        e.preventDefault();
                                    }}>Start Chat</Button>
                                        </Stack>    
                                </Card>
                            </Layout.Section>
                                
                              <Layout.Section oneThird>
                                <Card sectioned>
                               
                                        <Stack distribution="equalSpacing" alignment="center" spacing="extraTight">
                                        <Thumbnail source={Mail} size="medium"/>
                                           
                                               <Tooltip content="ebay_support@cedcommerce.com">
                                    <TextStyle variation="strong"> <Button size="slim"><a style={{color:'black'}} href={
                                        'mailto:divyamishra@cedcommerce.com&cc=srajanshukla@cedcommerce.com'
                                    }>Send Mail</a></Button></TextStyle>
                                    </Tooltip>
                                        </Stack>    
                                    </Card>
                                    
                                    </Layout.Section>
                                  
                                 */}
                             
                            
                       
                   
                        

                        <Stack spacing={"tight"} vertical={true}>
                            <Card title="Have an issue?" sectioned>
                                    <Select
                                        label="Section" requiredIndicator
                                        options={options}
                                        onChange={this.handleSelectChange}
                                        placeholder="Select the section in which you are facing issue"
                                        value={this.state.option}
                                    />
                                    <br/>
                                    <TextField
                                        label="Issue" requiredIndicator
                                        placeholder="Describe the issue you are facing..."
                                        value={this.state.body}
                                        multiline={
                                            5
                                        }
                                        onChange={this.handleTextChange.bind(this,'body')}
                                    />
                                    <br/>
                                    <Button submit loading={scheduleDemoLoader} primary onClick={this.submit.bind(this)}>Submit</Button>
                                    </Card>
                                </Stack> 
                                </Stack>
                                </Layout.Section>
                                <Layout.Section oneHalf>
                                <Stack distribution={"fill"}>
                        <Card title={"Schedule demo"}>
                            <Card.Section>
                                <Stack vertical={true} >
                                    <Form onSubmit={this.submitMeetingSchedule.bind(this)}>
                                    <FormLayout >
                                    <FormLayout.Group condensed={true}>
                            <TextField requiredIndicator
                                label="Email address"
                                placeholder="Please provide email address.."
                                value={this.state.meeting.email}
                                type="email"
                                onChange={this.handleallTextChange.bind(this,'meeting', 'email')}
                            />
                           <Select requiredIndicator
                                label="Medium"
                                placeholder="Select Medium"
                                options={preferredMeeting}
                                onChange={this.handleallTextChange.bind(this,'meeting', 'preferred_meeting')}
                                
                                value={this.state.meeting.preferred_meeting}
                            />
                            </FormLayout.Group>
                                <FormLayout.Group condensed={true}>
                            <Select requiredIndicator
                                label="Time Zone"
                                placeholder="Select Time Zone"
                                options={timezone}
                                onChange={this.handleallTextChange.bind(this,'meeting', 'time_zone')}
                                
                                value={this.state.meeting.time_zone}
                            />
                            
                            <Select requiredIndicator
                                label="Time"
                                placeholder="Select Time"
                                options={preferredTime}
                                onChange={this.handleallTextChange.bind(this,'meeting', 'preferred_time')}
                                
                                value={this.state.meeting.preferred_time}
                            />
                                </FormLayout.Group>
                                <FormLayout.Group>
                                    <TextField
                                        label="Preferred Date"
                                        placeholder="Preferred date.."
                                        min={currentDateInString}
                                        
                                        value={this.state.meeting.date}
                                        type={"date"} requiredIndicator
                                        onChange={this.handleallTextChange.bind(this,'meeting', 'date')}
                                    />
                                </FormLayout.Group>
                           
                           
                            <TextField
                                label="Additional Note"
                                placeholder="Any additional note..."
                                multiline={3}
                                value={this.state.meeting.additional_note}
                                onChange={this.handleallTextChange.bind(this,'meeting', 'additional_note')}
                            />
                          
                             <Button submit loading={scheduleDemoLoader} primary>Submit</Button>
                            
                             </FormLayout>
                            </Form>
                                </Stack>
                                
                            </Card.Section>
                            
                        </Card>
                        
                                
                                
                    
                        </Stack>
                       
                               
                           
                            
                    </Layout.Section>
                  
                </Layout>
{/* 
                <FooterHelp>
    Learn more about{' '}
    <Link external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=contact-us-2">
    Contact Us
    </Link>
  </FooterHelp> */}
            </Page>
        );
    }
    redirect(url) {
        this.props.history.push(url);
    }
}

export default ReportAnIssue;
