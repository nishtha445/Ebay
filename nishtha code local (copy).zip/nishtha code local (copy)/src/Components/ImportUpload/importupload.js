import React, {Component} from 'react';
import {
    Page,
    Card,
    Select,
    Button,
    Label,
    Modal,
    Banner, Layout, Stack, FormLayout, DisplayText, Icon, Heading
} from '@shopify/polaris';
import { NavLink } from 'react-router-dom';
import Skeleton from "../../shared/skeleton";
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import {capitalizeWord, modifyAttributes} from "../../shared/static-functions";
import {environment} from "../../environments/environment";

class ImportUpload extends Component {
    profilesList = [];
    constructor() {
        super();
        this.state = {
            default_item_id: {
                separator: '_',
                attributes: [
                    {
                        attribute: '',
                        parent_attribute: '',
                        static_text: 'shopify'
                    },
                    {
                        attribute: 'targetCountry',
                        parent_attribute: 'marketplace_attribute',
                        static_text: ''
                    },
                    {
                        attribute: 'source_product_id',
                        parent_attribute: 'details',
                        static_text: ''
                    },
                    {
                        attribute: 'source_variant_id',
                        parent_attribute: 'variants',
                        static_text: ''
                    }
                ]
            },
            item_id_example: 'shopify_US_9330430195923_12800472882413',
            importServicesList: [],
            importerShopLists: [],
            uploadServicesList: [],
            uploaderShopLists: [],
            showImportProducts: false,
            showUploadProducts: false,
            importtype:'api',
            importProductsDetails: {
                source: '',
                shop: '',
                shop_id: ''
            },
            uploadProductDetails: {
                source: '',
                source_shop: '',
                source_shop_id: '',
                target: '',
                target_shop: '',
                target_shop_id: '',
                selected_profile: '',
                profile_type: ''
            },
            openModal: false,
            file_handle: {
                isfileUploaded: false,
                showDetails:false,
                fileuploaded_data: {}
            }
        };
        this.getAllImporterServices();
        this.getAllUploaderServices();
    }

    getAllImporterServices() {
        requests.getRequest('connector/get/services', { 'filters[type]': 'importer' })
            .then(data => {
                if (data.success === true) {
                    this.state.importServicesList = [];
                    for (let i = 0; i < Object.keys(data.data).length; i++) {
                        let key = Object.keys(data.data)[i];
                        if (data.data[key].usable || !environment.isLive) {
                            this.state.importServicesList.push({
                                label: data.data[key].title,
                                value: data.data[key].marketplace,
                                shops: data.data[key].shops
                            });
                        }
                    }
                    this.updateState();
                } else {
                    notify.error('Your product upload limit has expired. Upgrade your plan');
                }
            });
    }

    getAllUploaderServices() {
        requests.getRequest('connector/get/services', { 'filters[type]': 'uploader' })
            .then(data => {
                if (data.success === true) {
                    this.state.uploadServicesList = [];
                    for (let i = 0; i < Object.keys(data.data).length; i++) {
                        let key = Object.keys(data.data)[i];
                        if (data.data[key].usable || !environment.isLive) {
                            this.state.uploadServicesList.push({
                                label: data.data[key].title,
                                value: data.data[key].marketplace,
                                shops: data.data[key].shops
                            });
                        }
                    }
                    this.updateState();
                    if(this.state.uploadServicesList.length==0){
                        notify.info('Your product upload limit has expired. Upgrade your plan');
                    }
                } else {
                    notify.error('Your product upload limit has expired. Upgrade your plan');
                }
            });
    }

    renderDefaultIdBanner() {
        return (
            <Banner status="info" title={'By default the item ID generated is of this format:'}>
                <div style={{fontSize:'1.2rem'}}>
                    <Stack spacing={"none"}>
                        {
                            this.state.default_item_id.attributes.map((attribute) => {
                                if (attribute.static_text !== '') {
                                    return (
                                        <Stack.Item
                                            key={this.state.default_item_id.attributes.indexOf(attribute)}>
                                            {attribute.static_text}
                                            {
                                                this.state.default_item_id.attributes.indexOf(attribute) < (this.state.default_item_id.attributes.length - 1) &&
                                                <React.Fragment>{this.state.default_item_id.separator}</React.Fragment>
                                            }
                                        </Stack.Item>
                                    );
                                } else if (attribute.attribute !== '') {
                                    return (
                                        <Stack.Item
                                            key={this.state.default_item_id.attributes.indexOf(attribute)}>
                                            {'{{ ' + modifyAttributes(attribute.attribute) + ' }}'}
                                            {
                                                this.state.default_item_id.attributes.indexOf(attribute) < (this.state.default_item_id.attributes.length - 1) &&
                                                <React.Fragment>{this.state.default_item_id.separator}</React.Fragment>
                                            }
                                        </Stack.Item>
                                    );
                                }
                            })
                        }
                    </Stack>
                    <br/>
                    <Heading element={"h6"}>For Example:</Heading>
                    <p style={{marginTop:'1rem'}}>
                        {this.state.item_id_example}
                    </p>
                    <br/>
                    <p style={{fontSize:'1.2rem'}}>If you want to change it Goto Configurations > Custom Item ID or <NavLink to="/panel/configuration/customItemId">click here</NavLink>. In order to know more about Custom Item Id and how it affects my products Goto our <NavLink to="/panel/help?faq=item id">Help</NavLink> section.</p>
                </div>
            </Banner>
        );
    }


    renderImportProductsModal() {
        return (
            <div>
                <Modal
                    open={this.state.showImportProducts}
                    onClose={() => {
                        this.state.importtype='api'
                        this.state.showImportProducts = false;
                        this.state.file_handle.isfileUploaded= false;
                        this.state.file_handle.showDetails=false;
                        this.state.file_handle.fileuploaded_data={};
                        this.updateState();
                    }}
                    title="Import Products"
                    primaryAction={{disabled:this.state.importProductsDetails.source === ''?true:false,content:'Import Products',
                        onAction: this.importProducts.bind(this)

                    }}
                >
                    <Modal.Section>
                        <Stack vertical={true}>
                            <Select
                                label="Import From"
                                placeholder="Source"
                                options={this.state.importServicesList}
                                onChange={this.handleImportChange.bind(this, 'source')}
                                disabled={true}
                                value={this.state.importProductsDetails.source}
                            />

                            {
                                this.state.importProductsDetails.source !== '' &&
                                this.state.importerShopLists.length > 1 &&
                                <Select
                                    label="Shop"
                                    placeholder="Source Shop"
                                    options={this.state.importerShopLists}
                                    onChange={this.handleImportChange.bind(this, 'shop')}
                                    value={this.state.importProductsDetails.shop}
                                />
                            }
                        </Stack>
                    </Modal.Section>
                </Modal>
            </div>
        );
    }

    handleImportChange(key, value) {
        this.state.importProductsDetails[key] = value;
        if (key === 'source') {
            this.state.importerShopLists = [];
            this.state.importProductsDetails.shop = '';
            this.state.importProductsDetails.shop_id = '';
            for (let i = 0; i < this.state.importServicesList.length; i++) {
                if (this.state.importServicesList[i].value === value) {
                    for (let j = 0; j < this.state.importServicesList[i].shops.length; j++) {
                        this.state.importerShopLists.push({
                            label: this.state.importServicesList[i].shops[j].shop_url,
                            value: this.state.importServicesList[i].shops[j].shop_url,
                            shop_id: this.state.importServicesList[i].shops[j].id
                        });
                    }
                    break;
                }
            }
            if (this.state.importerShopLists.length > 0) {
                this.state.importProductsDetails.shop = this.state.importerShopLists[0].value;
                this.state.importProductsDetails.shop_id = this.state.importerShopLists[0].shop_id;
            }
        } else if (key === 'shop') {
            for (let i = 0; i < this.state.importerShopLists.length; i++) {
                if (this.state.importerShopLists[i].value === value) {
                    this.state.importProductsDetails.shop_id = this.state.importerShopLists[i].shop_id;
                    break;
                }
            }
        }
        this.updateState();
    }

    importProducts() {
        requests.getRequest('connector/product/import',
            {
                marketplace: this.state.importProductsDetails.source,
                shop: this.state.importProductsDetails.shop,
                shop_id: this.state.importProductsDetails.shop_id
            })
            .then(data => {
                this.state.showImportProducts = false;
                this.updateState();
                if (data.success === true) {
                    if (data.code === 'product_import_started') {
                        notify.info('Import process started. Check progress in activities section.');
                        setTimeout(() => {
                            this.redirect('/panel/queuedtasks');
                        }, 500);
                    } else {
                        notify.success(data.message);
                    }
                } else {
                    notify.error(data.message);
                }
            });
    }

    renderUploadProductsModal() {
        return (
            <Modal
                open={this.state.showUploadProducts}
                onClose={() => {
                    this.state.showUploadProducts = false;
                    this.updateState();
                }}
                title="Upload Products"
            >
                <Modal.Section>
                    <Stack vertical={true}>

                        <Banner status="info">
                            <Label>You can create an <NavLink to="/panel/profiling/create">Custom Profile</NavLink> for products upload. To know more about Profile and Default Profile visit our <NavLink to="/panel/help?faq=profile">Help</NavLink> section.</Label>
                        </Banner>
                        {this.renderDefaultIdBanner()}
                        {
                            this.profilesList.length > 0 &&
                            <Select
                                label="Select Profile"
                                options={this.profilesList}
                                placeholder="Custom Profile"
                                onChange={this.handleProfileSelect.bind(this)}
                                value={this.state.uploadProductDetails.selected_profile}
                            />
                        }
                        {
                            this.profilesList.length === 0 &&
                            <React.Fragment>
                                <Banner status="warning">
                                    <Label>No profiles for {capitalizeWord(this.state.uploadProductDetails.source)} and {capitalizeWord(this.state.uploadProductDetails.target)} integration</Label>
                                </Banner>
                                <Stack alignment={"center"} vertical={true}>
                                    <Button onClick={() => {
                                        this.redirect('/panel/profiling/create');
                                    }} primary>
                                        Create Profile
                                    </Button>
                                    <Button onClick={() => {
                                        this.state.uploadProductDetails.profile_type = '';
                                        this.state.uploadProductDetails.selected_profile = 'default_profile';
                                        this.updateState();
                                    }} primary>
                                        Select Default Profile
                                    </Button>
                                </Stack>
                            </React.Fragment>
                        }

                        <Stack alignment={"center"} vertical={true}>
                            <Button onClick={() => {
                                this.uploadProducts();
                            }}
                                    disabled={!(this.state.uploadProductDetails.source !== '' &&
                                        this.state.uploadProductDetails.target !== '' &&
                                        this.state.uploadProductDetails.selected_profile !== '')}
                                    primary>
                                Upload Products
                            </Button>
                        </Stack>
                    </Stack>
                </Modal.Section>
            </Modal>
        );
    }

    handleProfileSelect(profile) {
        if ( profile === 'default_profile' ) {
            this.handleUploadChange('selected_profile',profile);
        } else {
            this.state.uploadProductDetails.selected_profile = profile;
            this.updateState();
        }
    }

    handleUploadChange(key, value) {
        switch (key) {
            case 'selected_profile':
                if (value === 'custom_profile') {
                    if (this.state.uploadProductDetails.source === '' ||
                        this.state.uploadProductDetails.target === '') {
                        notify.info('Please choose product import source and product upload target first');
                    } else {
                        this.getMatchingProfiles();
                        this.state.uploadProductDetails.profile_type = 'custom';
                        this.state.uploadProductDetails[key] = '';
                    }
                } else {
                    this.state.uploadProductDetails.profile_type = '';
                    this.state.uploadProductDetails[key] = value;
                }
                break;
            case 'source':
                this.state.importerShopLists = [];
                this.state.uploadProductDetails.source = value;
                this.state.uploadProductDetails.profile_type = '';
                this.state.uploadProductDetails.selected_profile = 'default_profile';
                this.state.uploadProductDetails.source_shop = '';
                this.state.uploadProductDetails.source_shop_id = '';
                for (let i = 0; i < this.state.importServicesList.length; i++) {
                    if (this.state.importServicesList[i].value === value) {
                        for (let j = 0; j < this.state.importServicesList[i].shops.length; j++) {
                            this.state.importerShopLists.push({
                                label: this.state.importServicesList[i].shops[j].shop_url,
                                value: this.state.importServicesList[i].shops[j].shop_url,
                                shop_id: this.state.importServicesList[i].shops[j].id
                            });
                        }
                        break;
                    }
                }
                if (this.state.importerShopLists.length > 0) {
                    this.state.uploadProductDetails.source_shop = this.state.importerShopLists[0].value;
                    this.state.uploadProductDetails.source_shop_id = this.state.importerShopLists[0].shop_id;
                }
                break;
            case 'target':
                this.state.uploaderShopLists = [];
                this.state.uploadProductDetails.target = value;
                this.state.uploadProductDetails.profile_type = '';
                this.state.uploadProductDetails.selected_profile = 'default_profile';
                this.state.uploadProductDetails.target_shop = '';
                this.state.uploadProductDetails.target_shop_id = '';
                for (let i = 0; i < this.state.uploadServicesList.length; i++) {
                    if (this.state.uploadServicesList[i].value === value) {
                        for (let j = 0; j < this.state.uploadServicesList[i].shops.length; j++) {
                            this.state.uploaderShopLists.push({
                                label: this.state.uploadServicesList[i].shops[j].shop_url,
                                value: this.state.uploadServicesList[i].shops[j].shop_url,
                                shop_id: this.state.uploadServicesList[i].shops[j].id
                            });
                        }
                        break;
                    }
                }
                if (this.state.uploaderShopLists.length > 0) {
                    this.state.uploadProductDetails.target_shop = this.state.uploaderShopLists[0].value;
                    this.state.uploadProductDetails.target_shop_id = this.state.uploaderShopLists[0].shop_id;
                }
                break;
            case 'source_shop':
                this.state.uploadProductDetails.profile_type = '';
                this.state.uploadProductDetails.selected_profile = 'default_profile';
                for (let i = 0; i < this.state.importerShopLists.length; i++) {
                    if (this.state.importerShopLists[i].value === value) {
                        this.state.uploadProductDetails.source_shop_id = this.state.importerShopLists[i].shop_id;
                        this.state.uploadProductDetails.source_shop = this.state.importerShopLists[i].value;
                        break;
                    }
                }
                break;
            case 'target_shop':
                this.state.uploadProductDetails.profile_type = '';
                this.state.uploadProductDetails.selected_profile = 'default_profile';
                for (let i = 0; i < this.state.uploaderShopLists.length; i++) {
                    if (this.state.uploaderShopLists[i].value === value) {
                        this.state.uploadProductDetails.target_shop_id = this.state.uploaderShopLists[i].shop_id;
                        this.state.uploadProductDetails.target_shop = this.state.uploaderShopLists[i].value;
                        break;
                    }
                }
                break;
        }
        this.updateState();
    }

    getMatchingProfiles() {
        this.profilesList = [];
        const data = {
            source: this.state.uploadProductDetails.source,
            target: this.state.uploadProductDetails.target
        };
        if (this.state.uploadProductDetails.source_shop !== '' &&
            this.state.uploadProductDetails.source_shop !== null) {
            data['source_shop'] = this.state.uploadProductDetails.source_shop;
        }
        if (this.state.uploadProductDetails.target_shop !== '' &&
            this.state.uploadProductDetails.target_shop !== null) {
            data['target_shop'] = this.state.uploadProductDetails.target_shop;
        }
        requests.getRequest('connector/profile/getMatchingProfiles', data)
            .then(data => {
                if (data.success) {
                    this.profilesList.push({
                        label: 'Default Profile(Upload products with Default Settings)',
                        value: 'default_profile'
                    });
                    for (let i = 0; i < data.data.length; i++) {
                        this.profilesList.push({
                            label: data.data[i].name,
                            value: data.data[i].id
                        });
                    }
                    this.updateState();
                } else {
                    notify.error(data.message);
                }
            });
    }

    uploadProducts() {
        const data = Object.assign({}, this.state.uploadProductDetails);
        data['marketplace'] = data['target'];
        if(this.state.uploadProductDetails.target_shop_id!=='') {
            requests.postRequest('connector/product/upload', data)
                .then(data => {
                    this.state.showUploadProducts = false;
                    if (data.success) {
                        if (data.code === 'product_upload_started') {
                            notify.info('Upload process started. Check progress in activities section.');
                            setTimeout(() => {
                                this.redirect('/panel/queuedtasks');
                            }, 500);
                        } else {
                            notify.success(data.message);
                        }
                    } else {
                        notify.error(data.message);
                        if (data.code === 'link_your_account') {
                            setTimeout(() => {
                                this.redirect('/panel/accounts');
                            }, 1200);
                        }
                    }
                    this.updateState();
                });
        }
        else {
            notify.info('Your product upload limit has expired. Upgrade your plan');
        }
    }

    testAction(){
        requests.getRequest('frontend/test/login').then(data=>{
            console.log(data);
        })
    }
    testAction1(){
        requests.getRequest('frontend/app/getOrderDatewise',{timeline:'monthly'}).then(data=>{
            console.log(data);
        })
    }

    render() {
        return (
            <Page
                fullWidth={true}
                title="Manage Products" /*primaryAction={{content:"Test",onAction:this.testAction.bind(this)}}*/
            >
                <FormLayout>
                    <br/>
                    <Banner title="Follow these steps:" status="info">
                        <ul style={{fontSize:'1.3rem'}}>
                            <li>
                                Import your product drom Shopify to App.
                            </li>
                            <li>
                                Then upload your Products from App to Merchant center, You can upload it by <NavLink to="/panel/help?faq=profiling">Default Profile</NavLink> or by <NavLink to="/panel/profiling/create">Custom Profile</NavLink>
                            </li>
                        </ul>
                        <Label>
                            <strong>Note:</strong> You can check your products <NavLink to="/panel/products">here</NavLink>
                        </Label>
                    </Banner>
                    <Stack vertical={false} alignment={"center"} distribution={"fillEvenly"}>
                        {this.state.importServicesList.length < 1 && this.state.uploadServicesList < 1 ?
                            <Skeleton case="dounut"/> :
                            <Card>
                                <Card.Section>
                                    <div style={{cursor: 'pointer'}} onClick={() => {
                                        this.state.importProductsDetails.source = '';
                                        this.state.importProductsDetails.shop = '';
                                        this.state.importProductsDetails.shop_id = '';
                                        this.handleImportChange('source', 'shopify');
                                        this.state.showImportProducts = true;
                                        this.updateState();
                                    }}>
                                        <Stack vertical={true} alignment={"center"}>
                                            <img src={require('../../assets/img/import.png')} height={'100rem'}/>
                                            <p style={{fontSize:'2rem',color: '#3f4eae',fontWeight:'bold'}}>Import Products</p>
                                            <p style={{fontSize:'1rem',fontWeight:'bold'}}>(From Shopify To App)</p>
                                        </Stack>
                                    </div>
                                </Card.Section>
                            </Card>
                        }


                        {this.state.importServicesList.length < 1 && this.state.uploadServicesList < 1 ?
                            <Skeleton case="dounut"/> :
                            <Card>
                                <Card.Section>
                                    <div style={{cursor: 'pointer'}} onClick={() => {
                                        this.state.uploadProductDetails.source = '';
                                        this.state.uploadProductDetails.target = '';
                                        this.state.uploadProductDetails.selected_profile = 'default_profile';
                                        this.state.uploadProductDetails.profile_type = '';
                                        this.state.showUploadProducts = true;
                                        this.handleUploadChange('source', 'shopify');
                                        this.handleUploadChange('target', 'google');
                                        this.handleUploadChange('selected_profile', 'default_profile');
                                        this.getMatchingProfiles();
                                        this.updateState();
                                    }}>
                                        <Stack vertical={true} alignment={"center"}>
                                            <img src={require('../../assets/img/upload.png')} height={'100rem'}/>
                                            <p style={{fontSize:'2rem',color: '#3f4eae',fontWeight:'bold'}}>Upload Products</p>
                                            <p style={{fontSize:'1rem',fontWeight:'bold'}}>(From App To Google)</p>
                                        </Stack>
                                    </div>
                                </Card.Section>
                            </Card>
                        }
                    </Stack>
                </FormLayout>
                {this.renderImportProductsModal()}
                {this.renderUploadProductsModal()}
            </Page>
        );
    }

    updateState() {
        const state = this.state;
        this.setState(state);
    }

    redirect(url) {
        this.props.history.push(url);
    }
}

export default ImportUpload;
