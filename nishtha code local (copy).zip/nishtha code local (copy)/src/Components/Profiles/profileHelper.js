import React from 'react';
import { Badge, Icon, Stack, TextStyle, Tooltip } from "@shopify/polaris";
import { DeleteMajorMonotone, EditMajorMonotone, ViewMajorMonotone } from "@shopify/polaris-icons";

function actionRenderer(incellFunc, params) {
    // console.log('params', params)
    return (
        <Stack vertical={false} distribution={"leading"} >
            {/* <Tooltip content={"Preview"}>
                <p onClick={incellFunc.bind(this, 'preview', params.data)}>
                    <Icon source={ViewMajorMonotone} />
                </p>
            </Tooltip> */}
            <Tooltip content={"Edit"}>
                <p onClick={incellFunc.bind(this, 'edit', params.data)} style={{cursor:'pointer'}}>
                    <Icon source={EditMajorMonotone} />
                </p>
            </Tooltip>
            <Tooltip content={"Delete"}>
                <p onClick={incellFunc.bind(this, 'delete', params.data)} style={{cursor:'pointer'}}>
                    <Icon source={DeleteMajorMonotone} />
                </p>
            </Tooltip>
        </Stack>
    );
}

function titleDetails(incellElement, params) {
    // console.log('params', params)
    let { value: titlte } = params;
    // return <p>{titlte}</p>
    return <Tooltip content={"Edit"} preferredPosition="above">
        <div style={{ cursor: 'pointer' }} onClick={(e) => {
            incellElement('edit', params.data);
            e.preventDefault();
        }} onMouseOver={e => {
            e.target.style.textDecoration = 'underline';
        }} onMouseOut={e => {
            e.target.style.textDecoration = 'none';
        }}>
            <TextStyle variation="strong">
                {titlte}
                {/* {titlte.length > 30 ? titlte.slice(0, 30) + "...." : titlte} */}
            </TextStyle>
        </div>
    </Tooltip>
}

export function gridPropColumns(incellElement = () => { }, innerWidth) {
    let deductedWidth = innerWidth;
    let imageWidth = 120;
    let profileIDWidth = deductedWidth/3;
    let titleWidth = deductedWidth/2;
    let queryWidth = deductedWidth/1;
    let productCountWidth = deductedWidth/3;
    if(innerWidth >= 425) {
        deductedWidth = innerWidth - (innerWidth*15/100);
        imageWidth = 120;
        profileIDWidth = deductedWidth/3;
        titleWidth = deductedWidth/2;
        queryWidth = deductedWidth/1;
        productCountWidth = deductedWidth/4;
    }
    if(innerWidth >= 768) {
        deductedWidth = innerWidth - (innerWidth*15/100);
        imageWidth = 120;
        profileIDWidth = deductedWidth/6;
        titleWidth = deductedWidth/4;
        queryWidth = deductedWidth/3;
        productCountWidth = deductedWidth/7;
    } 
    if(innerWidth >= 1366) {
        deductedWidth = innerWidth - (innerWidth*15/100);
        imageWidth = 120;
        profileIDWidth = deductedWidth/11;
        titleWidth = deductedWidth/2;
        queryWidth = deductedWidth/3;
        productCountWidth = deductedWidth/9;
    }
    return [
        {
            headerName: "Actions", field: "actions",
            autoHeight: true,
            width: 100,
            pinned: 'right',
            cellRendererFramework: actionRenderer.bind(this, incellElement.bind(this)),
            // resizable: true, 
        },
        {
            headerName: 'Profile ID', field: 'profile_id',
            sortable: true,
            resizable: true, 
            // cellRendererFramework: titleDetails.bind(this, incellElement.bind(this)),
            width: profileIDWidth
        },
        {
            headerName: 'Name', field: 'name',
            cellRendererFramework: titleDetails.bind(this, incellElement.bind(this)),
            sortable: true,
            // width: 400,
            resizable: true, 
            width: titleWidth
        },
        {
            headerName: "Count", field: 'productCount',
            sortable: true,
            // width: 300,
            resizable: true, 
            // cellRendererFramework: productTypeDetails.bind(this, incellElement.bind(this)),
            width: productCountWidth
        },
        {
            headerName: "Query", field: 'query',
            sortable: true,
            // width: 400,
            resizable: true, 
            // cellRendererFramework: productTypeDetails.bind(this, incellElement.bind(this)),
            width: queryWidth
        },
    ]
};

export const pageSizeOptionProducts = [50, 100, 150, 200];

export function getpaginationInfo(totalrecords, pageSize) {
    let pages = Math.ceil(parseInt(totalrecords) / parseInt(pageSize));
    return { pages, totalrecords };
}

export function extractValuesfromRequest(rows = [], user_id = '') {
    // console.log(rows)
    let modifiedRows = [];
    // console.log('rows', rows);
    rows.forEach(row => {
        // console.log('rows', row);
        // let { image_main, title, product_type, vendor } = row.details
        let { name, query, product_count, profile_id } = row;
        // product_count = `${product_count} products in profile `;
        product_count = `${product_count} products`;
        // data['targetCategory']=(row["targetCategory"] !== ""?row["targetCategory"]:<div title={" "}><img title={""} src={require("../../assets/img/dots.png")}/></div>)
        modifiedRows.push({
            // main_image: image_main,
            name,
            query,
            productCount: product_count,
            profile_id,
            previewJSONData: row
        })
    });
    return modifiedRows;
}

export const filterCondition = [
    { label: 'equals', value: "1", disable_for: ['query'] },
    { label: 'not equals', value: "2", disable_for: ['query']  },
    {
        label: 'contains', value: "3"
    },
    {
        label: 'does not contains', value: "4"
    },
    {
        label: 'starts with', value: "5", disable_for: ['query'] 
    },
    {
        label: 'ends with', value: "6", disable_for: ['query'] 
    }
];

export const filterOptions = [
    {
        headerName: "Name", field: "name"
    },
    {
        headerName: "Query", field: "query"
    },
];

export function getFilterforRequest(filters = []) {
    // console.log(filters);
    let tempObj = {};
    filters.forEach(filter => {
        tempObj[`filter[${filter['attribute']}][${filter['condition']}]`] = filter['value'];
    });
    // console.log('filter', tempObj);
    return tempObj;
}
