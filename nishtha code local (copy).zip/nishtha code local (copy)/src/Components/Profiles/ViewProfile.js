import React, {Component} from 'react';
import {
  Page,
  Layout,
  TextField,
  Card,
  Stack,
  Heading,
  Select,
  Banner,
  Label,
  Autocomplete,
  Button,
  FormLayout,
  Collapsible,
  ButtonGroup,
  DataTable, Pagination, ChoiceList, Thumbnail, Icon
} from "@shopify/polaris";
import {isUndefined} from "util";
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import * as queryString from "query-string";
import Skeleton from "../../shared/skeleton";
import SmartDataTable from "../../shared/smartTable/SmartDataTable";
import {paginationShow} from "../../shared/static-functions";
import {SearchMinor} from "@shopify/polaris-icons";
import LoadingOverlay from 'react-loading-overlay';
import notfound from '../../assets/img/notfound.png';
const shippingPackageType = [
  {label:'Unselect',value:''},
  {label:'Bulky Goods',value:'C_BULKY_GOODS'},
  {label:'Caravan',value:'C_CARAVAN'},
  {label:'Cars',value:'C_CARS'},
  {label:'Custom Code',value:'C_CUSTOM_CODE'},
  {label:'Europallet',value:'C_EUROPALLET'},
  {label:'Expandable Tough Bags',value:'C_EXPANDABLE_TOUGH_BAGS'},
  {label:'ExtraLargePack',value:'C_EXTRA_LARGE_PACK'},
  {label:'Furniture',value:'C_FURNITURE'},
  {label:'Industry Vehicles',value:'C_INDUSTRY_VEHICLES'},
  {label:'Large Canada PostBox',value:'C_LARGE_CANADA_POST_BOX'},
  {label:'Large Canada Post Bubble Mailer',value:'C_LARGE_CANADA_POST_BUBBLE_MAILER'},
  {label:'Large Envelope',value:'C_LARGE_ENVELOPE'},
  {label:'Letter',value:'C_LETTER'},
  {label:'MailingBoxes',value:'C_MAILING_BOXES'},
  {label:'MediumCanadaPostBox',value:'C_MEDIUM_CANADA_POST_BOX'},
  {label:'MediumCanadaPostBubbleMailer',value:'C_MEDIUM_CANADA_POST_BUBBLE_MAILER'},
  {label:'Motorbikes',value:'C_MOTORBIKES'},
  {label:'None',value:'C_NONE'},
  {label:'One Way Pallet',value:'C_ONE_WAY_PALLET'},
  {label:'Package Thick Envelope',value:'C_PACKAGE_THICK_ENVELOPE'},
  {label:'Padded Bags',value:'C_PADDED_BAGS'},
  {label:'Parcel Or Padded Envelope',value:'C_PARCEL_OR_PADDED_ENVELOPE'},
  {label:'Roll',value:'C_ROLL'},
  {label:'Small Canada PostBox',value:'C_SMALL_CANADA_POST_BOX'},
  {label:'Small Canada Post BubbleMailer',value:'C_SMALL_CANADA_POST_BUBBLE_MAILER'},
  {label:'Tough Bags',value:'C_TOUGH_BAGS'},
  {label:'UPS Letter',value:'C_UPS_LETTER'},
  {label:'USPS Flat Rate Envelope',value:'C_USPS_FLAT_RATE_ENVELOPE'},
  {label:'USPS Large Pack',value:'C_USPS_LARGE_PACK'},
  {label:'Very Large Pack',value:'C_VERY_LARGE_PACK'},
  {label:'Winepak',value:'C_WINEPAK'},
];
const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');

class ViewProfile extends Component {
  filters = {
    column_filters: {}
  };
  gridSettings = {
    activePage: 1,
    count: '5'
  };
  pageLimits = [
    {label: 5, value: '5'},
    {label: 10, value: '10'},
    {label: 15, value: '15'},
    {label: 20, value: '20'},
    {label: 25, value: '25'}
  ];
  visibleColumns = ['main_image', 'title', 'sku', 'price'];
  visibleColumnsTestQuery = ['title'];
  imageColumns = ['main_image'];
  columnTitles = {
    source_product_id: {
      title: 'Product ID',
      sortable: false
    },
    main_image: {
      title: 'Image',
      sortable: false
    },
    title: {
      title: 'Title',
      sortable: false
    },
    type: {
      title: 'Type',
      sortable: false
    },
    quantity: {
      title: 'Quantity',
      sortable: false
    },
    sku: {
      title: 'Vendor',
      sortable: false
    },
    price: {
      title: 'Product Type',
      sortable: false
    },
    weight: {
      title: 'Weight',
      sortable: false
    },
    weight_unit: {
      title: 'Weight Unit',
      sortable: false
    }
  };

  importServices = [];
  uploadServices = [];
  importShopLists = [];
  uploadShopLists = [];
  sourceAttributes = [];
  filteredProducts = {
    runQuery: false,
    totalProducts: 0
  };
  filterConditions = [
    { label: "Equals", value: "==" },
    { label: "Not Equals", value: "!=" },
    { label: "Contains", value: "%LIKE%" },
    { label: "Does Not Contains", value: "!%LIKE%" },
    { label: "Greater Than", value: ">" },
    { label: "Less Than", value: "<" },
    { label: "Greater Than Equal To", value: ">=" },
    { label: "Less Than Equal To", value: "<=" }
  ];

  constructor(props){
    super(props);
    this.state={
      grid_loader: false,
      showCollectionDetails: false,
      autocomplete : {
        shipping_policy : {
             selected : '',
             textsearch : '',
             options:[]
        },
        payment_policy : {
          selected : '',
          textsearch : '',
          options:[]
        },
        return_policy : {
          selected : '',
          textsearch : '',
          options:[]
        },
        inventory_template : {
          selected : '',
          textsearch : '',
          options:[]
        },
        pricing_template : {
          selected : '',
          textsearch : '',
          options:[]
        },
        title_template :{
          selected : '',
          textsearch : '',
          options:[]
        },
        category_template : {
          selected : '',
          textsearch : '',
          options:[]
        }
     },
      form_data:{
        profile_name:'',
        dropdown: {
          shipping_policy:{
            heading:'Shipping Policy',
            selected_id:'',
            show_dropdown:false,
            options:[]
          },

          payment_policy:
            {
              heading:'Payment Policy',
              selected_id:'',
              show_dropdown:false,
              options:[]
            },
          return_policy:{
            heading:'Return Policy',
            selected_id:'',
            show_dropdown:false,
            options:[]
          },

          inventory_template:{
            heading:'Inventory template',
            selected_id:'',
            key:'inventory',
            show_dropdown:false,
            options:[]
          },
          pricing_template:{
            heading:'Pricing template',
            selected_id:'',
            key:'pricing',
            show_dropdown:false,
            options:[]
          },
          title_template:{
            heading:'Title template',
            selected_id:'',
            key:'title',
            show_dropdown:false,
            options:[]
          },
          category_template:{
            heading:'Category template',
            selected_id:'',
            key:'category',
            show_dropdown:false,
            options:[]
          },
        },

        basicDetails: {
          source: "shopify",
          sourceShop: "",
          targetShop: "",
          target: "ebay"
        },
        variation_image_setting:[],
        shipping_package_type : "",
        queryBuilder:{

          filterQuery: {
            primaryQuery: [
              {
                key: "",
                operator: "",
                value: ""
              }
            ],
            condition: "AND",
            position: 1,
            secondaryQuery: {}
          },

          products_select: {
            query: "",
            targetCategory: "",
            marketplaceAttributes: []
          },

          sourceAttributes: []

        },


      },
      editFilterQuery:false,
      profileUpdated : false,

      profileData:{
        query:'',
      },
      profile_id:'',
      options_recieved:{
        shopifyattrib:[],
      },
      errors:{
        profile_name:false,
        shipping_policy: false,
        payment_policy: false,
        return_policy: false,
        title_template: false,
        pricing_template: false,
        inventory_template: false,
        category_template: false,
        querybuilder:false,
      },
      businessPolicyprepared:false,
      templatesPrepared:false,
      QuerybuilderLoader:false,
      newFilteredData:false,
      site_id:'',
      products:[],
      loader_import_collection:false,
      loader_update_collection:false,
      collections_options : [],
      collection_selected : '',
      pagination_show: 0,
      totalPage: 0,
      // utkarsh
      saveBtnLoader: false
    }
    this.getBusinessPolicy();
    this.getTemplates();
    this.fetchDataForSteptwo();
    this.getImportServices();
    this.getUploadServices();
  }

  setShopifyAttribute(data){
    let temparr=[];
    data.forEach((value,index)=>{
      temparr.push({label:value,value:value})
    });
    this.state.options_recieved.shopifyattrib=temparr;
    this.setState(this.state);
  }
  getShopifyConfigurableAttributes(){
    requests.getRequest('connector/get/configurableAttributes').then(data=>{
      if(data.success){
        this.setShopifyAttribute(data.data);
      }
    })
  }


  handleBasicDetailsChange(key, value) {
    this.state.form_data.basicDetails[key] = value;
    switch (key) {
      case "source":
        for (let i = 0; i < this.importServices.length; i++) {
          if (this.importServices[i].value === value) {
            this.importShopLists = [];
            for (let j = 0; j < this.importServices[i].shops.length; j++) {
              this.importShopLists.push({
                label: this.importServices[i].shops[j].shop_url,
                value: this.importServices[i].shops[j].shop_url,
                shop_id: this.importServices[i].shops[j].id
              });
            }
            this.state.form_data.basicDetails.sourceShop =
              this.importShopLists.length > 0
                ? this.importShopLists[0].value
                : "";
          }
        }
        break;
      case "target":
        for (let i = 0; i < this.uploadServices.length; i++) {
          if (this.uploadServices[i].value === value) {
            this.uploadShopLists = [];
            for (let j = 0; j < this.uploadServices[i].shops.length; j++) {
              this.uploadShopLists.push({
                label: this.uploadServices[i].shops[j].site_id,
                value: this.uploadServices[i].shops[j].site_id,
                shop_id: this.uploadServices[i].shops[j].id
              });
            }
            this.state.form_data.basicDetails.targetShop =
              this.uploadShopLists.length > 0
                ? this.uploadShopLists[0].value
                : "";
          }
        }
        break;
    }
    this.updateState();
  }
  componentDidMount(){
    this.getProfileID();
    this.getShopifyConfigurableAttributes();
    this.getSideID();
  }

  getSideID() {
    requests.getRequest('ebayV1/get/siteId').then(data => {
      if (data.success) {
        this.state.site_id = !isUndefined(data.data.site_id) ? data.data.site_id : '';
        // this.state.site_id ='MOTORS';
      }
      this.setState(this.state);
    });

  }

  getProfileID(){
    let queryparams = queryString.parse(this.props.location.search);
    if(!isUndefined(queryparams['message'])) {
      let data_recieved = JSON.parse(cryptr.decrypt(decodeURI(queryparams['message'])));
      if (!isUndefined(data_recieved['id'])) {
        this.state.profile_id = data_recieved['id'];
      }
    }else{
      this.redirect('/panel/profiles');
    }
    this.setState(this.state);
    this.getProfileData()
  }

  populateFilters(query, attributes){

    let finalQuery = {};
    let finalQueryArray = [];
    let dividebyOrQuery = query.split("||");
    let Orquery = [];
    dividebyOrQuery.forEach((elementOr) => {
      let removeWhiteSpaces = elementOr.trim();
      let removeOpeningBrackets = removeWhiteSpaces.replace("(","");
      let removeClosingBrackets = removeOpeningBrackets.replace(")","");
      let dividebyAndQuery = removeClosingBrackets.split('&&');
      let AndelementsQuery = [];
      dividebyAndQuery.forEach((elementAnd) =>{
        let removeWhiteSpaceAnd = elementAnd.trim();
        AndelementsQuery.push(removeWhiteSpaceAnd);
      });
      Orquery.push(AndelementsQuery);
    });
    Orquery.forEach((queryElement, index) => {
      let andElementsFinal = [];
      queryElement.forEach(andQueryElements => {

        let attributeToDivideFromFilter = this.filterConditions.filter( filterCond => andQueryElements.includes(` ${filterCond.value} `));
        let attributeToDivideFrom = " ";
        if(attributeToDivideFromFilter.length) {
          attributeToDivideFrom = attributeToDivideFromFilter[0]['value'];
        }

         let finalDividebyAndTest = andQueryElements.split(attributeToDivideFrom);
        finalDividebyAndTest = finalDividebyAndTest.map(filterVal => filterVal.trim());
         let finalDividebyAnd = andQueryElements.split(" ");

         let optionsIfexists = attributes.filter( attribObj => attribObj.value === finalDividebyAnd[0]);

         let optionsField = '';
         if( optionsIfexists.length && optionsIfexists[0].hasOwnProperty('options_shopify')){

           optionsField  = [...this.dictionedData(optionsIfexists[0].options_shopify)];

         }
         andElementsFinal.push({
           key: finalDividebyAndTest[0],
           operator: finalDividebyAnd[1],
           value: finalDividebyAndTest[1],
           options: optionsField!=='' && optionsField.length > 0? [...optionsField]:undefined,
         });
       });
      let tempObj = {
        primaryQuery: [...andElementsFinal],
       position : index+1,
       condition : index === 0?'AND':'OR',
        secondaryQuery:{}
      };
      finalQueryArray.push({...tempObj});
    });
    finalQueryArray.slice().reverse().forEach((finalizeElement) => {
      let tempOBjFinal = {...finalizeElement};
      if(finalQuery.hasOwnProperty('secondaryQuery')){
        tempOBjFinal.secondaryQuery ={
          ...finalQuery
        }
        finalQuery = { ... tempOBjFinal };
      }else {
        finalQuery = {
          ...finalizeElement
        }
      }
    })
    this.state.form_data.queryBuilder.filterQuery = {...finalQuery};
    this.setState(this.state);

  }

  getProfileData(){
    this.setState({grid_loader: true})
    requests.postRequest('connector/profile/getProfile', {
      id: this.state.profile_id
    }).then(data=>{
      if(data.success) {

        this.state.profileData = data.data;
        this.state.products = this.modifyProductsData(data.data.products_data);
        this.state.pagination_show = paginationShow(this.gridSettings.activePage, this.gridSettings.count, data.data.products_data_count, true)
        this.state.form_data.profile_name = data.data.name;
        this.state.form_data.shipping_package_type = data.data.shipping_package_type;
        this.state.totalPage = data.data.products_data_count;
        this.settemplatesPolicy(data.data.marketplaceAttributes);
        this.populateFilters(data.data.query, this.sourceAttributes);
        if(data.data.query.includes('collections')) {
          this.setState({showCollectionDetails: true})
        }
      }
      else{
        notify.error(data.message)
        this.redirect('/panel/profiles');
      }
      this.setState({grid_loader: false})
    })

  }

  modifyProductsData(data) {
    // console.log('data', data)
    let products = [];
    for (let i = 0; i < data.length; i++) {
      let rowData = {};
      rowData['source_product_id'] = data[i].details.source_product_id;
      // rowData['main_image'] = <Thumbnail source={data[i].variants['main_image']}/>;
      rowData['main_image'] = <Thumbnail source={data[i].details.image_main === '' ? notfound : data[i].details.image_main}/>;
      rowData['title'] = data[i].details.title;
      rowData['sku'] = data[i].details.vendor === '' ? 'N/A' : data[i].details.vendor ;
      rowData['price'] = data[i].details.product_type === '' ? 'N/A' : data[i].details.product_type;
      // rowData['sku'] = data[i].variants['sku'];
      // rowData['price'] = data[i].variants['price'];
      rowData['quantity'] = data[i].variants['quantity'];
      rowData['type'] = data[i].details.type;
      rowData['weight'] = data[i].variants['weight'];
      rowData['weight_unit'] = data[i].variants['weight_unit'];
      products.push(rowData);
    }
    return products;
  }

  settemplatesPolicy(data){
    if(!isUndefined(data)){
      Object.keys(data).map(key=>{
        this.state.form_data.dropdown[key].selected_id=data[key];
      })
    }
    this.setState(this.state);
  }


  operations(data,event) {
    // switch (event) {
    //     case 'grid':
    //         let tempObj={id:data['profile_id']}
    //         let message=cryptr.encrypt(JSON.stringify(tempObj));
    //         this.redirect('/panel/profiles/viewprofile?message=' + message);break;
    //     default:
    //         let tempObj1={id:data['profile_id']}
    //         let message1=cryptr.encrypt(JSON.stringify(tempObj1));
    //         this.redirect('/panel/profiles/viewprofile?message=' + message1);break;
    // }
  }

  getImportServices() {
    requests
      .getRequest("connector/get/services", { "filters[type]": "importer" })
      .then(data => {
        if (data.success === true) {
          this.importServices = [];
          for (let i = 0; i < Object.keys(data.data).length; i++) {
            let key = Object.keys(data.data)[i];
            if(key === 'shopify_importer') {
              this.importServices.push({
                label: data.data[key].title,
                value: data.data[key].marketplace,
                shops: data.data[key].shops
              });
            }
          }
          this.handleBasicDetailsChange("source", "shopify");
          this.updateState();
        } else {
          notify.error(
            "You have no available product import service. Kindly choose a plan."
          );
        }
      });
  }



  getUploadServices() {
    requests
      .getRequest("connector/get/services", { "filters[type]": "uploader" })
      .then(data => {
        if (data.success) {
          this.uploadServices = [];
          for (let i = 0; i < Object.keys(data.data).length; i++) {
            let key = Object.keys(data.data)[i];
            if(key==='ebay_uploader') {
              this.uploadServices.push({
                label: data.data[key].title,
                value: data.data[key].marketplace,
                shops: data.data[key].shops
              });
            }
          }
          this.handleBasicDetailsChange("target", "ebay");
          this.updateState();
        } else {
          notify.error(
            "You have no available product upload service. Kindly choose a plan."
          );
        }
      });
  }



  redirect(url){
    this.props.history.push(url);
  }

  fetchDataForSteptwo(fetchMarketplaceAttributes) {
    this.getSourceAttributes();
  }
  dictionedData(data){
    let Obj ={};
    data.forEach((option,index)=>{
      Obj[option.label] = index;
    });
    let Ordered_Array = [];

    Object.keys(Obj).sort().forEach(key =>{
      if(!(data[Obj[key]]['label']).includes(data[Obj[key]]['value']))
        data[Obj[key]]['label'] = data[Obj[key]]['label']+"-"+data[Obj[key]]['value'];
      Ordered_Array.push(data[Obj[key]]);
    });
    return Ordered_Array;
  }

  getSourceAttributes() {
    requests
      .getRequest("ebayV1/get/getSourceAttributes", {
        marketplace: 'shopify'
      })
      .then(data => {
        if (data.success) {
          this.sourceAttributes = [];
          for (let i = 0; i < data.data.length; i++) {
            if(!isUndefined(data.data[i].options)){
              let dictioned_options = this.dictionedData(data.data[i].options);

              this.sourceAttributes.push({
                label: data.data[i].title,
                value: data.data[i].code,
                options_shopify: dictioned_options.slice(0)
              })
              if(data.data[i].code == 'collections') {
                this.state.collections_options = dictioned_options.slice(0);
              }
            }else{
              this.sourceAttributes.push({
                label: data.data[i].title,
                value: data.data[i].code
              });
            }
          }
          this.updateState();
        } else {
          notify.error(data.message);
        }
      });
  }

  updateState() {
    const state = this.state;
    this.setState(state);
  }


  getBusinessPolicy(){
    requests.postRequest('ebayV1/template/get',{multitype:['shipping','payment','return']}).then(data => {
      if(data.success){
        if(data.data.length!==0){
          this.general_skeleton=false;
          this.createDropdownData(data.data);
        }
      }

    });
  }

  getTemplates(){
    requests.postRequest('ebayV1/template/get',{multitype:['category','price','inventory','title']}).then(data => {
      if(data.success){
        if(data.data.length!==0){
          this.general_skeleton=false;
          this.createDropdownDataTemplates(data.data);
        }
      }

    });
  }

  saveConfigurations(key){
    console.log(
      this.state.dropdown[key]
    )
  }

  resetProfileData(){
    this.getProfileID();
    this.state.profileUpdated=false;
    this.state.editFilterQuery=false;
    this.setState(this.state);
  }
  general_skeleton=true;

  removeAssignedtemplate(key){
    let tempObj = {
      section : 'profile',
      details: {
        type : key,
        profile_id: this.state.profile_id,
      }
    };
    requests.postRequest('ebayV1/template/unassignTemplatePolicy',tempObj).then(data =>{
      if(data.success){
        notify.success(data.message);
      }else{
        notify.error(data.message);
      }
      this.getProfileData();
    });
  }

  renderTemplates(){
    let temparr=[];
    if(this.general_skeleton){
      return <Skeleton case="profile_templete"/>
    }
    else{
      Object.keys(this.state.form_data.dropdown).map(key=>{

        if(key.includes("template")) {

          temparr.push(
            <Layout.Section oneHalf key={'template'+key}>
              {this.state.form_data.dropdown[key].options.length !== 0 ?
                <Card actions={key.includes('inventory') || key.includes('title') || key.includes('pricing') ?{content :'Remove', onAction:this.removeAssignedtemplate.bind(this,key)}:{}}>

                  <Card.Section title={this.state.form_data.dropdown[key].heading}>

                  <Autocomplete
                          options={this.state.autocomplete[key].options}
                          selected={this.state.autocomplete[key].selected}
                          onSelect={this.autocompleteSelectionChange.bind(this, key)}
                          textField={ <Autocomplete.TextField
                              onChange={this.autocompleteTextChange.bind(this, key)}
                              label=""
                              value={this.state.autocomplete[key].textsearch}
                              prefix={<Icon source={SearchMinor} color="inkLighter" />}
                              placeholder="Search"
                          />}
                      />
                    < Select
                      key={'dropdown_' + key + '_details'}
                      options={this.state.form_data.dropdown[key].options}
                      error={this.state.errors[key]?'*required field':''}
                      placeholder={"Choose.."}
                      value={this.state.form_data.dropdown[key].selected_id}
                      onChange={this.dropdownChange.bind(this, key, 'selected_id')}/>

                  </Card.Section>


                </Card>
                :
                <Card>
                  <Card.Section>
                    <Banner status={"info"}>
                      <p>No {this.state.form_data.dropdown[key].heading} found, Kindly create one in <a style={{color:'blue',cursor:'pointer'}} onClick={this.createNewTemplate.bind(this,this.state.form_data.dropdown[key].key)}>Templates section</a></p>
                    </Banner>
                  </Card.Section>
                </Card>
              }
            </Layout.Section>
          )
        }
      })

      return temparr;
    }
  }

  autocompleteSelectionChange(key, value){
      let selectedOption = this.state.form_data.dropdown[key].options.filter(obj => obj.value == value[0]);
      let { autocomplete, form_data }  = this.state;
      autocomplete[key].selected = value;
      if(selectedOption.length > 0){
        form_data.dropdown[key].selected_id = value[0];
        autocomplete[key].textsearch = selectedOption[0]['label'];
      }
      this.setState({ autocomplete, form_data });
  }
  autocompleteTextChange(key, value){
    let matchedOptions = [];
    if(value == ''){
     matchedOptions = [...this.state.form_data.dropdown[key].options];
    }else{
    matchedOptions = (this.state.form_data.dropdown[key].options).filter( obj => ((obj.label).toLowerCase()).includes(value.toLowerCase()));
    }
    let { autocomplete }  = this.state;
    autocomplete[key].textsearch = value;
    autocomplete[key].options = [...matchedOptions];
    this.setState({ autocomplete });
  }

  renderProfiles(){

    let temparr=[];
    if(this.general_skeleton){
      return <Skeleton case="profile_businesspolicy"/>
    }
    else {
      // if(this.state.site_id !== 'MOTORS') {
      Object.keys(this.state.form_data.dropdown).map(key => {
        if (key.includes("policy")) {
          temparr.push(
            <React.Fragment key={key + '12'}>
              {this.state.form_data.dropdown[key].options.length !== 0 ?
                <Card /*primaryFooterAction={{
                                            content: 'Save',
                                            onAction: this.saveConfigurations.bind(this, key)
                                        }}*/>

                  <Card.Section title={this.state.form_data.dropdown[key].heading}>

                      <Autocomplete
                          options={this.state.autocomplete[key].options}
                          selected={this.state.autocomplete[key].selected}
                          onSelect={this.autocompleteSelectionChange.bind(this, key)}
                          textField={ <Autocomplete.TextField
                              onChange={this.autocompleteTextChange.bind(this, key)}
                              label=""
                              value={this.state.autocomplete[key].textsearch}
                              prefix={<Icon source={SearchMinor} color="inkLighter" />}
                              placeholder="Search"
                          />}
                      />

                    < Select
                      key={'dropdown_' + key + '_details'}
                      options={this.state.form_data.dropdown[key].options}
                      error={this.state.errors[key] ? '*required field' : ''}
                      placeholder={"Choose.."}
                      value={this.state.form_data.dropdown[key].selected_id}
                      onChange={this.dropdownChange.bind(this, key, 'selected_id')}/>

                  </Card.Section>


                </Card>
                :
                <Card>
                  <Card.Section>
                    <Banner status={"info"}>
                      <p>No {this.state.form_data.dropdown[key].heading} found, Kindly create
                        one
                        in <a style={{color: 'blue', cursor: 'pointer'}}
                              onClick={this.createNewBusinesspolicy.bind(this,key)}>Business
                          profiles</a> section</p>
                    </Banner>
                  </Card.Section>
                </Card>
              }
            </React.Fragment>
          )
        }
      })
      // }else{
      //     Object.keys(this.state.form_data.dropdown).map(key => {
      //         if (key.includes("policy") && key !== 'return_policy') {
      //             temparr.push(
      //                 <React.Fragment key={key + '12'}>
      //                     {this.state.form_data.dropdown[key].options.length !== 0 ?
      //                         <Card /*primaryFooterAction={{
      //                                 content: 'Save',
      //                                 onAction: this.saveConfigurations.bind(this, key)
      //                             }}*/>
      //
      //                             <Card.Section title={this.state.form_data.dropdown[key].heading}>
      //
      //                                 < Select
      //                                     key={'dropdown_' + key + '_details'}
      //                                     options={this.state.form_data.dropdown[key].options}
      //                                     error={this.state.errors[key] ? '*required field' : ''}
      //                                     placeholder={"Choose.."}
      //                                     value={this.state.form_data.dropdown[key].selected_id}
      //                                     onChange={this.dropdownChange.bind(this, key, 'selected_id')}/>
      //
      //                             </Card.Section>
      //
      //
      //                         </Card>
      //                         :
      //                         <Card>
      //                             <Card.Section>
      //                                 <Banner status={"info"}>
      //                                     <p>No {this.state.form_data.dropdown[key].heading} found, Kindly create
      //                                         one
      //                                         in <a style={{color: 'blue', cursor: 'pointer'}}
      //                                               onClick={this.redirect.bind(this, '/panel/businesspolicies/list')}>Business
      //                                             profiles</a> section</p>
      //                                 </Banner>
      //                             </Card.Section>
      //                         </Card>
      //                     }
      //                 </React.Fragment>
      //             )
      //         }
      //     })
      // }

      return temparr;
    }
  }

  saveProfile(){
    if(this.formValidator()) {
      let PolicyandTemplate={};
      Object.keys(this.state.form_data.dropdown).map(key=>{
        PolicyandTemplate[key]=this.state.form_data.dropdown[key].selected_id;
      });
      let tempObj={
        data:{
          profile_id:this.state.profile_id,
          name:this.state.form_data.profile_name.trim(),
          source:'shopify',
          target:'ebay',
          shipping_package_type: this.state.form_data.shipping_package_type,
          user_id:this.state.profileData.user_id,
          sourceShop:this.state.form_data.basicDetails.sourceShop,
          targetShop:this.state.form_data.basicDetails.targetShop,
          query:this.state.editFilterQuery?this.state.form_data.queryBuilder.products_select.query:this.state.profileData.query,
          marketplaceAttributes:Object.assign({},PolicyandTemplate),
        },
      };
      this.setState({saveBtnLoader: true})
      requests.postRequest("connector/profile/set",tempObj).then(data=>{
        if(data.success){
          notify.success(data.message);
          this.state.profileUpdated=false;
          this.setState(this.state);
        }else{
          notify.error(data.message);
        }
        this.setState({saveBtnLoader: false})
      });
    }
  }

  createCopyProfile(){
    requests.postRequest("connector/profile/copy",{ profile_id: this.state.profile_id }).then(data=>{
      if(data.success){
        notify.success(data.message);
        this.redirect('/panel/profiles');
      }else{
        notify.error(data.message);
      }
    });
  }

  formValidator(){
    let error=0;
    Object.keys(this.state.form_data).map(key=>{
      switch(key){
        case 'profile_name':
          if(this.state.form_data.profile_name === '') {
            error++;
            this.state.errors.profile_name = true
          }
          else{
            this.state.errors.profile_name = false
          }
          break;
        case 'dropdown':
          if(this.state.site_id !== 'MOTORS') {
            Object.keys(this.state.form_data.dropdown).map(dropdown => {
              if (dropdown !== 'inventory_template' && dropdown !== 'pricing_template' && dropdown !== 'title_template') {
                if (this.state.form_data.dropdown[dropdown].selected_id === '') {
                  error++;
                  this.state.errors[dropdown] = true;
                }
                else {
                  this.state.errors[dropdown] = false;
                }
              }
            });
          }else{
            Object.keys(this.state.form_data.dropdown).map(dropdown => {
              if (dropdown !== 'inventory_template' && dropdown !== 'pricing_template' && dropdown !== 'title_template' && dropdown !== 'return_policy') {
                if (this.state.form_data.dropdown[dropdown].selected_id === '') {
                  error++;
                  this.state.errors[dropdown] = true;
                }
                else {
                  this.state.errors[dropdown] = false;
                }
              }
            });
          }
          break;

        case 'queryBuilder':
          if(this.state.editFilterQuery) {
            if (this.state.form_data.queryBuilder.products_select.query === '') {
              error++;
              this.state.errors.querybuilder = true;
            }
            else {
              this.state.errors.querybuilder = false;
            }
            break;
          }
      }
    });
    this.setState(this.state);
    if(error===0){
      return true;
    }
    else {
      return false;
    }
  }


  pageSettingsChange(operation ,event) {
    console.log(operation);
    this.gridSettings.count = event
    this.gridSettings.activePage = 1;
    if(operation === 'filteredData'){
      this.runFilterQuery();
    }else {
      this.getProducts();
    }
  }
  updateProductsinCollections(){
    this.setState({loader_update_collection:true});
    requests.postRequest('ebayV1/get/updateProductsinCollection',{collection_id:this.state.collection_selected}).then(data=>{
      if(data.success){
        notify.success(data.message);
        this.getSourceAttributes();
      }else {
        notify.error(data.message);
      }
      this.setState({loader_update_collection:false});
    })
  }
  getProducts = () => {
    this.setState({grid_loader: true})
    requests.postRequest('connector/profile/getProfile', {
      id: this.state.profile_id,
      activePage: this.gridSettings.activePage,
      count: this.gridSettings.count
    }, false, true).then(data => {
      if (data.success) {
        const products = this.modifyProductsData(data.data.products_data);
        this.setState({
          products: products,
          totalPage: data.data.products_data_count,
          pagination_show: paginationShow(this.gridSettings.activePage, this.gridSettings.count, data.data.products_data_count, true)
        });
      } else {
        this.setState({
          pagination_show: paginationShow(0, 0, 0, false),
        });
        notify.error(data.message);
      }
      this.setState({grid_loader: false})
    });
  }

  importCollections(){
    this.setState({loader_import_collection:true});
    requests.getRequest('shopify/import/collections',{shop:this.importShopLists[0].value}).then(data=>{
      if(data.success){
        notify.success(data.message);
        this.getSourceAttributes();
      }else {
        notify.error(data.message);
      }
      this.setState({loader_import_collection:false});
    })
  }


  render() {
    return (
      <Page fullWidth={true}
            breadcrumbs={[{content: 'Profiles', onAction:this.redirect.bind(this,'/panel/profiles')}]}
            title={"View profile"}
        /*primaryAction={{content:'Submit',onAction:this.saveProfile.bind(this)}}*/
            actionGroups={[
              {
                title: 'Actions',
                accessibilityLabel: 'Action group label',
                actions: [
                  {
                    content: 'Create duplicate profile',
                    accessibilityLabel: 'Individual action label',
                    onAction: this.createCopyProfile.bind(this)
                    ,
                  },
                ],
              },
            ]}
      >
        <Card /*primaryFooterAction={{content:'Submit',onAction:this.saveProfile.bind(this)}}*/>
          <Collapsible open={this.state.profileUpdated} id="basic-collapsible-profile-updated">
            <Card.Section>
              <Stack>
                <Stack.Item fill>
                  <React.Fragment></React.Fragment>
                </Stack.Item>
                <Stack.Item>
                  <ButtonGroup>
                    <Button loading={this.state.saveBtnLoader} primary={true} onClick={() => {
                      this.saveProfile();
                    }}> Save </Button>
                    <Button onClick={() => {
                      this.resetProfileData();
                    }} destructive> Discard </Button>
                  </ButtonGroup>
                </Stack.Item>
              </Stack>
            </Card.Section>
          </Collapsible>
          <Card.Section title={"Profile name"}>
            <TextField
              key={'ProfileName'}
              value={this.state.form_data.profile_name}
              error={this.state.errors.profile_name?'*required field':''}
              placeholder={'Profile name...'}
              onChange={this.feildsChange.bind(this,'form_data','profile_name')}/>
          </Card.Section>
          <Card.Section title={"Business policies"}>
            <FormLayout>
              <FormLayout.Group condensed>
                {
                  this.renderProfiles()
                }
              </FormLayout.Group>
            </FormLayout>
          </Card.Section>

          <Card.Section title={"Templates"}>
            <Layout>
              {
                this.renderTemplates()
              }
            </Layout>
          </Card.Section>
          <Card.Section title={"Package type"}>
            <Select label={""} options={shippingPackageType} onChange={this.feildsChange.bind(this,'form_data','shipping_package_type')} value={this.state.form_data.shipping_package_type}/>
          </Card.Section>
          {/*<Card.Section title={'Variation image setting'}>*/}
          {/*<div style={{maxHeight: 100, overflowY: 'scroll'}}>*/}
          {/*<ChoiceList*/}
          {/*key={'VariationImageSetting'}*/}
          {/*title={''}*/}
          {/*allowMultiple*/}
          {/*choices={this.state.options_recieved.shopifyattrib}*/}
          {/*selected={this.state.form_data.variation_image_setting}*/}
          {/*onChange={this.feildsChange.bind(this,'form_data','variation_image_setting')}*/}
          {/*/>*/}
          {/*</div>*/}
          {/*</Card.Section>*/}
          {this.state.showCollectionDetails && <Card.Section title={"Collection action"}>
            <Stack vertical={true} distribution={"fill"}>

              <Banner
                  title={"Please note if products are not shown in app then you need to import them using following steps."}
                  status={"warning"}
              >
                <ol>
                  <li>Select your collections from configuration section and</li>
                  <li>Import them by Shopify action > Import Collection products from Shopify action in Product section</li>
                </ol>
              </Banner>
              <Banner
                  title="To update products assigned to a collection, click on button below. Please note this action only assigns the product ids in the app but for products to display you need to import them using above instruction."
                  // action={{
                  //   content: 'Update product in collection',
                  //   onAction: this.updateProductsinCollections.bind(this),
                  //   loading: this.state.loader_update_collection,
                  //   disabled: this.state.collection_selected === ''
                  // }}
              >
                <div class="d-flex justify-content-between">
                  {/* <div class="w-75"> */}
                  <Select label={''}

                          options={this.state.collections_options}
                          placeholder={'Select...'}
                          value={this.state.collection_selected}
                          onChange={(e) => {
                            this.setState({collection_selected: e});
                          }}
                  />
                  {/* </div> */}
                  <Button onClick={this.updateProductsinCollections.bind(this)} loading={this.state.loader_update_collection} disabled={this.state.collection_selected === ''}>Update product in collection</Button>
                </div>
              </Banner>

            </Stack>
          </Card.Section>}
          <Card.Section>
            <TextField label={ <h3>Filter Query</h3>}
                       value={this.state.profileData.query} readOnly={true}
                       connectedRight={ <Button
                         onClick={() => {
                           // if (this.state.editFilterQuery) {
                           //   this.state.form_data.queryBuilder.filterQuery = {
                           //     primaryQuery: [
                           //       {
                           //         key: '',
                           //         operator: '',
                           //         value: ''
                           //       }
                           //     ],
                           //     condition: 'AND',
                           //     position: 1,
                           //     secondaryQuery: {}
                           //   };
                           //   this.state.updatedFilterQuery = '';
                           // }
                           this.setState({
                             editFilterQuery: !this.state.editFilterQuery,
                             profileUpdated : true
                           });
                         }}
                         primary>{this.state.editFilterQuery ? 'Cancel' : 'Edit'}</Button>}/>
          </Card.Section>

          <Collapsible open={this.state.editFilterQuery} id="basic-collapsible-query">
            <Card.Section title={'Filter products'}>

              {this.state.errors.querybuilder &&
              <Banner status="critical">
                <Label>
                  Kindly generate a query for filtering products.
                </Label>
              </Banner>
              }
              <br/>
              {
                this.renderQueryBuilderStructure()
              }
              {this.state.form_data.queryBuilder.products_select.query !== "" &&

              <Stack vertical={true}>
                {this.state.form_data.queryBuilder.products_select.query !== "" && (
                  <div className='mt-3' style={{textAlign:'center'}}>
                    <Button
                      loading={this.state.QuerybuilderLoader}
                      onClick={() => {
                        this.runFilterQuery();
                      }}
                      primary
                    >
                      Test Your Query
                    </Button>
                  </div>
                )}
                {this.filteredProducts.runQuery && (
                  <Banner title="Selected Products Count" status="success">
                    <Label>
                      Total {this.filteredProducts.totalProducts} product(s) are selected
                      under this query : {this.state.form_data.queryBuilder.products_select.query}
                    </Label>
                  </Banner>
                )}
              </Stack>
              }
            </Card.Section>
          </Collapsible>
          {this.state.form_data.queryBuilder.products_select.query === "" && !this.state.newFilteredData &&
            <Card.Section title={"Product data"}>
            <LoadingOverlay
              active={this.state.grid_loader}
              spinner={true}
              text='Loading please wait...'
            >
              <FormLayout>
                <Stack vertical='true' alignment={"trailing"}>
                  <p>{this.state.pagination_show} Products</p>
                </Stack>
                <SmartDataTable
                  data={this.state.products}
                  uniqueKey="sku"
                  columnTitles={this.columnTitles}
                  className='ui compact selectable table'
                  withLinks={true}
                  ViewColumnsHide={true}
                  operations={this.operations}
                  hideResetFilter={true}
                  visibleColumns={this.visibleColumns}
                  imageColumns={this.imageColumns}
                  getVisibleColumns={(event) => {
                    this.visibleColumns = event;
                  }}
                  sortable
                />
                <Stack vertical={false} distribution={"center"}>
                  <Pagination
                    hasPrevious={1 < this.gridSettings.activePage}
                    onPrevious={() => {
                      this.gridSettings.activePage--;
                      this.getProducts();
                    }}
                    hasNext={this.state.totalPage / Number(this.gridSettings.count) > this.gridSettings.activePage}
                    onNext={() => {
                      this.gridSettings.activePage++;
                      this.getProducts();
                    }}
                  />
                  <Select
                    options={this.pageLimits}
                    value={this.gridSettings.count}
                    onChange={this.pageSettingsChange.bind(this,'queryProduct')}>
                  </Select>
                </Stack>
              </FormLayout>
              </LoadingOverlay>
            </Card.Section>
          }
          {this.state.newFilteredData &&
          <Card.Section title={"Filtered Product data"}>
            <FormLayout>
              <Stack vertical='true' alignment={"trailing"}>
                <p>{this.state.pagination_show} Products</p>
              </Stack>
              <SmartDataTable
                data={this.state.products}
                uniqueKey="sku"
                columnTitles={this.columnTitles}
                className='ui compact selectable table'
                withLinks={true}
                ViewColumnsHide={true}
                operations={this.operations}
                hideResetFilter={true}
                visibleColumns={this.visibleColumnsTestQuery}
                imageColumns={this.imageColumns}
                getVisibleColumns={(event) => {
                  this.visibleColumnsTestQuery = event;
                }}
                sortable
              />
              <Stack vertical={false} distribution={"center"}>
                <Pagination
                  hasPrevious={1 < this.gridSettings.activePage}
                  onPrevious={() => {
                    this.gridSettings.activePage--;
                    this.runFilterQuery();
                  }}
                  hasNext={this.state.totalPage / Number(this.gridSettings.count) > this.gridSettings.activePage}
                  onNext={() => {
                    this.gridSettings.activePage++;
                    this.runFilterQuery();
                  }}
                />
                <Select
                  options={this.pageLimits}
                  value={this.gridSettings.count}
                  onChange={this.pageSettingsChange.bind(this,'filteredData')}>
                </Select>
              </Stack>
            </FormLayout>
          </Card.Section>
          }
        </Card>
      </Page>
    );
  }

  runFilterQuery() {
    if(!this.state.QuerybuilderLoader) {
      this.state.QuerybuilderLoader = true;
    }
    if(!this.state.newFilteredData ) {
      this.state.newFilteredData = true;
    }
    this.setState(this.state);
    if (this.state.form_data.queryBuilder.products_select.query !== "") {
      requests
        .postRequest("ebayV1/get/productsByQuery", {
          marketplace: 'shopify',
          query: this.state.form_data.queryBuilder.products_select.query,
          activePage: this.gridSettings.activePage,
          count: this.gridSettings.count
        })
        .then(data => {
          if (data.success) {
            this.filteredProducts = {
              runQuery: true,
              totalProducts: data.data
            };
            this.state.products = this.modifyProductsData(data.rows);
            this.state.totalPage = data.data;
            this.state.pagination_show= paginationShow(this.gridSettings.activePage, this.gridSettings.count, data.data, true)
          } else {
            notify.error(data.message);
          }
          this.state.QuerybuilderLoader=false;
          this.updateState();
        });
    } else {
      notify.info("Please prepare a custom query to select products");
      this.state.QuerybuilderLoader=false;
      this.updateState();
    }
  }


  renderQueryBuilderStructure(){
    let temparr=[];

    temparr.push(
      <React.Fragment key={'QueryBuilder'}>
        <Stack vertical={true} spacing={"loose"}>
          {/* <Banner status="info">
            <Label>
              <h4>
                <b>Add rule</b> corresponds to && (AND) condition
              </h4>
            </Label>
            <Label>
              <h4>
                <b>Add rule group</b> corresponds to || (OR) condition
              </h4>
            </Label>
          </Banner> */}
          {this.renderQueryBuilder(this.state.form_data.queryBuilder.filterQuery)}
        </Stack>
      </React.Fragment>

    )

    return temparr;

  }

  checkForOptions(value) {
    let temp = false;
    this.sourceAttributes.forEach(data => {
      if (data.value === value) {
        if (!isUndefined(data.options_shopify)) {
          temp = data.options_shopify;
        }
      }
    });
    return temp;
  }

  handleQueryBuilderChange(position, index, field, value) {
    // this.checkForOptions(value);
    this.filteredProducts.runQuery = false;
    if(field === 'value') {
      value = value.trimStart();
    }
    if (field === "key") {
      if(value === 'collections') {
        this.state.showCollectionDetails = true;
        // this.setState({showCollectionDetails: true}, () => {
        //   console.log(this.state)
        // })
      } else {
        this.state.showCollectionDetails = false;
      }
      const options = this.checkForOptions(value);
      if (options !== false) {
        this.state.form_data.queryBuilder.filterQuery = this.updateQueryFilter(
          this.state.form_data.queryBuilder.filterQuery,
          position,
          index,
          field,
          value,
          options
        );
      } else {
        this.state.form_data.queryBuilder.filterQuery= this.updateQueryFilter(
          this.state.form_data.queryBuilder.filterQuery,
          position,
          index,
          field,
          value
        );
      }
    } else {
      this.state.form_data.queryBuilder.filterQuery = this.updateQueryFilter(
        this.state.form_data.queryBuilder.filterQuery,
        position,
        index,
        field,
        value
      );
    }
    this.handleFilterQueryChange(this.state.form_data.queryBuilder.filterQuery);
    this.updateState();
  }

  handleFilterQueryChange(query) {
    this.state.form_data.queryBuilder.products_select.query = this.prepareQuery(query, "");
  }

  prepareQuery(query, preparedQuery) {
    preparedQuery += "(";
    let end = "";
    for (let i = 0; i < query.primaryQuery.length; i++) {
      if (
        query.primaryQuery[i].key !== "" &&
        query.primaryQuery[i].operator !== "" &&
        query.primaryQuery[i].value !== ""
      ) {
        preparedQuery +=
          end +
          query.primaryQuery[i].key +
          " " +
          query.primaryQuery[i].operator +
          " " +
          query.primaryQuery[i].value;
        end = " && ";
      }
    }
    preparedQuery += ")";
    if (preparedQuery === "()") {
      preparedQuery = "";
    }
    if (Object.keys(query.secondaryQuery).length > 0) {
      const orQuery = this.prepareQuery(query.secondaryQuery, "");
      if (orQuery !== "") {
        preparedQuery += " || " + orQuery;
      }
    }
    return preparedQuery;
  }


  updateQueryFilter(query, position, index, field, value, options) {
    if (query.position === position) {
      if (field === "key") {
        query.primaryQuery[index]["value"] = "";
        if (isUndefined(options)) {
          query.primaryQuery[index].options = undefined;
        }
      }
      if (!isUndefined(options)) {
        query.primaryQuery[index][field] = value;
        query.primaryQuery[index].options = options;
      } else {
        query.primaryQuery[index][field] = value;
      }
    } else {
      query.secondaryQuery = this.updateQueryFilter(
        query.secondaryQuery,
        position,
        index,
        field,
        value,
        options
      );
    }
    return query;
  }

  renderQueryBuilder(querySet) {
    return (
      <React.Fragment>
      <Banner status="info">
        <Label>
          <h4>
            <b>Add rule group</b> corresponds to || (OR) condition
          </h4>
        </Label>
      </Banner>
      <br />
      <FormLayout>
        {querySet.position === 1 && this.state.form_data.queryBuilder.products_select.query !== "" && (
          <Banner title="Prepared Query" status="info">
            <Label>{this.state.form_data.queryBuilder.products_select.query}</Label>
          </Banner>
        )}
        <Card sectioned>
          {querySet.primaryQuery.map(query => {

            return (
              <FormLayout key={'line'+query}>
                <br />
                <Banner status="info">
                  <Label>
                    <h4>
                      <b>Add rule</b> corresponds to && (AND) condition
                    </h4>
                  </Label>
                </Banner>
                <FormLayout.Group condensed>
                  <Select
                    label="Attribute"
                    options={this.sourceAttributes}
                    placeholder="Select Attribute"
                    onChange={this.handleQueryBuilderChange.bind(
                      this,
                      querySet.position,
                      querySet.primaryQuery.indexOf(query),
                      "key"
                    )}
                    value={query.key}
                  />

                  <Select
                    label="Operator"
                    options={this.filterConditions}
                    placeholder="Select Operator"
                    onChange={this.handleQueryBuilderChange.bind(
                      this,
                      querySet.position,
                      querySet.primaryQuery.indexOf(query),
                      "operator"
                    )}
                    value={query.operator}
                  />

                  {isUndefined(query.options) || query.options.length <= 0 ? (
                    <TextField
                      label="Value"
                      value={query.value}
                      placeholder="Filter Value"
                      onChange={this.handleQueryBuilderChange.bind(
                        this,
                        querySet.position,
                        querySet.primaryQuery.indexOf(query),
                        "value"
                      )}
                    />
                  ) : (
                    <Select
                      label="Value"
                      options={query.options}
                      placeholder="Filter Value"
                      onChange={this.handleQueryBuilderChange.bind(
                        this,
                        querySet.position,
                        querySet.primaryQuery.indexOf(query),
                        "value"
                      )}
                      value={query.value}
                    />
                  )}
                </FormLayout.Group>
                <Stack>
                  <Stack.Item fill>
                    <React.Fragment />
                  </Stack.Item>
                  {
                    <Stack.Item>

                      <Button
                        disabled={querySet.primaryQuery.length===1}
                        onClick={() => {
                          this.handleDeleteRule(
                            querySet.position,
                            querySet.primaryQuery.indexOf(query)
                          );
                        }}
                      >
                        Delete Rule
                      </Button>

                    </Stack.Item>
                  }
                  {
                    <Stack.Item>
                      {querySet.primaryQuery.indexOf(query) ===
                      querySet.primaryQuery.length - 1 && (
                        <Button
                          onClick={() => {
                            this.handleAddRule(querySet.position);
                          }}
                          primary
                        >
                          Add Rule
                        </Button>
                      )}
                    </Stack.Item>
                  }
                </Stack>
              </FormLayout>
            );
          })}
        </Card>

        <Stack vertical={true} alignment={"trailing"}>
          <ButtonGroup>
            {Object.keys(querySet.secondaryQuery).length === 0 &&
            querySet.position !== 1 && (
              <Button
                onClick={() => {
                  this.handleDeleteGroup(querySet.position);
                }}
              >
                Delete Rule Group
              </Button>
            )}

            {Object.keys(querySet.secondaryQuery).length === 0 && (
              <Button
                onClick={() => {
                  this.handleAddGroup(querySet.position, "OR");
                }}
                primary
              >
                Add Rule Group
              </Button>
            )}
          </ButtonGroup>
        </Stack>
        {Object.keys(querySet.secondaryQuery).length > 1 && (
          <React.Fragment>
            {this.renderQueryBuilder(querySet.secondaryQuery)}
          </React.Fragment>
        )}
      </FormLayout>
      </React.Fragment>
    );
  }

  handleAddGroup(position, condition) {
    this.state.form_data.queryBuilder.filterQuery = this.addGroup(
      this.state.form_data.queryBuilder.filterQuery,
      position,
      condition
    );
    this.handleFilterQueryChange(this.state.form_data.queryBuilder.filterQuery);
    this.updateState();
  }
  deleteGroup(query, position) {
    if (query.position === position) {
      query = {};
    } else {
      query.secondaryQuery = this.deleteGroup(query.secondaryQuery, position);
    }
    return query;
  }

  addGroup(query, position, condition) {
    if (query.position === position) {
      query.secondaryQuery = {
        primaryQuery: [
          {
            key: "",
            operator: "",
            value: ""
          }
        ],
        condition: condition,
        position: position + 1,
        secondaryQuery: {}
      };
    } else {
      query.secondaryQuery = this.addGroup(
        query.secondaryQuery,
        position,
        condition
      );
    }
    return query;
  }

  deleteRule(query, position, index) {
    if (query.position === position) {
      query.primaryQuery.splice(index, 1);
    } else {
      query.secondaryQuery = this.deleteRule(
        query.secondaryQuery,
        position,
        index
      );
    }
    return query;
  }

  addRule(query, position) {
    if (query.position === position) {
      query.primaryQuery.push({
        key: "",
        operator: "",
        value: ""
      });
    } else {
      query.secondaryQuery = this.addRule(query.secondaryQuery, position);
    }
    return query;
  }

  handleAddRule(position) {
    this.state.form_data.queryBuilder.filterQuery = this.addRule(this.state.form_data.queryBuilder.filterQuery, position);
    this.handleFilterQueryChange(this.state.form_data.queryBuilder.filterQuery);
    this.updateState();
  }

  handleDeleteRule(position, index) {
    this.state.form_data.queryBuilder.filterQuery = this.deleteRule(
      this.state.form_data.queryBuilder.filterQuery,
      position,
      index
    );
    this.handleFilterQueryChange(this.state.form_data.queryBuilder.filterQuery);
    this.updateState();
  }

  handleDeleteGroup(position) {
    this.state.form_data.queryBuilder.filterQuery = this.deleteGroup(this.state.form_data.queryBuilder.filterQuery, position);
    this.handleFilterQueryChange(this.state.form_data.queryBuilder.filterQuery);
    this.updateState();
  }


  feildsChange(key,tag,value){
    let tempObj=Object.assign({},this.state);
    tempObj[key][tag]=value;
    tempObj.profileUpdated=true;
    this.setState(tempObj);

  }


  createDropdownData(data){
    let return_dropdown_options=[];
    let payment_dropdown_options=[];
    let shipping_dropdown_options=[];
    data.forEach((obj,index)=>{
      switch (obj.type) {
        case 'return':
          if(!isUndefined(obj.data))
          {
            return_dropdown_options.push(
              {label:obj.data.profileName,value:(obj.data.profileId).toString()}
            );
          }
          break
        case 'payment':
          if(!isUndefined(obj.data))
          {
            payment_dropdown_options.push(
              {label:obj.data.profileName,value:(obj.data.profileId).toString()}
            );
          }
          break;
        case 'shipping':
          if(!isUndefined(obj.data))
          {
            shipping_dropdown_options.push(
              {label:obj.data.profileName,value:(obj.data.profileId).toString()}
            );
          }
          break;
      }
    });
    // if(this.state.site_id!=='MOTORS') {
      if (return_dropdown_options.length === 0) {
        this.state.form_data.dropdown.return_policy.show_dropdown = false;
      }
      else {
        this.state.form_data.dropdown.return_policy.show_dropdown = true;
        this.state.form_data.dropdown.return_policy.options = return_dropdown_options;
        this.state.autocomplete.return_policy.options = [...return_dropdown_options];
      }
    // }
    if(payment_dropdown_options.length===0){
      this.state.form_data.dropdown.payment_policy.show_dropdown=false;
    } else{
      this.state.form_data.dropdown.payment_policy.show_dropdown=true;
      this.state.form_data.dropdown.payment_policy.options=payment_dropdown_options;
      this.state.autocomplete.payment_policy.options = [...payment_dropdown_options];
    }
    if(shipping_dropdown_options.length===0){
      this.state.form_data.dropdown.shipping_policy.show_dropdown=false;
    }else{
      this.state.form_data.dropdown.shipping_policy.show_dropdown=true;
      this.state.form_data.dropdown.shipping_policy.options=shipping_dropdown_options;
      this.state.autocomplete.shipping_policy.options = [...shipping_dropdown_options];
    }
    this.state.businessPolicyprepared =true;
    this.setState(this.state);
  }

  createDropdownDataTemplates(data){
    let check=0;
    let price_dropdown_options=[];
    let title_dropdown_options=[];
    let inventory_dropdown_options=[];
    let category_dropdown_options=[];
    data.forEach((obj,index)=>{
      switch (obj.type) {
        case 'price':
          // if(!isUndefined(obj.data))
          // {
          price_dropdown_options.push(
            {label:obj.title,value:(obj._id).toString()}
          );
          // }
          break;
        case 'category':
          // if(!isUndefined(obj.data))
          // {
          category_dropdown_options.push(
            {label:obj.title,value:(obj._id).toString()}
          );
          // }
          break;
        case 'title':
          // if(!isUndefined(obj.data))
          // {
          title_dropdown_options.push(
            {label:obj.title,value:(obj._id).toString()}
          );
          // }
          break;
        case 'inventory':
          // if(!isUndefined(obj.data))
          // {
          inventory_dropdown_options.push(
            {label:obj.title,value:(obj._id).toString()}
          );
          // }
          break;

      }
    });
    if(title_dropdown_options.length===0){
      check=1;
      this.state.form_data.dropdown.title_template.show_dropdown=false;
    }else{
      this.state.form_data.dropdown.title_template.show_dropdown=true;
      this.state.form_data.dropdown.title_template.options=title_dropdown_options;
      this.state.autocomplete.title_template.options = [ ...title_dropdown_options];
    }
    if(inventory_dropdown_options.length===0){
      check=1;
      this.state.form_data.dropdown.inventory_template.show_dropdown=false;
    }else{
      this.state.form_data.dropdown.inventory_template.show_dropdown=true;
      this.state.form_data.dropdown.inventory_template.options=inventory_dropdown_options;
      this.state.autocomplete.inventory_template.options = [ ...inventory_dropdown_options];
    }
    if(price_dropdown_options.length===0){
      check=1;
      this.state.form_data.dropdown.pricing_template.show_dropdown=false;
    }else{
      this.state.form_data.dropdown.pricing_template.show_dropdown=true;
      this.state.form_data.dropdown.pricing_template.options=price_dropdown_options;
      this.state.autocomplete.pricing_template.options = [ ...price_dropdown_options];
    }
    if(category_dropdown_options.length===0){
      check=1;
      this.state.form_data.dropdown.category_template.show_dropdown=false;
    }else{
      this.state.form_data.dropdown.category_template.show_dropdown=true;
      this.state.form_data.dropdown.category_template.options=category_dropdown_options;
      this.state.autocomplete.category_template.options = [ ...category_dropdown_options];
    }
    if (check === 1) {
      this.state.missingOptions = true;
    }
    else {
      this.state.missingOptions = false;
    }
    this.state.templatesPrepared = true;

    this.setState(this.state);
  }

  dropdownChange(key,tag,value){
    let tempObj = Object.assign({}, this.state);
    tempObj.form_data.dropdown[key][tag] = value;
    tempObj.profileUpdated=true;
    this.setState(tempObj);

  }

  createNewTemplate(key){
    let tempObj={display:key,type:'Template'}
    let message=cryptr.encrypt(JSON.stringify(tempObj));
    this.redirect('/panel/template/modifier?message='+encodeURI(message));
  }

  createNewBusinesspolicy(key){
    let tempObj={display:key,type:'Business policy'}
    let message=cryptr.encrypt(JSON.stringify(tempObj));
    this.redirect('/panel/template/modifier?message='+encodeURI(message));
  }
}

export default ViewProfile;
