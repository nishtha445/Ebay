import React, { Component } from 'react';
import {
    Page,
    Select,
    Pagination,
    Modal,
    Card,
    Label,
    Banner,
    EmptyState,
    Stack, Badge, TextContainer
} from '@shopify/polaris';

import { requests } from '../../services/request';
import { notify } from '../../services/notify';
import { globalState } from '../../services/globalstate';
import SmartDataTable from '../../shared/smartTable';
import { paginationShow } from "../../shared/static-functions";
import { isUndefined } from "util";

import Grid from "../../shared/react-data-grid/grid";
import { column, createDemoRows } from "../../shared/react-data-grid/createDemoRows";
import LoadingOverlay from "react-loading-overlay";
import ModalVideo from "react-modal-video";


const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');
const {
    DraggableHeader: { DraggableContainer }
} = require("react-data-grid-addons");

const defaultData = {
    width: 200,
    filterable: true,
    editable: false,
    sortable: false,
    resizable: true,
    draggable: true,

};

const defaultParams = {
    rowHeight: 50,
    minHeight: window.innerHeight - 170,
    headerRowHeight: 50,
    headerFiltersHeight: 50,
    enableCellSelect: false,
}

const sortingOptions = [
    { label: 'Title', value: 'name' },
    { label: 'Sort disabled', value: '' }
];
const sortingOptionsHighLow = [
    { label: 'High to low', value: 'DEC' },
    { label: 'Low to High', value: 'INC' },
    { label: 'Preference disabled', value: '' }
];



class Profiles extends Component {
    video = { Modal: false, id: '' };
    filters = {
        column_filters: {}
    };
    gridSettings = {
        activePage: 1,
        count: 5
    };
    grid_loader = false;
    pageLimits = [
        { label: 5, value: '5' },
        { label: 10, value: '10' },
        { label: 15, value: '15' },
        { label: 20, value: '20' },
        { label: 25, value: '25' }
    ];
    visibleColumns = ['name'/*, 'targetCategory'*/, 'query', 'product_count'];
    customButton = [];
    hideFilters = ['product_count', 'query'];
    columnTitles = {
        name: {
            title: 'Name',
            sortable: true
        },
        targetCategory: {
            title: 'Category',
            sortable: true
        },
        query: {
            title: 'Query',
            sortable: true
        },
        product_count: {
            title: 'Product Count',
            sortable: true,
        },
        profile_id: {
            title: 'Id',
            sortable: false,
        }
    };
    constructor() {
        super();
        this.state = {
            profiles: [],
            totalPage: 0,
            confirm_delete: false,
            profile_id: 0,
            pagination: {
                page: 1,
                totalNumberOfPages: 0,
                totalNumberOfProducts: 0,
                totalNumberOfItems: 0,
                pageSize: 25,
            },
            profile_in_uploaded: {
                modal: false,
                data: {}
            },
            selected: 0,
            selectedTab: 0,
            check: [],
            rows: [],
            sortby: '',
            high_low_sort: '',
            appliedFilters: {},
            expandedRows: {},
            selectedIndexes: [],
            columns: column.map(c => ({ ...defaultData, ...c })),
            visibleColumns: { 'name': 1, 'query': 1, 'productCount': 1, 'action': 1 },
            pagination_show: "",
            preparedFilter: {},
            rawData: [],
            toolbar_suffix: "Profiles",

        };
        this.getProfiles();
        this.operations = this.operations.bind(this);
    }


    componentDidMount() {
        document.title = 'Create/Edit profile and easily list them on eBay - CedCommerce';
        document.description = 'Place & segment your Shopify products based on product properties such as type, vendor, etc. in particular profile to assign various business policies (Return, Payment, Shipping ), templates.';
        if (!document.title.includes(localStorage.getItem('shop_url'))) {
            document.title += !isUndefined(localStorage.getItem('shop_url')) ? " " + localStorage.getItem('shop_url') : "";
        }
    }
    operations(data, event) {
        switch (event) {
            case 'grid':
                let tempObj = { id: data['profile_id'] }
                let message = cryptr.encrypt(JSON.stringify(tempObj));
                this.redirect('/panel/profiles/viewprofile?message=' + message); break;
            default:
                let tempObj1 = { id: data['profile_id'] }
                let message1 = cryptr.encrypt(JSON.stringify(tempObj1));
                this.redirect('/panel/profiles/viewprofile?message=' + message1); break;
        }
    }

    getProfiles() {
        this.grid_loader = true;
        this.setState({ profiles: createDemoRows("", true, "Profile_grid") })
        let { pagination } = this.state;
        const pageSettings = Object.assign({}, { count: pagination.pageSize, activePage: pagination.page });
        requests.getRequest('connector/profile/getAllProfiles', Object.assign({}, pageSettings, this.state.appliedFilters, {
            sort: this.state.sortby !== '' ? this.state.sortby : false,
            order: this.state.high_low_sort !== '' ? this.state.high_low_sort : false
        }))
            .then(data => {
                if (data.success) {
                    this.setState({
                        profiles: createDemoRows(data.data.rows, false, "Profile_grid"),
                        totalPage: data.data.count,
                        rawData: data.data.rows
                    });
                    this.state.pagination.totalNumberOfItems = data.data.count;
                    this.state.pagination.totalNumberOfPages = Math.ceil(data.data.count / this.state.pagination.pageSize);

                    this.setState({ totalPage: data.data.count });

                    // this.setState({ profiles:this.modifyProfilesData(data.data.rows)})

                    // this.state.pagination_show = paginationShow(this.gridSettings.activePage,this.gridSettings.count,data.data.count,true);
                    this.updateState();
                } else {
                    notify.error(data.message);
                }
                this.grid_loader = false;
                this.updateState();
            });
    }

    modifyProfilesData(profiles) {
        let profilesList = [];
        for (let i = 0; i < profiles.length; i++) {

            profilesList.push({
                name: profiles[i].name,
                targetCategory: profiles[i].targetCategory,
                query: profiles[i].query,
                profile_id: profiles[i].profile_id,
                product_count: profiles[i].product_count + (profiles[i].product_count > 1 ? " products in profile" : " product in profile")
            });

        }
        return profilesList;
    }

    prepareFilterObject() {
        const filters = {};
        for (let i = 0; i < Object.keys(this.filters.column_filters).length; i++) {
            const key = Object.keys(this.filters.column_filters)[i];
            if (this.filters.column_filters[key].value !== '') {
                filters['filter[' + key + '][' + this.filters.column_filters[key].operator + ']'] = this.filters.column_filters[key].value;
            }
        }
        return filters;
    }

    deleteProfile = () => {
        // console.log(this.state.profile_id);

        requests.getRequest('connector/profile/delete?id=' + this.state.profile_id).then(e => {
            if (e.success) {
                if (e.code !== 'profile_in_uploaded') {
                    notify.success(e.message);
                } else {
                    this.state.profile_in_uploaded.modal = true;
                    this.state.profile_in_uploaded.data = Object.assign({}, e.data);
                    this.setState(this.state);
                }
            } else {
                notify.error(e.message);
            }
            this.getProfiles();
        });
        this.setState({ confirm_delete: false });
    }
    redirect(url) {
        this.props.history.push(url);
    }

    saveAllprofiles() {
        requests.getRequest('ebayV1/app/saveallProfiles').then(data => {
            if (data.success) notify.success(data.message);
            else notify.error(data.message);
        });
    }

    render() {
        return (
            <Page fullWidth={true}
                titleMetadata={<Stack vertical={false}><p style={{ cursor: 'pointer' }} onClick={() => {
                    window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=profil', '_blank')
                }}><Badge status={"info"}><b style={{ color: '#0000aa', textDecoration: 'underline' }}>Need help?</b></Badge></p>
                    <p style={{ color: '#3B7DC4', textDecoration: 'underline', cursor: 'pointer' }}
                        onClick={this.openvideoModal.bind(this, 'ptGo3ktQJ30')}><Badge status={"info"}><b
                            style={{ color: '#0000aa', textDecoration: 'underline' }}>Help Video?</b></Badge></p>
                </Stack>
                }
                title="Profiles" primaryAction={{ content: 'Create', onAction: this.redirect.bind(this, '/panel/profiles/createprofile') }}
                secondaryActions={[{ content: 'Save all profiles', onAction: this.saveAllprofiles.bind(this) }]}
            >
                <Banner status={"info"}>
                    <b>Profiles</b> are helpful in case you want to upload a particular group of products with a certain set of policies and templates. Instead of applying these conditions individually on each product you can simply create a profile and apply the same to a group of products by assigning them to a profile.
                </Banner>
                <Banner status={"warning"}>
                    <b>Note</b> Templates and Policies of <b>Default Profile</b> are set in <b style={{ color: '#0000aa', textDecoration: 'underline', cursor: 'pointer' }}
                        onClick={() => {
                            this.redirect('/panel/config');
                        }}
                    >Configurations Section</b>
                </Banner>
                <br />
                <Stack vertical>

                    <Stack spacing={"loose"}>
                        <Stack.Item>
                            <div style={{ paddingTop: '1.5rem' }}>
                                <Select label={''} options={sortingOptions} value={this.state.sortby}
                                    helpText={'Use this option for sorting'} onChange={(e) => {
                                        this.state.sortby = e;
                                        this.setState({ sortby: e }, () => {
                                            this.getProfiles();
                                        });
                                    }} />
                            </div>
                        </Stack.Item>
                        {this.state.sortby !== '' &&
                            <Stack.Item>
                                <div style={{ paddingTop: '1.5rem' }}>
                                    <Select label={''} options={sortingOptionsHighLow} value={this.state.high_low_sort}
                                        helpText={'Set your preferred order'} onChange={(e) => {
                                            this.state.high_low_sort = e;
                                            this.setState({ high_low_sort: e }, () => {
                                                this.getProfiles();
                                            });
                                        }} />
                                </div>
                            </Stack.Item>
                        }
                        <Stack.Item fill></Stack.Item>
                    </Stack>

                    {/*<div className="col-12 text-right">
                        <h5 className="mr-5 mt-2">{this.state.pagination_show} Profile(s)</h5>
                        <hr/>
                    </div>*/}
                    {/* <div className="pr-3 pl-3 pt-2 pb-2">
                        <SmartDataTable
                            data={this.state.profiles}
                            multiSelect={false}
                            customButton={this.customButton}
                            className='ui compact selectable table'
                            columnFiltersValue={this.filters.column_filters}
                            ViewColumnsHide={true}
                            operations={this.operations}
                            hideFilters={this.hideFilters}
                            visibleColumns={this.visibleColumns}
                            columnTitles={this.columnTitles}
                            showColumnFilters={true}
                            showViewColumns={false}
                            rowActions={{
                                edit: false,
                                delete: true
                            }}
                            deleteRow={(row) => {
                                this.setState({profile_id:row['profile_id'], confirm_delete: true});
                                // this.state.toDeleteRow = row;
                                // this.state.deleteProductData = true;
                                // const state = this.state;
                                // this.setState(state);
                            }}
                            getVisibleColumns={(event) => {
                                this.visibleColumns = event;
                            }}
                            columnFilters={(filters) => {
                                this.filters.column_filters = filters;
                                this.getProfiles();
                            }}
                            sortable
                        />
                        <div className="row mt-3">
                            <div className="col-6 text-right">
                                <Pagination
                                    hasPrevious={1 < this.gridSettings.activePage}
                                    onPrevious={() => {
                                        this.gridSettings.activePage--;
                                        this.getProfiles();
                                    }}
                                    hasNext={this.state.totalPage/this.gridSettings.count > this.gridSettings.activePage}
                                    onNext={() => {
                                        this.gridSettings.activePage++;
                                        this.getProfiles();
                                    }}
                                />
                            </div>
                            <div className="col-md-2 col-sm-2 col-6">
                                <Select
                                    options={this.pageLimits}
                                    value={this.gridSettings.count}
                                    onChange={this.pageSettingsChange.bind(this)}>
                                </Select>
                            </div>
                        </div>
                    </div>*/}
                    <LoadingOverlay
                        active={this.grid_loader}
                        spinner
                        text='Loading please wait...'
                    >
                        <DraggableContainer onHeaderDrop={this.onHeaderDrop}>
                            <Grid
                                suffix={this.state.toolbar_suffix}
                                rowGetter={i => this.state.profiles[i]}
                                rowsCount={this.state.profiles.length}
                                onGridRowsUpdated={this.onGridRowsUpdated}
                                hideLoader={this.state.hideLoader}
                                onRowClick={this.getRowData} columns={this.state.columns}
                                onAddFilter={filter => this.handleFilterChange(filter)}
                                onClearFilters={(e) => { this.setState({ appliedFilters: {} }, () => { this.getProfiles() }) }}
                                onCheckCellIsEditable={(e) => { return this.onCheckCellIsEditable(e) }}
                                onGridSort={(sortColumn, sortDirection) => this.sortRows(sortColumn, sortDirection)}
                                getValidFilterValues={columnKey => this.getValidFilterValues(this.state.rows, columnKey)}
                                getSubRowDetails={this.getSubRowDetails(this.state.expandedRows)}
                                visibleColumns={this.state.visibleColumns}
                                // onCellExpand={args => this.onCellExpand(args)}
                                getCellClick={this.getCellClick}
                                paginationProps={this.state.pagination}
                                handlePagination={this.handlePagination}
                                filtercolumnSize={defaultParams}
                                hideColumnToggleButton={true}
                                handleColumn={this.handleColumn}
                                // performMassAction={this.performMassAction}
                                rowSelection={{
                                    showCheckbox: false,
                                    enableShiftSelect: true,
                                    onRowsSelected: this.onRowsSelected,
                                    onRowsDeselected: this.onRowsDeselected,
                                    selectBy: {
                                        indexes: this.state.selectedIndexes
                                    }
                                }}
                                emptyRowsView={this.EmptyRowsView}
                            />
                        </DraggableContainer>
                    </LoadingOverlay>
                </Stack>
                <Modal open={this.state.confirm_delete}
                    title={'Are You Sure?'}
                    onClose={() => { this.setState({ confirm_delete: false }); }}
                    primaryAction={{ 'content': 'Yes', onAction: () => { this.deleteProfile() } }}
                    secondaryActions={{ 'content': 'Cancel', onClick: () => { this.setState({ confirm_delete: false }) } }}>
                    <Modal.Section>
                        <div className="w-100 text-center">
                            <Label>
                                <p>If you delete this profile then the products in this profile will sync with seller panel by Default Profile, Do you want to continue?</p>
                            </Label>
                        </div>
                    </Modal.Section>
                </Modal>
                {this.state.profile_in_uploaded.modal && this.deletionNotSafeModal()}
                <ModalVideo channel='youtube' isOpen={this.video.Modal} videoId={this.video.id} onClose={this.closevideoModal.bind(this)} />
            </Page>
        );
    }

    openvideoModal(id) {
        this.video.Modal = true;
        this.video.id = id;
        this.setState(this.state);
    }

    closevideoModal() {
        this.video.Modal = false;
        this.video.id = '';
        this.setState(this.state);
    }

    deletionNotSafeModal() {
        return (

            <Modal
                open={this.state.profile_in_uploaded.modal}
                onClose={() => {
                    this.state.profile_in_uploaded.modal = false;
                    this.state.profile_in_uploaded.data = {};
                    this.setState(this.state);
                }}
                title="Deletion prohibited"
            >
                <Modal.Section>
                    <TextContainer>
                        <Banner status={"warning"}>
                            This Profile is used to upload {this.state.profile_in_uploaded.data.count} product(s) ,hence it's deletion is not allowed.
                        </Banner>
                    </TextContainer>
                </Modal.Section>
            </Modal>

        );
    }

    pageSettingsChange(event) {
        this.gridSettings.count = event;
        this.gridSettings.activePage = 1;
        this.getProfiles();
    }

    addSearchFilter(searchValue) {
        const state = this.state;
        state.searchValue = searchValue;
        this.setState(state);
        if (searchValue !== null &&
            searchValue !== '') {
            this.filters['title'] = searchValue;
            this.getProfiles();
        }
    }

    //-----grid function ---------------//

    setVisibleColumns() {
        let check = [];
        for (let key in column) {
            if (column[key]["key"] in this.state.visibleColumns) {
                check.push({ ...defaultData, ...column[key] })
            }
        }

        this.setState({ columns: check }, () => {

        })
    }

    prepareFilterObject(coloumn, index) {
        // //console.log(coloumn);
        let filterObtained = '';
        if (coloumn !== '') {
            switch (coloumn) {
                case 'name':
                case 'targetCategory':
                    filterObtained = (index === undefined) ? 'filter[' + coloumn + ']' : 'filter[' + coloumn + '][' + index + ']';
                    break;
            }
        }
        return filterObtained;
    }

    // filter Change

    handleFilterChange = filter => {
        console.log(filter)
        let { appliedFilters, preparedFilter } = this.state;
        preparedFilter[filter["key"]] = [this.prepareFilterObject(filter["key"], filter["operator"]), filter["rawValue"]];
        if (filter["rawValue"] === "") {
            delete preparedFilter[filter["key"]];
        }
        appliedFilters = {};
        this.setState({ preparedFilter, appliedFilters }, () => {
            for (let i in this.state.preparedFilter) {
                if (this.state.preparedFilter.hasOwnProperty(i)) {
                    appliedFilters[this.state.preparedFilter[i][0]] = this.state.preparedFilter[i][1];
                }
            }
            this.setState({ appliedFilters }, () => {
                this.getProfiles();
            });
        });

    };

    // deleteProfile = () => {
    //     // //console.log(this.state.profile_id);
    //     requests.getRequest('connector/profile/delete?id=' + this.state.profile_id).then(e => {
    //         if ( e.success ) {
    //             notify.success(e.message);
    //         } else {
    //             notify.error(e.message);
    //         }
    //         this.getProfiles();
    //     });
    //     this.setState({confirm_delete: false});
    // };

    getCellClick = (e) => {
        console.log(e, this.state.rawData);
        if (e.idx > 0) {
            //console.log("check");
            let tempObj = { id: this.state.rawData[e.rowIdx]['profile_id'] }
            let message = cryptr.encrypt(JSON.stringify(tempObj));
            this.redirect('/panel/profiles/viewprofile?message=' + message);
        }
        else if (e.idx == 0) {
            this.setState({ confirm_delete: true, profile_id: this.state.rawData[e.rowIdx]['profile_id'] });
        }

    }

    // on Grid Update

    onGridRowsUpdated = (fieldName, fromRow, toRow, updated) => {
        // //console.log(fieldName, fromRow, toRow, updated);
        this.setState(state => {
            const rows = state.rows.slice();
            for (let i = fromRow; i <= toRow; i++) {
                rows[i] = { ...rows[i], ...updated };
            }
            return { rows };
        });
    };

    onHeaderDrop = (source, target) => {
        const stateCopy = Object.assign({}, this.state);
        const columnSourceIndex = this.state.columns.findIndex(
            i => i.key === source
        );
        const columnTargetIndex = this.state.columns.findIndex(
            i => i.key === target
        );

        stateCopy.columns.splice(
            columnTargetIndex,
            0,
            stateCopy.columns.splice(columnSourceIndex, 1)[0]
        );

        const emptyColumns = Object.assign({}, this.state, { columns: [] });
        this.setState(emptyColumns);

        const reorderedColumns = Object.assign({}, this.state, {
            columns: stateCopy.columns
        });
        this.setState(reorderedColumns);
    };

    // set the Drop down Filter Value here

    getValidFilterValues = (rows, columnId) => {
        console.log('object')
        let val = rows
            .map(r => r[columnId])
            .filter((item, i, a) => {
                return i === a.indexOf(item);
            });
        return val;
    };

    sortRows = (sortColumn, sortDirection) => {
        // //console.log(sortColumn, sortDirection);
    };

    onCheckCellIsEditable = (event) => {
        // return false;
        let flag = true;
        if (event.row.variants && event.column.key !== 'title')
            flag = false;
        if (event.row.type === 'child' && event.column.key === 'title')
            flag = false;
        return flag;
    };

    onRowsSelected = rows => {
        // //console.log(rows);
        this.setState({
            selectedIndexes: this.state.selectedIndexes.concat(
                rows.map(r => r.rowIdx)
            )
        });
    };

    onRowsDeselected = rows => {
        // //console.log(rows);
        let rowIndexes = rows.map(r => r.rowIdx);
        this.setState({
            selectedIndexes: this.state.selectedIndexes.filter(
                i => rowIndexes.indexOf(i) === -1
            )
        });
    };

    handlePagination = (pageProps) => {
        this.setState({ pagination: pageProps }, () => {
            this.getProfiles();
        });
    };

    handleColumn = (columnProps) => {
        // //console.log(columnProps);
        this.setState({ visibleColumns: columnProps }, () => {
            this.setVisibleColumns();
        })

    }

    performMassAction = (action) => {
        // //console.log(action);
    };

    EmptyRowsView = () => {
        return (
            <EmptyState heading="No profile found"
                action={{
                    content: 'Refresh', onAction: () => {
                        this.setState({ appliedFilters: {} }, () => {
                            this.getProfiles();
                        });
                    }
                }}
                image="https://cdn.shopify.com/s/assets/admin/empty-states-fresh/emptystate-abandoncheckout-de95c7af243bfbc1a127a7bd1a6a9b7a5769ddc295a303268fdf26913f16801c.svg">
            </EmptyState>
        );
    };

    handleTabChange(event) {
        this.state.selectedTab = event;
        this.state.showLoaderBar = false;
        this.state.pagination = {
            page: 1,
            totalNumberOfPages: 0,
            totalNumberOfProducts: 0,
            totalNumberOfItems: 0,
            pageSize: 25,
        }
        this.setState(this.state);
        this.getProfiles();
    }

    getRowData = (g, f, d, s) => {
        // //console.log(g, f, d, s);
    }

    getSubRowDetails = expandedRows1 => rowItem => {
        let { expandedRows } = this.state;
        const isExpanded = expandedRows && expandedRows[rowItem.id]
            ? expandedRows[rowItem.id]
            : false;
        return {
            group: rowItem.variants && rowItem.variants.length > 0,
            expanded: isExpanded,
            children: rowItem.variants,
            field: "title",
            treeDepth: rowItem.treeDepth || 0,
            siblingIndex: rowItem.siblingIndex,
            numberSiblings: rowItem.numberSiblings
        };
    };

    updateSubRowDetails(subRows, parentTreeDepth) {
        const treeDepth = parentTreeDepth || 0;
        subRows.forEach((sr, i) => {
            sr.treeDepth = treeDepth + 1;
            sr.siblingIndex = i;
            sr.numberSiblings = subRows.length;
        });
    }

    onCellExpand = args => {
        let { rows, expandedRows } = this.state;
        const rowKey = args.rowData.id;
        const rowIndex = rows.indexOf(args.rowData);
        const subRows = args.expandArgs.children;
        if (expandedRows && !expandedRows[rowKey]) {
            expandedRows[rowKey] = true;
            this.updateSubRowDetails(subRows, args.rowData.treeDepth);
            rows.splice(rowIndex + 1, 0, ...subRows);
        } else if (expandedRows[rowKey]) {
            expandedRows[rowKey] = false;
            rows.splice(rowIndex + 1, subRows.length);
        }
        this.setState({ expandedRows: expandedRows, rows: rows });
        return { expandedRows, rows };
    };


    updateState() {
        const state = this.state;
        this.setState(state);
    }
}

export default Profiles;
