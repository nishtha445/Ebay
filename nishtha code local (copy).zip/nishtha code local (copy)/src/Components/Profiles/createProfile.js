import React, {Component} from 'react';
import {
  Page,
  Layout,
  TextField,
  Card,
  Stack,
  Heading,
  Select,
  Banner,
  Label,
  Button,
  FormLayout,
  ButtonGroup,
  ChoiceList
} from "@shopify/polaris";
import {isUndefined} from "util";
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import Skeleton from "../../shared/skeleton";
import {environment} from "../../environments/environment";
const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');
const shippingPackageType = [
  {label:'Unselect',value:''},
  {label:'Bulky Goods',value:'C_BULKY_GOODS'},
  {label:'Caravan',value:'C_CARAVAN'},
  {label:'Cars',value:'C_CARS'},
  {label:'Custom Code',value:'C_CUSTOM_CODE'},
  {label:'Europallet',value:'C_EUROPALLET'},
  {label:'Expandable Tough Bags',value:'C_EXPANDABLE_TOUGH_BAGS'},
  {label:'ExtraLargePack',value:'C_EXTRA_LARGE_PACK'},
  {label:'Furniture',value:'C_FURNITURE'},
  {label:'Industry Vehicles',value:'C_INDUSTRY_VEHICLES'},
  {label:'Large Canada PostBox',value:'C_LARGE_CANADA_POST_BOX'},
  {label:'Large Canada Post Bubble Mailer',value:'C_LARGE_CANADA_POST_BUBBLE_MAILER'},
  {label:'Large Envelope',value:'C_LARGE_ENVELOPE'},
  {label:'Letter',value:'C_LETTER'},
  {label:'MailingBoxes',value:'C_MAILING_BOXES'},
  {label:'MediumCanadaPostBox',value:'C_MEDIUM_CANADA_POST_BOX'},
  {label:'MediumCanadaPostBubbleMailer',value:'C_MEDIUM_CANADA_POST_BUBBLE_MAILER'},
  {label:'Motorbikes',value:'C_MOTORBIKES'},
  {label:'None',value:'C_NONE'},
  {label:'One Way Pallet',value:'C_ONE_WAY_PALLET'},
  {label:'Package Thick Envelope',value:'C_PACKAGE_THICK_ENVELOPE'},
  {label:'Padded Bags',value:'C_PADDED_BAGS'},
  {label:'Parcel Or Padded Envelope',value:'C_PARCEL_OR_PADDED_ENVELOPE'},
  {label:'Roll',value:'C_ROLL'},
  {label:'Small Canada PostBox',value:'C_SMALL_CANADA_POST_BOX'},
  {label:'Small Canada Post BubbleMailer',value:'C_SMALL_CANADA_POST_BUBBLE_MAILER'},
  {label:'Tough Bags',value:'C_TOUGH_BAGS'},
  {label:'UPS Letter',value:'C_UPS_LETTER'},
  {label:'USPS Flat Rate Envelope',value:'C_USPS_FLAT_RATE_ENVELOPE'},
  {label:'USPS Large Pack',value:'C_USPS_LARGE_PACK'},
  {label:'Very Large Pack',value:'C_VERY_LARGE_PACK'},
  {label:'Winepak',value:'C_WINEPAK'},
];
class CreateProfile extends Component {
  importServices = [];
  uploadServices = [];
  importShopLists = [];
  uploadShopLists = [];
  sourceAttributes = [];
  filteredProducts = {
    runQuery: false,
    totalProducts: 0
  };
  filterConditions = [
    { label: "Equals", value: "==" },
    { label: "Not Equals", value: "!=" },
    { label: "Contains", value: "%LIKE%" },
    { label: "Does Not Contains", value: "!%LIKE%" },
    { label: "Greater Than", value: ">" },
    { label: "Less Than", value: "<" },
    { label: "Greater Than Equal To", value: ">=" },
    { label: "Less Than Equal To", value: "<=" }
  ];

  constructor(props){
    super(props);
    this.state={
      submitBtnLoader: false,
      showCollectionDetails: false,
      form_data:{
        profile_name:'',

        dropdown: {
          shipping_policy:{
            heading:'Shipping Policy',
            selected_id:'',
            show_dropdown:false,
            options:[]
          },
          payment_policy:
            {
              heading:'Payment Policy',
              selected_id:'',
              show_dropdown:false,
              options:[]
            },
          return_policy:{
            heading:'Return Policy',
            selected_id:'',
            show_dropdown:false,
            options:[]
          },
          inventory_template:{
            heading:'Inventory template',
            key:'inventory',
            selected_id:'',
            show_dropdown:false,
            options:[]
          },
          pricing_template:{
            heading:'Pricing template',
            selected_id:'',
            key:'pricing',
            show_dropdown:false,
            options:[]
          },
          title_template:{
            heading:'Title template',
            selected_id:'',
            key:'title',
            show_dropdown:false,
            options:[]
          },
          category_template:{
            heading:'Category template',
            selected_id:'',
            key:'category',
            show_dropdown:false,
            options:[]
          },
        },

        basicDetails: {
          source: "shopify",
          sourceShop: "",
          targetShop: "",
          target: "ebay"
        },
        shipping_package_type : "",
        variation_image_setting:[],
        queryBuilder:{

          filterQuery: {
            primaryQuery: [
              {
                key: "",
                operator: "",
                value: ""
              }
            ],
            condition: "AND",
            position: 1,
            secondaryQuery: {}
          },

          products_select: {
            query: "",
            targetCategory: "",
            marketplaceAttributes: []
          },

          sourceAttributes: []

        }

      },
      missingOptions:false,
      options_recieved:{
        shopifyattrib:[],
      },
      businessPolicyprepared :false,
      templatesPrepared : false,
      loader_import_collection:false,
      loader_update_collection:false,
      collections_options : [],
      collection_selected : '',
      errors:{
        profile_name:false,
        shipping_policy: false,
        payment_policy: false,
        return_policy: false,
        title_template: false,
        pricing_template: false,
        inventory_template: false,
        category_template: false,
        querybuilder:false,
      },
      QuerybuilderLoader:false,
      site_id:'',
    }

    this.fetchDataForSteptwo();
    this.getImportServices();
    this.getUploadServices();
  }

  setShopifyAttribute(data){
    let temparr=[];
    data.forEach((value,index)=>{
      temparr.push({label:value,value:value})
    });
    this.state.options_recieved.shopifyattrib=temparr;
    this.setState(this.state);
  }
  getShopifyConfigurableAttributes(){
    requests.getRequest('connector/get/configurableAttributes').then(data=>{
      if(data.success){
        this.setShopifyAttribute(data.data);
      }
    })
  }

  handleBasicDetailsChange(key, value) {
    this.state.form_data.basicDetails[key] = value;
    switch (key) {
      case "source":
        for (let i = 0; i < this.importServices.length; i++) {
          if (this.importServices[i].value === value) {
            this.importShopLists = [];
            for (let j = 0; j < this.importServices[i].shops.length; j++) {
              this.importShopLists.push({
                label: this.importServices[i].shops[j].shop_url,
                value: this.importServices[i].shops[j].shop_url,
                shop_id: this.importServices[i].shops[j].id
              });
            }
            this.state.form_data.basicDetails.sourceShop =
              this.importShopLists.length > 0
                ? this.importShopLists[0].value
                : "";
          }
        }
        break;
      case "target":
        for (let i = 0; i < this.uploadServices.length; i++) {
          if (this.uploadServices[i].value === value) {
            this.uploadShopLists = [];
            for (let j = 0; j < this.uploadServices[i].shops.length; j++) {
              this.uploadShopLists.push({
                label: this.uploadServices[i].shops[j].site_id,
                value: this.uploadServices[i].shops[j].site_id,
                shop_id: this.uploadServices[i].shops[j].id
              });
            }
            this.state.form_data.basicDetails.targetShop =
              this.uploadShopLists.length > 0
                ? this.uploadShopLists[0].value
                : "";
          }
        }
        break;
    }
    this.updateState();
  }

  getImportServices() {
    requests
      .getRequest("connector/get/services", { "filters[type]": "importer" })
      .then(data => {
        if (data.success === true) {
          this.importServices = [];
          for (let i = 0; i < Object.keys(data.data).length; i++) {
            let key = Object.keys(data.data)[i];
            if(key === 'shopify_importer') {
              this.importServices.push({
                label: data.data[key].title,
                value: data.data[key].marketplace,
                shops: data.data[key].shops
              });
            }
          }
          this.handleBasicDetailsChange("source", "shopify");
          this.updateState();
        } else {
          notify.error(
            "You have no available product import service. Kindly choose a plan."
          );
        }
      });
  }


  FillDefaultSettings(){

    requests.getRequest('ebayV1/get/globalConfigData').then(data=>{
      if(data.success){
        Object.keys(data.data).map(key=>{
          if(key==='payment_policy' || key==='return_policy' || key==='shipping_policy' || key==='category_template' || key === 'title_template' || key === 'price_template' || key === 'inventory_template'){
            let newKey = key;
            if(key === 'price_template') key = "pricing_template";
            this.state.form_data.dropdown[key].selected_id=data.data[newKey]?data.data[newKey]:'';
          }
          // if(key==='category_template') this.state.form_data.dropdown[key].selected_id = true
        })
        this.setState(this.state);
      }
      this.getSideID();
    })

  }


  componentDidMount() {
    this.FillDefaultSettings();
    this.getShopifyConfigurableAttributes();

  }
  getSideID() {
    requests.getRequest('ebayV1/get/siteId').then(data => {
      if (data.success) {
        this.state.site_id = !isUndefined(data.data.site_id) ? data.data.site_id : '';
        // this.state.site_id ='MOTORS';
      }
      this.setState(this.state);
      this.getBusinessPolicy();

    });

  }

  getUploadServices() {
    requests
      .getRequest("connector/get/services", { "filters[type]": "uploader" })
      .then(data => {
        if (data.success) {
          this.uploadServices = [];
          for (let i = 0; i < Object.keys(data.data).length; i++) {
            let key = Object.keys(data.data)[i];
            if(key==='ebay_uploader') {
              this.uploadServices.push({
                label: data.data[key].title,
                value: data.data[key].marketplace,
                shops: data.data[key].shops
              });
            }
          }
          this.handleBasicDetailsChange("target", "ebay");
          this.updateState();
        } else {
          notify.error(
            "You have no available product upload service. Kindly choose a plan."
          );
        }
      });
  }



  redirect(url){
    this.props.history.push(url);
  }

  fetchDataForSteptwo(fetchMarketplaceAttributes) {
    this.getSourceAttributes();
  }
  dictionedData(data){
    let Obj ={};
    data.forEach((option,index)=>{
      Obj[option.label] = index;
    });
    let Ordered_Array = [];
    Object.keys(Obj).sort().forEach(key =>{
      data[Obj[key]]['label'] = data[Obj[key]]['label']+"-"+data[Obj[key]]['value']
      Ordered_Array.push(data[Obj[key]]);
    });
    return Ordered_Array;
  }

  getSourceAttributes() {
    requests
      .getRequest("ebayV1/get/getSourceAttributes", {
        marketplace: 'shopify'
      })
      .then(data => {
        if (data.success) {
          this.sourceAttributes = [];
          for (let i = 0; i < data.data.length; i++) {
            if(!isUndefined(data.data[i].options)){
              let dictioned_options = this.dictionedData(data.data[i].options);
              this.sourceAttributes.push({
                label: data.data[i].title,
                value: data.data[i].code,
                options_shopify: dictioned_options.slice(0)
              });
              if(data.data[i].code == 'collections') {
                this.state.collections_options = dictioned_options.slice(0);
              }
            }else{
              this.sourceAttributes.push({
                label: data.data[i].title,
                value: data.data[i].code
              });
            }
          }

          this.updateState();
        } else {
          notify.error(data.message);
        }
      });
  }

  updateState() {
    const state = this.state;
    this.setState(state);
  }

  general_skeleton=true;

  getBusinessPolicy(){
    requests.postRequest('ebayV1/template/get',{multitype:['shipping','payment','return']}).then(data => {
      if(data.success){
        if(data.data.length!==0){
          this.general_skeleton=false;
          this.createDropdownData(data.data);
        }
      }
      this.getTemplates();
    });
  }

  getTemplates(){
    requests.postRequest('ebayV1/template/get',{multitype:['category','price','inventory','title']}).then(data => {
      if(data.success){
        if(data.data.length!==0){
          this.createDropdownDataTemplates(data.data);
        }
      }

    });

  }

  saveConfigurations(key){
    console.log(
      this.state.dropdown[key]
    )
  }

  createNewTemplate(key){
    let tempObj={display:key,type:'Template'}
    let message=cryptr.encrypt(JSON.stringify(tempObj));
    this.redirect('/panel/template/modifier?message='+encodeURI(message));
  }

  createNewBusinesspolicy(key){
    let tempObj={display:key,type:'Business policy'}
    let message=cryptr.encrypt(JSON.stringify(tempObj));
    this.redirect('/panel/template/modifier?message='+encodeURI(message));
  }


  renderTemplates(){
    let temparr=[];
    if(this.general_skeleton){
      return <Skeleton case="profile_templete"/>
    }
    else {
      Object.keys(this.state.form_data.dropdown).map(key => {

        if (key.includes("template")) {

          temparr.push(
            <Layout.Section oneHalf key={'template' + key}>
              {this.state.form_data.dropdown[key].options.length !== 0 ?
                <Card /*primaryFooterAction={{
                                        content: 'Save',
                                        onAction: this.saveConfigurations.bind(this, key)
                                    }}*/>

                  <Card.Section title={this.state.form_data.dropdown[key].heading}>

                    < Select
                      key={'dropdown_' + key + '_details'}
                      options={this.state.form_data.dropdown[key].options}
                      error={this.state.errors[key] ? '*required field' : ''}
                      placeholder={"Choose.."}
                      value={this.state.form_data.dropdown[key].selected_id}
                      onChange={this.dropdownChange.bind(this, key, 'selected_id')}/>

                  </Card.Section>


                </Card>
                :
                <Card>
                  <Card.Section>
                    <Banner status={"info"}>
                      <p>No {this.state.form_data.dropdown[key].heading} found, Kindly create one
                        in <a style={{color: 'blue', cursor: 'pointer'}}
                              onClick={this.createNewTemplate.bind(this,this.state.form_data.dropdown[key].key)}>Templates
                          section</a></p>
                    </Banner>
                  </Card.Section>
                </Card>
              }
            </Layout.Section>
          )
        }
      })

      return temparr;
    }
  }



  renderProfiles(){

    let temparr=[];
    if(this.general_skeleton){
      return <Skeleton case="profile_businesspolicy"/>
    }
    else{
      // if(this.state.site_id!=='MOTORS') {
      Object.keys(this.state.form_data.dropdown).map(key => {
        if (key.includes("policy")) {
          temparr.push(
            <React.Fragment key={key + '12'}>
              {this.state.form_data.dropdown[key].options.length !== 0 ?
                <Card /*primaryFooterAction={{
                                        content: 'Save',
                                        onAction: this.saveConfigurations.bind(this, key)
                                    }}*/>

                  <Card.Section title={this.state.form_data.dropdown[key].heading}>

                    < Select
                      key={'dropdown_' + key + '_details'}
                      options={this.state.form_data.dropdown[key].options}
                      error={this.state.errors[key] ? '*required field' : ''}
                      placeholder={"Choose.."}
                      value={this.state.form_data.dropdown[key].selected_id}
                      onChange={this.dropdownChange.bind(this, key, 'selected_id')}/>

                  </Card.Section>


                </Card>
                :
                <Card>
                  <Card.Section>
                    <Banner status={"info"}>
                      <p>No {this.state.form_data.dropdown[key].heading} found, Kindly create
                        one in <a style={{color: 'blue', cursor: 'pointer'}}
                                  onClick={this.createNewBusinesspolicy.bind(this,key)}>Business
                          profiles</a> section</p>
                    </Banner>
                  </Card.Section>
                </Card>
              }
            </React.Fragment>
          )
        }
      });
      // }
      // else{
      //     Object.keys(this.state.form_data.dropdown).map(key => {
      //         if (key.includes("policy") && key !=='return_policy') {
      //             temparr.push(
      //                 <React.Fragment key={key + '12'}>
      //                     {this.state.form_data.dropdown[key].options.length !== 0 ?
      //                         <Card /*primaryFooterAction={{
      //                             content: 'Save',
      //                             onAction: this.saveConfigurations.bind(this, key)
      //                         }}*/>
      //
      //                             <Card.Section title={this.state.form_data.dropdown[key].heading}>
      //
      //                                 < Select
      //                                     key={'dropdown_' + key + '_details'}
      //                                     options={this.state.form_data.dropdown[key].options}
      //                                     error={this.state.errors[key] ? '*required field' : ''}
      //                                     placeholder={"Choose.."}
      //                                     value={this.state.form_data.dropdown[key].selected_id}
      //                                     onChange={this.dropdownChange.bind(this, key, 'selected_id')}/>
      //
      //                             </Card.Section>
      //
      //
      //                         </Card>
      //                         :
      //                         <Card>
      //                             <Card.Section>
      //                                 <Banner status={"info"}>
      //                                     <p>No {this.state.form_data.dropdown[key].heading} found, Kindly create
      //                                         one in <a style={{color: 'blue', cursor: 'pointer'}}
      //                                                   onClick={this.redirect.bind(this, '/panel/businesspolicies/list')}>Business
      //                                             profiles</a> section</p>
      //                                 </Banner>
      //                             </Card.Section>
      //                         </Card>
      //                     }
      //                 </React.Fragment>
      //             )
      //         }
      //     });
      // }

      return temparr;
    }

  }

  saveProfile(){
    if(this.formValidator()) {
      let PolicyandTemplate={};
      Object.keys(this.state.form_data.dropdown).map(key=>{
        PolicyandTemplate[key]=this.state.form_data.dropdown[key].selected_id;
      });
      let tempObj={
        saveInTable:true,
        step:1,
        data:{
          name:this.state.form_data.profile_name.trim(),
          source:'shopify',
          target:'ebay',
          shipping_package_type: this.state.form_data.shipping_package_type,
          sourceShop:this.state.form_data.basicDetails.sourceShop,
          targetShop:this.state.form_data.basicDetails.targetShop,
          query:this.state.form_data.queryBuilder.products_select.query,
          marketplaceAttributes:Object.assign({},PolicyandTemplate),
        },
      };
      this.setState({submitBtnLoader: true})
      requests.postRequest("connector/profile/set",tempObj).then(data=>{
        if(data.success){
          notify.success(data.message);
          this.redirect('/panel/profiles');
        }else{
          notify.error(data.message);
        }
        this.setState({submitBtnLoader: false})
      });
    }
  }

  formValidator(){
    let error=0;
    // console.log('this.state.form_data',this.state.form_data)
    Object.keys(this.state.form_data).map(key=>{
      switch(key){
        case 'profile_name':
          if(this.state.form_data.profile_name === '') {
            error++;
            this.state.errors.profile_name = true
          }
          else{
            this.state.errors.profile_name = false
          }
          // console.log('error', error)
          break;
        case 'dropdown':
          // console.log('this.state.site_id', this.state.site_id)
          if(this.state.site_id !== 'MOTORS') {
            Object.keys(this.state.form_data.dropdown).map(dropdown => {
              if (dropdown !== 'inventory_template' && dropdown !== 'pricing_template' && dropdown !== 'title_template') {
                if (this.state.form_data.dropdown[dropdown].selected_id === '') {
                  error++;
                  this.state.errors[dropdown] = true;
                  // console.log('error', error)
                }
                else {
                  this.state.errors[dropdown] = false;
                }
              }
            });
          }else{
            Object.keys(this.state.form_data.dropdown).map(dropdown => {
              if (dropdown !== 'inventory_template' && dropdown !== 'pricing_template' && dropdown !== 'title_template' && dropdown !== 'return_policy') {
                if (this.state.form_data.dropdown[dropdown].selected_id === '') {
                  error++;
                  this.state.errors[dropdown] = true;
                }
                else {
                  this.state.errors[dropdown] = false;
                }
              }
            });
          }
          break;

        case 'queryBuilder':

          if(this.state.form_data.queryBuilder.products_select.query===''){
            error++;
            this.state.errors.querybuilder=true;
          }
          else{
            this.state.errors.querybuilder=false;
          }
          // console.log('error', error)
          break;
      }
    });
    this.setState(this.state);
    if(error===0){
      return true;
    }
    else {
      return false;
    }
  }

  renderErrors(){
    let temparr=[];
    if(this.state.site_id === 'MOTORS') {
      Object.keys(this.state.form_data.dropdown).map(key => {
        if (key !== 'pricing_template' && key !== 'inventory_template' && key !== 'title_template' && key !== 'return_policy') {
          if (this.state.form_data.dropdown[key].options.length === 0) {
            temparr.push(
              <Banner status={"critical"}>
                <p>No {this.state.form_data.dropdown[key].heading} found, Kindly create one</p>
              </Banner>
            );
          }
        }
      })
    }else{
      Object.keys(this.state.form_data.dropdown).map(key => {
        if (key !== 'pricing_template' && key !== 'inventory_template' && key !== 'title_template') {
          if (this.state.form_data.dropdown[key].options.length === 0) {
            temparr.push(
              <Banner status={"critical"}>
                <p>No {this.state.form_data.dropdown[key].heading} found, Kindly create one</p>
              </Banner>
            );
          }
        }
      })
    }
    return temparr;
  }


  importCollections(){
    this.setState({loader_import_collection:true});
    requests.getRequest('shopify/import/collections',{shop:this.importShopLists[0].value}).then(data=>{
      if(data.success){
        notify.success(data.message);
        this.getSourceAttributes();
      }else {
        notify.error(data.message);
      }
      this.setState({loader_import_collection:false});
    })
  }

  updateProductsinCollections(){
    this.setState({loader_update_collection:true});
    requests.postRequest('ebayV1/get/updateProductsinCollection',{collection_id:this.state.collection_selected}).then(data=>{
      if(data.success){
        notify.success(data.message);
        this.getSourceAttributes();
      }else {
        notify.error(data.message);
      }
      this.setState({loader_update_collection:false});
    })
  }


  render() {
    return (
      <Page fullWidth={true}  breadcrumbs={[{content: 'Profiles', onAction:this.redirect.bind(this,'/panel/profiles')}]} title={"Create profile"}
            primaryAction={{content:'Submit',onAction:this.saveProfile.bind(this), loading: this.state.submitBtnLoader}}>
        <Card primaryFooterAction={{content:'Submit',onAction:this.saveProfile.bind(this), loading: this.state.submitBtnLoader}}>
          {this.state.missingOptions &&
          <Card.Section>
            <FormLayout>
              {this.renderErrors()}
            </FormLayout>
          </Card.Section>
          }
          <Card.Section title={"Profile name"}>
            <TextField
              key={'ProfileName'}
              value={this.state.form_data.profile_name}
              error={this.state.errors.profile_name?'*required field':''}
              placeholder={'Profile name...'}
              onChange={this.feildsChange.bind(this,'form_data','profile_name')}/>
          </Card.Section>
          {this.state.businessPolicyprepared &&
          <Card.Section title={"Business policies"}>
            <FormLayout>
              <FormLayout.Group condensed>
                {
                  this.renderProfiles()
                }
              </FormLayout.Group>
            </FormLayout>
          </Card.Section>
          }
          {this.state.templatesPrepared &&
          <Card.Section title={"Templates"}>
            <Layout>
              {
                this.renderTemplates()
              }
            </Layout>
          </Card.Section>
          }
          <Card.Section title={"Package type"}>
            <Select label={""} options={shippingPackageType} onChange={this.feildsChange.bind(this,'form_data','shipping_package_type')} value={this.state.form_data.shipping_package_type}/>
          </Card.Section>
          {/*<Card.Section title={'Variation image setting'}>*/}
          {/*<div style={{maxHeight: 100, overflowY: 'scroll'}}>*/}
          {/*<ChoiceList*/}
          {/*key={'VariationImageSetting'}*/}
          {/*title={''}*/}
          {/*allowMultiple*/}
          {/*choices={this.state.options_recieved.shopifyattrib}*/}
          {/*selected={this.state.form_data.variation_image_setting}*/}
          {/*onChange={this.feildsChange.bind(this,'form_data','variation_image_setting')}*/}
          {/*/>*/}
          {/*</div>*/}
          {/*</Card.Section>*/}
          <Card.Section title={'Filter products'}>
            {this.state.showCollectionDetails && <Stack vertical={true} distribution={"fill"}>

                <Banner
                    title={"Please note if products are not shown in app then you need to import them using following steps."}
                    status={"warning"}
                >
                  <ol>
                    <li>Select your collections from configuration section and</li>
                    <li>Import them by Shopify action > Import Collection products from Shopify action in Product section</li>
                  </ol>
                </Banner>
                <Banner
                  title="To update products assigned to a collection, click on button below. Please note this action only assigns the product ids in the app but for products to display you need to import them using above instruction."
                  // action={{
                  //   content: 'Update product in collection',
                  //   onAction: this.updateProductsinCollections.bind(this),
                  //   loading: this.state.loader_update_collection,
                  //   disabled: this.state.collection_selected === ''
                  // }}
                >
                  <div class="d-flex justify-content-between">
                  {/* <div class="w-75"> */}
                    <Select label={''}

                            options={this.state.collections_options}
                            placeholder={'Select...'}
                            value={this.state.collection_selected}
                            onChange={(e) => {
                              this.setState({collection_selected: e});
                            }}
                    />
                  {/* </div> */}
                  <Button onClick={this.updateProductsinCollections.bind(this)} loading={this.state.loader_update_collection} disabled={this.state.collection_selected === ''}>Update product in collection</Button>
                  </div>
                </Banner>

            </Stack>}
            {this.state.errors.querybuilder &&
            <Banner status="critical">
              <Label>
                Kindly generate a query for filtering products.
              </Label>
            </Banner>
            }
            <br/>
            {
              this.renderQueryBuilderStructure()
            }
            {this.state.form_data.queryBuilder.products_select.query !== "" &&

            <Stack vertical={true}>
              {this.state.form_data.queryBuilder.products_select.query !== "" && (
                <div className={'mt-5'} style={{textAlign:'center'}}>
                  <Button
                    loading={this.state.QuerybuilderLoader}
                    onClick={() => {
                      this.runFilterQuery();
                    }}
                    primary
                  >
                    Test Your Query
                  </Button>
                </div>
              )}
              {this.filteredProducts.runQuery && (
                <Banner title="Selected Products Count" status="success">
                  <Label>
                    Total {this.filteredProducts.totalProducts} product(s) are selected
                    under this query : {this.state.form_data.queryBuilder.products_select.query}
                  </Label>
                </Banner>
              )}
            </Stack>
            }
          </Card.Section>
        </Card>
      </Page>
    );
  }

  runFilterQuery() {
    this.state.QuerybuilderLoader=true;
    if (this.state.form_data.queryBuilder.products_select.query !== "") {
      requests
        .postRequest("ebayV1/get/productsByQuery", {
          marketplace: 'shopify',
          query: this.state.form_data.queryBuilder.products_select.query,
          sendCount: true
        })
        .then(data => {
          if (data.success) {
            this.filteredProducts = {
              runQuery: true,
              totalProducts: data.data
            };
          } else {
            notify.error(data.message);
          }
          this.state.QuerybuilderLoader=false;
          this.updateState();
        });
    } else {
      notify.info("Please prepare a custom query to select products");
      this.state.QuerybuilderLoader=false;
      this.updateState();
    }
  }


  renderQueryBuilderStructure(){
    let temparr=[];

    temparr.push(
      <React.Fragment key={'QueryBuilder'}>
        <Stack vertical={true} spacing={"loose"}>
          {/* <Banner status="info">
            <Label>
              <h4>
                <b>Add rule</b> corresponds to && (AND) condition
              </h4>
            </Label>
            <Label>
              <h4>
                <b>Add rule group</b> corresponds to || (OR) condition
              </h4>
            </Label>
          </Banner> */}
          {this.renderQueryBuilder(this.state.form_data.queryBuilder.filterQuery)}
        </Stack>
      </React.Fragment>

    )

    return temparr;

  }

  checkForOptions(value) {
    let temp = false;
    this.sourceAttributes.forEach(data => {
      if (data.value === value) {
        if (!isUndefined(data.options_shopify)) {
          temp = data.options_shopify;
        }
      }
    });
    return temp;
  }

  handleQueryBuilderChange(position, index, field, value) {
    // this.checkForOptions(value);
    this.filteredProducts.runQuery = false;
    if(field === 'value') {
      value = value.trimStart();
    }
    if (field === "key") {
      if(value === 'collections') {
        this.state.showCollectionDetails = true;
        // this.setState({showCollectionDetails: true}, () => {
        //   console.log(this.state)
        // })
      } else {
        this.state.showCollectionDetails = false;
      }
      const options = this.checkForOptions(value);
      if (options !== false) {
        this.state.form_data.queryBuilder.filterQuery = this.updateQueryFilter(
          this.state.form_data.queryBuilder.filterQuery,
          position,
          index,
          field,
          value,
          options
        );
      } else {
        this.state.form_data.queryBuilder.filterQuery= this.updateQueryFilter(
          this.state.form_data.queryBuilder.filterQuery,
          position,
          index,
          field,
          value
        );
      }
    } else {
      this.state.form_data.queryBuilder.filterQuery = this.updateQueryFilter(
        this.state.form_data.queryBuilder.filterQuery,
        position,
        index,
        field,
        value
      );
    }
    this.handleFilterQueryChange(this.state.form_data.queryBuilder.filterQuery);
    this.updateState();
  }

  handleFilterQueryChange(query) {
    this.state.form_data.queryBuilder.products_select.query = this.prepareQuery(query, "");
  }

  prepareQuery(query, preparedQuery) {
    preparedQuery += "(";
    let end = "";
    for (let i = 0; i < query.primaryQuery.length; i++) {
      if (
        query.primaryQuery[i].key !== "" &&
        query.primaryQuery[i].operator !== "" &&
        query.primaryQuery[i].value !== ""
      ) {
        preparedQuery +=
          end +
          query.primaryQuery[i].key +
          " " +
          query.primaryQuery[i].operator +
          " " +
          query.primaryQuery[i].value;
        end = " && ";
      }
    }
    preparedQuery += ")";
    if (preparedQuery === "()") {
      preparedQuery = "";
    }
    if (Object.keys(query.secondaryQuery).length > 0) {
      const orQuery = this.prepareQuery(query.secondaryQuery, "");
      if (orQuery !== "") {
        preparedQuery += " || " + orQuery;
      }
    }
    return preparedQuery;
  }

  updateQueryFilter(query, position, index, field, value, options) {
    if (query.position === position) {
      if (field === "key") {
        query.primaryQuery[index]["value"] = "";
        if (isUndefined(options)) {
          query.primaryQuery[index].options = undefined;
        }
      }
      if (!isUndefined(options)) {
        query.primaryQuery[index][field] = value;
        query.primaryQuery[index].options = options;
      } else {
        query.primaryQuery[index][field] = value;
      }
    } else {
      query.secondaryQuery = this.updateQueryFilter(
        query.secondaryQuery,
        position,
        index,
        field,
        value,
        options
      );
    }
    return query;
  }

  renderQueryBuilder(querySet) {

    return (
      <React.Fragment>
      <Banner status="info">
        <Label>
          <h4>
            <b>Add rule group</b> corresponds to || (OR) condition
          </h4>
        </Label>
      </Banner>
      <br />
      <FormLayout>
        {querySet.position === 1 && this.state.form_data.queryBuilder.products_select.query !== "" && (
          <Banner title="Prepared Query" status="info">
            <Label>{this.state.form_data.queryBuilder.products_select.query}</Label>
          </Banner>
        )}

        <Card sectioned>
          {querySet.primaryQuery.map(query => {
            return (
              <FormLayout key={'line'+query}>
                <br />
              <Banner status="info">
                <Label>
                  <h4>
                    <b>Add rule</b> corresponds to && (AND) condition
                  </h4>
                </Label>
              </Banner>
                <FormLayout.Group condensed>
                  <Select
                    label="Attribute"
                    options={this.sourceAttributes}
                    placeholder="Select Attribute"
                    onChange={this.handleQueryBuilderChange.bind(
                      this,
                      querySet.position,
                      querySet.primaryQuery.indexOf(query),
                      "key"
                    )}
                    value={query.key}
                  />

                  <Select
                    label="Operator"
                    options={this.filterConditions}
                    placeholder="Select Operator"
                    onChange={this.handleQueryBuilderChange.bind(
                      this,
                      querySet.position,
                      querySet.primaryQuery.indexOf(query),
                      "operator"
                    )}
                    value={query.operator}
                  />

                  {isUndefined(query.options) || query.options.length <= 0 ? (
                    <TextField
                      label="Value"
                      value={query.value}
                      placeholder="Filter Value"
                      onChange={this.handleQueryBuilderChange.bind(
                        this,
                        querySet.position,
                        querySet.primaryQuery.indexOf(query),
                        "value"
                      )}
                    />
                  ) : (
                    <Select
                      label="Value"
                      options={query.options}
                      placeholder="Filter Value"
                      onChange={this.handleQueryBuilderChange.bind(
                        this,
                        querySet.position,
                        querySet.primaryQuery.indexOf(query),
                        "value"
                      )}
                      value={query.value}
                    />
                  )}
                </FormLayout.Group>
                <Stack>
                  <Stack.Item fill>
                    <React.Fragment />
                  </Stack.Item>
                  {
                    <Stack.Item>
                      {/*{querySet.primaryQuery.indexOf(query) !== 0 && (*/}
                      <Button
                        disabled={querySet.primaryQuery.length===1}
                        onClick={() => {
                          this.handleDeleteRule(
                            querySet.position,
                            querySet.primaryQuery.indexOf(query)
                          );
                        }}
                      >
                        Delete Rule
                      </Button>
                      {/*)}*/}
                    </Stack.Item>
                  }
                  {
                    <Stack.Item>
                      {querySet.primaryQuery.indexOf(query) ===
                      querySet.primaryQuery.length - 1 && (
                        <Button
                          onClick={() => {
                            this.handleAddRule(querySet.position);
                          }}
                          primary
                        >
                          Add Rule
                        </Button>
                      )}
                    </Stack.Item>
                  }
                </Stack>
              </FormLayout>
            );
          })}
        </Card>

        <Stack vertical={true} alignment={"trailing"}>
          <ButtonGroup>
            {Object.keys(querySet.secondaryQuery).length === 0 &&
            querySet.position !== 1 && (
              <Button
                onClick={() => {
                  this.handleDeleteGroup(querySet.position);
                }}
              >
                Delete Rule Group
              </Button>
            )}

            {Object.keys(querySet.secondaryQuery).length === 0 && (
              <Button
                onClick={() => {
                  this.handleAddGroup(querySet.position, "OR");
                }}
                primary
              >
                Add Rule Group
              </Button>
            )}
          </ButtonGroup>
        </Stack>
        {Object.keys(querySet.secondaryQuery).length > 1 && (
          <React.Fragment>
            {this.renderQueryBuilder(querySet.secondaryQuery)}
          </React.Fragment>
        )}


      </FormLayout>
      </React.Fragment>
    );
  }

  handleAddGroup(position, condition) {
    this.state.form_data.queryBuilder.filterQuery = this.addGroup(
      this.state.form_data.queryBuilder.filterQuery,
      position,
      condition
    );
    this.handleFilterQueryChange(this.state.form_data.queryBuilder.filterQuery);
    this.updateState();
  }
  deleteGroup(query, position) {
    if (query.position === position) {
      query = {};
    } else {
      query.secondaryQuery = this.deleteGroup(query.secondaryQuery, position);
    }
    return query;
  }

  addGroup(query, position, condition) {
    if (query.position === position) {
      query.secondaryQuery = {
        primaryQuery: [
          {
            key: "",
            operator: "",
            value: ""
          }
        ],
        condition: condition,
        position: position + 1,
        secondaryQuery: {}
      };
    } else {
      query.secondaryQuery = this.addGroup(
        query.secondaryQuery,
        position,
        condition
      );
    }
    return query;
  }

  deleteRule(query, position, index) {
    if (query.position === position) {
      query.primaryQuery.splice(index, 1);
    } else {
      query.secondaryQuery = this.deleteRule(
        query.secondaryQuery,
        position,
        index
      );
    }
    return query;
  }

  addRule(query, position) {
    if (query.position === position) {
      query.primaryQuery.push({
        key: "",
        operator: "",
        value: ""
      });
    } else {
      query.secondaryQuery = this.addRule(query.secondaryQuery, position);
    }
    return query;
  }

  handleAddRule(position) {
    this.state.form_data.queryBuilder.filterQuery = this.addRule(this.state.form_data.queryBuilder.filterQuery, position);
    this.handleFilterQueryChange(this.state.form_data.queryBuilder.filterQuery);
    this.updateState();
  }

  handleDeleteRule(position, index) {
    this.state.form_data.queryBuilder.filterQuery = this.deleteRule(
      this.state.form_data.queryBuilder.filterQuery,
      position,
      index
    );
    this.handleFilterQueryChange(this.state.form_data.queryBuilder.filterQuery);
    this.updateState();
  }

  handleDeleteGroup(position) {
    this.state.form_data.queryBuilder.filterQuery = this.deleteGroup(this.state.form_data.queryBuilder.filterQuery, position);
    this.handleFilterQueryChange(this.state.form_data.queryBuilder.filterQuery);
    this.updateState();
  }


  feildsChange(key,tag,value){
    let tempObj=Object.assign({},this.state);
    tempObj[key][tag]=value;
    this.setState(tempObj);

  }


  createDropdownData(data){
    let check=0;
    let return_dropdown_options=[];
    let payment_dropdown_options=[];
    let shipping_dropdown_options=[];
    data.forEach((obj,index)=>{
      switch (obj.type) {
        case 'return':
          if(!isUndefined(obj.data))
          {
            return_dropdown_options.push(
              {label:obj.data.profileName,value:(obj.data.profileId).toString()}
            );
          }
          break
        case 'payment':
          if(!isUndefined(obj.data))
          {
            payment_dropdown_options.push(
              {label:obj.data.profileName,value:(obj.data.profileId).toString()}
            );
          }
          break;
        case 'shipping':
          if(!isUndefined(obj.data))
          {
            shipping_dropdown_options.push(
              {label:obj.data.profileName,value:(obj.data.profileId).toString()}
            );
          }
          break;

      }
    });
    // if(this.state.site_id !== 'MOTORS' && this.state.site_id !== '') {
    if (return_dropdown_options.length === 0) {
      this.state.form_data.dropdown.return_policy.show_dropdown = false;
      check = 1;
    }
    else {
      this.state.form_data.dropdown.return_policy.show_dropdown = true;
      this.state.form_data.dropdown.return_policy.options = return_dropdown_options;
    }
    // }
    if(payment_dropdown_options.length===0){
      check=1;
      this.state.form_data.dropdown.payment_policy.show_dropdown=false;
    } else{
      this.state.form_data.dropdown.payment_policy.show_dropdown=true;
      this.state.form_data.dropdown.payment_policy.options=payment_dropdown_options;
    }
    if(shipping_dropdown_options.length===0){
      check=1;
      this.state.form_data.dropdown.shipping_policy.show_dropdown=false;
    }else{
      this.state.form_data.dropdown.shipping_policy.show_dropdown=true;
      this.state.form_data.dropdown.shipping_policy.options=shipping_dropdown_options;
    }
    if (check === 1) {
      this.state.missingOptions = true;
    }
    else {
      this.state.missingOptions = false;
    }
    this.state.businessPolicyprepared =true;
    this.setState(this.state);
  }

  createDropdownDataTemplates(data){
    let check=0;
    let price_dropdown_options=[];
    let title_dropdown_options=[];
    let inventory_dropdown_options=[];
    let category_dropdown_options=[];
    data.forEach((obj,index)=>{
      switch (obj.type) {
        case 'price':
          // if(!isUndefined(obj.data))
          // {
          price_dropdown_options.push(
            {label:obj.title,value:(obj._id).toString()}
          );
          // }
          break;
        case 'category':
          // if(!isUndefined(obj.data))
          // {
          category_dropdown_options.push(
            {label:obj.title,value:(obj._id).toString()}
          );
          // }
          break;
        case 'title':
          // if(!isUndefined(obj.data))
          // {
          title_dropdown_options.push(
            {label:obj.title,value:(obj._id).toString()}
          );
          // }
          break;
        case 'inventory':
          // if(!isUndefined(obj.data))
          // {
          inventory_dropdown_options.push(
            {label:obj.title,value:(obj._id).toString()}
          );
          // }
          break;

      }
    });
    if(title_dropdown_options.length===0){
      check=1;
      this.state.form_data.dropdown.title_template.show_dropdown=false;
    }else{
      this.state.form_data.dropdown.title_template.show_dropdown=true;
      this.state.form_data.dropdown.title_template.options=title_dropdown_options;
    }
    if(inventory_dropdown_options.length===0){
      check=1;
      this.state.form_data.dropdown.inventory_template.show_dropdown=false;
    }else{
      this.state.form_data.dropdown.inventory_template.show_dropdown=true;
      this.state.form_data.dropdown.inventory_template.options=inventory_dropdown_options;
    }
    if(price_dropdown_options.length===0){
      check=1;
      this.state.form_data.dropdown.pricing_template.show_dropdown=false;
    }else{
      this.state.form_data.dropdown.pricing_template.show_dropdown=true;
      this.state.form_data.dropdown.pricing_template.options=price_dropdown_options;
    }
    if(category_dropdown_options.length===0){
      check=1;
      this.state.form_data.dropdown.category_template.show_dropdown=false;
    }else{
      this.state.form_data.dropdown.category_template.show_dropdown=true;
      this.state.form_data.dropdown.category_template.options=category_dropdown_options;
    }
    if (check === 1) {
      this.state.missingOptions = true;
    }
    else {
      this.state.missingOptions = false;
    }
    this.state.templatesPrepared = true;

    this.setState(this.state);
  }

  dropdownChange(key,tag,value){
    let tempObj = Object.assign({}, this.state);
    tempObj.form_data.dropdown[key][tag] = value;
    this.setState(tempObj);
  }
}

export default CreateProfile;
