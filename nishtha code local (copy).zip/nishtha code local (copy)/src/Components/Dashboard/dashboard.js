import React, {Component} from 'react';
import {
  Page,
  TextStyle,
  FooterHelp,
  Layout,
  Stack,
  ResourceList,
  Avatar,
  Banner,
  Label,
  Checkbox,
  Card,
  Select,
  DisplayText,
  Heading,
  Link,
  Icon,
  Badge,
  Modal,
  Button,
  FormLayout,
  List,
  Thumbnail,
  TextField, Tooltip, TextContainer
} from "@shopify/polaris";
import { Like } from '../../assets/img/like.png';
import {
  ThumbsUpMajorMonotone, ThumbsDownMajorMonotone
} from '@shopify/polaris-icons';
import {Bar,Doughnut,Line} from 'react-chartjs-2';
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import Skeleton from "../../shared/skeleton";
import noDatafound from  "../../assets/img/data_nahi.png";
import noDatafound222x176 from  "../../assets/img/222x176.png";
import noDatafound320x260 from  "../../assets/img/320x260.png";
import {isUndefined} from "util";
import ModalVideo from "react-modal-video";
import { globalState } from '../../services/globalstate';


class Dashboard extends Component {

  constructor(props) {
    super(props)
    this.state = {
      freeClientMsgStatusFalse: false,
      site_id: '',
      on_app_since : 31,
      plan_expire : false,
      skeleton:[true,true,true],
      shop_url : '',
      limitExhausted:{
        modal:false,
        order:false,
        product:false
      },
      show_review_modal : false,
      review:{
        reason : '',
        never_ask_again:false,
        choice : '',
      },
      linegraphskeleton:true,
      recurring_planskeleton:true,
      datewiseskeleton:true,
      recentactivityskeleton:true,
      productStats:{
        newProducts:0,
        failedProducts:0
      },
      backgroundColor: ['#084E8A',
        '#007ACE',
        '#B4E1FA',],
      hoverBackgroundColor: ['#084E8A',
        '#007ACE',
        '#B4E1FA',],
      // backgroundColor: ['#00848E',
      //     '#47C1BF',
      //     '#B7ECEC',],
      // hoverBackgroundColor: ['#00848E',
      //     '#47C1BF',
      //     '#B7ECEC',],
      data1: {datasets: [{data: [0, 0, 0],}], title:"Loading Details....."},
      data2: {datasets: [{data: [0, 0, 0],}], title:"Loading Details....."},
      data3: {datasets: [{data: [0, 0, 0],}], title:"Loading Details....."},
      months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
      months_short: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      options1: [{label: 'Last 6 Week', value: 'weekly'}, {label: 'Monthly', value: 'monthly'}, {label: 'Yearly', value: 'yearly'},],
      options2: [{label: '30 Days', value: "1"}, {label: '90 Days', value: "3"}, {label: '180 Days', value: "6"}, {label: '360 Days', value: "12"},],
      legend: {display: true},
      no_getOrderAnalytics: false,
      no_getOrderDatewise:false,
      no_getOrderRevenueRangewise:false,
      no_getProductsUploadedData_and_ImportedData:false,
      Recurrying: false,
      recentActivities: [],
      selected_graph: "monthly",
      selected_revenue: "",
      graph_to_show: {labels: [], datasets: [{label: '', data: [], backgroundColor: '',}]},
      plan: "",
      price: '',
      activated_on: '',
      next_billing: "",
      active: false,
      Revenue_Heading: "Last 30 Days",
      Revenue: 0.000,
      has_active_plan : true,
      Total_revenue: 0.000,
      to_redirect:["/panel/orders","/panel/products","/panel/accounts"],
      content_data:{
        datanews:[],
        datablog:[],
      },

    }

  }
  video={Modal:false,id:''};
  preparedata() {
    this.getSideID();
    this.getOrderAnalytics();
    this.getProductsUploadedData_and_ImportedData()
    this.getServiceCredits();
    this.getOrderDatewise();
    this.getActiveRecurrying();
    this.getallNotifications();
    this.getOrderRevenueRangewise();
    this.getFailedProducts();
    this.getNewProducts();
    this.tableBlogData();
    this.newsdatafrombackend();
    this.showAppReviewModal();
    this.getAllImporterServices();
    this.getPlanExpire();
  }

  getPlanExpire(){
    requests.getRequest('frontend/app/getPlanExpire')
        .then(response => {
          if(response.success){
            this.setState({ plan_expire : response.data.plan_expire, on_app_since : response.data.on_app_since, has_plan_expire : response.data.has_plan_expire, has_active_plan: response.data.has_active_plan },()=>{
              if(!response.data.has_active_plan && globalState.getLocalStorage('freeClientMsgStatusFalse') === null) {
                globalState.setLocalStorage('freeClientMsgStatusFalse', !response.data.has_active_plan);
                this.setState({freeClientMsgStatusFalse: globalState.getLocalStorage('freeClientMsgStatusFalse')})
              }
              if(response.data.plan_expire) this.redirect('/panel/plans?exp=hash');
            });
          }
        });
  }

  getSideID() {
    requests.getRequest('ebayV1/get/siteId').then(data => {
      if (data.success) {
        this.state.site_id = !isUndefined(data.data.site_id) ? data.data.site_id : '';
        // this.state.site_id ='MOTORS';
      }
      this.setState(this.state);
    });

  }

  getAllImporterServices() {
    requests.getRequest('connector/get/services', {'filters[type]': 'importer'})
      .then(data => {
        if (data.success === true) {
          for (let i = 0; i < Object.keys(data.data).length; i++) {
            let key = Object.keys(data.data)[i];
            if (!isUndefined(key) && key === 'shopify_importer') {

               this.setState({shop_url: data.data[key].shops});

            }
          }
        }
      });
  }

  showAppReviewModal(){
    requests.getRequest('frontend/app/showReviewFormCustomer').then(data => {
      if(data.success){
        this.setState({show_review_modal : data.data.show_review_modal});
      }
    });
  }

  getFailedProducts(){
    requests.getRequest('ebayV1/get/failedProducts',{count:10,activePage:1}).then(data=>{
      if(data.success){
        this.state.productStats.failedProducts=data.data.count;
        this.setState(this.state);
      }
    });
  }

  getNewProducts(){
    requests.getRequest('ebayV1/get/newProducts',{count:10,activePage:1}).then(data=>{
      if(data.success){
        this.state.productStats.newProducts=data.data.count;
        this.setState(this.state);
      }
    });
  }
  getallNotifications() {
    requests.getRequest('connector/get/allNotifications',{count:3,activePage:0},false,true).then(response => {
      if (response.success) {
        this.state.recentActivities = response.data.rows;
        this.state.totalRecentActivities = response.data.count;
        this.state.recentactivityskeleton=false
        this.updateState();
      }
    })
  }

  componentDidMount(){
    document.title='Sell on eBay with eBay Marketplace Integration App | CedCommerce';
    document.description='CedCommerce introduces the eBay Marketplace Integration App enabling the Shopify merchants to sell on eBay by helping them to manage their products & orders.';
    if(!document.title.includes(localStorage.getItem('shop_url'))) {
      document.title += !isUndefined(localStorage.getItem('shop_url')) ? " " + localStorage.getItem('shop_url') : "";
    }

    this.preparedata();
  }

  getActiveRecurrying() {
    requests.getRequest('frontend/app/getActiveRecurrying',undefined,false,true)
      .then(response => {
        if (response.success) {
          this.setState({
            Recurrying: true,
            plan: response.data.name,
            activated_on: response.data.activated_on,
            price: response.data.price,
            next_billing: response.data.billing_on,
            recurring_planskeleton:false
          })

        }

        else {
          this.setState({
            Recurrying: false,
            recurring_planskeleton:false
          })
        }
      })
  }
  getOrderDatewise() {
    requests.getRequest('ebayV1/get/getOrderDatewise',{timeline:"monthly"},false,true)
      .then(response => {
        if(response.success) {
          let length = response.data.length
          let temp = 0;
          for (let i = 0; i < length; i++) {

            if (response.data[i].count === 0) {
              temp += 1;
            }
          }
          if (temp === length) {
            this.state.no_getOrderDatewise = false
            this.state.datewiseskeleton = false
            this.updateState();
          }
          else {
            this.state.no_getOrderDatewise = true
            this.state.datewiseskeleton = false
            this.updateState();
            this.dataextraction(response, "months", "monthly")
            this.handleChange("monthly")
          }
        }
      })
  }
  getOrderRevenueRangewise() {
    requests.getRequest('ebayV1/get/getOrderRevenueRangewise',{timeline:"1"},false,true)
      .then(response => {
        if(response.success) {
          let Revenue = response.data[0].revenue
          let Total_revenue = response.data[0].total_revenue
          if (Revenue == 0 && Total_revenue == 0) {
            this.setState({
              no_getOrderRevenueRangewise: true,
              linegraphskeleton: false

            })

          }
          else {
            this.dataextraction(response, "", "Last 30 Days")
            this.setState({
              no_getOrderRevenueRangewise: false,
              linegraphskeleton: false
            })
          }
        }


      })
  }
  getServiceCredits() {
    requests.getRequest('frontend/app/getServiceCredits',{service_code:'ebay_uploader'},false,true)
      .then(response => {
        if (response.success) {
          /*let total_credit = response.data.available_credits + response.data.total_used_credits
           let In_Ratio = response.data.available_credits / total_credit * 100;
           let In_Ratio1 = 100 - In_Ratio;*/
          requests.getRequest('frontend/app/getServiceCredits',{service_code:'ebay_order_sync'},false,true).then(ordercredits=>{
            if(ordercredits.success){
              this.setState({
                data3: {
                  labels: ["Product", "Orders"],
                  datasets: [{
                    data: [response.data.available_credits,ordercredits.data.available_credits],
                    backgroundColor: this.state.backgroundColor,
                    hoverBackgroundColor: this.state.hoverBackgroundColor,
                  }],
                  title: "Available Credits",
                },
              })
              this.state.skeleton[2]=false;
              if(response.data.available_credits === 0 || ordercredits.data.available_credits === 0){
                this.state.limitExhausted.modal = true;
                this.state.limitExhausted.order = ordercredits.data.available_credits === 0 ;
                this.state.limitExhausted.product = response.data.available_credits === 0 ;
              }

              this.setState(
                this.state
              );
            }
          })


        }

      });
  }
  handleChange = (newValue) => {
    let key = localStorage.getItem("token")
    let getOrderDatewise = "ebayV1/get/getOrderDatewise";
    let getOrderRevenueRangewise = "ebayV1/get/getOrderRevenueRangewise";
    let final;
    if (newValue == "weekly" || newValue == "monthly" || newValue == "yearly") {

      final = getOrderDatewise;
      this.setState({selected_graph: newValue});
    }
    else if (newValue == "1" || newValue == "3" || newValue == "6" || newValue == "12") {

      final = getOrderRevenueRangewise;
      this.setState({selected_revenue: newValue});

    }
    requests.getRequest(final,{timeline:newValue},false,true).then(response => {
      switch (newValue) {
        case "weekly" :
          this.dataextraction(response, "months_short", "weekly")
          break;
        case "monthly":
          this.dataextraction(response, "months", "monthly")
          break;
        case "yearly":
          this.dataextraction(response, "months", "yearly")
          break;
        case "1":
          this.dataextraction(response, "", "Last 30 Days")
          break;
        case "3":
          this.dataextraction(response, "", "Last 90 Days")
          break;
        case "6":
          this.dataextraction(response, "", "Last 180 Days")
          break;
        case "12":
          this.dataextraction(response, "", "Last 360 Days")
          break;
      }
    })
  }
  dataextraction = (response, months, stat) => {
    let label = []
    let count = []
    let length = response.data.length;
    if (stat == "weekly" || stat == "monthly" || stat == "yearly") {
      for (let i = 0; i < length; i++) {
        let start_date = new Date(response.data[i].start)
        let end_date = new Date(response.data[i].end)
        let Start_Month = this.state[months][start_date.getMonth()]
        let End_Month = this.state[months][end_date.getMonth()]
        let Start_Date = start_date.getDate()
        let End_Date = end_date.getDate()
        let year = start_date.getFullYear()
        let temp_label = Start_Date + " " + Start_Month + "-" + End_Date + " " + End_Month;
        let temp_label2 = Start_Month;
        let temp_label3 = year
        let final_label;
        if (stat == "weekly") {
          final_label = temp_label
        } else if (stat == "monthly") {
          final_label = temp_label2
        } else if (stat == "yearly") {
          final_label = temp_label3
        }
        let temp_count = response.data[i].count
        label.push(final_label)
        count.push(temp_count)
      }
      this.setState({
        graph_to_show: {
          labels: label,
          datasets: [
            {label: '', data: count, backgroundColor: 'lightblue',},]

        },

      })
    }
    else if (stat == "Last 30 Days" || stat == "Last 90 Days" || stat == "Last 180 Days" || stat == "Last 360 Days") {
      let Revenue_Heading = stat
      let Revenue = response.data[0].revenue
      let Total_revenue = response.data[0].total_revenue
      this.setState({
        Revenue: Revenue.toFixed(2),
        Revenue_Heading: Revenue_Heading,
        Total_revenue: Total_revenue.toFixed(2)
      })
    }
  }
  getProductsUploadedData_and_ImportedData() {

    requests.getRequest('ebayV1/get/productAnalytics',{},false,true).then(response => {
      if (response.success) {
        this.setState({
          data2: {
            labels: ["Uploaded", "Not uploaded","Ended","Error"],
            datasets: [{
              data: [response.data.uploaded, response.data.not_uploaded, response.data.ended, response.data.error],
              backgroundColor: this.state.backgroundColor,
              hoverBackgroundColor: this.state.hoverBackgroundColor,
            }], title: "Products Details"
          },
          no_getProductsUploadedData_and_ImportedData:false,
        })
        this.state.skeleton[1]=false;
        this.setState(
          this.state
        )

      } else {
        this.setState({
          no_getProductsUploadedData_and_ImportedData:true,
        })
        notify.error(response.message);
      }
    })


  }
  getOrderAnalytics() {
    requests.getRequest('frontend/app/getOrderAnalytics',undefined,false,true).then(response => {
      if (response.success && !(response.data.fulfilled_orders == 0 && response.data.unfulfilled_orders == 0 && response.data.cancelled_orders == 0))
      {

        this.setState({
          data1: {
            labels: ["Fulfilled", "Unfulfilled", "Cancelled"],
            datasets: [{
              data: [response.data.fulfilled_orders, response.data.unfulfilled_orders, response.data.cancelled_orders],
              backgroundColor: this.state.backgroundColor,
              hoverBackgroundColor: this.state.hoverBackgroundColor,
            }],
            title: "Order Details",
          },
          no_getOrderAnalytics: false
        })
        this.state.skeleton[0]=false;
        this.setState(
          this.state

        )

      }
      else if (response.success && response.data.fulfilled_orders == 0 && response.data.unfulfilled_orders == 0 && response.data.cancelled_orders == 0) {

        this.setState({
          no_getOrderAnalytics: true
        })
      } else {
        this.setState({
          no_getOrderAnalytics: true
        })
      }
    })
  }
  to_render_or_not(){
    const legend = {
      display: false,
    };
    if(!this.state.no_getOrderDatewise){
      return((this.state.linegraphskeleton?<Skeleton case="body"/> :<Stack distribution="center"><img src={noDatafound} width="100%"/></Stack>))
    }
    else{

      return((this.state.linegraphskeleton? <Skeleton case="body"/>:<Line data={this.state.graph_to_show} legend={legend}/>))
    }

  }
  to_render_final_graph_selector(value) {
    if (value == 1) {
      return (
        <Stack>
          <Stack.Item fill>
          </Stack.Item>
          <Stack.Item>
            <Select
              key="sales"
              options={ this.state.options1}
              onChange={this.handleChange}
              value={this.state.selected_graph}
            />
          </Stack.Item>
        </Stack>

      )
    }
    else if (value == 2) {
      return (
        <Select
          key="revenue"
          options={this.state.options2}
          onChange={this.handleChange}
          value={this.state.selected_revenue}
        />
      )
    }
  }
  to_final_render_Doughnut() {
    const legendOpts = {
      display: true,
      position: 'right',
      fullWidth: true,
      reverse: false,
      labels: {
        fontColor: 'Black'
      }
    };
    let arr = [];
    let temp_order=this.state.no_getOrderAnalytics;
    let temp_products=this.state.no_getProductsUploadedData_and_ImportedData;
    for (let i = 0; i < 3; i++) {
      let yourVariable = "data" + (i + 1);
      let title = this.state[yourVariable]
      if(temp_order && i==0){

        arr.push(
          <Layout.Section oneThird>
            <Card
              title="Orders Details"
              sectioned
              /*actions={{content: <Link><Icon source="help" color="inkLighter" backdrop={true} /></Link>,
                  onClick:() => {this.redirect('/panel/help?faq=order')}}
              }*/>
              <Stack distribution="center">
                <img className='img-fluid ' src={noDatafound222x176} width="100%"/>
              </Stack>
            </Card>
          </Layout.Section>
        );
        temp_order=false
        continue;
      }
      else  if(temp_products && i==1){
        arr.push(
          <Layout.Section oneThird key={yourVariable}>
            <Card
              title="Products Details "
              sectioned
              /* actions={{content:<Link><Icon source="help" color="inkLighter" backdrop={true} /></Link>,
                   onClick:()=>{ this.redirect('/panel/products')}
               }}*/>
              <Stack distribution="center">
                <img className='img-fluid ' src={noDatafound222x176} width="100%"/>
              </Stack>
            </Card>
          </Layout.Section>
        );
        temp_products=false
        continue;
      }
      arr.push(
        <Layout.Section oneThird key={yourVariable}><div onClick={() =>
        {
          this.redirect(this.state.to_redirect[i])
        }}>
          {
            (this.state.skeleton[i] ? <Skeleton/>:

                <Card title={title.title} sectioned>
                  <Doughnut data={this.state[yourVariable]} options={this.state.legend}
                            legend={legendOpts}/>
                </Card>

            )}
        </div >
        </Layout.Section>
      );
    }
    return (arr)

  }

  recurring_plan() {
    if (this.state.Recurrying === true) {
      return (this.state.recurring_planskeleton?<Skeleton case="body"/>:
          <Card >
            <div  onClick={() =>
            {
              this.redirect('/panel/accounts')
            }}>
              <ResourceList
                items={[
                  {
                    id: 341,
                    name: 'Current Plan',
                    location: this.state.plan,
                  },
                  {
                    id: 342,
                    name: 'Current Plan Price',
                    location: "$ "+this.state.price,
                  },
                  {
                    id: 343,
                    name: 'Plan Activated On',
                    location: this.state.activated_on,
                  },
                  {
                    id: 256,
                    name: 'Next Billing Cycle',
                    location: this.state.next_billing,
                  },
                ]}
                renderItem={(item) => {
                  const {id, url, name, location} = item;
                  const media = <Avatar customer size="medium" name={name} />


                  return (
                    <ResourceList.Item id={id} url={url} media={media}>
                      <h3>
                        <TextStyle variation="strong">{name}</TextStyle>
                      </h3>
                      <div>{location}</div>
                    </ResourceList.Item>
                  );
                }}
              />
            </div>
          </Card>
      )
    }
    else {
      return (this.state.recurring_planskeleton?<Skeleton case="body"/>:
          <Layout>
            <Layout.Section>
              <Banner status="info">
                <p>No active recurring plan found</p>
              </Banner>
            </Layout.Section>
            <Layout.Section>
              <img  src={noDatafound320x260} width="100%"/>
            </Layout.Section>
          </Layout>
      )
    }
  }
  final_revenue(){
    if(this.state.no_getOrderRevenueRangewise){
      return( <img   src={noDatafound320x260} width="100%"/>)
    }
    else{
      return((this.state.datewiseskeleton? <Skeleton case="activity_render"/>:
          <Layout>
            <Layout.Section>
              <Stack distribution="equalSpacing">
                <p>{this.state.Revenue_Heading}</p>
                <b>$ {this.state.Revenue}</b>
              </Stack>
            </Layout.Section>
            <Layout.Section>
              <Stack distribution="equalSpacing">
                <p>Total Revenue</p>
                <b >$ {this.state.Total_revenue}</b>
              </Stack>
            </Layout.Section>
          </Layout>
      ))
    }
  }

  productsStats(){
    if(this.state.productStats.newProducts===0 && this.state.productStats.failedProducts===0){
      return(
        <img   src={noDatafound320x260} width="100%"/>
      )
    }
    else{
      return((this.state.datewiseskeleton? <Skeleton case="activity_render"/>:
          <Layout>
            <Layout.Section>
              <Stack distribution="equalSpacing">
                <p className="font-weight-bold" /*style={{color:'#007bff',textDecoration: "underline" /*,cursor:'pointer'}}*/ /*onClick={this.redirect.bind(this,'/panel/products/new')}*/>New products</p>
                <Badge status={"attention"}>{this.state.productStats.newProducts}</Badge>
              </Stack>
            </Layout.Section>
            <Layout.Section>
              <Stack distribution="equalSpacing">
                <p className="font-weight-bold" /*style={{color:'#007bff',textDecoration: "underline"/*,cursor:'pointer'}}*/ /*onClick={this.redirect.bind(this,'/panel/products/failed')}*/>Failed products</p>
                <Badge status={"warning"}>{this.state.productStats.failedProducts}</Badge>
              </Stack>
            </Layout.Section>
          </Layout>
      ))
    }
  }

  newsdatafrombackend() {
    let temparr = [];
    requests.getRequest('frontend/admin/addNews').then(data => {
      if (data.success) {
        for (let i = 0; i < data.data.length; i++) {
          temparr.push({
            label: data.data[i],
            value: i
          });

        }
        this.state.content_data.datanews = temparr.reverse();

        this.setState(this.state);
      }
    })
  }
  tableBlogData(){
    let temparr=[];
    requests.getRequest('frontend/admin/addBlog').then(data=>{
      if (data.success) {
        for (let i = 0; i < data.data.length; i++) {
          temparr.push({
            label: data.data[i],
            value: i
          });

        }
        this.state.content_data.datablog = temparr.reverse();
        this.setState(this.state);
      }
    })

  }

  render() {

    var rows = [];
    var rows_blog = [];
    for (let i = 0; i < this.state.content_data.datanews.length; i++) {
      rows.push(
        {
          url: this.state.content_data.datanews[i]['label']['content_link'],
          name: this.state.content_data.datanews[i]['label']['title'],
          description: this.state.content_data.datanews[i]['label']['description'],
          media: (
            <Thumbnail
              source={this.state.content_data.datanews[i]['label']['image_url']}
              alt="News Logo"
            />)
        }
      );

    }
    if(this.state.content_data.datanews.length>3) {
      rows = rows.splice(0, 3);
    }

    for(let i = 0; i< this.state.content_data.datablog.length; i++) {
      rows_blog.push(
        {
          url: this.state.content_data.datablog[i]['label']['content_link'],
          name: this.state.content_data.datablog[i]['label']['title'],
          description: this.state.content_data.datablog[i]['label']['description'],
          media: (
            <Thumbnail
              source={this.state.content_data.datablog[i]['label']['image_url']}
              alt="News Logo"
            />)
        }
      );
      if(this.state.content_data.datablog.length > 3){
        rows_blog = rows_blog.splice(0,3)
      }
      if (rows_blog.length <= 0){
        this.state.content_data.no_blog_data = true;
        this.setState(this.state);
      }

    }
    let { on_app_since, has_plan_expire, has_active_plan } = this.state;
    let days_remaining = 30 - on_app_since;
    return (
      <Page title={"Dashboard"}
            titleMetadata={<Stack vertical={false}>
              <p style={{cursor:'pointer'}} onClick={()=>{
              window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=das','_blank')
            }}><Badge status={"info"}><b style={{color:'#0000aa', textDecoration:'underline'}}>Need help?</b></Badge>
              </p>
              <p style={{color:'#3B7DC4',textDecoration:'underline', cursor: 'pointer'}} onClick={this.openvideoModal.bind(this,'2pos_rypAVY')}><Badge status={"info"}><b style={{color:'#0000aa', textDecoration:'underline'}}>Help Video?</b></Badge></p>
              { (days_remaining > 0 && !has_active_plan) &&
                <React.Fragment>
                  <p><Badge status={ !has_plan_expire ? "success": "critical"}>{`${days_remaining} day(s) remaining for free trial`}</Badge></p>
                  <Modal open={this.state.freeClientMsgStatusFalse} 
                  onClose={() => this.setState({freeClientMsgStatusFalse: false}, 
                    () => {
                      globalState.setLocalStorage('freeClientMsgStatusFalse', false)
                    }
                  )} title="Offer valid till 31st Decemeber, 2021">
                    <Modal.Section>
                      <TextContainer>
                        <p>
                          <Link url="mailto:ebay_support@cedcommerce.com" external removeUnderline>Click Here!</Link>To Get Flat 40% Off On All The Yearly Subscription Plans
                        </p>
                      </TextContainer>
                    </Modal.Section>
                  </Modal>
                </React.Fragment>
              }
              {
                (days_remaining < 0 && has_plan_expire) &&
                <p><Badge status={ !has_plan_expire ? "success": "warning"}><b>{`Your plan has expired`}</b></Badge></p>
              }
            </Stack>}
            fullWidth={true}>
        <Stack vertical={true} spacing={"loose"}>
          <Banner status={"warning"}><span><b>
                Increase your products visibility with Google Free Listings. Start with our <span style={{color:'#0000aa', textDecoration:'underline',cursor:'pointer'}} onClick={()=>{
            window.open("https://bit.ly/3khI3wa")
          }}>FREE PLAN</span>.
              </b></span></Banner>
          {/*<Banner status={"warning"}><span><b>*/}
          {/*      Buckle up !!! Limited Offer for a week!!! Valid till 31 Aug 2021  !!! Get Up To 20% off On All Yearly Plans <span style={{color:'#0000aa', textDecoration:'underline',cursor:'pointer'}} onClick={()=>{*/}
          {/*  this.redirect('/panel/help/report');*/}
          {/*}}>Contact Us</span> Now.*/}
          {/*    </b></span></Banner>*/}
          <Layout>
            <Layout.Section>
              <Layout sectioned={false}>
                {this.to_final_render_Doughnut()}
              </Layout>
            </Layout.Section>
            <Layout.Section>
              {this.state.totalRecentActivities > 3 ?
                <Card title="Recent Activities"   primaryFooterAction={{content:'View All Activities',
                  onClick:() => {
                    this.redirect("/panel/activities/recent");
                  }
                }}>
                  {this.render_recent_activity()}
                </Card>:<Card title="Recent Activities" >
                  {this.render_recent_activity()}
                </Card>}
            </Layout.Section>
            <Layout.Section secondary>
              <Card title="Recurring Plan" sectioned>
                {this.recurring_plan()}
              </Card>
            </Layout.Section>
            <Layout.Section>
              {/*<Card sectioned={true}
                              title={"Recommended Apps"}
                              actions={[{content: <a href='https://apps.shopify.com/partners/cedcommerce' target='_blank'>More Apps</a>}]}>
                            {this.renderRecommendedApps()}
                        </Card>*/}
              <Layout>
                <Layout.Section oneThird>
                  {/*----------------------------Recommended Apps-----------------------*/}
                  <Card title="Recommended Apps" sectioned={true}
                        actions={[{content: 'See all', url: 'https://apps.shopify.com/partners/cedcommerce',external:true}]}>
                    <ResourceList
                      items={this.state.site_id == 'US' ? [
                        {
                          url: 'https://apps.shopify.com/facebook-marketplace-connector',
                          name: 'Facebook & Instagram Shopping',
                          description: 'Sell on Facebook & Instagram, list products and manage orders.',
                          media: (
                            <Thumbnail
                              source="https://cdn.shopify.com/app-store/listing_images/8e58c700f1ecc2539682f6a04a8852c7/icon/CNyDx+T0lu8CEAE=.png?height=84&width=84"
                              alt="facebook marketplace connector"
                            />
                          ),
                        },
                        {
                          url: 'https://apps.shopify.com/wish-marketplace-integration',
                          name: 'Wish Marketplace Integration',
                          description: 'All in one solution to ease & manage your selling on Wish.com.',
                          media: (
                            <Thumbnail
                              source="https://cdn.shopify.com/app-store/listing_images/33e17a8988791e04821ac3b0d8b4f434/icon/CIaj/8j0lu8CEAE=.png?height=84&amp;width=84"
                              alt="wish integration logo"
                            />
                          ),
                        },
                        {
                          url: `https://apps.shopify.com/ced-importer`,
                          name: 'Multichannel Importer',
                          description: 'Etsy Importer, eBay Importer Amazon Importer FBA, file import',
                          media: (
                            <Thumbnail
                              source="https://cdn.shopify.com/app-store/listing_images/5b1d8296277176f72fcfbdb371c4a6e8/icon/CJ2umLP0lu8CEAE=.png?height=84&width=84"
                              alt="Multichannel Importer logo"
                            />
                          ),
                        },
                        {
                          url: 'https://apps.shopify.com/etsy-marketplace-integration',
                          name: 'Etsy Marketplace Integration',
                          description: 'Easily manage listings, inventory, orders & more on Etsy.com',
                          media: (
                            <Thumbnail
                              source="https://cdn.shopify.com/app-store/listing_images/2fa150931ca28a5ed6a17dc69c40477b/icon/CNLtvLz0lu8CEAE=.png?height=84&amp;width=84"
                              alt="Etsy Marketplace Integration logo"
                            />
                          ),
                        },
                      ]:
                        [
                          {
                            url: 'https://apps.shopify.com/wish-marketplace-integration',
                            name: 'Wish Marketplace Integration',
                            description: 'All in one solution to ease & manage your selling on Wish.com.',
                            media: (
                                <Thumbnail
                                    source="https://cdn.shopify.com/app-store/listing_images/33e17a8988791e04821ac3b0d8b4f434/icon/CIaj/8j0lu8CEAE=.png?height=84&amp;width=84"
                                    alt="wish integration logo"
                                />
                            ),
                          },
                          {
                            url: `https://apps.shopify.com/ced-importer`,
                            name: 'Multichannel Importer',
                            description: 'Etsy Importer, eBay Importer Amazon Importer FBA, file import',
                            media: (
                                <Thumbnail
                                    source="https://cdn.shopify.com/app-store/listing_images/5b1d8296277176f72fcfbdb371c4a6e8/icon/CJ2umLP0lu8CEAE=.png?height=84&width=84"
                                    alt="Multichannel Importer logo"
                                />
                            ),
                          },
                          {
                            url: 'https://apps.shopify.com/etsy-marketplace-integration',
                            name: 'Etsy Marketplace Integration',
                            description: 'Easily manage listings, inventory, orders & more on Etsy.com',
                            media: (
                                <Thumbnail
                                    source="https://cdn.shopify.com/app-store/listing_images/2fa150931ca28a5ed6a17dc69c40477b/icon/CNLtvLz0lu8CEAE=.png?height=84&amp;width=84"
                                    alt="Etsy Marketplace Integration logo"
                                />
                            ),
                          },
                        ]
                      }
                      renderItem={(item) => {
                        const {url, name, media, description} = item;

                        return (
                          <a href={url} target="_blank" style={{textDecoration:"none", color:"#000"}}><ResourceList.Item
                            media={media}
                            accessibilityLabel={`View details for ${name}`}
                          >
                            <h3>
                              <TextStyle variation="strong">{name}</TextStyle>
                            </h3>
                            <Label>
                              {description}
                            </Label>
                          </ResourceList.Item></a>
                        );
                      }}
                    />
                  </Card>
                  {/*----------------------------End Of Recommended Apps-----------------------*/}
                </Layout.Section>
                {rows.length > 0 ? <Layout.Section oneThird>
                  <Card title="News">
                    <Card.Section>
                      <ResourceList
                        items={rows}
                        renderItem={(item) => {
                          const {url,name,description,media} = item;

                          return (
                            <a href={url} target="_blank" style={{textDecoration:"none", color:"#000"}}><ResourceList.Item
                              media={media}
                              accessibilityLabel={`View details for ${name}`}
                            >
                              <h3>
                                <TextStyle variation="strong">{name}</TextStyle>
                              </h3>
                              <label>
                                {description}
                              </label>
                            </ResourceList.Item></a>
                          );
                        }}
                      />
                    </Card.Section>
                  </Card>
                </Layout.Section> : <Layout.Section oneThird>
                  <Card title="News">
                    <Card.Section>
                      <Stack distribution="center">
                        <img className='img-fluid pt-5 mt-2' src={require("../../assets/img/data_nahi.png")} width="100%"/>
                      </Stack>
                    </Card.Section>
                  </Card>
                </Layout.Section>}

                {rows_blog.length > 0?
                  <Layout.Section oneThird>
                    <Card title="Blogs">
                      <Card.Section>
                        <ResourceList
                          items={rows_blog}
                          renderItem={(item) => {
                            const {url, name,media,description} = item;

                            return (
                              <a href={url} target="_blank" style={{textDecoration:"none", color:"#000"}}><ResourceList.Item
                                media={media}
                                accessibilityLabel={`View details for ${name}`}
                              >
                                <h3>
                                  <TextStyle variation="strong">{name}</TextStyle>
                                </h3>
                                <label>
                                  {description}
                                </label>
                              </ResourceList.Item></a>
                            );
                          }}
                        />
                      </Card.Section>
                    </Card>
                  </Layout.Section>: <Layout.Section oneThird>
                    <Card title="Blogs">
                      <Card.Section>
                        <Stack distribution="center">
                          <img className='img-fluid pt-5 mt-2' src={require("../../assets/img/data_nahi.png")} width="100%"/>
                        </Stack>
                      </Card.Section>
                    </Card>
                  </Layout.Section>}
              </Layout>
            </Layout.Section>
            <Layout.Section>
              <Card sectioned title="Orders">
                {this.to_render_final_graph_selector(1)}
                {this.to_render_or_not()}
              </Card>
            </Layout.Section>
            <Layout.Section secondary>
              <Card>
                <Card.Section title={"Revenue"}>
                  <Layout>
                    <Layout.Section>
                      {this.to_render_final_graph_selector(2)}
                    </Layout.Section>
                    <Layout.Section>
                      {this.final_revenue()}
                    </Layout.Section>
                  </Layout>
                </Card.Section>
                {/*<Card.Section title={"Products status"}>*/}
                {/*<Layout>*/}
                {/*<Layout.Section>*/}
                {/*{this.productsStats()}*/}
                {/*</Layout.Section>*/}
                {/*</Layout>*/}
                {/*</Card.Section>*/}
              </Card>
            </Layout.Section>

          </Layout>
        </Stack>
        <FooterHelp>
    Learn more about{' '}
    <Link external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=das">
    Dashboard
    </Link>
  
  </FooterHelp>
  {/* <Banner title="Order archived">
  <p>This order was archived on March 7, 2017 at 3:12pm EDT.</p>
</Banner> */}
        {this.renderExhaustModal()}
        {this.renderReviewModal()}
        <ModalVideo channel='youtube' isOpen={this.video.Modal} videoId={this.video.id}  onClose={this.closevideoModal.bind(this)} />
      </Page>

    )
  }

  renderExhaustModal() {
    return (
      <div>
        <Modal
          open={this.state.limitExhausted.modal}
          onClose={() => {
            this.state.limitExhausted.modal = false;
            this.updateState();
          }}
          title="Credit limit expired"
          /* primaryAction={{disabled:this.state.importProductsDetails.source === '',content:'Import Products',
               onAction: this.importProducts.bind(this)

           }}*/
        >
          <Modal.Section>
            <Banner status={"warning"}><b>Your {this.state.limitExhausted.order?"order ":""}{this.state.limitExhausted.product && this.state.limitExhausted.order?" & ":""}{this.state.limitExhausted.product?"product ":""} credit limit is exhausted kindly select a plan from <span style={{cursor:'pointer',color:'blue'}} onClick={this.redirect.bind(this,'/panel/plans')}>Plans Section</span></b></Banner>
          </Modal.Section>
        </Modal>
      </div>
    );
  }

  handleReview(reviewType){
    this.state.review.choice = reviewType;
    this.setState(this.state);
  }

  submitReview(){
    requests.postRequest('frontend/app/setReviewByCustomer',this.state.review).then(data =>{
      if(data.success){
        notify.success(data.message);
      }else{
        notify.info(data.message);
      }
      this.setState({show_review_modal : false});
    });
  }

  renderReviewModal() {
    return (
      <div>
        <Modal
          open={this.state.show_review_modal}
          onClose={() => {
            this.state.show_review_modal = false;
            this.updateState();
          }}
          title="Did you like our app ?"
          primaryAction={this.state.review.choice !== '' || this.state.review.never_ask_again ?{content : 'Submit' , onAction:this.submitReview.bind(this)}:false}
        >
          <Modal.Section>
          <div className={'row'}>
            <div className={'col-12 col-md-6'}>
              <Stack distribution={"center"}>
                <Tooltip content={"Like"}>
                  <div style={{cursor : 'pointer'}} onClick={(e) =>{
                    this.handleReview('like');
                    e.preventDefault();
                  }}>
                  <Thumbnail
                    source={require('../../assets/img/positive-vote.png')}
                    size="large"
                    alt="Like"
                  />
                  </div>
                </Tooltip>
              </Stack>
            </div>
            <div className={'col-12 col-md-6'}>
              <Stack distribution={"center"} >
                <Tooltip content={"Dislike"}>
                  <div style={{cursor : 'pointer'}} onClick={(e) =>{
                    this.handleReview('dislike');
                    e.preventDefault();
                  }}>
                  <Thumbnail
                    source={require('../../assets/img/negative-vote.png')}
                    size="large"
                    alt="Dislike"
                  />
                  </div>
                </Tooltip>
              </Stack>
            </div>
            <div className={'col-12 text-center mt-5'}>
              <p style={{fontWeight:'bold'}}>
                {this.state.review.choice === 'like' &&
                  "Thank you so much for the feedback your appreciation means a lot !!!"
                }
                {this.state.review.choice === 'dislike' &&
                "We are really sorry for the inconvinence caused to you, Kindly submit your feedback below to help us improve"
                }
              </p>
            </div>
            <div className={'col-12 mt-5'}>
              <Stack vertical={true} distribution={"center"}>
                <Checkbox
                  label={'Never ask again'}
                  checked={this.state.review.never_ask_again}
                  onChange={(e) => {
                  this.state.review.never_ask_again = e ;
                  this.setState(this.state);
                }}/>
                {this.state.review.choice === 'dislike' &&
                  <TextField
                    multiline={4}
                    value={this.state.review.reason}
                    type={"text"}
                    label={"Please submit a feedback, it will help us in improving"}
                    onChange={(text) => {
                      this.state.review.reason = text;
                      this.setState(this.state);
                    }}
                  />
                }
              </Stack>
            </div>
          </div>
          </Modal.Section>
        </Modal>
      </div>
    );
  }

  render_recent_activity(){
    return(this.state.recentactivityskeleton? <Skeleton case="body"/>:

        <Card.Section>
          {
            this.state.recentActivities.map((activity, index) => {
              return (
                <Banner status={activity.severity}
                        title={activity.message}
                        key={this.state.recentActivities.indexOf(activity)}>
                  <Stack vertical={true}>
                    <Stack distribution="equalSpacing">
                      {activity.url !== null && activity.severity !== 'success' ?
                        <a href={activity.url} target={'_blank'}>View
                          Report</a>
                        : ''}
                      <p>{activity.created_at}</p>
                    </Stack>
                  </Stack>
                </Banner>
              );
            })
          }
          {
            this.state.recentActivities.length === 0 &&
            <Stack distribution="center">
              <img className='img-fluid' src={noDatafound} width="100%"/>
            </Stack>

          }


        </Card.Section>

    )
  }

  openvideoModal(id){
    this.video.Modal=true;
    this.video.id=id;
    this.setState(this.state);
  }

  closevideoModal(){
    this.video.Modal=false;
    this.video.id='';
    this.setState(this.state);
  }
  updateState() {
    const state = this.state;
    this.setState(state);
  }
  redirect(url) {

    this.props.history.push(url);
  }

}

export default Dashboard;