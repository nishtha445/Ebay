import React, {Component} from 'react';
import { Stack , Heading,DisplayText,Page} from "@shopify/polaris";
import {requests} from "../../services/request";

class Maintainence extends Component {

  constructor(props) {
    super(props);
    this.state = {
      show_banner:true // CHangessssss
    }
  }


  componentDidMount() {
    // this.getMaintainenceCheck();   // CHangessssss
  }
  redirect(url){
    this.props.history.push(url);
  }
  getMaintainenceCheck (){
    requests.getRequest('frontend/app/checkMaintainence').then(data=>{
      if(data.success) {
        if (!data.data.inMaintainence) {
          this.setState({show_banner:false},()=>{
            this.redirect('/auth/login');
          });
        }else{
          this.setState({show_banner:true});
        }
      }
    })
  }

  render() {
    return (
      <React.Fragment>
        <Page>
          {this.state.show_banner &&
          <Stack vertical={true} alignment={"center"}>
            <img width={400} src={require('../../assets/server_maintainence.jpg')}/>
            {/* <DisplayText element={"h4"}>Server under maintainence</DisplayText>
            <Heading element={"h4"}>We request to keep patience and revist after sometime</Heading> */}
            <DisplayText element={"h4"}>Site is under maintenance (12 PM to 2 PM - IST).</DisplayText>
            <Heading element={"h4"}>Will back In Next 2 hours.</Heading>
            <Heading element={"h4"}>Please connect with us on Chat</Heading>
          </Stack>
          }
        </Page>
      </React.Fragment>
    );
  }
}

export default Maintainence;
