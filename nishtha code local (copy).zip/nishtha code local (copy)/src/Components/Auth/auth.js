import React, {Component} from 'react';
import {Redirect, Route, Switch} from "react-router-dom";
import Login from "./Login/login";
import WelcomeScreen from "../WelcomeScreen/welcomescreen";
import Registrations from "../Registration/registrations";
import Maintainence from "./maintainence";
// import Versioncheck from "../VersionCheck/versionCheck";


class Auth extends Component {


    render() {
        return (

            <Switch>
                <Route exact path="/auth/" render={() => (
                    <Redirect to="/auth/login"/>
                )}/>
                <Route path='/auth/login' component={Login}/>
                {/*<Route path='/auth/vcheck' component={Versioncheck}/>*/}
                <Route exact path='/auth/welcome' component={WelcomeScreen}/>
                <Route exact path='/auth/registration' component={Registrations}/>
              <Route exact path='/auth/maintainence' component={Maintainence}/>
            </Switch>
        );
    }
}

export default Auth;
