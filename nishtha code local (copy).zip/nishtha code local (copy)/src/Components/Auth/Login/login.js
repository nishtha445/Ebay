import React, {Component} from 'react';
import {Page, Card, Form, FormLayout, TextField, Button, AppProvider, Stack, DisplayText} from "@shopify/polaris";
import {requests} from "../../../services/request";
import {globalState} from "../../../services/globalstate";
import {notify} from "../../../services/notify";
import {BrowserRouter, withRouter} from "react-router-dom";
import * as queryString from "query-string";
import Background from "../../../assets/background.png";
import {environment} from "../../../environments/environment";
import StyleRoot from "radium/es/components/style-root";
import Cancel from "../../../assets/img/warning.png";
import Radium from "radium";
import {fadeInRight, flipInX,bounceInLeft} from "react-animations";

export const MainContext=React.createContext()

const styles = {
    fadeInRight: {
        animation: 'x 3s',
        animationName: Radium.keyframes(fadeInRight, 'fadeInRight')
    },
    flipInX:{
        animation: 'x 3s',
        animationName: Radium.keyframes(flipInX, 'flipInX')
    },
    bounceInLeft:{
        animation: 'x 3s',
        animationName: Radium.keyframes(bounceInLeft, 'bounceInLeft')
    }
}

class Login extends Component {
   

    fieldErrors = {
        username: false,
        password: false
    };
    fieldValidations = {
        username: /^[A-Za-z0-9_-][A-Za-z0-9_-][A-Za-z0-9_-]+(?:[_-][A-Za-z0-9]+)*$/,
        password: /^.{4,}$/
    };

    constructor(props){
        super(props);
        this.state={
            enableExceptionBanner:false,
            button_loader_login:false,
            username:"",
            password:"",
            browserCompatible:'',
            checkcomplete:false,
            skype:'',
            whatsapp:''
        }


    }
    
    removeLocalStorage() {
      globalState.removeLocalStorage('user_authenticated');
        globalState.removeLocalStorage('auth_token');
        if((this.verifyCompatibilityofBrowser())) {
          this.getMaintainenceCheck();
            this.autoRedirect();
            this.state.browserCompatible=true;
        }
        else{
            this.state.browserCompatible=false;
        }

        this.state.checkcomplete=true;
        this.setState(this.state);
    }


    verifyCompatibilityofBrowser(){

        var nVer = navigator.appVersion;
        var nAgt = navigator.userAgent;
        var browserName  = navigator.appName;
        var fullVersion  = ''+parseFloat(navigator.appVersion);
        var majorVersion = parseInt(navigator.appVersion,10);
        var nameOffset,verOffset,ix;

// In Opera 15+, the true version is after "OPR/"
        if ((verOffset=nAgt.indexOf("OPR/"))!=-1) {
            browserName = "Opera";
            fullVersion = nAgt.substring(verOffset+4);
        }
// In older Opera, the true version is after "Opera" or after "Version"
        else if ((verOffset=nAgt.indexOf("Opera"))!=-1) {
            browserName = "Opera";
            fullVersion = nAgt.substring(verOffset+6);
            if ((verOffset=nAgt.indexOf("Version"))!=-1)
                fullVersion = nAgt.substring(verOffset+8);
        }
// In MSIE, the true version is after "MSIE" in userAgent
        else if ((verOffset=nAgt.indexOf("MSIE"))!=-1) {
            browserName = "Microsoft Internet Explorer";
            fullVersion = nAgt.substring(verOffset+5);
        }
// In Chrome, the true version is after "Chrome"
        else if ((verOffset=nAgt.indexOf("Chrome"))!=-1) {
            browserName = "Chrome";
            fullVersion = nAgt.substring(verOffset+7);
        }
// In Safari, the true version is after "Safari" or after "Version"
        else if ((verOffset=nAgt.indexOf("Safari"))!=-1) {
            browserName = "Safari";
            fullVersion = nAgt.substring(verOffset+7);
            if ((verOffset=nAgt.indexOf("Version"))!=-1)
                fullVersion = nAgt.substring(verOffset+8);
        }
// In Firefox, the true version is after "Firefox"
        else if ((verOffset=nAgt.indexOf("Firefox"))!=-1) {
            browserName = "Firefox";
            fullVersion = nAgt.substring(verOffset+8);
        }
// In most other browsers, "name/version" is at the end of userAgent
        else if ( (nameOffset=nAgt.lastIndexOf(' ')+1) <
            (verOffset=nAgt.lastIndexOf('/')) )
        {
            browserName = nAgt.substring(nameOffset,verOffset);
            fullVersion = nAgt.substring(verOffset+1);
            if (browserName.toLowerCase()==browserName.toUpperCase()) {
                browserName = navigator.appName;
            }
        }
// trim the fullVersion string at semicolon/space if present
        if ((ix=fullVersion.indexOf(";"))!=-1)
            fullVersion=fullVersion.substring(0,ix);
        if ((ix=fullVersion.indexOf(" "))!=-1)
            fullVersion=fullVersion.substring(0,ix);

        majorVersion = parseInt(''+fullVersion,10);
        if (isNaN(majorVersion)) {
            fullVersion  = ''+parseFloat(navigator.appVersion);
            majorVersion = parseInt(navigator.appVersion,10);
        }
        let compatible=true;
        switch (browserName) {
            case 'Firefox':
                if(majorVersion<67){
                    compatible=false;
                }
                break;
            case 'Opera':
                if(majorVersion<60){
                    compatible=false;
                }
                break;
            case 'Chrome':
                if(majorVersion<74){
                    compatible=false;
                }
                break;
            case 'Safari':
                if(majorVersion<12){
                    compatible=false;
                }
                break;
        }

        return compatible;

    }



    handleChange(feild,value){
        this.state[feild]=value;
        this.validateForm(value, feild);
        this.setState(this.state);
    }
    validateForm(data, key) {
        this.fieldErrors[key] = !this.fieldValidations[key].test(data);
    }
    handleSubmit=()=>{
        this.button_loaderToggle();
        requests.getRequest('user/shopifyLogin', this.state)
            .then(data => {
                if (data.success === true) {
                    notify.success(data.message);
                    this.button_loaderToggle();
                    globalState.setLocalStorage('user_authenticated', 'true');
                    globalState.setLocalStorage('auth_token', data.data.token);
                    this.redirect('/auth/welcome');
                    requests.getRequest('user/getDetails', undefined, false, true)
      .then(data => {
        if (data.success) {
          requests.getRequest(`ebayV1/upload/getAppSettings?user_id=${data.data.id}`)
          .then(data=>{
            if(data.skype!=='N/A')
            {
              //socialMediaDetails.skype=data.skype
              this.state.skype=data.skype
  
            }
            else if(data.whatsapp!=='N/A')
            {
                //socialMediaDetails.whatsapp=data.whatsapp
                this.state.whatsapp=data.whatsapp
  
            }
          })
        } 
      });
                } else {
                    this.button_loaderToggle();
                    notify.error(data.message);
                }
            });
    }

    componentDidMount(){
      
      this.removeLocalStorage();


    }

  getMaintainenceCheck (){
    requests.getRequest('frontend/app/checkMaintainence').then(data=>{
      if(data.success) {
          if (data.data.inMaintainence) {
            this.redirect('/auth/maintainence');
          }
      }
    })
  }
    redirect(url){

        this.props.history.push(url);
    }

    button_loaderToggle(){
        this.state.button_loader_login=!this.state.button_loader_login;
        this.setState(this.state);
    }
    autoRedirect()
    {
        const  queryParams = queryString.parse(this.props.location.search);
        if(queryParams['user_token']!=null && queryParams['code']!=null) {
            globalState.setLocalStorage('user_authenticated', 'true');
            globalState.setLocalStorage('auth_token', queryParams['user_token']);
            globalState.setLocalStorage('shop', queryParams['shop']);
            this.redirect('/auth/welcome');
        } else if ( queryParams['admin_user_token'] ) {
            globalState.setLocalStorage('user_authenticated', 'true');
            globalState.setLocalStorage('auth_token',queryParams['admin_user_token']);
            this.redirect('/auth/welcome');
        }

    }

    EnableautoRedirect(){
        let  queryParams = queryString.parse(this.props.location.search);
        if(Object.keys(queryParams).length>0){
            this.autoRedirect();
        }else{
            notify.error('Unauthorized access');
        }
    }

    renderExceptionBanner(){
        setTimeout(()=>{
            this.state.enableExceptionBanner=true;
            this.setState(this.state);
        },5000)
        return (
            <StyleRoot>
                {this.state.enableExceptionBanner?
                    <div style={styles.flipInX}>
                        <Card>
                            <Card.Section>
                                <div style={{textAlign:'center',minHeight:'35rem',marginTop:'10rem'}}>
                                    <Stack alignment={"center"} vertical={true}>
                                        <img src={Cancel} style={{height:'5rem',width:'5rem'}} />
                                        <DisplayText size={"extraLarge"}>
                                            Oops !!
                                        </DisplayText>
                                        <DisplayText size='small'>
                                            <b>Unauthorized access attempt</b>
                                        </DisplayText>
                                        <DisplayText size='small'>
                                            Kindly revisit the app from your shopify store's apps section
                                        </DisplayText>
                                    </Stack>
                                </div>
                            </Card.Section>
                        </Card>
                    </div>:''}
            </StyleRoot>
        );
    }


    renderCompatibilityCheck(){

        return (
            <StyleRoot>
                {!this.state.browserCompatible?
                    <div style={styles.flipInX}>
                        <Card primaryFooterAction={{content:'Proceed anyway',onAction:this.EnableautoRedirect.bind(this)
                        }}>
                            <Card.Section>
                                <div style={{textAlign:'center',minHeight:'35rem',marginTop:'10rem'}}>
                                    <Stack alignment={"center"} vertical={true}>
                                        <img src={Cancel} style={{height:'5rem',width:'5rem'}} />
                                        <DisplayText size={"extraLarge"}>
                                            Oops !!
                                        </DisplayText>
                                        <DisplayText size='small'>
                                            <b>It seems your browser is not updated</b>
                                        </DisplayText>
                                        <DisplayText size='small'>
                                            <b>We strongly recommend you to update your browser to the latest version</b>
                                        </DisplayText>
                                        <DisplayText size='small'>
                                            <p>As our app is build on updated themes of Shopify so the theme may go haywire on an outdated version</p>
                                        </DisplayText>
                                        <DisplayText size='small'>
                                            <p style={{fontSize:"2rem"}}>Below are the list of latest version of browsers</p>
                                            <ul className="text-left" style={{fontSize:"2rem"}}>
                                                <li>Opera   : 60.x or higher.</li>
                                                <li>Firefox : 67.x</li>
                                                <li>Chrome  : 74.x</li>
                                                <li>Safari  : 12.x</li>
                                            </ul>
                                        </DisplayText>
                                    </Stack>
                                </div>
                            </Card.Section>
                        </Card>
                    </div>:''}
            </StyleRoot>
        );
    }


    renderLogin(){
        let temparr=[];
        if(this.state.browserCompatible && this.state.browserCompatible!=='' ) {
            if (environment.isLive) {
                temparr.push(
                    <Page
                        title=""
                    >{this.renderExceptionBanner()}
                    </Page>)
            } else {
                temparr.push(
                    <div style={{
                        marginTop: "5%",
                        marginLeft: "30%",
                        marginRight: "30%",
                        backgroundImage: `url(${Background})`
                    }}>
                        
                        <Page
                            title="Log in"
                        >
                            <Card subdued="Enter details">
                                <Card.Section>
                                    <Form onSubmit={this.handleSubmit.bind(this)}>
                                        <FormLayout>
                                            <TextField
                                                value={this.state.username}
                                                onChange={this.handleChange.bind(this, 'username')}
                                                label="Username"
                                                error={this.fieldErrors.username ? 'Enter valid username' : ''}
                                                type="text"
                                            />
                                            <TextField
                                                value={this.state.password}
                                                onChange={this.handleChange.bind(this, 'password')}
                                                label="Password"
                                                error={this.fieldErrors.password ? 'Enter valid password' : ''}
                                                type="password"
                                            />

                                            <Button loading={this.state.button_loader_login}
                                                    onClick={this.handleSubmit.bind(this)}>Submit</Button>
                                            
                                        </FormLayout>
                                    </Form>
                                </Card.Section>
                            </Card>
                            

                        </Page>
                        
                    </div>
                )
            }
        }else {
            temparr.push(

                <Page
                    title=""
                >{this.renderCompatibilityCheck()}
                </Page>
            )
        }
        return temparr;
    }

    render() {
        return (
            <MainContext.Provider value={this.state}>
            {this.state.checkcomplete &&
            this.renderLogin()}
            </MainContext.Provider>
        );
    }
}

export default withRouter(Login);
