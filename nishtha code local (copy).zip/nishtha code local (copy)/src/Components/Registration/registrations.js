import React, { Component } from 'react';
import {
  Page,
  Heading,
  Card,
  DisplayText,
  Button,
  OptionList,
  Form,
  Modal,
  Checkbox,
  TextField,
  Tooltip,
  FormLayout,
  Select,
  Icon,
  Label,
  Stack,
  Banner,
  TextContainer,
  SkeletonBodyText,
  ProgressBar,
  Collapsible,
  Link
} from "@shopify/polaris";
import { NavLink } from "react-router-dom";
import { isUndefined } from "util";
import { requests } from "../../services/request";
import { term_and_conditon } from "./term&condition";
import { json } from "../../environments/static-json";
import { notify } from "../../services/notify";
import './registration_styles.css';
import { fadeInRight, flipInX } from 'react-animations';
import Radium, { StyleRoot } from 'radium';
import AppsShared from "../../shared/app/apps";
import history from "../../shared/history";
import InstallAppsShared from "../../shared/app/install-apps";
import PlanBody from "../../shared/plans/plan-body";

import Checked from '../../assets/checked.png';
import MappingProducts from "../../shared/Mapping/mappingproducts";

import AccountSettings from "../Accounts/Settings";
import CategoryTemplate from "../../templates/CategoryTemplate";
import ModalVideo from "react-modal-video";
import {ChevronDownMinor, ChevronRightMinor} from "@shopify/polaris-icons";


const styles = {
  fadeInRight: {
    animation: 'x 3s',
    animationName: Radium.keyframes(fadeInRight, 'fadeInRight')
  },
  flipInX: {
    animation: 'x 3s',
    animationName: Radium.keyframes(flipInX, 'flipInX')
  }
}
let domain = [];
class Registrations extends Component {

  constructor(props) {
    super(props);

    this.state = {
      text:'Read more',
      textInside1:'If the products are already listed on eBay with any Integration app using Inventory Based API then Integration...',
      textInside2:'If the products are already listed on eBay with any Integration app using Inventory Based API then Integration for eBay app will not be able to manage those listings, as this app works on Traditional API .If you want to manage them with this app, It is requested to end those listings and list them again as new product using Integration for eBay App by CedCommerce.',
      open:false,
      additional_user_data: false,
      skeleton_indicators: true,
      button_loader: false,
      active_anchor: '',
      errorPolicyfound: false,
      PlanChecked: false,
      accountChecked: false,
      noProductsonShopify: false,
      errors_recieved_policy: [],
      importServicesList: [],
      vedio: { Modal: false, id: '' },
      info: {
        full_name: '',
        mobile: '',
        mobile_code: '+1',
        country_code: 'US',
        email: '',
        skype_id: '',
        primary_time_zone: 'Pacific Time',
        best_time_to_contact: '8-12',
        term_and_conditon: false,
        how_u_know_about_us: 'Shopify App Store',
        Other_text: '',
        categories: [],
        revenue: '<500',

      }, // Step 1
      info_error: {
        full_name: false,
        mobile: '',
        email: false,
        skype_id: '',
        primary_time_zone: 'Pacific Time',
        best_time_to_contact: '8-12',
        term_and_conditon: false,
        how_u_know_about_us: '',

      }, // Step 1
      otpCheck: {
        status: false,
        pin: '',
        error: false,
        number_change: false,
      }, // step 1
      plans: [], // step 2
      /****** step 3 ********/
      API_code: ['google'], // connector/get/installationForm, method -> get, eg: { code : 'google' }
      account_linked: [], // merchant center account. linked type
      modalOpen: false,
      /********* Step 3 ends **********/
      /********* Step 4 **********/
      // config_API: ['google'],
      // config: false,
      // google_configuration: {},
      // google_configuration_updated: false,
      // account_information_updated: false,
      /********* Step 4 Ends **********/
      stepData: [], // this will store the current showing step, which is selected from data object e.g Shopify_Google []
      active_step: 0,
      categories_options: '',
      data: {
        data: [ //Shopify_Google old Name
          {
            heading: "Tell us about yourself",
            message: "Enter Your Basic Information", // step data
            stepperMessage: 'Basic Information', // stepper Small Message
            API_endpoint: '', // Api End Point is used to check to send data or get data (no use Right Now)
            data: '', // Data additional Field
            method: 'GET', // Method Type
            redirectTo: '/panel/configuration', // After Completion Where To Redirect
            anchor: 'U-INFO', // Which Function to call e.g : 'U-INFO' then call div which take User basic Information
            stepperActive: false, // used in stepper Check either Completed or not and also help in deciding with step to go
          }, // step 1
          {
            heading: 'Get your account linked',
            message: <p> Link your <b>Account.</b> Make sure that you have your <b>Google Merchant
              Account</b>, and you have your <b>website URL claimed and Verified</b> on your Merchant
              Center</p>,
            stepperMessage: 'Account linked',
            API_endpoint: '', // Api End Point is used to check to send data or get data
            data: '', // Data additional Field
            method: 'GET', // Method Type
            redirectTo: '/panel/accounts', // After Completion Where To Redirect
            anchor: 'LINKED', // Which Function to call e.g : 'U-INFO' then call div which take User basic Information
            stepperActive: false, // used in stepper Check either Completed or not
          }, // step 2
          {
            heading: 'Choose a plan',
            message: <p> Choose a plan (7 Days Trial Period)</p>,
            stepperMessage: 'Choose a plan', // stepper Small Message
            API_endpoint: '', // Api End Point is used to check to send data or get data
            data: '', // Data additional Field
            method: 'GET', // Method Type
            redirectTo: '/panel/plans', // After Completion Where To Redirect
            anchor: 'PLANS', // Which Function to call e.g : 'U-INFO' then call div which take User basic Information
            stepperActive: false, // used in stepper Check either Completed or not
          }, // step 3
          {
            heading: 'Map eBay and Shopify fields',
            message: <span>Enter default configuration</span>,
            stepperMessage: 'Default Configurations',
            API_endpoint: '', // Api End Point is used to check to send data or get data
            data: <p>Now goto <NavLink to="/panel/import">Upload Products</NavLink> section, first import
              products from shopify. <br />When import completed upload your products on google. </p>, // Data additional Field
            method: 'GET', // Method Type
            redirectTo: '/panel/configuration', // After Completion Where To Redirect
            anchor: 'MAPPING', // Which Function to call e.g : 'U-INFO' then call div which take User basic Information
            stepperActive: false, // used in stepper Check either Completed or not
          }, // step 4

          {
            heading: 'Set your business policies',
            message: <span>Set Product ID format as per your Merchant Center</span>,
            stepperMessage: 'Default Item ID',
            API_endpoint: '', // Api End Point is used to check to send data or get data
            data: <p>Now goto <NavLink to="/panel/configuration/customerItemId">Upload Products</NavLink>
              section, first import products from shopify. <br />When import completed upload your products
              on google. </p>, // Data additional Field
            method: 'GET', // Method Type
            redirectTo: '/panel/configuration/customItemId', // After Completion Where To Redirect
            anchor: 'BUSINESSPOLICY', // Which Function to call e.g : 'U-INFO' then call div which take User basic Information
            stepperActive: false, // used in stepper Check either Completed or not
          },
          {
            heading: 'Set default category template',
            message: <span>Set Product ID format as per your Merchant Center</span>,
            anchor: 'CATEGORYTEMPLATE', // Which Function to call e.g : 'U-INFO' then call div which take User basic Information

          }
        ]
      },
    };

    this.openNewWindow = this.openNewWindow.bind(this);
    // this.checkConfig = this.checkConfig.bind(this);
    this.saveMapping = this.saveMapping.bind(this);
    this.redirectResult = this.redirectResult.bind(this);
    this.getFormData = this.getFormData.bind(this);
    this.getFormDataCAtegoryTemplate = this.getFormDataCAtegoryTemplate.bind(this);
    this.buttonLoadertoggle = this.buttonLoadertoggle.bind(this);
    this.paymentStatus = this.paymentStatus.bind(this);
    this.checkStepCompleted();
    this.myRef = React.createRef();
    this.myRefcustomId = React.createRef();
    this.SaveCategorydetails = React.createRef();

  }
handleCollapsibleOpen=()=>{

  this.setState({open:!this.state.open})
  this.state.text==='Read more'?this.setState({text:'Read less',textInside1:''}):this.setState({text:'Read more',textInside1:'If the products are already listed on eBay with any Integration app using Inventory Based API then Integration...'})
}
  getSiteId = () => {
    requests.getRequest('ebayV1/get/siteId').then(siteIDdata => {
      if(siteIDdata.success) {
        let {site_id} = siteIDdata.data;
        domain = json.country.filter(name => name.siteId === site_id)
      }
    })
  }

  componentDidMount() {
    this.getSiteId();
    this.getShopurl();
    document.title = 'Sell on eBay with eBay Marketplace Integration App | CedCommerce';
    document.description = 'CedCommerce introduces the eBay Marketplace Integration App enabling the Shopify merchants to sell on eBay by helping them to manage their products & orders.';
  }

  getShopurl() {
    this.getAllImporterServices()
  }

  /*render*/
  render() {
    return (
      <div style={{ margin: "auto" }}>
        <Page>

          {
            this.state.active_step < this.state.data.data.length ?
              this.rendersteps() : this.renderFinalBanner()
          }
          <Modal
            open={this.state.errorPolicyfound}
            onClose={this.toggleSettingModal.bind(this)}
            title="Errors found in policy"
          >
            <Modal.Section>
              <Stack distribution={"fill"}>
                {
                  this.renderErrorsFound()
                }
              </Stack>
            </Modal.Section>
          </Modal>

          {/*<Button size={"large"} primary onClick={this.changeStep.bind(this,1)} >Reset</Button>*/}

        </Page>
      </div>
    );
  }

  renderErrorsFound() {
    let temparr = [];
    this.state.errors_recieved_policy.forEach((value, index) => {
      temparr.push(<Banner key={index + 'Errors'} status={"critical"}>{value}</Banner>)
    })
    return temparr;
  }
  renderProgressindicator(step) {
    let i = 0;
    let temparr = [];
    while (i < this.state.data.data.length) {
      if (i === step) {
        temparr.push(<span key={"stepper-dot" + i} className="progress-dot-active" />);
      }
      else {
        temparr.push(<span key={"stepper-dot" + i} className="progress-dot" />);
      }
      i++;
    }
    return temparr
  }

  getStepBody(anchor) {
    switch (anchor) {
      case 'U-INFO':
        return this.renderGetUserInfo();
      case 'PLANS':
        return this.renderPlan();
      case 'LINKED':
        return this.renderLinkedAccount();
      case 'MAPPING':
        return this.renderMapping();
      case 'BUSINESSPOLICY':
        return this.renderBusinessPolicy();
      case 'CATEGORYTEMPLATE':
        return this.renderCategoryTemplate();
      default:
        console.log('This Is default');
    }

  }

  renderFinalBanner() {
    setTimeout(() => {
      this.redirect('/panel/dashboard');
    }, 5000)
    return (
      <StyleRoot>
        <div style={styles.flipInX}>
          <Card>
            <Card.Section>
              <div style={{ textAlign: 'center', minHeight: '35rem', marginTop: '10rem' }}>
                <Stack alignment={"center"} vertical={true}>
                  <img src={Checked} style={{ height: '5rem', width: '5rem' }} />
                  <DisplayText size={"extraLarge"}>
                    Registration Complete
                    </DisplayText>
                  <DisplayText size={"small"}>
                    Redirecting to Panel
                    </DisplayText>
                </Stack>
              </div>
            </Card.Section>
          </Card>
        </div>
      </StyleRoot>
    );
  }

  rendersteps() {
    return (
      /* <ReactCSSTransitionGroup
           transitionName="example"
           transitionAppear={true}
           transitionAppearTimeout={1000}
           transitionEnterTimeout={1000}
           transitionLeaveTimeout={1000}>*/

      <Card title={!isUndefined(this.state.importServicesList) && !isUndefined(this.state.importServicesList[0]) && !isUndefined(this.state.importServicesList[0].shops) && !isUndefined(this.state.importServicesList[0].shops[0]) && !isUndefined(this.state.importServicesList[0].shops[0].shop_url) ? this.state.importServicesList[0].shops[0].shop_url : ''} /*primaryFooterAction={{content:this.state.active_step===4?"Save & Complete":"Next",onAction:this.jumpforwardStep.bind(this,this.state.active_step+1),loading:this.state.button_loader}}
                   secondaryFooterAction={{content:'Skip',onAction:this.checkCustomId.bind(this),disabled:this.state.active_step===4?false:true}}*/
      >
        <div style={{ textAlign: "center", padding: 20 }}>
          <Card.Header title={
            this.state.skeleton_indicators ?
              <SkeletonBodyText lines={2} /> :
              <DisplayText size="large" element="h1">{this.state.data.data[this.state.active_step]['heading']}</DisplayText>
          }>

          </Card.Header>
          <div style={{ marginTop: 10 }}>

            {

              this.state.skeleton_indicators ?
                <SkeletonBodyText lines={2} /> :
                this.renderProgressindicator(this.state.active_step)

            }
          </div>
        </div>
        <Card.Section>
          <div style={{ minHeight: '30rem' }}>
            {
              this.state.active_step == 2 &&
              <Banner status={"warning"} title={"Please note"} >
                <p style={{ fontSize: 18 }}>The plans listed below <b>provide the service to list the products on eBay marketplace</b>. It is <b>not related</b> in any way <b>with the selling limit of seller on eBay marketplace</b>, for that seller need to <b style={{ color: 'blue', cursor: "pointer" }} onClick={() => {
                  window.open('https://www.ebay.com/help/selling/listings/selling-limits?id=4107', '_blank')
                }
                }>contact with eBay marketplace separately</b>.</p>
              </Banner>
            }
            {
              this.state.skeleton_indicators ?
                <SkeletonBodyText lines={20} /> :
                this.getStepBody(this.state.data.data[this.state.active_step].anchor)
            }
            <br />
          </div>
        </Card.Section>
        <Card.Section>
          <Stack /*distribution={"trailing"}*/ alignment={"center"} vertical={true}>

            <Stack.Item>
              <Button primary loading={this.state.button_loader} onClick={this.jumpforwardStep.bind(this, this.state.active_step + 1)}>{this.state.active_step === 5 ? "Save & Complete" : "Next"}</Button>
            </Stack.Item>

          </Stack>
        </Card.Section>
        <ModalVideo channel='youtube' isOpen={this.state.vedio.Modal} videoId={this.state.vedio.id} onClose={this.closeVedioModal.bind(this)} />
      </Card>

      /* </ReactCSSTransitionGroup>*/
    );
  }

  openVedioModal(id) {
    this.state.vedio.Modal = true;
    this.state.vedio.id = id;
    this.setState(this.state);
  }

  closeVedioModal() {
    this.state.vedio.Modal = false;
    this.state.vedio.id = '';
    this.setState(this.state);
  }

  renderGetUserInfo() {

    return (
      <StyleRoot key={"userinfo-body"}>
        <div style={styles.fadeInRight}>
          <React.Fragment>
            <Card actions={[{ content: 'Help video?', onAction: this.openVedioModal.bind(this, 'jr84JmKFPH4') }]}>
              <Card.Section>
                <Form /*onSubmit={this.handleSubmit} target="_blank"*/>
                  <FormLayout>
                    {/*<FormLayout.Group>*/}
                    {/*<TextField*/}
                    {/*value={this.state.info.full_name}*/}
                    {/*minLength={5}*/}
                    {/*onChange={this.handleFormChange.bind(this, 'full_name')}*/}
                    {/*error={this.state.info_error.full_name ? '*Field Is Empty' : null}*/}
                    {/*label="Full Name *"*/}
                    {/*type="text"*/}
                    {/*helpText={this.state.info.full_name === '' && this.state.info_error.full_name !== true ?*/}
                    {/*<p  style={{color: 'green',marginTop:"0.5%"}}>*Required</p>*/}
                    {/*: null*/}
                    {/*}*/}
                    {/*/>*/}
                    {/*</FormLayout.Group>*/}
                    {/*<FormLayout.Group condensed>*/}
                    {/*<TextField*/}
                    {/*value={this.state.info.email}*/}
                    {/*minLength={5}*/}
                    {/*error={this.state.info_error.email ? '*Field Is Empty' : null}*/}
                    {/*onChange={this.handleFormChange.bind(this, 'email')}*/}
                    {/*label="Email *"*/}
                    {/*type="email"*/}
                    {/*helpText= {this.state.info.email === '' && this.state.info_error.email !== true ?*/}
                    {/*<p  style={{color: 'green',marginTop:"1%"}}>*Required</p>*/}
                    {/*: null*/}
                    {/*}*/}
                    {/*/>*/}
                    {/*<TextField*/}
                    {/*value={this.state.info.skype_id}*/}
                    {/*onChange={this.handleFormChange.bind(this, 'skype_id')}*/}
                    {/*label="Skype ID:"*/}
                    {/*type="text"*/}
                    {/*/>*/}
                    {/*</FormLayout.Group>*/}
                    {/*<FormLayout.Group  condensed>*/}
                    {/*/!*<Select*!/*/}
                    {/*/!*label="Your Primary Time Zone"*!/*/}
                    {/*/!*options={[*!/*/}
                    {/*/!*{label: 'Pacific Time', value: 'Pacific Time'},*!/*/}
                    {/*/!*{label: 'Mountain Time', value: 'Mountain Time'},*!/*/}
                    {/*/!*{label: 'Central Time', value: 'Central Time'},*!/*/}
                    {/*/!*{label: 'Eastern Time', value: 'Eastern Time'},*!/*/}
                    {/*/!*{label: 'Hawaii Standard Time', value: 'Hawaii Standard Time'},*!/*/}
                    {/*/!*{label: 'Alaska Daylight Time', value: 'Alaska Daylight Time'},*!/*/}
                    {/*/!*{label: 'other', value: 'other'},*!/*/}
                    {/*/!*]}*!/*/}
                    {/*/!*onChange={this.handleFormChange.bind(this, 'primary_time_zone')}*!/*/}
                    {/*/!*value={this.state.info.primary_time_zone}*!/*/}
                    {/*/>*/}

                    {/*<Select*/}
                    {/*label="Preferable Time For Calling"*/}
                    {/*options={[*/}
                    {/*{label: '0-4', value: '0-4'},*/}
                    {/*{label: '4-8', value: '4-8'},*/}
                    {/*{label: '8-12', value: '8-12'},*/}
                    {/*{label: '12-16', value: '12-16'},*/}
                    {/*{label: '16-20', value: '16-20'},*/}
                    {/*{label: '20-24', value: '20-24'},*/}
                    {/*]}*/}
                    {/*onChange={this.handleFormChange.bind(this, 'best_time_to_contact')}*/}
                    {/*value={this.state.info.best_time_to_contact}*/}
                    {/*/>*/}
                    {/*</FormLayout.Group>*/}

                    <FormLayout.Group condensed>
                      {/*<Select*/}
                      {/*label="Country *"*/}
                      {/*placeholder="Select"*/}
                      {/*options={json.country_mobile_code}*/}
                      {/*onChange={this.handleFormChange.bind(this, 'country_code')}*/}
                      {/*value={this.state.info.country_code}*/}
                      {/*/>*/}

                      {/*<TextField label={'Code'} readOnly={true} value={this.state.info.mobile_code}/>*/}

                      <TextField
                        value={this.state.info.mobile}
                        minLength={5}
                        maxLength={14}
                        connectedLeft={
                          <Select
                            label=""
                            placeholder="Select"
                            options={json.country_mobile_code}
                            onChange={this.handleFormChange.bind(this, 'country_code')}
                            value={this.state.info.country_code} />
                        }
                        prefix={this.state.info.mobile_code}
                        error={this.state.info_error.mobile ? '*' : null}
                        onChange={this.handleFormChange.bind(this, 'mobile')}
                        helpText={"*required field, OTP will be send to this number for verification"}
                        label="Phone Number *"
                        type="text"
                      />
                      {/*{this.state.info.mobile === '' && this.state.info_error.mobile !== true ?*/}
                      {/*<p style={{color: 'green',marginTop:"1%"}}>*required</p>*/}
                      {/*: null*/}
                      {/*}*/}


                    </FormLayout.Group>
                    <FormLayout.Group>
                      <div ariaExpanded={this.state.additional_user_data}>
                        <Card>
                          <Card.Section>
                            <div style={{ cursor: 'pointer' }} onClick={this.handleToggleClick.bind(this, 'additional_user_data')}>
                              <Stack distribution={"equalSpacing"}>
                                <b>Additional user information</b>
                                <Button plain icon={this.state.additional_user_data ? ChevronDownMinor : ChevronRightMinor} />
                              </Stack>
                            </div>
                          </Card.Section>
                          <Collapsible open={this.state.additional_user_data} id={'ebayProductdata'}>
                            <Card>
                              <Card.Section>
                                <FormLayout>
                                  <FormLayout.Group>
                                    <TextField
                                      value={this.state.info.full_name}
                                      minLength={5}
                                      onChange={this.handleFormChange.bind(this, 'full_name')}
                                      error={this.state.info_error.full_name ? '*Field Is Empty' : null}
                                      label="Full Name *"
                                      type="text"
                                      helpText={this.state.info.full_name === '' && this.state.info_error.full_name !== true ?
                                        <p style={{ color: 'green', marginTop: "0.5%" }}>*Required</p>
                                        : null
                                      }
                                    />
                                  </FormLayout.Group>
                                  <FormLayout.Group condensed>
                                    <TextField
                                      value={this.state.info.email}
                                      minLength={5}
                                      error={this.state.info_error.email ? '*Field Is Empty' : null}
                                      onChange={this.handleFormChange.bind(this, 'email')}
                                      label="Email *"
                                      type="email"
                                      helpText={this.state.info.email === '' && this.state.info_error.email !== true ?
                                        <p style={{ color: 'green', marginTop: "1%" }}>*Required</p>
                                        : null
                                      }
                                    />
                                    <TextField
                                      value={this.state.info.skype_id}
                                      onChange={this.handleFormChange.bind(this, 'skype_id')}
                                      label="Skype ID:"
                                      type="text"
                                    />
                                  </FormLayout.Group>
                                  <FormLayout.Group condensed>
                                    {/*<Select*/}
                                    {/*label="Your Primary Time Zone"*/}
                                    {/*options={[*/}
                                    {/*{label: 'Pacific Time', value: 'Pacific Time'},*/}
                                    {/*{label: 'Mountain Time', value: 'Mountain Time'},*/}
                                    {/*{label: 'Central Time', value: 'Central Time'},*/}
                                    {/*{label: 'Eastern Time', value: 'Eastern Time'},*/}
                                    {/*{label: 'Hawaii Standard Time', value: 'Hawaii Standard Time'},*/}
                                    {/*{label: 'Alaska Daylight Time', value: 'Alaska Daylight Time'},*/}
                                    {/*{label: 'other', value: 'other'},*/}
                                    {/*]}*/}
                                    {/*onChange={this.handleFormChange.bind(this, 'primary_time_zone')}*/}
                                    {/*value={this.state.info.primary_time_zone}*/}
                                    {/*/>*/}

                                    <Select
                                      label="Preferable Time For Calling"
                                      options={[
                                        { label: '0-4', value: '0-4' },
                                        { label: '4-8', value: '4-8' },
                                        { label: '8-12', value: '8-12' },
                                        { label: '12-16', value: '12-16' },
                                        { label: '16-20', value: '16-20' },
                                        { label: '20-24', value: '20-24' },
                                      ]}
                                      onChange={this.handleFormChange.bind(this, 'best_time_to_contact')}
                                      value={this.state.info.best_time_to_contact}
                                    />
                                  </FormLayout.Group>
                                  <FormLayout.Group condensed>
                                    <Select
                                      label="Monthly store earning"
                                      placeholder="Select"
                                      options={[
                                        { label: '<500 $', value: '<500' },
                                        { label: '500-1000 $', value: '500-1000' },
                                        { label: '1000-2000 $', value: '1000-2000' },
                                        { label: '2000-5000 $', value: '2000-5000' },
                                        { label: '5000-8000 $', value: '5000-8000' },
                                        { label: '8000-10000 $', value: '8000-10000' },
                                        { label: '10000-20000 $', value: '10000-20000' },
                                        { label: '20000-50000 $', value: '20000-50000' },
                                        { label: '>50000 $', value: '>50000' }
                                      ]}
                                      onChange={this.handleFormChange.bind(this, 'revenue')}
                                      value={this.state.info.revenue}
                                    />

                                    <TextField
                                      label={'The categories you sell in'}
                                      onChange={(updated) => {
                                        this.state.info.categories = updated;
                                        this.setState(this.state);
                                      }}
                                      value={this.state.categories_options}
                                    />

                                  </FormLayout.Group>
                                </FormLayout>
                              </Card.Section>
                            </Card>
                          </Collapsible>
                        </Card>
                      </div>
                    </FormLayout.Group>
                    <FormLayout.Group >
                      <Select
                        label="How do you came to know about us?"
                        placeholder="Select"
                        options={[
                          { label: 'Shopify App Store', value: 'Shopify App Store' },
                          { label: 'Google Ads', value: 'Google Ads' },
                          { label: 'FaceBook Ads', value: 'FaceBook Ads' },
                          { label: 'Twitter', value: 'Twitter' },
                          { label: 'Yahoo', value: 'Yahoo' },
                          { label: 'Youtube', value: 'Youtube' },
                          { label: 'Other', value: 'Other' },
                        ]}
                        onChange={this.handleFormChange.bind(this, 'how_u_know_about_us')}
                        value={this.state.info.how_u_know_about_us}
                      />
                    </FormLayout.Group>
                    <FormLayout.Group >
                      {this.state.info.how_u_know_about_us === 'Other' ?
                        <TextField
                          value={this.state.info.Other_text}
                          onChange={this.handleFormChange.bind(this, 'Other_text')}
                          label="Kindly mention your source"
                          type="text"
                        /> : null
                      }
                    </FormLayout.Group>
                    <FormLayout.Group >
                      <div
                        style={{ height: '150px', width: '100%', overflow: 'auto' }}>
                        <div style={{ textAlign: 'center' }}>
                          <DisplayText size={"medium"}>CedCommerce Terms & Conditions and Privacy Policy</DisplayText>
                        </div>
                        {term_and_conditon()}
                      </div>
                    </FormLayout.Group>
                    <FormLayout.Group>
                      <Stack vertical={false} spacing={"extraTight"}>
                        <Checkbox
                          checked={this.state.info.term_and_conditon}
                          label={"Accept terms & conditions"}
                          error={this.state.info_error.term_and_conditon ? '*required' : ''}
                          onChange={this.handleFormChange.bind(this, 'term_and_conditon')}
                        />
                        <div style={{ cursor: 'pointer' }} onClick={
                          this.downloadPrivacyPolicy.bind(this)
                        }>
                          <Tooltip content={"Download privacy policy"}><Icon color={"blueDark"} source={"import"} /></Tooltip>
                        </div>
                      </Stack>
                    </FormLayout.Group>
                    {/*<FormLayout.Group >*/}
                    {/*<Button submit primary>Submit</Button>*/}
                    {/*</FormLayout.Group>*/}
                  </FormLayout>
                </Form>
              </Card.Section>
            </Card>
            <Modal open={this.state.otpCheck.status} onClose={() => {
              this.setState({
                otpCheck: {
                  status: false,
                  pin: '',
                  error: false,
                  number_change: false
                }
              })
            }}
            >
              <Modal.Section>
                <React.Fragment>
                  <Form onSubmit={this.handleOTPSubmit}>
                    <FormLayout >

                      {this.state.otpCheck.number_change ?

                        <FormLayout.Group condensed>
                          <Select
                            label="Country"
                            placeholder="Select"
                            options={json.country_mobile_code}
                            onChange={this.handleFormChange.bind(this, 'country_code')}
                            value={this.state.info.country_code}
                          />
                          <TextField label={'Code'} readOnly={true}
                            value={this.state.info.mobile_code} />
                          <TextField
                            value={this.state.info.mobile}
                            minLength={5}
                            maxLength={14}
                            error={this.state.info_error.mobile ? '*Please Enter Detail' : null}
                            onChange={this.handleFormChange.bind(this, 'mobile')}
                            helpText={this.state.info.mobile === '' && this.state.info_error.mobile !== true ?
                              <p style={{ fontSize: "1rem" }}>*required field, OTP will be send to this number for verification</p>
                              : null
                            }
                            label="Phone Number:"
                            type="text"
                          />



                        </FormLayout.Group>
                        :

                        <FormLayout.Group condensed>
                          <Stack vertical={true}>
                            <Stack.Item>
                              <TextField label={"Phone no."} readOnly={true}
                                value={this.state.info.mobile_code + '' + this.state.info.mobile} />
                            </Stack.Item>
                            <Stack.Item>
                              <a href="javascript:void(0)"
                                onClick={this.handleOTPChange.bind(this, 'number_change', true)}>Change
                                    Mobile Number</a><br />
                            </Stack.Item>
                          </Stack>
                          <Stack vertical={true}>
                            <Stack.Item>
                              <TextField
                                value={this.state.otpCheck.pin}
                                minLength={5}
                                maxLength={14}
                                error={this.state.otpCheck.error ? '*Please Enter Detail' : null}
                                onChange={this.handleOTPChange.bind(this, 'pin')}
                                label="Enter OTP"
                                type="text"
                              />
                            </Stack.Item>
                            <Stack.Item>
                              <a href="javascript:void(0)"
                                onClick={this.handleOTPChange.bind(this, 'resend')}>Resend
                                    OTP</a>
                            </Stack.Item>
                          </Stack>
                        </FormLayout.Group>}
                      <FormLayout.Group >
                        <Stack vertical={true} alignment={"center"} spacing={"extraTight"}>
                          <Stack.Item>
                            <Button
                              submit
                              primary
                              disabled={this.state.otpCheck.pin.length <= 3 && !this.state.otpCheck.number_change}
                            >
                              Submit
                              </Button>
                          </Stack.Item>
                          <Stack.Item>
                            <DisplayText size="small">
                              <span style={{ fontSize: '1rem' }}>
                                {this.state.otpCheck.number_change ? '' :
                                  "OTP will be valid for 5 minutes"}
                              </span>
                            </DisplayText>
                          </Stack.Item>
                        </Stack>
                      </FormLayout.Group>
                    </FormLayout>
                  </Form>
                </React.Fragment>
              </Modal.Section>
            </Modal>
          </React.Fragment>
        </div>
      </StyleRoot>

    );
  }

  renderLinkedAccount() {
    if (this.state.accountChecked === false) {
      this.checkLinkedAccountentry();
      this.state.accountChecked = true;
      this.setState(this.state);
    }
    // if (localStorage.getItem('taskStatus')) {
    //     let data = JSON.parse(localStorage.getItem('taskStatus'));
    //     if (data.shop === globalState.getLocalStorage('shop')) {
    //         if (data.success && data.isConnected) {
    //             this.checkLinkedAccount();
    //         }
    //         localStorage.removeItem('taskStatus');
    //     }
    // }
    return (
      <StyleRoot key={"accountlink-body"}>
        <div style={styles.fadeInRight}>
          <AppsShared history={history} fromRegistration={true} redirectResult={this.redirectResult} />
          <React.Fragment>
            {this.state.modalOpen ?
              <InstallAppsShared history={this.props.history} redirect={this.redirectResult}
                code={this.state.code} site_id={this.state.site_id} mode={this.state.mode} /> : null}
          </React.Fragment>
        </div>
      </StyleRoot>
    );
  }

  renderPlan() {
    if (this.state.PlanChecked === false) {
      this.checkPaymententry()
      this.state.PlanChecked = true;
      this.setState(this.state);
    }

    // if (localStorage.getItem('taskStatus')) {
    //     let data = JSON.parse(localStorage.getItem('taskStatus'));
    //     if (data.shop === globalState.getLocalStorage('shop')) {
    //         if (data.success && data.isPlan) {
    //             this.checkPayment();
    //         }
    //         localStorage.removeItem('taskStatus');
    //     }
    // }
    return (
      <StyleRoot key={"plan-body"}>
        <div style={styles.fadeInRight}>
          <Stack vertical={true} alignment={"center"} >
            <Stack.Item></Stack.Item>
            <Stack.Item>
              <span style={{ 'fontSize': '25px' }}><b>Most popular plans</b></span>
            </Stack.Item>
            <Stack.Item alignment={"center"}>
              <FormLayout.Group condensed>
                <Stack vertical={true} alignment={"center"}>
                  {/*<span style={{'fontSize':'25px'}}><b>Most popular monthly</b></span>*/}
                  <PlanBody paymentStatus={this.paymentStatus} plantype={"Silver"} showFreePlan={false} />
                </Stack>
                <Stack vertical={true} alignment={"center"}>
                  {/*<span style={{'fontSize':'25px'}}><b>Most popular yearly</b></span>*/}
                  <PlanBody paymentStatus={this.paymentStatus} plantype={"Bronze"} showFreePlan={false} />
                </Stack>
              </FormLayout.Group>
            </Stack.Item>
            <Stack.Item>
              <Stack vertical={true} alignment={"center"}>
                <span style={{ 'fontSize': '25px' }}><b>Other Paid Plans</b></span>
                <FormLayout.Group condensed>

                  <PlanBody paymentStatus={this.paymentStatus} plantype={"Gold"} showFreePlan={false} />
                  <PlanBody paymentStatus={this.paymentStatus} plantype={"Platinum"} showFreePlan={false} />
                </FormLayout.Group>
              </Stack>
              {/*  <Stack vertical={true} alignment={"center"}>*/}
              {/*    <br/>*/}
              {/*    <span style={{'fontSize':'35px'}}><b>Monthly Plans</b></span>*/}
              {/*    <PlanBody paymentStatus={this.paymentStatus} plantype={"Monthly"} showFreePlan={false} />*/}
              {/*  </Stack>*/}
              {/*</Stack.Item>*/}
              {/*<Stack.Item >*/}
              {/*  <Stack vertical={true} alignment={"center"}>*/}
              {/*    <br/>*/}
              {/*    <span style={{'fontSize':'35px'}}><b>Mega Saver Plans</b></span>*/}
              {/*    <PlanBody paymentStatus={this.paymentStatus} plantype={"Yearly"}  showFreePlan={false}/>*/}
              {/*  </Stack>*/}

            </Stack.Item>
            <Stack.Item>
              <Stack vertical={true} alignment={"center"}>
                <span style={{ 'fontSize': '25px' }}><b>Free Plan</b></span>
                <PlanBody paymentStatus={this.paymentStatus} showFreePlan={true} />
              </Stack>
            </Stack.Item>
          </Stack>
        </div>
      </StyleRoot>
    );
  }

  renderMapping() {
    return (
      <StyleRoot key={"configuration-body"}>
        <Card actions={[{ content: 'Help video?', onAction: this.openVedioModal.bind(this, '2lFk4LFxl0c') }]}>
          <Card.Section>
            <div style={styles.fadeInRight}>
        <Stack vertical>
          <Banner status={"info"}>
            <Stack spacing="extraTight">
             <Stack.Item fill>
                <p>
         <TextContainer>{this.state.textInside1}</TextContainer>
          <Collapsible
            open={this.state.open}
            id="basic-collapsible"
            transition={{duration: '500ms', timingFunction: 'ease-in-out'}}
            expandOnPrint
          >
              <TextContainer>
               {this.state.textInside2}
                <br/>
  <Link  url='https://developer.ebay.com/api-docs/sell/inventory/overview.html' external>Know more</Link>
                </TextContainer>
             </Collapsible>
             </p>
           </Stack.Item>
   <Stack.Item>
   
           <Button size={"slim"} plain
            onClick={this.handleCollapsibleOpen}
            ariaExpanded={this.state.open}
            ariaControls="basic-collapsible"
          >
            {this.state.text}
          </Button>
</Stack.Item>
           </Stack>
          </Banner>
          <br/>
        </Stack>
     
              <Banner status={"info"}>
                <p className="text-justify">If you are already selling on eBay, then you need to map your <b>Title(s)</b> and <b>SKU(s)</b> between eBay and Shopify. This will help us in recognizing your already existing products on eBay and hence avoiding any sort of duplicity issues.</p>
              </Banner>
              {/* {domain.length > 0 && domain[0].hasOwnProperty('domainName') && <Banner status="info">You can create business policy directly on eBay seller panel <Link url={`https://www.bizpolicy.ebay${domain[0]['domainName']}/businesspolicy/manage`} external={true}>Click Here </Link></Banner>} */}
              <br />
              {this.state.noProductsonShopify &&
                <Banner status={"info"}><p>No products were found on your <span style={{ color: 'blue', textDecoration: 'underline', cursor: 'pointer' }} onClick={() => { window.open('https://' + this.state.importServicesList[0].shops[0].shop_url + "/admin/products", '_blank'); }}>Shopify store,</span> Kindly create some products and
                  then proceed with the registration.</p></Banner>
              }
              <MappingProducts ref={this.myRef} history={this.props.history} saveMapping={this.saveMapping.bind(this)} />
            </div>
          </Card.Section>
        </Card>
      </StyleRoot>
    );
  }

  renderBusinessPolicy() {

    return (
      <StyleRoot key={"item-id-body"}>
        <div style={styles.fadeInRight}>
          <Stack vertical={true} spacing={"loose"}>
            <Stack distribution={"trailing"}>
              <p style={{ color: '#3B7DC4', cursor: 'pointer' }} onClick={this.openVedioModal.bind(this, 'Py3zDdTxSfI')}>Help video?</p>
            </Stack>
            <AccountSettings ref={this.myRefcustomId} showSave={false} history={this.props.history} recieveFormData={this.getFormData} domain={domain} />
          </Stack>
        </div>
      </StyleRoot>
    );
  }

  renderCategoryTemplate() {

    return (
      <StyleRoot key={"item-id-body"}>

        <div style={styles.fadeInRight}>
          <Stack vertical={true} spacing={"loose"}>
            <Stack distribution={"trailing"}>
              <p style={{ color: '#3B7DC4', cursor: 'pointer' }} onClick={this.openVedioModal.bind(this, 'qit-0hRCbzQ')}>Help video?</p>
            </Stack>
            <CategoryTemplate ref={this.SaveCategorydetails} showSecondaryCategory={false} infoBanner={true} history={this.props.history} recieveFormdata={this.getFormDataCAtegoryTemplate} />
          </Stack>
        </div>

      </StyleRoot>
    );
  }

  /*render*/

  /* Step 1 Important Functions */

  handleToggleClick(key) {
    let tempObj = Object.assign({}, this.state);
    tempObj[key] = !tempObj[key];
    this.setState(tempObj);
  }

  downloadPrivacyPolicy() {
    window.open(" https://express.sellernext.com/others/ebayIntegrationPrivacyPolicy.pdf", "_blank")
  }

  handleFormChange = (field, value) => { // this function is used to submit user basic info
    let data = this.state.info;
    if (field == 'full_name') {
      data[field] = value.replace('.', '').replace(',', '').replace(/[^\w\s]/gi, "").replace(/[0-9]/gi, '')
      let tempData = this.state.info_error;
      if (this.state.info[field] !== '' || this.state.info[field])
        tempData[field] = false;
      this.setState({
        info: data,
        info_error: tempData
      });
      if (field === 'country_code') {
        let temp;
        json.country_mobile_code.forEach(e => {
          if (e.value === value) {
            temp = e.phone_code;
          }
        });
        this.handleFormChange('mobile_code', temp);
      }
    }
    else if (field == 'skype_id') {
      data[field] = value.replace('.', '').replace(',', '').replace(/[^\w\s]/gi, "")//.replace(/[0-9]/gi, '')
      let tempData = this.state.info_error;
      if (this.state.info[field] !== '' || this.state.info[field])
        tempData[field] = false;
      this.setState({
        info: data,
        info_error: tempData
      });
      if (field === 'country_code') {
        let temp;
        json.country_mobile_code.forEach(e => {
          if (e.value === value) {
            temp = e.phone_code;
          }
        });
        this.handleFormChange('mobile_code', temp);
      }
    }
    else if (field == 'mobile') {
      data[field] = value.replace(',', '').replace('.', '').replace(/[a-zA-Z]/gi, '');
      let tempData = this.state.info_error;
      if (this.state.info[field] !== '' || this.state.info[field])
        tempData[field] = false;
      this.setState({
        info: data,
        info_error: tempData
      });
      if (field === 'country_code') {
        let temp;
        json.country_mobile_code.forEach(e => {
          if (e.value === value) {
            temp = e.phone_code;
          }
        });
        this.handleFormChange('mobile_code', temp);
      }
    }
    else {
      data[field] = value//.replace('-', '').replace(',', '').replace('.', '');
      let tempData = this.state.info_error;
      if (this.state.info[field] !== '' || this.state.info[field])
        tempData[field] = false;
      this.setState({
        info: data,
        info_error: tempData
      });
      if (field === 'country_code') {
        let temp;
        json.country_mobile_code.forEach(e => {
          if (e.value === value) {
            temp = e.phone_code;
          }
        });
        this.handleFormChange('mobile_code', temp);
      }
    }
  };

  handleOTPSubmit = () => {
    if (this.state.otpCheck.pin !== '' && !this.state.otpCheck.number_change) {
      requests.postRequest('core/app/matchOtp', { otp: this.state.otpCheck.pin }).then(data => {
        if (data.success) {
          this.setState({
            otpCheck: {
              status: false,
              pin: '',
              error: false,
              number_change: false,
            }
          });
          let tempInfo = Object.assign({}, this.state.info);
          tempInfo.mobile = tempInfo.mobile_code + '-' + tempInfo.mobile;
          requests.getRequest('core/user/updateuser', tempInfo).then(data => {
            if (data.success) {
              notify.success(data.message);
              window.fbq('track', 'Lead');
              window.gtag('event', 'conversion', {
                'send_to': 'AW-944073096/mcMkCM3xjIcBEIjTlcID',
                'value': 1.0,
                'currency': 'INR'
              });
              window.gtag('config', 'AW-944073096');
              this.buttonLoadertoggle();
              this.changeStep(1);
            } else {
              notify.error(data.message);
            }
          });
        } else {
          notify.error(data.message);
        }
      })
    } else if (this.state.otpCheck.number_change && this.state.info.mobile !== '') {
      this.handleSubmit();
    } else {
      notify.info('Field is empty');
    }
  };

  userdetailsSave() {
    if (this.state.info.term_and_conditon &&
      this.state.info.full_name !== '') {
      let tempInfo = Object.assign({}, this.state.info);
      tempInfo.mobile = tempInfo.mobile_code + '-' + tempInfo.mobile;
      requests.getRequest('core/user/updateuser', tempInfo).then(data => {
        if (data.success) {
          notify.success(data.message);
          window.fbq('track', 'Lead');
          window.gtag('event', 'conversion', {
            'send_to': 'AW-944073096/mcMkCM3xjIcBEIjTlcID',
            'value': 1.0,
            'currency': 'INR'
          });
          window.gtag('config', 'AW-944073096');
          this.buttonLoadertoggle();
          this.changeStep(1);
        } else {
          notify.error(data.message);
        }
      });
    } else {
      let tempData = this.state.info_error;
      if (this.state.info.full_name === '')
        tempData.full_name = true;
      // if (this.state.info.email === '')
      //     tempData.email = true;
      // if (this.state.info.mobile === '')
      //     tempData.mobile = true;
      if (!this.state.info.term_and_conditon)
        tempData.term_and_conditon = true;
      this.setState({ info_error: tempData });
    }
  }

  handleOTPChange = (arg, value) => {
    if (arg === 'resend') {
      this.handleSubmit();
      this.buttonLoadertoggle();
    } else {
      let otpCheck = this.state.otpCheck;
      otpCheck[arg] = value;
      this.setState({ otpCheck: otpCheck });
    }
  };

  sendInstallationMail() {
    requests.getRequest('frontend/app/sendInstallationMail').then(data => {
      return true;
    })
  }

  handleSubmit = () => { // this function is used to submit user basic info
    if (this.state.info.email !== '') {
      requests.postRequest('frontend/app/verifyEmail', { email: this.state.info.email }).then(data => {
        if (data.success) {
          this.sendInstallationMail();
          this.userdetailsSave();
          this.initiatefetchVendorProductType()
        } else {
          let tempData = this.state.info_error;
          if (this.state.info.email === '')
            tempData.email = true;
          this.setState({ info_error: tempData });
          notify.info("Having trouble in email validation?, Feel free to contact us");
          notify.error(data.message);
        }
      });
    } else {
      let tempData = this.state.info_error;
      if (this.state.info.email === '')
        tempData.email = true;
      this.setState({ info_error: tempData });
    }
    this.buttonLoadertoggle();
  };

  autofilldetails() {
    requests.getRequest('frontend/app/getShopDetails').then(data => {
      if (data.success) {
        this.state.skeleton_indicators = false;
        this.state.info.full_name = data.data.full_name;
        this.state.info.email = data.data.email;
        this.state.info.mobile = data.data.mobile;
        this.handleFormChange('country_code', data.data.country)
        this.setState(this.state);
      }
      else {
        notify.error("Payment Required For Shop");
        this.redirect('/auth/login');
      }
    });
  }

  /* Step 1 Important Functions */


  /*Step 2 needed function*/

  checkLinkedAccount() {
    requests.getRequest('frontend/app/checkAccount?code=ebay').then(data => {
      if (data.success) {
        if (data.data.account_connected) {
          notify.success('Account is connected successfully');
          this.importBusinessPolicies();
          this.changeStep(2);
        } else {
          notify.info('Account not connected');
          this.state.button_loader = false;
          this.setState(this.state);
        }
      } else {
        notify.error(data.message);
      }
    });
  }

  checkLinkedAccountentry() {
    requests.getRequest('frontend/app/checkAccount?code=ebay').then(data => {
      if (data.success) {
        if (data.data.account_connected) {
          notify.success('Account is connected successfully');
          this.importBusinessPolicies();
          this.changeStep(2);
        } else {
          this.state.button_loader = false;
          this.setState(this.state);
        }
      } else {
        notify.error(data.message);
      }
    });
  }

  importBusinessPolicies() {
    requests.getRequest('ebayV1/import/businessPolicies').then(data => {

    });
  }

  /*Step 2 needed function*/


  /*Step 3 needed function*/

  checkPayment() {
    this.buttonLoadertoggle();
    requests.getRequest('plan/plan/getActive').then(status => {
      if (status.success) {
        notify.success('Your plan is activated');
        this.changeStep(3);
      } else {
        notify.error(status.message);
        this.state.button_loader = false;
        this.setState(this.state);
      }
    });
  }

  checkPaymententry() {
    this.buttonLoadertoggle();
    requests.getRequest('plan/plan/getActive').then(status => {
      if (status.success) {
        notify.success('Your plan is activated');
        this.changeStep(3);
      } else {
        // notify.error(status.message);
        this.state.button_loader = false;
        this.setState(this.state);
      }
    });
  }

  paymentStatus(event) {
    if (event === 'Confirmation') {
      this.checkPaymententry();
      // this.setState({modalOpen: !this.state.modalOpen});
    } else {
      // notify.info(event);
    }
  }

  /*Step 3 needed function*/

  /*Step 4 needed function*/

  getAllImporterServices() {
    requests.getRequest('connector/get/services', { 'filters[type]': 'importer' })
      .then(data => {
        if (data.success === true) {
          this.state.importServicesList = [];
          for (let i = 0; i < Object.keys(data.data).length; i++) {
            let key = Object.keys(data.data)[i];
            if (!isUndefined(key) && key === 'shopify_importer') {
              this.state.importServicesList.push({
                label: data.data[key].title,
                value: data.data[key].marketplace,
                shops: data.data[key].shops
              });
            }
          }
          this.updateState();
          localStorage.setItem('shop_url', !isUndefined(this.state.importServicesList[0].shops[0]) && !isUndefined(this.state.importServicesList[0].shops[0].shop_url) ? this.state.importServicesList[0].shops[0].shop_url : "");
          if (!document.title.includes(localStorage.getItem('shop_url'))) {
            document.title += !isUndefined(localStorage.getItem('shop_url')) ? " " + localStorage.getItem('shop_url') : "";
          }
        }
      });
  }

  getFiltersInfo(data) {
    let tempObj = {};
    let checkFilterUsed = false;
    if (data.optional_filter) {
      if (data.use_vendor_filter) {
        if (data.vendor !== '') {
          tempObj['vendor'] = data.vendor;
        }
        checkFilterUsed = true;
      }
      if (data.use_product_type_filter) {
        if (data.product_type !== '') {
          tempObj['product_type'] = data.product_type;
        }
        checkFilterUsed = true;
      }
    }
    if (checkFilterUsed) {
      return tempObj;
    } else {
      return false;
    }

  }

  saveMapping(data) {
    this.getAllImporterServices();
    let tempObj = Object.assign({}, data);
    if (data.selling_on_ebay === 'yes') {
      let filterObj = this.getFiltersInfo(data);
      delete tempObj.selling_on_ebay;
      delete tempObj.product_type_options;
      delete tempObj.vendor_options;
      delete tempObj.optional_filter;
      delete tempObj.use_product_type_filter;
      delete tempObj.use_vendor_filter;
      delete tempObj.vendor;
      delete tempObj.product_type;
      tempObj['filter'] = Object.assign({}, filterObj);
      requests.postRequest('ebayV1/upload/syncProducts', tempObj).then(data => {
        if (data.success) {
          let detailsforShop = {
            set_by_path: [{ path: 'AccountType', value: tempObj.account_type, framework: 'global' }],
            app_settings: {
              product_sync: tempObj['product_sync']
            }
          };
          requests.postRequest('ebayV1/get/setForShop', detailsforShop).then(data => {
            if (data.success) {
              this.state.noProductsonShopify = false;
              this.setState(this.state);
              this.changeStep(4);
            } else {
              this.state.noProductsonShopify = true;
              notify.info(data.message);
              this.state.button_loader = false;
              this.setState(this.state);
            }
          })
        } else {
          this.state.noProductsonShopify = true;
          notify.info(data.message);
          this.state.button_loader = false;
          this.setState(this.state);
        }
      });
    }
    else {
      this.importProducts(data);
    }
  }

  importProducts(dataRecieved) {
    requests.getRequest('ebayV1/get/siteId').then(siteIDdata => {
      if (siteIDdata.success) {
        let filterObj = this.getFiltersInfo(dataRecieved);
        requests.postRequest('connector/product/import',
          {
            marketplace: 'shopify',
            shop: '',
            shop_id: siteIDdata.data.site_id,
            product_status: dataRecieved['product_status'],
            filter: filterObj
          })
          .then(data => {
            if (data.success === true) {
              this.state.noProductsonShopify = false;
              this.setState(this.state);
              notify.success(data.message);
              this.changeStep(4);
            } else {
              // console.log(data.message);
              notify.info(data.message);

              this.state.noProductsonShopify = true;
              this.state.button_loader = false;
              this.setState(this.state);
            }
          });

      }
    });
  }

  toggleSettingModal() {
    this.state.errorPolicyfound = !this.state.errorPolicyfound;
    this.setState(this.state);
  }

  formModalData(data) {
    let temparr = [];
    Object.keys(data).map(key => {
      data[key].forEach((value, index) => {
        temparr.push(
          key.toUpperCase() + " Policy : " + value.message
        )
      });
      this.state.errorPolicyfound = true;
    });
    this.state.errors_recieved_policy = temparr;
    this.setState(this.state);
  }

  /*Step 4 needed function*/

  /*Step 5 needed function*/

  getFormData(data) {

    if (!('allSaved' in data)) {
      if (!('errors' in data)) {
        requests.postRequest('ebayV1/upload/saveAppSettings', data.app_setting).then(saveappsetting => {
          if (saveappsetting.success) {
            this.toggleskeleton();
            requests.postRequest('ebayV1/upload/saveGlobalPolicies', data).then(saveglobalsettings => {
              if (saveglobalsettings.success) {
                notify.success(saveglobalsettings.message);
                this.changeStep(5);
              }
              else {
                notify.error(saveglobalsettings.message);
                this.state.button_loader = false;
                this.setState(this.state);
                if (!isUndefined(saveglobalsettings.data)) {
                  this.formModalData(saveglobalsettings.data)
                }
              }
              this.toggleskeleton();
            });
          }
          else {
            notify.error(saveappsetting.message);
            this.state.button_loader = false;
            this.setState(this.state);
          }
        })
      }
      else {
        notify.error('Kindly fill all the required fields');
        this.state.button_loader = false;
        this.setState(this.state);
      }
    }
    else {
      this.changeStep(5);
    }

  }
  /*Step 5 needed function*/

  /*Step 6 needed function*/

  getFormDataCAtegoryTemplate(data) {
    this.buttonLoadertoggle()
    let temparr = [];
    temparr.push(data);
    requests.postRequest('ebayV1/upload/saveGlobalTemplates', temparr).then(response => {
      if (response.success) {
        this.changeStep(6);
        this.checkDefaultSettings()
      }
      else {
        notify.error(response.message);
        // this.buttonLoadertoggle();
      }
    })
  }

  checkDefaultSettings() {
    requests.getRequest('ebayV1/upload/checkDefaultSettings').then(data => {

    });
  }
  /*Step 6 needed function*/

  /*Basic neccessary functions */

  updateState() {
    let temp = Object.assign({}, this.state);
    this.state = temp;
    this.setState(this.state);
  }

  redirectResult(status, siteID, mode) {
    this.openNewWindow(status, siteID, mode);
  }

  openNewWindow(action, siteID, mode) {
    this.setState({ modalOpen: !this.state.modalOpen, code: action, site_id: siteID, mode: mode });
  } // Open Modal And A new Small Window For User

  toggleskeleton() {
    this.state.skeleton_indicators = !this.state.skeleton_indicators;

    this.updateState()
  }

  redirect(url) {
    this.props.history.push(url);
  }

  buttonLoadertoggle() {
    this.state.button_loader = !this.state.button_loader;
    this.updateState();
  }

  /*Basic neccessary functions */


  /*Step change Related Functions */

  checkStepCompleted() {
    let path = '/App/User/Step';
    requests.getRequest('frontend/app/getStepCompleted', { path: path }).then(data => {
      if (data.success) {
        if (data.data !== null && !isUndefined(data.data)) {
          this.state.active_step = parseInt(data.data);
          this.updateState();
          if (parseInt(data.data) == 0) {
            this.fetchLevelOnecategories()
          }
          this.autofilldetails();
        }
      }
      else {
        this.redirect('/auth/login');
      }
    });
  }

  fetchLevelOnecategories() {
    requests.postRequest("ebayV1/get/categories", { 'level': 1 }).then(data => {
      if (data.success) {
        // this.setCategoryOptions(data.data);
      }
    });
  }

  setCategoryOptions(data) {
    let temparr = [];
    data.forEach((value, index) => {
      temparr.push(
        { label: value.CategoryName, value: value.CategoryID }
      );
    });
    this.state.categories_options = temparr.slice(0);
    this.setState(this.state);
  }

  jumpforwardStep(step) {
    // this.toggleskeleton()
    this.buttonLoadertoggle();
    let current_step = this.state.active_step;
    let next_step = step;
    this.step_neccessary_function(current_step, next_step);
    // this.toggleskeleton();
  }

  initiatefetchVendorProductType() {
    requests.getRequest('shopify/product/initiateVendorProductTypeFetch').then(data => {
      if (data.success) { }
    })
  }

  step_neccessary_function(current_step, next_step) {
    switch (current_step) {
      case 0:
        if (next_step === 1) {
          this.handleSubmit();
          // this.userdetailsSave();
          // this.initiatefetchVendorProductType()
        }

        break;
      case 1:
        if (next_step === 0) {
          this.autofilldetails()
        }
        this.checkLinkedAccount();
        // this.changeStep(next_step);
        break;
      case 2:
        this.checkPayment();
        break;
      case 3:
        this.myRef.current.saveMatchingId();
        break;
      case 4:
        this.myRefcustomId.current.saveAllprofiles();
        break;
      case 5:
        this.buttonLoadertoggle();
        this.SaveCategorydetails.current.saveConfigData();
        break;
    }
  }

  changeStep(arg) {
    // arg means step number
    this.toggleskeleton()
    // this.updateState();
    let path = [];
    path.push('/App/User/Step');
    requests.postRequest('frontend/app/stepCompleted', { paths: path, step: arg }).then(value => {
      if (value.success) {
        this.state.active_step = arg;
        this.state.button_loader = false;
        // this.buttonLoadertoggle();
        this.toggleskeleton()
        window.scrollTo(0, 0);
      }
    });
  }

  /*Step Related Functions */
}



export default Registrations;
