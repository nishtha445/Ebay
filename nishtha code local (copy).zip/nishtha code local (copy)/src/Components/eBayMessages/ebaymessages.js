import React, {Component} from 'react';
import {Page, Card, DataTable,Pagination,Stack, Select,Button,FooterHelp,Link,Banner,TextField,FormLayout,Modal,Spinner,Layout, Subheading,Heading} from "@shopify/polaris";
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import {
  DeleteMajorMonotone
} from '@shopify/polaris-icons';


const pageSizeOption = [
  {label : '10' , value:'10'},
  {label : '20' , value:'20'},
  {label : '30' , value:'30'},
  {label : '50' , value:'50'}
];

const currentTime = new Date();
const year = currentTime.getFullYear();
const month = (currentTime.getMonth() + 1) < 10 ? '0' + (currentTime.getMonth() + 1) : currentTime.getMonth() + 1;
const date = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();

const currentDateInString = year + '-' + month + '-' + date;

const previousOneMonthDate = new Date();
previousOneMonthDate.setMonth(previousOneMonthDate.getMonth() - 1)

const previousOneMonthDateYear = previousOneMonthDate.getFullYear();
const previousOneMonthDateMonth = (previousOneMonthDate.getMonth() + 1) < 10 ? '0' + (previousOneMonthDate.getMonth() + 1) : previousOneMonthDate.getMonth() + 1;
const previousOneMonthDateDate = previousOneMonthDate.getDate() < 10 ? '0' + previousOneMonthDate.getDate() : previousOneMonthDate.getDate();
const fromDefaultDateInString = previousOneMonthDateYear + '-' + previousOneMonthDateMonth + '-' + previousOneMonthDateDate;

class Ebaymessages extends Component {

  constructor(props){
    super(props);
    this.state = {
      noData:false,
      rows:[],
      all_data : [],
      pagination:{
        activePage:1,
        perPage: '10',
        totalPages:100,
      },
      date_filter:{
        from: fromDefaultDateInString,
        to: currentDateInString,
      },
      modal:{
        open : false,
        content:'',
        title : '',
        key : '',
      },
      filter_modal : false,
      loader : {
        button_loader : false,
      }
    };
  }

  deleteMessage(index){
    const { all_data } = this.state ;
    let message_id = all_data[index].MessageID;
    requests.getRequest('ebayV1/delete/deleteMessages',{message_ids:[message_id]}).then(data => {
      if(data.success){
        notify.success(data.message);
      }else{
        notify.error(data.message);
      }
    })
  }

  setDataModal(data){
    let { modal } = this.state;
    modal.open = data.open;
    modal.content = data.content;
    modal.title = data.title;
    modal.key = data.key;
    this.setState({modal});
  }

  getModifieddata(data){
    
    return data.length? data.map((message, index) =>{  
      return [
        message.Sender,
        <p onClick={(e) => {
          let modalData = {
            title : message.ItemTitle,
            key : 'message_modal',
            content : <React.Fragment>
              <Card title={`Item id ${message.ItemID}`}>
                <Card.Section>
                  <Banner>
                    { message.Subject }
                  </Banner>
                </Card.Section>
              </Card>
            </React.Fragment>,
            open : true
          };
          this.setDataModal(modalData);
          e.preventDefault();
        }} style={{textDecoration:'underline',color: 'blue', cursor:'pointer'}}>{message.MessageID}</p>,
        message.ReceiveDate,
        message.ExpirationDate,
        <Button icon={DeleteMajorMonotone} onClick={this.deleteMessage.bind(this,index)} plain={true}/>  
      ];
    }) :[]

  }
  getNodata(data){
    this.setState({noData:true})
    return data.map((message, index) =>{  
    
      return [
       
        <Stack distribution="center">
          <div style={{marginTop:'70px',marginBottom:'70px'}}>
          <Heading >No messages found</Heading></div>
        </Stack>
       
       
      ];
    })
   
  }
  getMessages(){
    const { date_filter,loader } = this.state;
    
    loader.button_loader = true;
    this.setState({loader});
    let tempObj = {};
    if( date_filter.from !== '' && date_filter.to !== ''){
      tempObj = {
        start_time : date_filter.from,
        end_time : date_filter.to
      };
    }
    requests.getRequest('ebayV1/get/getMessage',{...{
        page: this.state.pagination.activePage,
        pageSize: this.state.pagination.perPage,
      }, ...tempObj}).then(data=>{
      if(data.success){
        if(data.data.Message) {
          console.log(data.data.Message)
          this.setState({ rows : this.getModifieddata(data.data.Message), all_data : data.data.Message }) 
        } 
        else if(Array.isArray(data.data) && data.data.length === 0 ) {
          
          this.setState({ rows : this.getNodata(['No messages found']), all_data :['No messages found']}) 
          notify.info('No message found');
          
        }
      }else{
        notify.error(data.message);
      }
      const { loader } = this.state;
      loader.button_loader = false;
      this.setState({loader});
    })
  }

  handlePagination(action){
    let pagination = Object.assign({},this.state.pagination);
    switch(action){
      case 'prev':
        if(pagination.activePage > 0){
          pagination.activePage --;
        }
        break;
      case 'next':
        if(pagination.activePage < pagination.totalPages){
          pagination.activePage ++;
        }
        break;
      default : break;
    }
    this.setState({pagination:pagination},() => {
      this.getMessages();
    });
  }

  componentDidMount() {
    this.getMessages()
  }

  getContentFilter(){
    let { date_filter } = this.state;
    
    let to_date = new Date(date_filter.from);
    let start_year = to_date.getFullYear();
    let start_month = (to_date.getMonth() + 1) < 10 ? '0' + (to_date.getMonth() + 1) : to_date.getMonth() + 1;
    let start_date = to_date.getDate() < 10 ? '0' + to_date.getDate() : to_date.getDate();
    let toDateinString = start_year + '-' + start_month + '-' + start_date;

    return    ( <Card primaryFooterAction={{content :'Get messages',onAction:() =>{
      if((this.state.date_filter.from !== "" && this.state.date_filter.to !== "")) {
        if((new Date(this.state.date_filter.to).getTime() > new Date(this.state.date_filter.from).getTime())) {
          this.getMessages();
          this.setState({filter_modal : false});
        } else {
          notify.error("From Date must be smaller than To Date")
        }
      } else {
        notify.error("Specify Dates")
      }
      }}}>
      <Card.Section title={'Date filter'}>
        <FormLayout condensed>
          <FormLayout.Group>
            <TextField label={'From'} type={'date'} max={currentDateInString} value ={ date_filter.from} onChange={(e)=>{
              date_filter.from = e;
              this.setState({date_filter});
            }}/>
            <TextField label={'To'} type={"date"} disabled={date_filter.from === ''} min={toDateinString} max={currentDateInString} value ={date_filter.to} onChange={(e)=>{
              date_filter.to = e;
              this.setState({date_filter});
            }}/>
          </FormLayout.Group>
        </FormLayout>
      </Card.Section>
    </Card>);
  }

  render() {

    const { rows , pagination , modal, loader } = this.state;
    const {  open , content , title , key } = modal;
    return (
      <Page fullWidth={true} 
            // primaryAction={{ content:'Get messages', onAction:()=>{
            //     this.setState({filter_modal : true});
            //   }}}
      >
        <Stack vertical={true} spacing={"loose"} distribution={"fill"}>

          {
            // (rows.length === 0) &&
           <Stack alignment="center" distribution="fill">
            {/* <Banner title={'To fetch the messages sent by eBay, kindly click on the “Get Messages” button.'} status={"info"}/> */}
           
            {/* <Button primary>Get Messages</Button> */}
            </Stack>
        
          }
          { rows.length > 0 && 
          !loader.button_loader && 

          <Card title={<Subheading>Messages</Subheading>} actions={[{content:<Button primary>Get messages</Button>, onAction:()=>this.setState({filter_modal : true})
          
            }]}>
           
              <div style={{maxHeight:340, overflowY:'scroll'}}>
                <DataTable hoverable={this.state.noData===true?false:true}
                  columnContentTypes={[
                    'text',
                    'text',
                    'text',
                    'text',
                    'text',
                  ]}
                  headings={[
                    'Sender',
                    'Message ID',
                    'Recieved Date',
                    'Expiration Date',
                    'Actions',
                  ]}
                  rows={rows}
                  
                />
              </div>
            {this.state.noData===false?
            <Card.Section>
              <React.Fragment>
                <Stack vertical={false} alignment={"center"} distribution="center">
                  <Select options={pageSizeOption} label={''} onChange={(e) => {
                    pagination.perPage = e;
                    pagination.activePage = 1;
                    this.setState({pagination},()=>{
                      this.getMessages();
                    });
                  }} value={pagination.perPage}/>
                  <Pagination
                    label={`Showing ${rows.length} of ${rows.length} results`}
                    hasPrevious
                    onPrevious={() => {
                      this.handlePagination('prev');
                    }}
                    hasNext
                    onNext={() => {
                      this.handlePagination('next');
                    }}
                  />
                </Stack>
              </React.Fragment>
            </Card.Section>:null}
          </Card>
          }
          {loader.button_loader &&
          <Stack vertical={true} alignment={"center"}>
            <Spinner accessibilityLabel="Spinner example" size="large" color="teal"/>
          </Stack>
          }
        </Stack>
        {
          this.getModal({switch : open, title : title, content : content, handleModal : this.handleModal.bind(this), key: key })
        }
        {
          this.getFilterModal()
        }
       
         <Stack distribution="center"><FooterHelp>
         
    Learn more about{' '}
    <Link external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=ebay-messages-2">
    eBay Messages
    </Link>
   
  </FooterHelp></Stack>
 
      </Page>
    );
  }

  getModal(data) {
    return (
      <Modal
        open={data.switch}
        onClose={data.handleModal.bind(this,data.key)}
        title={data.title}
      >
        <Modal.Section>
          {
            data.content
          }
        </Modal.Section>
      </Modal>)
  }

  getFilterModal() {
    return (
      <Modal
        open={this.state.filter_modal}
        onClose={()=>{
          this.setState({filter_modal:false});
        }}
        title={'Get messages'}
      >
        <Modal.Section>
          {
            this.getContentFilter()
          }
        </Modal.Section>
      </Modal>)
  }

  handleModal(data){
    let { modal } = this.state;
    switch (data) {
      case 'message_modal':
        modal.open = false;
        break;
      default :
        break;
    }
    this.setState({modal:modal});
  }

}

export default Ebaymessages;
