import React, { Component } from 'react'
import {Page, Stack, Card, Layout, FormLayout, ProgressBar,Badge,Icon,Banner,Thumbnail, Tooltip,Tabs,Subheading, Collapsible,TextContainer,Button, DisplayText,Link} from "@shopify/polaris";
import {ViewMajorMonotone,ProfileMajor, ProfileMajorMonotone,StarFilledMinor,HintMajorMonotone,LegalMajorMonotone,ExchangeMajorMonotone,RefreshMajorMonotone,ChatMajorMonotone} from '@shopify/polaris-icons';
import ModalVideo from "react-modal-video";
import history from "../../shared/history";
import AppsShared from "../../shared/app/apps";
import {requests} from "../../services/request";
import {notify} from "../../services/notify";
import Skeleton from "../../shared/skeleton";
import InstallAppsShared from "../../shared/app/install-apps";
import Ebaymessages from '../eBayMessages/ebaymessages';
import {isUndefined} from "util";
import 'bootstrap/dist/css/bootstrap.css';
import './accounts.css'
import LoadingOverlay from 'react-loading-overlay';

export class AccountsPanel extends Component {
  video={Modal:false,id:''};
    handleTabChange=(e)=>{
        this.setState({selected:e})
      }
      constructor(props) {
          super(props)
      
          this.state = {
            text:'More Details...',
            open:false,
            selected:0,
            loader:false,
            refreshEbayUserDetails: false,
            modalOpen:false,
            customer_details_loaded:false,
            account_information : {
              username: {label:'Username',value:''},
              // email: data.data.email,
              // skype_id: {label:'Skype Id',value:''},
              full_name: {label:'Full Name',value:''},
              mobile: {label:'Mobile',value:''},
              // phone:{label:'Phone',value:''},
            },
            active_plan:{
              title:{label:'Plan',value:''},
              activated_at:{label:'Activated At',value:''},
              main_price:{label:'Price',value:''},
              validity:{label:'Validity',value:''},
            },
            ebay_user_details:{},
            credits_info:{
              order:{
                available:0,
                total:0,
                percent:0
              },
              products:{
                available:0,
                total:0,
                percent:0
              }
            }
          }
          this.getUserDetails();
          this.getActivePlan();
          this.handleLoader = this.handleLoader.bind(this);
      }
      redirect(url) {
        this.props.history.push(url);
      }
      userDetails_skeleton=true;
      planDetails_skeleton=true;
      credit_skeleton=true;
    
      openvideoModal(id) {
        this.video.Modal = true;
        this.video.id = id;
        this.setState(this.state);
      }
      handleLoader(loader1){
          this.setState({loader:loader1})
      }
      handleToggle(){
        this.setState({open:!this.state.open})
        this.state.text==='More Details...'?this.setState({text:'Less Details...'}):this.setState({text:'More Details...'})
      }
      closevideoModal() {
        this.video.Modal = false;
        this.video.id = '';
        this.setState(this.state);
      }
      importBusinessPolicies(){
        requests.getRequest('ebayV1/import/businessPolicies').then(data=>{
          if(data.success){
            notify.success(data.message);
          }
          else{
            notify.error(data.message);
          }
        });
      }
      importEbayShopdetails(){
        this.setState({refreshEbayUserDetails: true})
        requests.getRequest('ebayV1/import/userDetails').then(data=>{
          if(data.success){
            this.setState({refreshEbayUserDetails: false})
            notify.success(data.message);
            this.getEbayUser();
          }else{
            notify.info(data.message);
          }
        })
      }
    
      updateState(){
        let temp=Object.assign({},this.state);
        this.state=temp;
        this.setState(this.state);
      }
    
      componentDidMount(){
        this.getServiceCredits();
       this.getEbayUser();
      }
      getEbayUser(){
        requests.getRequest('ebayV1/get/userDetails').then(data=>{
          if(data.success){
            this.state.ebay_user_details = Object.assign({},data.data);
          }
          this.setState(this.state);
        })
      }
      getActivePlan(){
        requests.getRequest('plan/plan/getActive').then(data => {
          if (data.success) {
            this.state.active_plan = this.extract_plandetails(data.data);
            this.planDetails_skeleton=false;
            this.setState(this.state);
          } else {
            // notify.error(data.message);
          }
        });
    
      }
      activeplandetails(){
        let temparr=[];
    
        if(this.planDetails_skeleton){return <Skeleton case="skeleton_General_Configurations"/>}
        else{
          Object.keys(this.state.active_plan).map(key=>{
            temparr.push(
              <Stack alignment="baseline" distribution="fillEvenly">
              
                  <Subheading>{this.state.active_plan[key]['label']}</Subheading>
                 <p>{key==='validity'?this.state.active_plan[key]['value']+' days':this.state.active_plan[key]['value']}</p>
                    
                 </Stack>
              

           
            );
          });
    
          return temparr;}
      }
      extract_plandetails(plan_data){
        let temp=Object.assign({},this.state.active_plan);
        Object.keys(this.state.active_plan).map(key=>{
          temp[key]['value']=plan_data[key];
        });
        this.state.active_plan=Object.assign({},temp);
        this.updateState();
      }
      renderUserDetails(){
        console.log(this.state.account_information)
        let temparr=[];
        Object.keys(this.state.account_information).map(key=>
        {
         
          temparr.push(

            <div style={{paddingBottom:'10px'}}>
            
            <Stack alignment="baseline" distribution="fillEvenly">
            
            <Subheading key={"accounts "+key}>{this.state.account_information[key].label}
              </Subheading>
              
              <p >{this.state.account_information[key].value}</p>
          
            </Stack>
            </div>
          )
        });
    
        return temparr;
      }
      getServiceCredits() {
        requests.getRequest('frontend/app/getServiceCredits',{service_code:'ebay_uploader'},false,true)
          .then(response => {
            if (response.success) {
              requests.getRequest('frontend/app/getServiceCredits',{service_code:'ebay_order_sync'},false,true).then(ordercredits=>{
                if(ordercredits.success){
    
                  let orderObj={
                    available:ordercredits.data.available_credits,
                    total:ordercredits.data.available_credits + ordercredits.data.total_used_credits,
                    percent:((ordercredits.data.available_credits)/(ordercredits.data.available_credits + ordercredits.data.total_used_credits))*100
                  };
                  let productObj={
                    available:response.data.available_credits,
                    total:response.data.available_credits + response.data.total_used_credits,
                    percent:((response.data.available_credits)/(response.data.available_credits + response.data.total_used_credits))*100
                  };
                  this.state.credits_info.order=Object.assign({},orderObj);
                  this.state.credits_info.products=Object.assign({},productObj);
                  this.credit_skeleton=false;
                  this.setState(
                    this.state
                  );
                }
              })
    
    
            }
    
          });
      }
    
      getUserDetails() {
        requests.getRequest('user/getDetails', undefined, false, true)
          .then(data => {
            if (data.success) {
    
              this.state.account_information = {
                username: {label:'Username',value:data.data.username!==''?data.data.username:'Not Available'},
                // email: data.data.email,
                // skype_id: {label:'Skype Id',value:data.data.skype_id!==''?data.data.skype_id:'Not Available'},
                full_name: {label:'Full Name',value:data.data.full_name!==''?data.data.full_name:'Not Available'},
                mobile: {label:'Mobile',value:data.data.mobile!==''?data.data.mobile:'Not Available'},
                // phone:{label:'Phone',value:!isUndefined(data.data.phone) && data.data.phone!==''?data.data.phone:'Not Available'}
    
              };
              this.state.customer_details_loaded=true;
              this.userDetails_skeleton=false
              this.updateState();
            } else {
              notify.error(data.message);
            }
          });
      }
    render() {
      let { SellerInfo , Store } = this.state.ebay_user_details;
        const tabs = [
          {
            id: 'reconnect account',
            content: (
            
                <Stack spacing="extraTight">
                  <Icon
                source={ExchangeMajorMonotone}
                color="base" />
               <p>Reconnect Account</p>
                </Stack>
             
            ),

            accessibilityLabel: 'reconnect account',
            panelID: 'reconnect account',
          },
          {
            id: 'eBay messages',
            content: (
            
              <Stack spacing="extraTight">
                <Icon
              source={ChatMajorMonotone}
              color="base" />
             <p>eBay Messages</p>
              </Stack>
           
          ),
          
           
          },
            {
              id: 'account',
              content: (
              
                  <Stack spacing="extraTight">
                    <Icon
  source={ProfileMajorMonotone}
  color="base" />
                 <p>App Account Details</p>
  </Stack>
               
              ),

              accessibilityLabel: 'account',
              panelID: 'account',
             }
         
            // {
            //   id: 'active plan details',
            //   content:  (
              
            //     <Stack spacing="extraTight">
            //    <p> Active Plan Details</p><Icon
            //     source={HintMajorMonotone}
            //     color="base" />
            //     </Stack>
             
            // ),
            //   panelID: 'active plan details',
            // },
            // {
            //   id: 'eBay user details',
            //   content:  (
              
            //     <Stack spacing="extraTight">
            //       <Icon
            //     source={LegalMajorMonotone}
            //     color="base" />
            //    <p>eBay User Details</p>
            //     </Stack>
             
            // ),
            //   panelID: 'eBay user details',
            // },
          ];
          const options = [
            {label: 'United States', value: 'USA'}
          ];
        
        return (
            <>
             <Page fullWidth={true} title="Accounts"
            titleMetadata={
              <Stack vertical={false}><p style={{cursor:'pointer'}} onClick={()=>{
              window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=top-right-thumbnail','_blank')
            }}><Badge status={"info"}><b style={{color:'#0000aa', textDecoration:'underline'}}>Need help?</b></Badge></p>
                <p style={{color: '#3B7DC4', textDecoration: 'underline', cursor: 'pointer'}}
                   onClick={this.openvideoModal.bind(this, 'ZRChv29iC04')}><Badge status={"info"}><b
                  style={{color: '#0000aa', textDecoration: 'underline'}}>Help Video?</b></Badge></p>
              </Stack>}
            secondaryActions={[{content:'Billing History',icon:ViewMajorMonotone,onAction:this.redirect.bind(this,'/panel/plans/billing')}]}>


<ModalVideo channel='youtube' isOpen={this.video.Modal} videoId={this.video.id}  onClose={this.closevideoModal.bind(this)} />


  
   <LoadingOverlay  active={this.state.loader}
                    spinner
                    text='Loading please wait...'
                >
          <Stack alignment="fill" distribution="fill" spacing="tight">
          <Stack.Item>
          <Tabs tabs={tabs} selected={this.state.selected} onSelect={this.handleTabChange}>
            {this.state.selected===0?
 
             
           <>  
          <Card sectioned>
             <Layout>
             <Layout.Section oneThird>
 <AppsShared history={history} fromRegistration={false} noReconnect={true} redirectResult={this.redirectResult}/>
 <React.Fragment>
   {this.state.modalOpen ?
     <InstallAppsShared history={this.props.history} redirect={this.redirectResult} loader={this.state.loader} handleLoader={this.handleLoader}
                        code={this.state.code} site_id={this.state.site_id} mode={this.state.mode}/> : null}
 </React.Fragment>
 </Layout.Section>
               <Layout.Section>
            <Card actions={[{content:<Button loading={this.state.refreshEbayUserDetails} primary>Refresh Details</Button>, onAction:this.importEbayShopdetails.bind(this)
              // icon: <Tooltip active={false} content="Import User"><Icon source={RefreshMajorMonotone} /></Tooltip>
              }]} sectioned>
                
                
                  
                      <Stack vertical={true}>
                    <Stack alignment="baseline" distribution="fillEvenly">
                      
                      <Subheading>{"UserID"}</Subheading>
                     <p>   {!isUndefined(this.state.ebay_user_details['UserID'])?
                          this.state.ebay_user_details['UserID']:'Not available'
                        }
                     </p>
                     </Stack>
                     <Stack alignment="baseline" distribution="fillEvenly">
                    <Subheading>{"Email"}</Subheading>
                    <p>
                    {!isUndefined(this.state.ebay_user_details['Email'])?
                          this.state.ebay_user_details['Email']:'Not available'
                        }
                    </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                     <Subheading>{"User ID Last Changed"}</Subheading>
                     <p>   {!isUndefined(this.state.ebay_user_details['UserIDLastChanged'])?
                          this.state.ebay_user_details['UserIDLastChanged']:'Not available'
                        }
                      </p>
                      </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Registration Date'}</Subheading>
                    <p>  
                    {!isUndefined(this.state.ebay_user_details['RegistrationDate'])
                          ?
                          this.state.ebay_user_details['RegistrationDate']: 'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                       <Subheading>{'eBay site'}</Subheading>
                       <p>  
                          {!isUndefined(this.state.ebay_user_details['Site'])?
                           this.state.ebay_user_details['Site']:'Not available'
                         }
                          </p>
                       </Stack>
                       <Stack alignment="baseline" distribution="fillEvenly">
                       <Subheading>{'Store URL'}</Subheading>
                       <p>  
                       {!isUndefined(this.state.ebay_user_details['SellerInfo']) && !isUndefined(this.state.ebay_user_details['SellerInfo']['StoreURL'])?
                        <Link url={this.state.ebay_user_details['SellerInfo']['StoreURL']} external>Visit</Link>:'Not available'
                          // <a href={this.state.ebay_user_details['SellerInfo']['StoreURL']} target={"_blank"}>Visit</a>:'Not available'
                         }
                       </p>
                       </Stack>
                    
                       
                      
          <Collapsible
            open={this.state.open}
            id="basic-collapsible"
            transition={{duration: '500ms', timingFunction: 'ease-in-out'}}
            expandOnPrint
          >

            <TextContainer>
            {/* <Stack alignment="baseline" distribution="fillEvenly">
                    <Subheading>{'User Id last changed'}</Subheading>
                    <p> {
                          !isUndefined(this.state.ebay_user_details['UserIDLastChanged'])
                            ?
                            this.state.ebay_user_details['UserIDLastChanged']:'N/A'
                        }
                        </p>
                        </Stack> */}
                        <Stack vertical>
                        <Stack alignment="baseline" distribution="fillEvenly">
                      <Subheading>{"PayPal Account Type"}</Subheading>
                     <p>
                        {!isUndefined(this.state.ebay_user_details['PayPalAccountType'])?
                          this.state.ebay_user_details['PayPalAccountType']:'Not available'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                     <Subheading>{"Motors Dealer"}</Subheading>
                      <p>
                        {!isUndefined(this.state.ebay_user_details['MotorsDealer'])?
                          this.state.ebay_user_details['MotorsDealer']?"Yes":"No":'Not available'
                        }
                        </p>
                        </Stack>
                      
                        <Stack alignment="baseline" distribution="fillEvenly">
                    <Subheading>{"BusinessRole"}</Subheading>
                    <p> {!isUndefined(this.state.ebay_user_details['BusinessRole'])?
                          this.state.ebay_user_details['BusinessRole']:'Not available'
                        }</p>
                        </Stack>
                         <Stack alignment="baseline" distribution="fillEvenly">
                    <Subheading>{"Paypal Account level"}</Subheading>
                    <p>  {!isUndefined(this.state.ebay_user_details['PayPalAccountLevel'])?
                          this.state.ebay_user_details['PayPalAccountLevel']:'Not available'
                        }</p>
                        </Stack>
                          <Stack alignment="baseline" distribution="fillEvenly">
                     <Subheading>{"Paypal Account Status"}</Subheading>
                    <p>    {!isUndefined(this.state.ebay_user_details['PayPalAccountStatus'])?
                          this.state.ebay_user_details['PayPalAccountStatus']:'Not available'
                        }</p>
                      </Stack>
                     
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'VAT Status'}</Subheading>
                    <p> {
                         !isUndefined(this.state.ebay_user_details['VATStatus'])
                         ?
                         this.state.ebay_user_details['VATStatus']:'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Unique Negative Feedback Count'}</Subheading>
                    <p> {
                       !isUndefined(this.state.ebay_user_details['UniqueNegativeFeedbackCount'])
                       ?
                       this.state.ebay_user_details['UniqueNegativeFeedbackCount']:'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Unique Positive Feedback Count'}</Subheading>
                    <p> {
                     !isUndefined(this.state.ebay_user_details['UniquePositiveFeedbackCount'])
                     ?
                     this.state.ebay_user_details['UniquePositiveFeedbackCount']:'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Store Owner'}</Subheading>
                    <p>  {!isUndefined(SellerInfo) && !isUndefined(SellerInfo['StoreOwner'])
                        && SellerInfo['StoreOwner']
                          ?
                          'True':'False'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Seller Business Type'}</Subheading>
                    <p>  
                    {
                          !isUndefined(SellerInfo) && !isUndefined(SellerInfo['SellerBusinessType'])
                            ?
                            SellerInfo['SellerBusinessType']:'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Payment Method'}</Subheading>
                    <p>  
                    {
                          !isUndefined(SellerInfo) && !isUndefined(SellerInfo['PaymentMethod'])
                          ?
                          SellerInfo['PaymentMethod']:'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Status'}</Subheading>
                    <p>  
                    {
                       !isUndefined(this.state.ebay_user_details['Status'])
                       ?
                       this.state.ebay_user_details['Status']:'N/A'
                        }
                    </p>
                    </Stack>
                 
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Enterprise Seller'}</Subheading>
                    <p>  
                    {!isUndefined(this.state.ebay_user_details['EnterpriseSeller'])
                        && this.state.ebay_user_details['EnterpriseSeller']
                          ?
                          'True':'False'
                        }
                        </p>

                  </Stack>
                  <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Feedback Rating Star'}</Subheading>
                    <p>  
                    {!isUndefined(this.state.ebay_user_details['FeedbackRatingStar'])
                          ?
                          this.state.ebay_user_details['FeedbackRatingStar']: 'N/A'
                        }
                        </p>

                      </Stack>
                      <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'ID Verified'}</Subheading>
                    <p>  
                    {!isUndefined(this.state.ebay_user_details['IDVerified'])
                        && this.state.ebay_user_details['IDVerified']
                          ?
                          'True':'False'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'New User'}</Subheading>
                    <p>  
                    {!isUndefined(this.state.ebay_user_details['NewUser'])
                        && this.state.ebay_user_details['NewUser']
                          ?
                          'True':'False'
                        }
                        </p>
                    </Stack>
                    <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Positive Feedback Percent'}</Subheading>
                    <p>  
                    {!isUndefined(this.state.ebay_user_details['PositiveFeedbackPercent'])
                          ?
                          this.state.ebay_user_details['PositiveFeedbackPercent']: 'N/A'
                        }
                        </p>
                        </Stack>
                      
                       
                      {!isUndefined(this.state.ebay_user_details['Store']) &&
                         <Stack alignment="baseline" distribution="fillEvenly">
                         <Subheading>{'Store name'}</Subheading>
                     <p>  
                         
                     {!isUndefined(this.state.ebay_user_details['Store']['Name'])?
                          this.state.ebay_user_details['Store']['Name']:'Not available'
                        }
                       
                         </p>
                         </Stack>}
                     
                       
                    
                       <Stack alignment="baseline" distribution="fillEvenly">
                       <Subheading>{'Store Subscription Level'}</Subheading>
                       <p>  
                       {
                           !isUndefined(Store) && !isUndefined(Store['SubscriptionLevel'])
                             ?
                             Store['SubscriptionLevel']:'N/A'
                       }
                        </p>
                       </Stack>
              </Stack>
            </TextContainer>
            
          </Collapsible>
          
          <Button size={"slim"} plain
            onClick={this.handleToggle.bind(this)}
            ariaExpanded={this.state.open}
            ariaControls="basic-collapsible"
          >{this.state.text}
            </Button>
          
                      {/* <Stack alignment="baseline" distribution="fillEvenly">
                    <Subheading>{'User Id last changed'}</Subheading>
                    <p> {
                          !isUndefined(this.state.ebay_user_details['UserIDLastChanged'])
                            ?
                            this.state.ebay_user_details['UserIDLastChanged']:'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'VAT Status'}</Subheading>
                    <p> {
                         !isUndefined(this.state.ebay_user_details['VATStatus'])
                         ?
                         this.state.ebay_user_details['VATStatus']:'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Unique Negative Feedback Count'}</Subheading>
                    <p> {
                       !isUndefined(this.state.ebay_user_details['UniqueNegativeFeedbackCount'])
                       ?
                       this.state.ebay_user_details['UniqueNegativeFeedbackCount']:'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Unique Positive Feedback Count'}</Subheading>
                    <p> {
                     !isUndefined(this.state.ebay_user_details['UniquePositiveFeedbackCount'])
                     ?
                     this.state.ebay_user_details['UniquePositiveFeedbackCount']:'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Store Owner'}</Subheading>
                    <p>  {!isUndefined(SellerInfo) && !isUndefined(SellerInfo['StoreOwner'])
                        && SellerInfo['StoreOwner']
                          ?
                          'True':'False'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Seller Business Type'}</Subheading>
                    <p>  
                    {
                          !isUndefined(SellerInfo) && !isUndefined(SellerInfo['SellerBusinessType'])
                            ?
                            SellerInfo['SellerBusinessType']:'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Payment Method'}</Subheading>
                    <p>  
                    {
                          !isUndefined(SellerInfo) && !isUndefined(SellerInfo['PaymentMethod'])
                          ?
                          SellerInfo['PaymentMethod']:'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Status'}</Subheading>
                    <p>  
                    {
                       !isUndefined(this.state.ebay_user_details['Status'])
                       ?
                       this.state.ebay_user_details['Status']:'N/A'
                        }
                    </p>
                    </Stack>
                    <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Registration Date'}</Subheading>
                    <p>  
                    {!isUndefined(this.state.ebay_user_details['RegistrationDate'])
                          ?
                          this.state.ebay_user_details['RegistrationDate']: 'N/A'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Enterprise Seller'}</Subheading>
                    <p>  
                    {!isUndefined(this.state.ebay_user_details['EnterpriseSeller'])
                        && this.state.ebay_user_details['EnterpriseSeller']
                          ?
                          'True':'False'
                        }
                        </p>

                  </Stack>
                  <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Feedback Rating Star'}</Subheading>
                    <p>  
                    {!isUndefined(this.state.ebay_user_details['FeedbackRatingStar'])
                          ?
                          this.state.ebay_user_details['FeedbackRatingStar']: 'N/A'
                        }
                        </p>

                      </Stack>
                      <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'ID Verified'}</Subheading>
                    <p>  
                    {!isUndefined(this.state.ebay_user_details['IDVerified'])
                        && this.state.ebay_user_details['IDVerified']
                          ?
                          'True':'False'
                        }
                        </p>
                        </Stack>
                        <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'New User'}</Subheading>
                    <p>  
                    {!isUndefined(this.state.ebay_user_details['NewUser'])
                        && this.state.ebay_user_details['NewUser']
                          ?
                          'True':'False'
                        }
                        </p>
                    </Stack>
                    <Stack alignment="baseline" distribution="fillEvenly">
                        <Subheading>{'Positive Feedback Percent'}</Subheading>
                    <p>  
                    {!isUndefined(this.state.ebay_user_details['PositiveFeedbackPercent'])
                          ?
                          this.state.ebay_user_details['PositiveFeedbackPercent']: 'N/A'
                        }
                        </p>
                        </Stack>
                      
                       
                      {!isUndefined(this.state.ebay_user_details['Store']) &&
                         <Stack alignment="baseline" distribution="fillEvenly">
                         <Subheading>{'Store name'}</Subheading>
                     <p>  
                         
                     {!isUndefined(this.state.ebay_user_details['Store']['Name'])?
                          this.state.ebay_user_details['Store']['Name']:'Not available'
                        }
                       
                         </p>
                         </Stack>}
                       <Stack alignment="baseline" distribution="fillEvenly">
                       <Subheading>{'eBay site'}</Subheading>
                       <p>  
                          {!isUndefined(this.state.ebay_user_details['Site'])?
                           this.state.ebay_user_details['Site']:'Not available'
                         }
                          </p>
                       </Stack>
                       
                       <Stack alignment="baseline" distribution="fillEvenly">
                       <Subheading>{'Store URL'}</Subheading>
                       <p>  
                       {!isUndefined(this.state.ebay_user_details['SellerInfo']) && !isUndefined(this.state.ebay_user_details['SellerInfo']['StoreURL'])?
                           <a href={this.state.ebay_user_details['SellerInfo']['StoreURL']} target={"_blank"}>Visit</a>:'Not available'
                         }
                       </p>
                       </Stack>
                       <Stack alignment="baseline" distribution="fillEvenly">
                       <Subheading>{'Store Subscription Level'}</Subheading>
                       <p>  
                       {
                           !isUndefined(Store) && !isUndefined(Store['SubscriptionLevel'])
                             ?
                             Store['SubscriptionLevel']:'N/A'
                       }
                        </p>
                       </Stack>                 */}
                  </Stack>
                                   
                  </Card> 
                  </Layout.Section>

 </Layout>
</Card>
</>


          
                 :this.state.selected===1?
                 <Ebaymessages></Ebaymessages>:
                  <Card sectioned>
                    <Stack vertical>
                    <Card sectioned title={<DisplayText size={"small"}>User Details</DisplayText>}>
                      <Stack alignment="baseline" distribution="fillEvenly">
                       
                        <p> {(this.userDetails_skeleton)?<Skeleton case="profile_businesspolicy"/>:
                  this.state.customer_details_loaded && this.renderUserDetails()}</p>
                 
                      </Stack>
                     
                 </Card>
                  
                  
                     
                   <Card title={<DisplayText size={"small"}>Credits</DisplayText>}>
                    
             {(this.credit_skeleton)?<Skeleton case="credit"/>:
               <>
                <Stack alignment="fill" spacing="loose" distribution="fill">
               <Stack.Item>
                 <Card.Section title={"Products"}>
                   <Stack vertical={true} spacing={"tight"}>
                     <p>{this.state.credits_info.products.available} remaining of {this.state.credits_info.products.total}</p>
                     <ProgressBar progress={this.state.credits_info.products.percent} size="small" />
                   </Stack>
                 </Card.Section>
                 </Stack.Item>
                 <Stack.Item>
                 <Card.Section title={"Orders"}>
                   <Stack vertical={true} spacing={"tight"}>
                     <p>{this.state.credits_info.order.available} remaining of {this.state.credits_info.order.total}</p>
                     <ProgressBar progress={this.state.credits_info.order.percent} size="small" />
                   </Stack>
                 </Card.Section>
                 </Stack.Item>
                 </Stack>
               </>}
             
           </Card>
           
                  
             
              <h1>
                 <Card sectioned title={<DisplayText size={"small"}>Active Plan Details</DisplayText>}>
              
                <Stack vertical={true} alignment="fill">
                  {this.activeplandetails()}
                </Stack>
             
            </Card>
              </h1>
              </Stack>
              </Card>
            
            //   :
            //   this.state.selected===2?
            //   <Card actions={[{content: 'Refresh eBay User Details', onAction:this.importEbayShopdetails.bind(this), loading: this.state.refreshEbayUserDetails
            //   // icon: <Tooltip active={false} content="Import User"><Icon source={RefreshMajorMonotone} /></Tooltip>
            //   }]}>
                
                
            //         <Card sectioned>
            //           <Stack vertical={true}>
            //         <Stack alignment="baseline" distribution="fillEvenly">
                      
            //           <Subheading>{"UserID"}</Subheading>
            //          <p>   {!isUndefined(this.state.ebay_user_details['UserID'])?
            //               this.state.ebay_user_details['UserID']:'Not available'
            //             }
            //          </p>
            //          </Stack>
            //          <Stack alignment="baseline" distribution="fillEvenly">
            //          <Subheading>{"User ID Last Changed"}</Subheading>
            //          <p>   {!isUndefined(this.state.ebay_user_details['UserIDLastChanged'])?
            //               this.state.ebay_user_details['UserIDLastChanged']:'Not available'
            //             }
            //           </p>
            //           </Stack>
            //           <Stack alignment="baseline" distribution="fillEvenly">
            //           <Subheading>{"PayPal Account Type"}</Subheading>
            //          <p>
            //             {!isUndefined(this.state.ebay_user_details['PayPalAccountType'])?
            //               this.state.ebay_user_details['PayPalAccountType']:'Not available'
            //             }
            //             </p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //          <Subheading>{"Motors Dealer"}</Subheading>
            //           <p>
            //             {!isUndefined(this.state.ebay_user_details['MotorsDealer'])?
            //               this.state.ebay_user_details['MotorsDealer']?"Yes":"No":'Not available'
            //             }
            //             </p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //         <Subheading>{"Email"}</Subheading>
            //         <p>
            //         {!isUndefined(this.state.ebay_user_details['Email'])?
            //               this.state.ebay_user_details['Email']:'Not available'
            //             }
            //         </p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //         <Subheading>{"BusinessRole"}</Subheading>
            //         <p> {!isUndefined(this.state.ebay_user_details['BusinessRole'])?
            //               this.state.ebay_user_details['BusinessRole']:'Not available'
            //             }</p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //         <Subheading>{"Paypal Account level"}</Subheading>
            //         <p>  {!isUndefined(this.state.ebay_user_details['PayPalAccountLevel'])?
            //               this.state.ebay_user_details['PayPalAccountLevel']:'Not available'
            //             }</p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //          <Subheading>{"Paypal Account Status"}</Subheading>
            //         <p>    {!isUndefined(this.state.ebay_user_details['PayPalAccountStatus'])?
            //               this.state.ebay_user_details['PayPalAccountStatus']:'Not available'
            //             }</p>
            //           </Stack>
            //           <Stack alignment="baseline" distribution="fillEvenly">
            //         <Subheading>{'User Id last changed'}</Subheading>
            //         <p> {
            //               !isUndefined(this.state.ebay_user_details['UserIDLastChanged'])
            //                 ?
            //                 this.state.ebay_user_details['UserIDLastChanged']:'N/A'
            //             }
            //             </p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'VAT Status'}</Subheading>
            //         <p> {
            //              !isUndefined(this.state.ebay_user_details['VATStatus'])
            //              ?
            //              this.state.ebay_user_details['VATStatus']:'N/A'
            //             }
            //             </p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'Unique Negative Feedback Count'}</Subheading>
            //         <p> {
            //            !isUndefined(this.state.ebay_user_details['UniqueNegativeFeedbackCount'])
            //            ?
            //            this.state.ebay_user_details['UniqueNegativeFeedbackCount']:'N/A'
            //             }
            //             </p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'Unique Positive Feedback Count'}</Subheading>
            //         <p> {
            //          !isUndefined(this.state.ebay_user_details['UniquePositiveFeedbackCount'])
            //          ?
            //          this.state.ebay_user_details['UniquePositiveFeedbackCount']:'N/A'
            //             }
            //             </p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'Store Owner'}</Subheading>
            //         <p>  {!isUndefined(SellerInfo) && !isUndefined(SellerInfo['StoreOwner'])
            //             && SellerInfo['StoreOwner']
            //               ?
            //               'True':'False'
            //             }
            //             </p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'Seller Business Type'}</Subheading>
            //         <p>  
            //         {
            //               !isUndefined(SellerInfo) && !isUndefined(SellerInfo['SellerBusinessType'])
            //                 ?
            //                 SellerInfo['SellerBusinessType']:'N/A'
            //             }
            //             </p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'Payment Method'}</Subheading>
            //         <p>  
            //         {
            //               !isUndefined(SellerInfo) && !isUndefined(SellerInfo['PaymentMethod'])
            //               ?
            //               SellerInfo['PaymentMethod']:'N/A'
            //             }
            //             </p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'Status'}</Subheading>
            //         <p>  
            //         {
            //            !isUndefined(this.state.ebay_user_details['Status'])
            //            ?
            //            this.state.ebay_user_details['Status']:'N/A'
            //             }
            //         </p>
            //         </Stack>
            //         <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'Registration Date'}</Subheading>
            //         <p>  
            //         {!isUndefined(this.state.ebay_user_details['RegistrationDate'])
            //               ?
            //               this.state.ebay_user_details['RegistrationDate']: 'N/A'
            //             }
            //             </p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'Enterprise Seller'}</Subheading>
            //         <p>  
            //         {!isUndefined(this.state.ebay_user_details['EnterpriseSeller'])
            //             && this.state.ebay_user_details['EnterpriseSeller']
            //               ?
            //               'True':'False'
            //             }
            //             </p>

            //       </Stack>
            //       <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'Feedback Rating Star'}</Subheading>
            //         <p>  
            //         {!isUndefined(this.state.ebay_user_details['FeedbackRatingStar'])
            //               ?
            //               this.state.ebay_user_details['FeedbackRatingStar']: 'N/A'
            //             }
            //             </p>

            //           </Stack>
            //           <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'ID Verified'}</Subheading>
            //         <p>  
            //         {!isUndefined(this.state.ebay_user_details['IDVerified'])
            //             && this.state.ebay_user_details['IDVerified']
            //               ?
            //               'True':'False'
            //             }
            //             </p>
            //             </Stack>
            //             <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'New User'}</Subheading>
            //         <p>  
            //         {!isUndefined(this.state.ebay_user_details['NewUser'])
            //             && this.state.ebay_user_details['NewUser']
            //               ?
            //               'True':'False'
            //             }
            //             </p>
            //         </Stack>
            //         <Stack alignment="baseline" distribution="fillEvenly">
            //             <Subheading>{'Positive Feedback Percent'}</Subheading>
            //         <p>  
            //         {!isUndefined(this.state.ebay_user_details['PositiveFeedbackPercent'])
            //               ?
            //               this.state.ebay_user_details['PositiveFeedbackPercent']: 'N/A'
            //             }
            //             </p>
            //             </Stack>
                      
                       
            //           {!isUndefined(this.state.ebay_user_details['Store']) &&
            //              <Stack alignment="baseline" distribution="fillEvenly">
            //              <Subheading>{'Store name'}</Subheading>
            //          <p>  
                         
            //          {!isUndefined(this.state.ebay_user_details['Store']['Name'])?
            //               this.state.ebay_user_details['Store']['Name']:'Not available'
            //             }
                       
            //              </p>
            //              </Stack>}
            //            <Stack alignment="baseline" distribution="fillEvenly">
            //            <Subheading>{'eBay site'}</Subheading>
            //            <p>  
            //               {!isUndefined(this.state.ebay_user_details['Site'])?
            //                this.state.ebay_user_details['Site']:'Not available'
            //              }
            //               </p>
            //            </Stack>
                       
            //            <Stack alignment="baseline" distribution="fillEvenly">
            //            <Subheading>{'Store URL'}</Subheading>
            //            <p>  
            //            {!isUndefined(this.state.ebay_user_details['SellerInfo']) && !isUndefined(this.state.ebay_user_details['SellerInfo']['StoreURL'])?
            //                <a href={this.state.ebay_user_details['SellerInfo']['StoreURL']} target={"_blank"}>Visit</a>:'Not available'
            //              }
            //            </p>
            //            </Stack>
            //            <Stack alignment="baseline" distribution="fillEvenly">
            //            <Subheading>{'Store Subscription Level'}</Subheading>
            //            <p>  
            //            {
            //                !isUndefined(Store) && !isUndefined(Store['SubscriptionLevel'])
            //                  ?
            //                  Store['SubscriptionLevel']:'N/A'
            //            }
            //             </p>
            //            </Stack>                
            //       </Stack>
            //         </Card>                
            //       </Card>
            //  
            // :<h1>Error</h1>
                  }
                
            </Tabs>
          </Stack.Item>
          {/* <Stack.Item>
            <div style={{position:'relative',top:'50px'}}>
             
              
            <AppsShared history={history} fromRegistration={false} noReconnect={true} redirectResult={this.redirectResult}/>
            <React.Fragment>
              {this.state.modalOpen ?
                <InstallAppsShared history={this.props.history} redirect={this.redirectResult}
                                   code={this.state.code} site_id={this.state.site_id} mode={this.state.mode}/> : null}
            </React.Fragment>
           
         
            </div>
            </Stack.Item> */}
            </Stack>
           
           </LoadingOverlay>

            </Page>





            </>
        )
    }
  
    redirectResult = (status,siteID,mode) => {
      this.openNewWindow(status,siteID,mode);
    };
  
    openNewWindow = (action,siteID,mode) => {
      this.setState({modalOpen: !this.state.modalOpen, code: action, site_id:siteID,mode:mode});
    };
  
}

export default AccountsPanel