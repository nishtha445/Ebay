import React, {Component} from 'react';
import {Card} from "@shopify/polaris";
import {requests} from "../../services/request";
import {isUndefined} from "util";

class WelcomeScreen extends Component {

    constructor(props){
        super(props);
        this.checkStepCompleted = this.checkStepCompleted.bind(this);
        this.welcomeuser();
    }
    welcomeuser(){
        this.getAllImporterServices()

    }


    getAllImporterServices() {
        requests.getRequest('connector/get/services', { 'filters[type]': 'importer' })
            .then(data => {
                if (data.success === true) {
                    let temparr = [];
                    for (let i = 0; i < Object.keys(data.data).length; i++) {
                        let key = Object.keys(data.data)[i];
                        if (!isUndefined(key) && key === 'shopify_importer') {
                            temparr.push({
                                label: data.data[key].title,
                                value: data.data[key].marketplace,
                                shops: data.data[key].shops
                            });
                        }
                    }
                    localStorage.setItem('shop_url',!isUndefined(temparr[0].shops[0]) && !isUndefined(temparr[0].shops[0].shop_url)?temparr[0].shops[0].shop_url:"");
                }
                this.checkStepCompleted();
            });
    }

    checkStepCompleted() {
        let path = '/App/User/Step';
        requests.getRequest('frontend/app/getStepCompleted', {path: path}).then(data => {
            if (data.success) {
                if(data.data<parseInt(6)) {
                    setTimeout(() => {
                        this.redirect('/auth/registration');
                    }, 3000)
                }
                else{
                    setTimeout(() => {
                    this.redirect('/panel/dashboard');
                    }, 3000)
                }
            }else{
                this.redirect('/auth/');
            }
        });
    }
    redirect(url){

        this.props.history.push(url);
    }
    render() {
        return (
            <Card>
               <Card.Section>
                    <img src={require('../../assets/welcome_screen.jpg')}
                         style={{height: '100%', width: '100%'}}/>
               </Card.Section>
            </Card>
        );
    }
}

export default WelcomeScreen;
