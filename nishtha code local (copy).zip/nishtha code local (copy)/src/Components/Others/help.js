import React, {Component} from 'react';
import {Button, Card, Collapsible, Modal, Page, ResourceList, Stack, TextContainer,Icon,Heading} from "@shopify/polaris";
import {NavLink} from "react-router-dom";
import {isUndefined} from "util";
import * as queryString from "query-string";
import {
    PageDownMajorMonotone, ChevronDownMinor, ChevronRightMinor
} from '@shopify/polaris-icons';

class Help extends Component {
    constructor(props) {
        super(props);
        this.modalOpen = this.modalOpen.bind(this); // modal function
        this.state = {
            modal: false, // modal show/hide
            search: '',// search
            noSearchFound: [1],
            open:false,
            faq: [
                {
                    id:1,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'How to connect my eBay seller account with app?',
                    ans:
                        <React.Fragment>
                            <ol>
                                <li className="mb-2">You need to authenticate your seller account with our app at second step of registration,</li>
                                <li className="mb-2">If you need to reconnect with different details you can do so from the Accounts section of the app.</li>
                            </ol>
                        </React.Fragment>
                },
                {
                    id:2,
                    show: false,
                    search: true,
                    ques: 'How to import already selling products and sync with Shopify ?',
                    ans:
                        <ul>
                            <li className="mb-2">At Step 4 of registration you need to map eBay attributes with Shopify attributes and proceed.</li>
                            <li className="mb-2">This will automatically initiate Product Import and syncing process.</li>
                        </ul>
                },
                {
                    id:3,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'Will my products get duplicated if i already sell on eBay and use this App?',
                    ans: <ul>
                        <li className="mb-2">No, Our app handles duplicate listing issue.</li>

                    </ul>
                },

                {
                    id:4,
                    show: false, // for collapse div
                    search: true, // for search
                    ques: 'How to register for eBay seller account ?',
                    ans: <ul>
                        <li className="mb-2">Registration for an eBay seller account can be done using your email address,for more information kindly visit <a href={'https://www.eBay/help/account/signing-ebay-account/signing-ebay-account?id=4191'} target={'_blank'}>eBay help section</a>. </li>
                    </ul>
                },
                {
                    id: 5,
                    show: false,
                    search: true,
                    ques: 'What are the terms and conditions to apply for eBay seller account?',
                    ans: <p>Though there are no prescribed terms and conditions, it is recommended that you go through <a href={'https://pages.ebay.in/terms-and-conditions/'} target={'_blank'}>terms and conditions </a>, put forth by eBay. </p>

                },
                {
                    id:6,
                    show: false,
                    search: true,
                    ques: 'What is profiling and what is Default Profile?',
                    ans: <React.Fragment>
                        <p className="text-justify"><b>Profiling</b> is a feature using which you can upload products with particular specifications by making your own customised profile (for example- all products with price 10$) from App to eBay marketplace.</p>

                        <p className="text-justify">So whenever you want to upload bulk products you can simply make your customised profile with specifications of your choice and upload all products in one go.</p>

                        {/*<p>In default Profile We Have Some Fixed Format. For Example Click <a href="javascript:void(0)" onClick={this.modalOpen}>Here</a></p>*/}
                    </React.Fragment>
                },
                {
                    id: 7,
                    show: false,
                    search: true,
                    ques: 'What do templates in the app stand for? Are they required?',
                    ans:
                        <React.Fragment>
                            <ul>
                                <li className="mb-2">A listing template contains information that is required to create a product listing: title, description, images, and other information that you indicate on eBay’s Sell Your Item form. Multiple listing templates for each product can be assigned, which allows you to list products in multiple ways.</li>
                                <li className="mb-2">Only <b>category template</b> is a required template.</li>
                            </ul>
                        </React.Fragment>
                },
                {
                    id: 8,
                    show: false,
                    search: true,
                    ques: 'How to create a template?',
                    ans: <React.Fragment>
                        <p className='mb-2'>You can create template by following steps </p>
                        <ol>
                            <li className='mb-2'>
                                Visit <a style={{color:'blue'}}><b>Templates</b></a> section of the app .
                            </li>
                            <li className='mb-2'>Select a template type you want to create.</li>
                            <li className='mb-2'>Click on create new.</li>
                        </ol>
                    </React.Fragment>
                },
                {
                    id: 9,
                    show: false,
                    search: true,
                    ques: 'What is the difference between Personal eBay account and Business eBay account?',
                    ans: <React.Fragment>
                        <ul>
                            <li>
                                Personal eBay accounts can be created if, someone wants to sell casually. For example, if a seller wants to end a particular stock of products, he can create <b>Personal eBay account</b>.
                            </li>
                            <li>
                                If you are selling or planning to sell large quantites then you need to register for a <b>Business eBay account</b>.
                            </li>
                        </ul>
                        <p>For more information regarding the same you can refer to <a href={'https://www.eBay/help/account/signing-ebay-account/signing-ebay-account?id=4191'} target={'_blank'}>eBay help documentation.</a></p>
                    </React.Fragment>
                },
                {
                    id: 10,
                    show: false,
                    search: true,
                    ques: 'What is Business policy?',
                    ans: <React.Fragment>

                        <p className={'mb-2'}>For creating a listing you`ll need to choose a set of business policies of buyers ie.   </p>
                        <ul>
                            <li className={'mb-2'}>Payment policy</li>
                            <li className={'mb-2'}>Shipping policy</li>
                            <li className={'mb-2'}>Return policy</li>
                        </ul>

                        <p>but you can streamline the process by creating business policies templates which can be used to define these set of policies on each listing without re-defining them again-again</p>
                    </React.Fragment>
                },
                {
                    id: 11,
                    show: false,
                    search: true,
                    ques: 'Is order management section based on profiling, templating and business policy?',
                    ans:
                        <React.Fragment>
                            <p>
                                <b>No</b>, If you are only on our app for order management then there is no need to create business policies and templates , Your orders will be managed using default settings.
                            </p>
                        </React.Fragment>
                },
                {
                    id: 12,
                    show: false,
                    search: true,
                    ques: 'Does the app support for eBay Motors site?',
                    ans: <React.Fragment>
                        <p><b>Yes</b>, Our app does support eBay Motors site</p>
                    </React.Fragment>
                },
                {
                    id: 13,
                    show: false,
                    search: true,
                    ques: 'What is the difference between Auction and Fixed price item?',
                    ans: <React.Fragment>
                        <ol>
                            <li>
                                <p><b>Auction price item : </b> Buyers can purchase your item immediately or place a bid.</p>
                            </li>
                            <li>
                                <p><b>Fixed price item : </b> Buyers can purchase your item immediately at the price you set, but cannot bid on your item.</p>
                            </li>
                        </ol>
                    </React.Fragment>
                },
                {
                    id: 14,
                    show: false,
                    search: true,
                    ques: 'Does the app support secondary category setting ?',
                    ans: <React.Fragment>
                        <p>
                            <b>Yes,</b> app does support secondary category, you can set the same during creation of category template by selecting <b>Enable secondary category.</b>
                        </p>
                    </React.Fragment>
                },
                {
                    id: 15,
                    show: false,
                    search: true,
                    ques: 'Does the app support international shipping and global shipping program ?',
                    ans: <React.Fragment>
                        <p>
                            <b>Yes,</b> app supports global shipping program and international shipping ,given global shipping is enabled from eBay seller panel.
                        </p>
                    </React.Fragment>
                },
                {
                    id: 16,
                    show: false,
                    search: true,
                    ques: 'Does the app support for all eBay Countries ?',
                    ans: <React.Fragment>
                        <p>
                            <b>Yes,</b> our app does support all eBay countries.
                        </p>
                    </React.Fragment>
                },

                {
                    id: 17,
                    show: false,
                    search: true,
                    ques: 'Can we manage multiple eBay stores from one app ?',
                    ans: <React.Fragment>
                        <p>
                            <b>No,</b> as of now multiple eBay stores can`t be managed from the app.
                        </p>
                    </React.Fragment>
                },


            ]
        };
        this.getQueryparams();
    }
    getQueryparams(){
        if(!isUndefined(this.props.location.search)) {
            const queryParams = queryString.parse(this.props.location.search);
            if ('faq' in queryParams) {
                this.state.search = queryParams['faq'];
                this.setState(this.state);
                this.handleSearch();
            }
        }
    }
    handleSearch() {
        try {
            let value = this.state.faq;
            let flag = 0;
            if ( this.state.search.length >= 2 ) {
                value.forEach(data => {
                    const text = data.ques.toLowerCase();
                    if ( text.search(this.state.search) === -1 ) {
                        data.search = false;
                    } else {
                        data.search = true;
                        flag = 1;
                    }
                });
            } else {
                value.forEach(data => {
                    data.search = true;
                    flag = 1;
                });
            }
            if (flag === 0) {
                this.setState({noSearchFound: []});
            } else {
                this.setState({noSearchFound: [1]});
            }
            this.setState({faq: value});
        } catch (e) {
            console.log(e);
        }
    }
    render() {
        return (
            <Page title="Help"  fullWidth={true}
                  secondaryActions={[{content:'Help documentation',icon:PageDownMajorMonotone,onAction:()=>{
                          window.open('https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=bsns-policies', '_blank');
                      }}]}
            >


                <Card>

                    <ResourceList
                        resourceName={{singular: 'Question', plural: 'Questions'}}
                        items={this.state.noSearchFound}
                        renderItem={item => {}}
                        filterControl={
                            <ResourceList.FilterControl

                                searchValue={this.state.search}
                                onSearchChange={(searchValue) => {
                                    this.setState({search : searchValue.toLowerCase()});
                                    this.handleSearch();
                                }}
                            />
                        }
                    />

                </Card>

                {this.state.faq.map(data => {
                    return (
                        data.search?
                            <div style={{marginTop:'1rem',marginBottom:'1rem'}}>
                                <React.Fragment key={data.id} >
                                    <div style={{cursor:'pointer'}} onClick={this.handleToggleClick.bind(this, data)} ariaExpanded={this.state.open}>
                                        <Card>
                                            <Card.Section>
                                                <Stack distribution={"equalSpacing"}>
                                                    <b>{data.ques}</b>
                                                    <Button plain icon={data.show?ChevronDownMinor:ChevronRightMinor}/>
                                                </Stack>
                                            </Card.Section>
                                            <Collapsible open={data.show} id={data.id}>
                                                <Card>
                                                    <Card.Section>
                                                        <Heading>Answer:</Heading>
                                                        <h5 className="pl-3"><br/>{data.ans}</h5>
                                                    </Card.Section>
                                                </Card>
                                            </Collapsible>
                                        </Card>
                                    </div>
                                </React.Fragment>
                            </div>
                            :'')}
                )}

                <Modal
                    open={this.state.modal}
                    title="Default Profile Example"
                    onClose={this.modalOpen}
                >
                    <Modal.Section>
                        <TextContainer>
                            <h2>eBay Attribute Mapping Are Something Like this: </h2>
                            <h4>
                                <ul>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'title'</p><Icon source={"arrowLeft"}/><Icon source={"horizontalDots"}/><Icon source={"arrowRight"}/><p>'title</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'description'</p><Icon source={"arrowLeft"}/><Icon source={"horizontalDots"}/><Icon source={"arrowRight"}/><p>'long_description'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'price'</p><Icon source={"arrowLeft"}/><Icon source={"horizontalDots"}/><Icon source={"arrowRight"}/><p>'price'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'link'</p><Icon source={"arrowLeft"}/><Icon source={"horizontalDots"}/><Icon source={"arrowRight"}/><p>'Your Product Link'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'brand'</p><Icon source={"arrowLeft"}/><Icon source={"horizontalDots"}/><Icon source={"arrowRight"}/><p>'vendor'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'image_link'</p><Icon source={"arrowLeft"}/><Icon source={"horizontalDots"}/><Icon source={"arrowRight"}/><p>'main_image'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'main_image'</p><Icon source={"arrowLeft"}/><Icon source={"horizontalDots"}/><Icon source={"arrowRight"}/><p>'container_id'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'gtin'</p><Icon source={"arrowLeft"}/><Icon source={"horizontalDots"}/><Icon source={"arrowRight"}/><p>'bar_code'</p></Stack></li>
                                    <li><Stack vertical={false} spacing={"extraTight"}><p>'mpn'</p><Icon source={"arrowLeft"}/><Icon source={"horizontalDots"}/><Icon source={"arrowRight"}/><p>'sku'</p></Stack></li>
                                </ul>
                            </h4>
                        </TextContainer>
                    </Modal.Section>
                </Modal>
            </Page>
        );
    }
    handleToggleClick = (event) => {
        let data = this.state.faq;
        data.forEach(key => {
            if ( key.id === event.id ) {
                key.show = !key.show;
            }
        });
        this.setState({
            faq : data,
        });
    };
    modalOpen() {
        this.setState({
            modal: !this.state.modal
        });
    }
    redirect(url) {
        this.props.history.push(url);
    }
}

export default Help;
