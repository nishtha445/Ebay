import React, {Component} from 'react';
import * as queryString  from 'query-string';
import "./message.css"
// import {
//     faCheck,faTimes
// } from '@fortawesome/free-solid-svg-icons';
// import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {globalState} from "../../services/globalstate";
import { isUndefined } from 'util';
import Checked from "../../assets/checked.png";
import Times from "../../assets/img/times.png";

class MessageShow extends Component {
    constructor(props) {
        super(props);
        this.state = {
            message: '',
            title: '',
            success: '',
            shop:null,
        };
        globalState.removeLocalStorage('shop');
    }
    componentWillMount() {
       const queryParams = queryString.parse(this.props.location.search);
       if(queryParams.message!=null && queryParams.success!=null) {
           if (queryParams.success === undefined || queryParams.success === 'false') {
               queryParams.success = 'BG-danger';
           } else {
               queryParams.success = 'BG-success';
           }
           this.setState({
               message: queryParams.message,
               title: queryParams.title,
               success: queryParams.success,
               shop:isUndefined(queryParams.shop)?null:queryParams.shop
           });
           localStorage.setItem('taskStatus',JSON.stringify({
               message: queryParams.message,
               title: queryParams.title,
               success: queryParams.success === 'BG-success',
               shop: isUndefined(queryParams.shop)?null:queryParams.shop,
               isPlan: !isUndefined(queryParams.isPlan),
               isConnected: !isUndefined(queryParams.isConnected)
           }));
           setTimeout(() => {

               this.redirect('/auth/welcome');
               // if ( !isUndefined(queryParams.shop) ) {
               //     globalState.setLocalStorage('shop',queryParams.shop);
               //     // globalState.setLocalStorage('plan_status',JSON.stringify(queryParams));
               //     window.location.href = 'https://' + queryParams.shop + '/admin/apps/ebay-integration';
               // }
           },3000)
       }
       else
       {
           this.redirect('/auth');
       }
    }
    redirect(url) {
        this.props.history.push(url);
    }
    render() {
        return (
                <div className="row text-center m-5 pt-5 h-100">
                    <div className="offset-md-3 offset-sm-1 col-md-6 col-sm-10 col-12 mt-5">
                        <div className="CARD w-100 bg-transparent">
                            <div className={`CARD-title-small common2 text-center ${this.state.success}`}>
                                {this.state.success ==='BG-success'?
                                    <img src={Checked} style={{height:'5rem',width:'5rem'}} />
                                    : <img src={Times} style={{height:'5rem',width:'5rem'}} />
                                }
                            </div>
                            <div className="CARD-body col-12 p-5 mt-5 pl-5 w-100" style={{height:360}}>
                                <h3 style={{fontFamily:'Serif'}}>{this.state.message}</h3>
                                {this.state.success ==='BG-success'?<div className="row">
                                    <div className="col-12">
                                        <img src={require('../../assets/img/success.gif')} className="w-100" height="300"/>
                                    </div>
                                </div>:<div className="row">
                                    <div className="col-12 col-sm-8 offset-0 offset-sm-2">
                                        <img src={require('../../assets/img/fail.gif')} className="w-100" height="300"/>
                                    </div>
                                </div>}
                                {/*{this.state.shop !== null?<div><h5 style={{fontFamily:'Serif',color:'#b9b9b9'}}>Redirecting...</h5></div>:null}*/}
                            </div>
                        </div>
                    </div>
                </div>
        );
    }
}

export default MessageShow;
