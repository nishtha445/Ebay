import MessageShow from './message';
import {
    Route,
    Switch,
    Redirect
} from 'react-router-dom';

import React, {Component} from 'react';
import PrivatePolicy from "./private_policy";
import Progress from "./progress";
import Help from "./help";

class OthersRoutes extends Component {
    render() {
        return (
            <Switch>
                <Route exact path="/show/" render={() => (
                    <Redirect to="/show/progress"/>
                )}/>
                <Route exact path="/show/message" component={MessageShow} />
                <Route exact path="/show/policy" component={PrivatePolicy} />
                <Route exact path="/show/faq" component={Help} />
                <Route exact path="/show/progress" component={Progress} />
                <Route exact path="**" render={() => (
                    <Redirect to="/show/progress"/>
                )}/>
            </Switch>
        );
    }
}

export default OthersRoutes;
