import React, {Component} from 'react';

class Progress extends Component {
    constructor(props) {
        super(props);
        console.log(props.location.state)
    }
    render() {
        return (
            <div>
                <h1>404! Not Found</h1>
            </div>
        );
    }
}

export default Progress;