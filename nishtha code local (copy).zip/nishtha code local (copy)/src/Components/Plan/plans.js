import React, {Component} from 'react';
import {Page, Stack, Heading, DisplayText, FormLayout, Badge, Modal, Banner,FooterHelp,Link} from "@shopify/polaris";
import PlanBody from "../../shared/plans/plan-body";
import {notify} from "../../services/notify";
import * as queryString from "query-string";
import DiscountImg from '../../assets/import-sync.jpg';

class Plans extends Component {
    constructor(props){
        super(props);
        this.state = {
            modal : {
                open : false,
                title : '',
                type : ''
            }
        }
        this.paymentStatus=this.paymentStatus.bind(this);
    }

    modalHandler( open, type, title){
        let { modal } = this.state;
        modal.open = open;
        modal.type = open ? type: '';
        modal.title = open ? title:'';
        this.setState({ modal });
    }

    componentDidMount() {
        const queryParams = queryString.parse(this.props.location.search);
        let { exp } = queryParams;
        if(exp){
            this.modalHandler(true, 'plan_expire', 'Plan expired')
        }
    }

    getModalStructure(type) {
        let adjustedWidthDiscountImage = '100%';
        if(window.innerWidth >= 768 ) {
            adjustedWidthDiscountImage = '70%';
        }
        switch (type) {
            case 'plan_expire':
                return <Modal.Section>
                    <Stack vertical={true} alignment="center">
                        <Banner title={<Stack vertical alignment="center" spacing="extraTight"><p>Your plan has expired, Please upgrade to a paid plan for proceeding further</p>
                            <p>If you want to avail this offer feel free to <Badge status={"attention"}><span  style={{color: 'darkblue', textDecoration:'underline', cursor:'pointer'}} onClick={(e) => {
                                    this.redirect('/panel/help/report')
                                    e.preventDefault();
                                }}>contact us</span></Badge></p>
                        </Stack>} />
                        
                        <center><img src={DiscountImg} width={adjustedWidthDiscountImage} /></center>
                    </Stack>
                </Modal.Section>
            default: return [];
        }
    }

    render() {
        let { modal } = this.state;
        let modalStructure = this.getModalStructure(modal.type);
        return (
            <Page fullWidth={true} title={""} /*primaryAction={{content:'Active Plan'}}*/>
                <Stack vertical={true} alignment={"center"} >
                    <Stack.Item>
                        <div style={{textAlign:'center'}}>
                        <p style={{fontSize:"3.6rem",fontWeight:'bold'}}>
                            Choose the best plan
                        </p>
                        <p style={{fontSize:"1.5rem",marginTop:'2rem'}}>
                            If you already have an existing plan you can upgrade or downgrade your plan
                        </p>
                            <p style={{fontSize:"1.5rem",marginTop:'1rem'}}>
                                <Badge status={"attention"}><p style={{fontWeight:'bold', fontSize:'1.5rem'}}>If you want a custom plan feel free to <span style={{color: 'darkblue', textDecoration:'underline', cursor:'pointer'}} onClick={(e) => {
                                    this.redirect('/panel/help/report')
                                    e.preventDefault();
                                }}>contact us</span></p></Badge>
                            </p>
                        </div>
                    </Stack.Item>
                    <Stack.Item>
                        <FormLayout.Group condensed>
                            <PlanBody paymentStatus={this.paymentStatus} plantype={"Bronze"} showFreePlan={false} />
                            <PlanBody paymentStatus={this.paymentStatus} plantype={"Silver"} showFreePlan={false} />
                            <PlanBody paymentStatus={this.paymentStatus} plantype={"Gold"} showFreePlan={false} />
                            <PlanBody paymentStatus={this.paymentStatus} plantype={"Platinum"} showFreePlan={false} />
                        </FormLayout.Group>
                    </Stack.Item>
                    {/*<Stack.Item>
                        <PlanBody plantype={"Monthly"} paymentStatus={this.paymentStatus} showFreePlan={false}/>
                    </Stack.Item>*/}

                </Stack>
                <Modal large={true} open={modal.open} title={modal.title} onClose={this.modalHandler.bind(this, false, '', '')}>
                    {
                        modalStructure
                    }
                </Modal>
                <FooterHelp>
    Learn more about{' '}
    <Link external url="https://docs.cedcommerce.com/shopify/ebay-marketplace-integration/?section=choose-a-plan-3">
    Choose a Plan
    </Link>
  </FooterHelp>
            </Page>
        );
    }


    paymentStatus(event) {
        if (event === 'Confirmation') {
            notify.success('Your plan is activated');
            // this.setState({modalOpen: !this.state.modalOpen});
        } else {
            // notify.info(event);
        }
    }
    redirect(url) {
        this.props.history.push(url);
    }
}

export default Plans;
